import Symconf113.ResidualFinal113
import Symconf113.NoRuler113

/-! `113_11` with no hypotheses: the Buratti–Stinson case `(113,11)` is now the
Lean theorem `Ruler113.noModularGolombRuler113` (cover search, kernel shards). -/
namespace Symconf113

/-- No 113-by-113 incidence of a symmetric configuration `113_11` exists. -/
theorem no_incidence113 : ¬ ∃ A : Int113, Incidence113 A :=
  no_unrestricted_incidence113 Ruler113.noModularGolombRuler113

end Symconf113

#print axioms Symconf113.Ruler113.noModularGolombRuler113
#print axioms Symconf113.no_incidence113

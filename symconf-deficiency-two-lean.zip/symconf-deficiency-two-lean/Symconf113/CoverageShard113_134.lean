import Symconf113.CoverageShard113_133

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5340 : NodeCoverage113 [15,15,12] 12 71 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5341 : NodeCoverage113 [15,15,11] 11 72 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5342 : NodeCoverage113 [15,15,10] 10 73 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5343 : NodeCoverage113 [15,15,9] 9 74 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5344 : NodeCoverage113 [15,15,8] 8 75 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5345 : NodeCoverage113 [15,15,7] 7 76 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5346 : NodeCoverage113 [15,15,6] 6 77 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5347 : NodeCoverage113 [15,15,5] 5 78 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5348 : NodeCoverage113 [15,15,3] 3 80 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5349 : NodeCoverage113 [15,15] 15 83 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5337
    (ChildrenCoverage113.cons _ _ compact113_node_5338
    (ChildrenCoverage113.cons _ _ compact113_node_5339
    (ChildrenCoverage113.cons _ _ compact113_node_5340
    (ChildrenCoverage113.cons _ _ compact113_node_5341
    (ChildrenCoverage113.cons _ _ compact113_node_5342
    (ChildrenCoverage113.cons _ _ compact113_node_5343
    (ChildrenCoverage113.cons _ _ compact113_node_5344
    (ChildrenCoverage113.cons _ _ compact113_node_5345
    (ChildrenCoverage113.cons _ _ compact113_node_5346
    (ChildrenCoverage113.cons _ _ compact113_node_5347
    (ChildrenCoverage113.cons _ _ compact113_node_5348
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_5350 : NodeCoverage113 [15,14] 14 84 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5351 : NodeCoverage113 [15,13] 13 85 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5352 : NodeCoverage113 [15,12] 12 86 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5353 : NodeCoverage113 [15,11] 11 87 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5354 : NodeCoverage113 [15,10] 10 88 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5355 : NodeCoverage113 [15,9] 9 89 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5356 : NodeCoverage113 [15,8] 8 90 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

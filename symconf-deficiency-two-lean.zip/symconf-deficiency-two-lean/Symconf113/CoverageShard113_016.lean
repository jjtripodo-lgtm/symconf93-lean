import Symconf113.CoverageShard113_014
import Symconf113.CoverageShard113_015

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0691 : NodeCoverage113 [49,3] 3 61 :=
  demand_node_prune113 49 compact113_demands_049 compact113_demands_049_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0692 : NodeCoverage113 [49] 49 64 :=
  node_fork113 (B := [49,48,47,46,45,44,43,42,41,40,39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0646
    (ChildrenCoverage113.cons _ _ compact113_node_0647
    (ChildrenCoverage113.cons _ _ compact113_node_0648
    (ChildrenCoverage113.cons _ _ compact113_node_0649
    (ChildrenCoverage113.cons _ _ compact113_node_0650
    (ChildrenCoverage113.cons _ _ compact113_node_0651
    (ChildrenCoverage113.cons _ _ compact113_node_0652
    (ChildrenCoverage113.cons _ _ compact113_node_0653
    (ChildrenCoverage113.cons _ _ compact113_node_0654
    (ChildrenCoverage113.cons _ _ compact113_node_0655
    (ChildrenCoverage113.cons _ _ compact113_node_0656
    (ChildrenCoverage113.cons _ _ compact113_node_0657
    (ChildrenCoverage113.cons _ _ compact113_node_0658
    (ChildrenCoverage113.cons _ _ compact113_node_0659
    (ChildrenCoverage113.cons _ _ compact113_node_0660
    (ChildrenCoverage113.cons _ _ compact113_node_0661
    (ChildrenCoverage113.cons _ _ compact113_node_0662
    (ChildrenCoverage113.cons _ _ compact113_node_0663
    (ChildrenCoverage113.cons _ _ compact113_node_0664
    (ChildrenCoverage113.cons _ _ compact113_node_0665
    (ChildrenCoverage113.cons _ _ compact113_node_0666
    (ChildrenCoverage113.cons _ _ compact113_node_0667
    (ChildrenCoverage113.cons _ _ compact113_node_0668
    (ChildrenCoverage113.cons _ _ compact113_node_0669
    (ChildrenCoverage113.cons _ _ compact113_node_0670
    (ChildrenCoverage113.cons _ _ compact113_node_0671
    (ChildrenCoverage113.cons _ _ compact113_node_0672
    (ChildrenCoverage113.cons _ _ compact113_node_0673
    (ChildrenCoverage113.cons _ _ compact113_node_0674
    (ChildrenCoverage113.cons _ _ compact113_node_0675
    (ChildrenCoverage113.cons _ _ compact113_node_0676
    (ChildrenCoverage113.cons _ _ compact113_node_0677
    (ChildrenCoverage113.cons _ _ compact113_node_0678
    (ChildrenCoverage113.cons _ _ compact113_node_0679
    (ChildrenCoverage113.cons _ _ compact113_node_0680
    (ChildrenCoverage113.cons _ _ compact113_node_0681
    (ChildrenCoverage113.cons _ _ compact113_node_0682
    (ChildrenCoverage113.cons _ _ compact113_node_0683
    (ChildrenCoverage113.cons _ _ compact113_node_0684
    (ChildrenCoverage113.cons _ _ compact113_node_0685
    (ChildrenCoverage113.cons _ _ compact113_node_0686
    (ChildrenCoverage113.cons _ _ compact113_node_0687
    (ChildrenCoverage113.cons _ _ compact113_node_0688
    (ChildrenCoverage113.cons _ _ compact113_node_0689
    (ChildrenCoverage113.cons _ _ compact113_node_0690
    (ChildrenCoverage113.cons _ _ compact113_node_0691
    ChildrenCoverage113.nil))))))))))))))))))))))))))))))))))))))))))))))

theorem compact113_node_0693 : NodeCoverage113 [48,48,17] 17 0 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0694 : NodeCoverage113 [48,48,14] 14 3 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0695 : NodeCoverage113 [48,48,13] 13 4 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0696 : NodeCoverage113 [48,48,12] 12 5 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0697 : NodeCoverage113 [48,48,11] 11 6 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0698 : NodeCoverage113 [48,48,10] 10 7 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0699 : NodeCoverage113 [48,48,9] 9 8 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0700 : NodeCoverage113 [48,48,8] 8 9 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0701 : NodeCoverage113 [48,48,7] 7 10 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0702 : NodeCoverage113 [48,48,6] 6 11 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0703 : NodeCoverage113 [48,48,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0704 : NodeCoverage113 [48,48,3] 3 14 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0705 : NodeCoverage113 [48,48] 48 17 :=
  node_fork113 (B := [17,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0693
    (ChildrenCoverage113.cons _ _ compact113_node_0694
    (ChildrenCoverage113.cons _ _ compact113_node_0695
    (ChildrenCoverage113.cons _ _ compact113_node_0696
    (ChildrenCoverage113.cons _ _ compact113_node_0697
    (ChildrenCoverage113.cons _ _ compact113_node_0698
    (ChildrenCoverage113.cons _ _ compact113_node_0699
    (ChildrenCoverage113.cons _ _ compact113_node_0700
    (ChildrenCoverage113.cons _ _ compact113_node_0701
    (ChildrenCoverage113.cons _ _ compact113_node_0702
    (ChildrenCoverage113.cons _ _ compact113_node_0703
    (ChildrenCoverage113.cons _ _ compact113_node_0704
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_0706 : NodeCoverage113 [48,47] 47 18 :=
  demand_node_prune113 47 compact113_demands_047 compact113_demands_047_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0707 : NodeCoverage113 [48,46] 46 19 :=
  demand_node_prune113 46 compact113_demands_046 compact113_demands_046_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0708 : NodeCoverage113 [48,45] 45 20 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0709 : NodeCoverage113 [48,44] 44 21 :=
  demand_node_prune113 44 compact113_demands_044 compact113_demands_044_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0710 : NodeCoverage113 [48,43] 43 22 :=
  demand_node_prune113 43 compact113_demands_043 compact113_demands_043_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0711 : NodeCoverage113 [48,42] 42 23 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0712 : NodeCoverage113 [48,41] 41 24 :=
  demand_node_prune113 41 compact113_demands_041 compact113_demands_041_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0713 : NodeCoverage113 [48,40] 40 25 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0714 : NodeCoverage113 [48,39] 39 26 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0715 : NodeCoverage113 [48,38] 38 27 :=
  demand_node_prune113 38 compact113_demands_038 compact113_demands_038_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0716 : NodeCoverage113 [48,37] 37 28 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0717 : NodeCoverage113 [48,36] 36 29 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0718 : NodeCoverage113 [48,35] 35 30 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0719 : NodeCoverage113 [48,34] 34 31 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0720 : NodeCoverage113 [48,33] 33 32 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0721 : NodeCoverage113 [48,32] 32 33 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0722 : NodeCoverage113 [48,31] 31 34 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0723 : NodeCoverage113 [48,30] 30 35 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0724 : NodeCoverage113 [48,29] 29 36 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0725 : NodeCoverage113 [48,28] 28 37 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0726 : NodeCoverage113 [48,27] 27 38 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0727 : NodeCoverage113 [48,26] 26 39 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0728 : NodeCoverage113 [48,25] 25 40 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0729 : NodeCoverage113 [48,24] 24 41 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0730 : NodeCoverage113 [48,23] 23 42 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0731 : NodeCoverage113 [48,22] 22 43 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

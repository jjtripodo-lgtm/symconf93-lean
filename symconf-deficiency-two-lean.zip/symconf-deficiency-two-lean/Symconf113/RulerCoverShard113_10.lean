import Symconf113.RulerCoverDefs113

namespace Symconf113.Ruler113

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem coverShard113_10 : (List.range' 101 12).any (opt2At 4 (go 6) [5,2,0] m1a)=false := by
  decide +kernel

end Symconf113.Ruler113

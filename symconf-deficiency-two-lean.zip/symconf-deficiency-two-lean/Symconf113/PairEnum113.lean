import Mathlib.Data.List.Perm.Subperm
import Mathlib.Data.List.Sort
import Mathlib.Tactic

/-! A finite, kernel-checkable enumerator for the column patterns that two
rows of an incidence can jointly see. A column is recorded by its length
`b` and the two rows' block degrees `(u1,v1)`, `(u2,v2)`. Only the
completeness of the enumerator is proved here: every list of options that
pays the given row totals is found up to permutation. -/
namespace Symconf113

structure PairOpt where
  b : ℕ
  u1 : ℕ
  v1 : ℕ
  u2 : ℕ
  v2 : ℕ
  deriving DecidableEq, Repr

namespace PairOpt
def c1 (o : PairOpt) : ℕ := o.u1*o.v1
def c2 (o : PairOpt) : ℕ := o.u2*o.v2
def x (o : PairOpt) : ℕ := o.b*o.v1*o.v2
end PairOpt

/-- Stage order: options read by row 1 first, by decreasing `v1`; then the
options seen only by row 2, by decreasing `v2`. -/
def PairOrder (o p : PairOpt) : Prop :=
  (0<o.u1 ∧ 0<p.u1 ∧ p.v1≤o.v1) ∨ (0<o.u1 ∧ p.u1=0) ∨ (o.u1=0 ∧ p.u1=0 ∧ p.v2≤o.v2)

instance (o p : PairOpt) : Decidable (PairOrder o p) := by
  unfold PairOrder; infer_instance

def PairOpt.OK (o : PairOpt) : Prop :=
  (0<o.u1 ∨ 0<o.u2) ∧ (0<o.u1 → 0<o.v1) ∧ (0<o.u2 → 0<o.v2)

instance (o : PairOpt) : Decidable o.OK := by
  unfold PairOpt.OK; infer_instance

def pairPrune (o : PairOpt) (s1 q1 s2 q2 : ℕ) : Bool :=
  if 0<o.u1 then decide (s1≤q1 ∧ q1≤s1*o.v1)
  else decide (s1=0 ∧ q1=0 ∧ s2≤q2 ∧ q2≤s2*o.v2)

def capDiv (cap n d : ℕ) : ℕ := if d=0 then cap else n/d

def pairBound (o : PairOpt) (s1 q1 s2 q2 x : ℕ) (cnt : ℕ → ℕ) : ℕ :=
  let k := cnt o.b
  min k (min (capDiv k s1 o.u1) (min (capDiv k q1 o.c1)
    (min (capDiv k s2 o.u2) (min (capDiv k q2 o.c2) (capDiv k x o.x)))))

def dropCount (cnt : ℕ → ℕ) (b m : ℕ) : ℕ → ℕ := fun y => if y=b then cnt y-m else cnt y

def pairEnum : List PairOpt → ℕ → ℕ → ℕ → ℕ → ℕ → (ℕ → ℕ) → List (List PairOpt)
  | O,s1,q1,s2,q2,x,cnt =>
    if s1=0 ∧ q1=0 ∧ s2=0 ∧ q2=0 then [[]]
    else
      match O with
      | [] => []
      | o::T =>
        if pairPrune o s1 q1 s2 q2 then
          (List.range (pairBound o s1 q1 s2 q2 x cnt+1)).flatMap (fun m =>
            (pairEnum T (s1-m*o.u1) (q1-m*o.c1) (s2-m*o.u2) (q2-m*o.c2) (x-m*o.x)
              (dropCount cnt o.b m)).map (fun D => List.replicate m o ++ D))
        else []

private theorem capDiv_ge {cap n d m : ℕ} (hc : m≤cap) (h : m*d≤n) : m≤capDiv cap n d := by
  unfold capDiv
  split_ifs with hd
  · exact hc
  · exact (Nat.le_div_iff_mul_le (Nat.pos_of_ne_zero hd)).mpr h

private theorem sum_split (L M N : List PairOpt) (o : PairOpt) (m : ℕ)
    (hp : (M++N).Perm L) (hm : M=List.replicate m o) (f : PairOpt → ℕ) :
    (L.map f).sum=m*f o+(N.map f).sum := by
  rw [←(hp.map f).sum_eq]
  simp [hm,List.sum_replicate]

private theorem sum_le_mul (L : List PairOpt) (f g : PairOpt → ℕ) (c : ℕ)
    (h : ∀ z∈L, f z≤g z*c) : (L.map f).sum≤(L.map g).sum*c := by
  induction L with
  | nil => simp
  | cons a L ih =>
    simp only [List.map_cons,List.sum_cons,Nat.add_mul]
    exact Nat.add_le_add (h a (by simp)) (ih (fun z hz => h z (List.mem_cons_of_mem _ hz)))

private theorem sum_le_sum' (L : List PairOpt) (f g : PairOpt → ℕ)
    (h : ∀ z∈L, f z≤g z) : (L.map f).sum≤(L.map g).sum := by
  simpa using sum_le_mul L f g 1 (by simpa using h)

private theorem sum_eq_zero' (L : List PairOpt) (f : PairOpt → ℕ)
    (h : ∀ z∈L, f z=0) : (L.map f).sum=0 := by
  induction L with
  | nil => simp
  | cons a L ih =>
    simp [h a (by simp), ih (fun z hz => h z (List.mem_cons_of_mem _ hz))]

/-- Every option list paying the exact row totals, at most the cross and
column-count budgets, is located by the enumerator up to permutation. -/
theorem pairEnum_complete (O L : List PairOpt) (s1 q1 s2 q2 x : ℕ) (cnt : ℕ → ℕ)
    (hsort : O.Pairwise PairOrder) (hok : ∀ o∈O, o.OK) (hL : ∀ o∈L, o∈O)
    (hs1 : (L.map PairOpt.u1).sum=s1) (hq1 : (L.map PairOpt.c1).sum=q1)
    (hs2 : (L.map PairOpt.u2).sum=s2) (hq2 : (L.map PairOpt.c2).sum=q2)
    (hx : (L.map PairOpt.x).sum≤x)
    (hc : ∀ y, (L.filter (fun o => o.b=y)).length≤cnt y) :
    ∃ D∈pairEnum O s1 q1 s2 q2 x cnt, D.Perm L := by
  induction O generalizing L s1 q1 s2 q2 x cnt with
  | nil =>
    cases L with
    | nil =>
      simp at hs1 hq1 hs2 hq2
      subst s1 q1 s2 q2
      exact ⟨[],by simp [pairEnum]⟩
    | cons z L => simpa using hL z (by simp)
  | cons o O ih =>
    by_cases hLe : L=[]
    · subst L
      simp at hs1 hq1 hs2 hq2
      subst s1 q1 s2 q2
      exact ⟨[],by simp [pairEnum]⟩
    · obtain ⟨z,hzL⟩ := List.exists_mem_of_ne_nil L hLe
      have hz := hok z (hL z hzL)
      have hne : ¬(s1=0 ∧ q1=0 ∧ s2=0 ∧ q2=0) := by
        rintro ⟨h1,-,h2,-⟩
        have a1 := List.le_sum_of_mem (List.mem_map_of_mem (f:=PairOpt.u1) hzL)
        have a2 := List.le_sum_of_mem (List.mem_map_of_mem (f:=PairOpt.u2) hzL)
        rcases hz.1 with h|h <;> omega
      have hafter (w : PairOpt) (hw : w∈L) : w=o ∨ PairOrder o w := by
        rcases List.mem_cons.mp (hL w hw) with h|h
        · exact Or.inl h
        · exact Or.inr ((List.pairwise_cons.mp hsort).1 w h)
      have hokw (w : PairOpt) (hw : w∈L) : w.OK := hok w (hL w hw)
      have hprune : pairPrune o s1 q1 s2 q2=true := by
        unfold pairPrune
        split_ifs with ho
        · apply decide_eq_true
          constructor
          · rw [←hs1,←hq1]
            apply sum_le_sum'
            intro w hw
            unfold PairOpt.c1
            by_cases hu : w.u1=0
            · simp [hu]
            · have := (hokw w hw).2.1 (Nat.pos_of_ne_zero hu)
              exact Nat.le_mul_of_pos_right _ this
          · rw [←hs1,←hq1]
            apply sum_le_mul
            intro w hw
            unfold PairOpt.c1
            by_cases hu : w.u1=0
            · simp [hu]
            · apply Nat.mul_le_mul_left
              rcases hafter w hw with rfl|h
              · exact le_rfl
              · rcases h with ⟨-,-,h⟩|⟨-,h⟩|⟨h,-⟩
                · exact h
                · exact absurd h hu
                · omega
        · have hzero (w : PairOpt) (hw : w∈L) : w.u1=0 := by
            rcases hafter w hw with rfl|h
            · omega
            · rcases h with ⟨h,-⟩|⟨h,-⟩|⟨-,h,-⟩ <;> omega
          apply decide_eq_true
          refine ⟨?_,?_,?_,?_⟩
          · rw [←hs1]; exact sum_eq_zero' _ _ hzero
          · rw [←hq1]; exact sum_eq_zero' _ _ (fun w hw => by simp [PairOpt.c1,hzero w hw])
          · rw [←hs2,←hq2]
            apply sum_le_sum'
            intro w hw
            unfold PairOpt.c2
            by_cases hu : w.u2=0
            · simp [hu]
            · exact Nat.le_mul_of_pos_right _ ((hokw w hw).2.2 (Nat.pos_of_ne_zero hu))
          · rw [←hs2,←hq2]
            apply sum_le_mul
            intro w hw
            unfold PairOpt.c2
            by_cases hu : w.u2=0
            · simp [hu]
            · apply Nat.mul_le_mul_left
              rcases hafter w hw with rfl|h
              · exact le_rfl
              · rcases h with ⟨h,-⟩|⟨h,-⟩|⟨-,-,h⟩
                · omega
                · omega
                · exact h
      let p : PairOpt → Bool := fun w => decide (w=o)
      let M := L.filter p
      let N := L.filter (fun w => !p w)
      let m := M.length
      have hpL : (M++N).Perm L := List.filter_append_perm p L
      have hm : M=List.replicate m o := by
        apply List.eq_replicate_of_mem
        intro w hw
        exact decide_eq_true_eq.mp (List.mem_filter.mp hw).2
      have hN (w : PairOpt) (hw : w∈N) : w∈O := by
        obtain ⟨h1,h2⟩ := List.mem_filter.mp hw
        have h3 : w≠o := by simpa [p] using h2
        exact (List.mem_cons.mp (hL w h1)).resolve_left h3
      have e1 := sum_split L M N o m hpL hm PairOpt.u1
      have e2 := sum_split L M N o m hpL hm PairOpt.c1
      have e3 := sum_split L M N o m hpL hm PairOpt.u2
      have e4 := sum_split L M N o m hpL hm PairOpt.c2
      have e5 := sum_split L M N o m hpL hm PairOpt.x
      -- the count of `o` itself is bounded by the column budget
      have hmc : m≤cnt o.b := by
        refine le_trans ?_ (hc o.b)
        have hsub : List.Sublist M (L.filter (fun w => w.b=o.b)) :=
          List.monotone_filter_right L (fun w hw => by
            simp only [p,decide_eq_true_eq] at hw
            simp [hw])
        exact hsub.length_le
      have hbound : m≤pairBound o s1 q1 s2 q2 x cnt := by
        unfold pairBound
        simp only [Nat.le_min]
        refine ⟨hmc,capDiv_ge hmc (by omega),capDiv_ge hmc (by omega),capDiv_ge hmc (by omega),
          capDiv_ge hmc (by omega),capDiv_ge hmc (by omega)⟩
      have hcN (y : ℕ) : (N.filter (fun w => w.b=y)).length≤dropCount cnt o.b m y := by
        have hsplit : (L.filter (fun w => w.b=y)).length =
            (M.filter (fun w => w.b=y)).length+(N.filter (fun w => w.b=y)).length := by
          rw [←(hpL.filter _).length_eq,List.filter_append,List.length_append]
        unfold dropCount
        split_ifs with hy
        · have hM : (M.filter (fun w => w.b=y)).length=m := by
            rw [hm]
            simp [List.filter_replicate,hy]
          have := hc y
          omega
        · have := hc y
          omega
      obtain ⟨D,hD,hDP⟩ := ih N
        (s1-m*o.u1) (q1-m*o.c1) (s2-m*o.u2) (q2-m*o.c2) (x-m*o.x) (dropCount cnt o.b m)
        (hsort.of_cons) (fun w hw => hok w (List.mem_cons_of_mem _ hw)) hN (by omega) (by omega) (by omega) (by omega) (by omega) hcN
      refine ⟨List.replicate m o++D,?_,?_⟩
      · rw [pairEnum,if_neg hne]
        simp only [hprune,if_true]
        exact List.mem_flatMap.mpr ⟨m,List.mem_range.mpr (by omega),List.mem_map.mpr ⟨D,hD,rfl⟩⟩
      · rw [←hm]
        exact (hDP.append_left M).trans hpL

end Symconf113

#print axioms Symconf113.pairEnum_complete

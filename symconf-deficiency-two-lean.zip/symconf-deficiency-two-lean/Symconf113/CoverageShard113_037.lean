import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1480 : NodeCoverage113 [36,36,18,18] 18 5 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1481 : NodeCoverage113 [36,36,18,17] 17 6 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1482 : NodeCoverage113 [36,36,18,16] 16 7 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1483 : NodeCoverage113 [36,36,18,15] 15 8 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1484 : NodeCoverage113 [36,36,18,14] 14 9 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1485 : NodeCoverage113 [36,36,18,13] 13 10 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1486 : NodeCoverage113 [36,36,18,12] 12 11 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1487 : NodeCoverage113 [36,36,18,11] 11 12 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1488 : NodeCoverage113 [36,36,18,10] 10 13 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1489 : NodeCoverage113 [36,36,18,9,9,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1490 : NodeCoverage113 [36,36,18,9,9] 9 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1489
    ChildrenCoverage113.nil)

theorem compact113_node_1491 : NodeCoverage113 [36,36,18,9,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1492 : NodeCoverage113 [36,36,18,9,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1493 : NodeCoverage113 [36,36,18,9,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1494 : NodeCoverage113 [36,36,18,9,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1495 : NodeCoverage113 [36,36,18,9,3] 3 11 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1496 : NodeCoverage113 [36,36,18,9] 9 14 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1490
    (ChildrenCoverage113.cons _ _ compact113_node_1491
    (ChildrenCoverage113.cons _ _ compact113_node_1492
    (ChildrenCoverage113.cons _ _ compact113_node_1493
    (ChildrenCoverage113.cons _ _ compact113_node_1494
    (ChildrenCoverage113.cons _ _ compact113_node_1495
    ChildrenCoverage113.nil))))))

theorem compact113_node_1497 : NodeCoverage113 [36,36,18,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1498 : NodeCoverage113 [36,36,18,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1499 : NodeCoverage113 [36,36,18,6] 6 17 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1500 : NodeCoverage113 [36,36,18,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1501 : NodeCoverage113 [36,36,18,3] 3 20 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1502 : NodeCoverage113 [36,36,18] 18 23 :=
  node_fork113 (B := [18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1480
    (ChildrenCoverage113.cons _ _ compact113_node_1481
    (ChildrenCoverage113.cons _ _ compact113_node_1482
    (ChildrenCoverage113.cons _ _ compact113_node_1483
    (ChildrenCoverage113.cons _ _ compact113_node_1484
    (ChildrenCoverage113.cons _ _ compact113_node_1485
    (ChildrenCoverage113.cons _ _ compact113_node_1486
    (ChildrenCoverage113.cons _ _ compact113_node_1487
    (ChildrenCoverage113.cons _ _ compact113_node_1488
    (ChildrenCoverage113.cons _ _ compact113_node_1496
    (ChildrenCoverage113.cons _ _ compact113_node_1497
    (ChildrenCoverage113.cons _ _ compact113_node_1498
    (ChildrenCoverage113.cons _ _ compact113_node_1499
    (ChildrenCoverage113.cons _ _ compact113_node_1500
    (ChildrenCoverage113.cons _ _ compact113_node_1501
    ChildrenCoverage113.nil)))))))))))))))

theorem compact113_node_1503 : NodeCoverage113 [36,36,17] 17 24 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1504 : NodeCoverage113 [36,36,16] 16 25 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1505 : NodeCoverage113 [36,36,15] 15 26 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1506 : NodeCoverage113 [36,36,14] 14 27 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1507 : NodeCoverage113 [36,36,13] 13 28 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1508 : NodeCoverage113 [36,36,12,12,12] 12 5 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1509 : NodeCoverage113 [36,36,12,12,11] 11 6 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1510 : NodeCoverage113 [36,36,12,12,10] 10 7 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1511 : NodeCoverage113 [36,36,12,12,9,8] 8 0 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1512 : NodeCoverage113 [36,36,12,12,9,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1513 : NodeCoverage113 [36,36,12,12,9,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_1514 : NodeCoverage113 [36,36,12,12,9] 9 8 :=
  node_fork113 (B := [8,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1511
    (ChildrenCoverage113.cons _ _ compact113_node_1512
    (ChildrenCoverage113.cons _ _ compact113_node_1513
    ChildrenCoverage113.nil)))

theorem compact113_node_1515 : NodeCoverage113 [36,36,12,12,8] 8 9 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1516 : NodeCoverage113 [36,36,12,12,7] 7 10 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1517 : NodeCoverage113 [36,36,12,12,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1518 : NodeCoverage113 [36,36,12,12,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1517
    ChildrenCoverage113.nil)

theorem compact113_node_1519 : NodeCoverage113 [36,36,12,12,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1520 : NodeCoverage113 [36,36,12,12,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_1521 : NodeCoverage113 [36,36,12,12,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1520
    ChildrenCoverage113.nil)

theorem compact113_node_1522 : NodeCoverage113 [36,36,12,12,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1518
    (ChildrenCoverage113.cons _ _ compact113_node_1519
    (ChildrenCoverage113.cons _ _ compact113_node_1521
    ChildrenCoverage113.nil)))

theorem compact113_node_1523 : NodeCoverage113 [36,36,12,12,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1524 : NodeCoverage113 [36,36,12,12,3] 3 14 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1525 : NodeCoverage113 [36,36,12,12] 12 17 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1508
    (ChildrenCoverage113.cons _ _ compact113_node_1509
    (ChildrenCoverage113.cons _ _ compact113_node_1510
    (ChildrenCoverage113.cons _ _ compact113_node_1514
    (ChildrenCoverage113.cons _ _ compact113_node_1515
    (ChildrenCoverage113.cons _ _ compact113_node_1516
    (ChildrenCoverage113.cons _ _ compact113_node_1522
    (ChildrenCoverage113.cons _ _ compact113_node_1523
    (ChildrenCoverage113.cons _ _ compact113_node_1524
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_1526 : NodeCoverage113 [36,36,12,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1527 : NodeCoverage113 [36,36,12,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1528 : NodeCoverage113 [36,36,12,9,9,8] 8 3 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1529 : NodeCoverage113 [36,36,12,9,9,7] 7 4 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1530 : NodeCoverage113 [36,36,12,9,9,6] 6 5 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1531 : NodeCoverage113 [36,36,12,9,9,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1532 : NodeCoverage113 [36,36,12,9,9,3] 3 8 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

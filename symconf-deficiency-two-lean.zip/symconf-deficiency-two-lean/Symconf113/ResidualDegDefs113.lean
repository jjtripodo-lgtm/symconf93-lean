import Symconf113.ResidualLeaves113

/-! The degree search split at its first level (the type-`A` row), so the
kernel checks run in four smaller pieces. -/
namespace Symconf113

/-- The degree search below a fixed type-`A` row `a`. -/
def degTop (a : ℕ × List ℕ) : Bool :=
  dfs degCompat leafIn 6 [a] (degLists.tail.map fun l => l.filter (degCompat a))

def degTopList : List (ℕ × List ℕ) := candA.map ((0,·))

theorem degree_unfold : dfs degCompat leafIn 7 [] degLists=degTopList.all degTop := rfl

end Symconf113

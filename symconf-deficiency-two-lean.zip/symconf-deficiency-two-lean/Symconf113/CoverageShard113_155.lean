import Symconf113.CoverageShard113_154

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_6681 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,10,9] 9 4 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6682 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,10,8] 8 5 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6683 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,10,7] 7 6 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6684 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,10,6] 6 7 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6685 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,10,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6686 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,10,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6685
    ChildrenCoverage113.nil)

theorem compact113_node_6687 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,10,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6688 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,10,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6686
    (ChildrenCoverage113.cons _ _ compact113_node_6687
    ChildrenCoverage113.nil))

theorem compact113_node_6689 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,10,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6690 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,10] 10 13 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6680
    (ChildrenCoverage113.cons _ _ compact113_node_6681
    (ChildrenCoverage113.cons _ _ compact113_node_6682
    (ChildrenCoverage113.cons _ _ compact113_node_6683
    (ChildrenCoverage113.cons _ _ compact113_node_6684
    (ChildrenCoverage113.cons _ _ compact113_node_6688
    (ChildrenCoverage113.cons _ _ compact113_node_6689
    ChildrenCoverage113.nil)))))))

theorem compact113_node_6691 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6692 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6693 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6694 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6695 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,5,5,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6696 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6695
    ChildrenCoverage113.nil)

theorem compact113_node_6697 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,5,5,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6698 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6696
    (ChildrenCoverage113.cons _ _ compact113_node_6697
    ChildrenCoverage113.nil))

theorem compact113_node_6699 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,5,5,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6700 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6698
    (ChildrenCoverage113.cons _ _ compact113_node_6699
    ChildrenCoverage113.nil))

theorem compact113_node_6701 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,5,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6702 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6700
    (ChildrenCoverage113.cons _ _ compact113_node_6701
    ChildrenCoverage113.nil))

theorem compact113_node_6703 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6704 : NodeCoverage113 [10,10,10,10,10,10,10,10,10] 10 23 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6690
    (ChildrenCoverage113.cons _ _ compact113_node_6691
    (ChildrenCoverage113.cons _ _ compact113_node_6692
    (ChildrenCoverage113.cons _ _ compact113_node_6693
    (ChildrenCoverage113.cons _ _ compact113_node_6694
    (ChildrenCoverage113.cons _ _ compact113_node_6702
    (ChildrenCoverage113.cons _ _ compact113_node_6703
    ChildrenCoverage113.nil)))))))

theorem compact113_node_6705 : NodeCoverage113 [10,10,10,10,10,10,10,10,9] 9 24 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6706 : NodeCoverage113 [10,10,10,10,10,10,10,10,8] 8 25 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6707 : NodeCoverage113 [10,10,10,10,10,10,10,10,7] 7 26 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6708 : NodeCoverage113 [10,10,10,10,10,10,10,10,6] 6 27 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6709 : NodeCoverage113 [10,10,10,10,10,10,10,10,5,5,5,5,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6710 : NodeCoverage113 [10,10,10,10,10,10,10,10,5,5,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6709
    ChildrenCoverage113.nil)

theorem compact113_node_6711 : NodeCoverage113 [10,10,10,10,10,10,10,10,5,5,5,5,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6712 : NodeCoverage113 [10,10,10,10,10,10,10,10,5,5,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6710
    (ChildrenCoverage113.cons _ _ compact113_node_6711
    ChildrenCoverage113.nil))

theorem compact113_node_6713 : NodeCoverage113 [10,10,10,10,10,10,10,10,5,5,5,5,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6714 : NodeCoverage113 [10,10,10,10,10,10,10,10,5,5,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6712
    (ChildrenCoverage113.cons _ _ compact113_node_6713
    ChildrenCoverage113.nil))

theorem compact113_node_6715 : NodeCoverage113 [10,10,10,10,10,10,10,10,5,5,5,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6716 : NodeCoverage113 [10,10,10,10,10,10,10,10,5,5,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6714
    (ChildrenCoverage113.cons _ _ compact113_node_6715
    ChildrenCoverage113.nil))

theorem compact113_node_6717 : NodeCoverage113 [10,10,10,10,10,10,10,10,5,5,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6718 : NodeCoverage113 [10,10,10,10,10,10,10,10,5,5] 5 23 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6716
    (ChildrenCoverage113.cons _ _ compact113_node_6717
    ChildrenCoverage113.nil))

theorem compact113_node_6719 : NodeCoverage113 [10,10,10,10,10,10,10,10,5,3] 3 25 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6720 : NodeCoverage113 [10,10,10,10,10,10,10,10,5] 5 28 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6718
    (ChildrenCoverage113.cons _ _ compact113_node_6719
    ChildrenCoverage113.nil))

theorem compact113_node_6721 : NodeCoverage113 [10,10,10,10,10,10,10,10,3] 3 30 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6722 : NodeCoverage113 [10,10,10,10,10,10,10,10] 10 33 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6704
    (ChildrenCoverage113.cons _ _ compact113_node_6705
    (ChildrenCoverage113.cons _ _ compact113_node_6706
    (ChildrenCoverage113.cons _ _ compact113_node_6707
    (ChildrenCoverage113.cons _ _ compact113_node_6708
    (ChildrenCoverage113.cons _ _ compact113_node_6720
    (ChildrenCoverage113.cons _ _ compact113_node_6721
    ChildrenCoverage113.nil)))))))

theorem compact113_node_6723 : NodeCoverage113 [10,10,10,10,10,10,10,9] 9 34 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6724 : NodeCoverage113 [10,10,10,10,10,10,10,8] 8 35 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6725 : NodeCoverage113 [10,10,10,10,10,10,10,7] 7 36 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6726 : NodeCoverage113 [10,10,10,10,10,10,10,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6727 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,5,5,5,5,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6728 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,5,5,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6727
    ChildrenCoverage113.nil)

theorem compact113_node_6729 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,5,5,5,5,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6730 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,5,5,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6728
    (ChildrenCoverage113.cons _ _ compact113_node_6729
    ChildrenCoverage113.nil))

theorem compact113_node_6731 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,5,5,5,5,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6732 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,5,5,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6730
    (ChildrenCoverage113.cons _ _ compact113_node_6731
    ChildrenCoverage113.nil))

theorem compact113_node_6733 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,5,5,5,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6734 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,5,5,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6732
    (ChildrenCoverage113.cons _ _ compact113_node_6733
    ChildrenCoverage113.nil))

theorem compact113_node_6735 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,5,5,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6736 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,5,5] 5 23 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6734
    (ChildrenCoverage113.cons _ _ compact113_node_6735
    ChildrenCoverage113.nil))

theorem compact113_node_6737 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,5,3] 3 25 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6738 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,5] 5 28 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6736
    (ChildrenCoverage113.cons _ _ compact113_node_6737
    ChildrenCoverage113.nil))

theorem compact113_node_6739 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,3,3,3,3,3,3,3,3,3,3,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_6740 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,3,3,3,3,3,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6739
    ChildrenCoverage113.nil)

theorem compact113_node_6741 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,3,3,3,3,3,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6740
    ChildrenCoverage113.nil)

theorem compact113_node_6742 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,3,3,3,3,3,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6741
    ChildrenCoverage113.nil)

theorem compact113_node_6743 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,3,3,3,3,3,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6742
    ChildrenCoverage113.nil)

theorem compact113_node_6744 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,3,3,3,3,3,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6743
    ChildrenCoverage113.nil)

theorem compact113_node_6745 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,3,3,3,3,3] 3 18 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6744
    ChildrenCoverage113.nil)

theorem compact113_node_6746 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,3,3,3,3] 3 21 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6745
    ChildrenCoverage113.nil)

theorem compact113_node_6747 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,3,3,3] 3 24 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6746
    ChildrenCoverage113.nil)

theorem compact113_node_6748 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,3,3] 3 27 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6747
    ChildrenCoverage113.nil)

theorem compact113_node_6749 : NodeCoverage113 [10,10,10,10,10,10,10,5,5,3] 3 30 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6748
    ChildrenCoverage113.nil)

theorem compact113_node_6750 : NodeCoverage113 [10,10,10,10,10,10,10,5,5] 5 33 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6738
    (ChildrenCoverage113.cons _ _ compact113_node_6749
    ChildrenCoverage113.nil))

theorem compact113_node_6751 : NodeCoverage113 [10,10,10,10,10,10,10,5,3] 3 35 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6752 : NodeCoverage113 [10,10,10,10,10,10,10,5] 5 38 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6750
    (ChildrenCoverage113.cons _ _ compact113_node_6751
    ChildrenCoverage113.nil))

theorem compact113_node_6753 : NodeCoverage113 [10,10,10,10,10,10,10,3] 3 40 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6754 : NodeCoverage113 [10,10,10,10,10,10,10] 10 43 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6722
    (ChildrenCoverage113.cons _ _ compact113_node_6723
    (ChildrenCoverage113.cons _ _ compact113_node_6724
    (ChildrenCoverage113.cons _ _ compact113_node_6725
    (ChildrenCoverage113.cons _ _ compact113_node_6726
    (ChildrenCoverage113.cons _ _ compact113_node_6752
    (ChildrenCoverage113.cons _ _ compact113_node_6753
    ChildrenCoverage113.nil)))))))

theorem compact113_node_6755 : NodeCoverage113 [10,10,10,10,10,10,9] 9 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.ResidualRealizeShardDefs113

/-! Kernel check: realizability for the subsets starting with bits true,true,false,false,true. -/
namespace Symconf113
set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
theorem realShard_25 : bools10.all (fun l => realB ([true,true,false,false,true] ++ l))=true := by decide +kernel
end Symconf113

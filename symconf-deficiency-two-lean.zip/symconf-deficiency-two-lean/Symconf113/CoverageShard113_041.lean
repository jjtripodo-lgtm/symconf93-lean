import Symconf113.CoverageShard113_040

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1660 : NodeCoverage113 [36,18,12,11] 11 36 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1661 : NodeCoverage113 [36,18,12,10] 10 37 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1662 : NodeCoverage113 [36,18,12,9] 9 38 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1663 : NodeCoverage113 [36,18,12,8] 8 39 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1664 : NodeCoverage113 [36,18,12,7] 7 40 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1665 : NodeCoverage113 [36,18,12,6] 6 41 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1666 : NodeCoverage113 [36,18,12,5] 5 42 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1667 : NodeCoverage113 [36,18,12,3] 3 44 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1668 : NodeCoverage113 [36,18,12] 12 47 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1659
    (ChildrenCoverage113.cons _ _ compact113_node_1660
    (ChildrenCoverage113.cons _ _ compact113_node_1661
    (ChildrenCoverage113.cons _ _ compact113_node_1662
    (ChildrenCoverage113.cons _ _ compact113_node_1663
    (ChildrenCoverage113.cons _ _ compact113_node_1664
    (ChildrenCoverage113.cons _ _ compact113_node_1665
    (ChildrenCoverage113.cons _ _ compact113_node_1666
    (ChildrenCoverage113.cons _ _ compact113_node_1667
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_1669 : NodeCoverage113 [36,18,11] 11 48 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1670 : NodeCoverage113 [36,18,10] 10 49 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1671 : NodeCoverage113 [36,18,9,9,9,9,9,9] 9 5 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1672 : NodeCoverage113 [36,18,9,9,9,9,9,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1673 : NodeCoverage113 [36,18,9,9,9,9,9,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1674 : NodeCoverage113 [36,18,9,9,9,9,9,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1675 : NodeCoverage113 [36,18,9,9,9,9,9,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1676 : NodeCoverage113 [36,18,9,9,9,9,9,3] 3 11 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1677 : NodeCoverage113 [36,18,9,9,9,9,9] 9 14 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1671
    (ChildrenCoverage113.cons _ _ compact113_node_1672
    (ChildrenCoverage113.cons _ _ compact113_node_1673
    (ChildrenCoverage113.cons _ _ compact113_node_1674
    (ChildrenCoverage113.cons _ _ compact113_node_1675
    (ChildrenCoverage113.cons _ _ compact113_node_1676
    ChildrenCoverage113.nil))))))

theorem compact113_node_1678 : NodeCoverage113 [36,18,9,9,9,9,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1679 : NodeCoverage113 [36,18,9,9,9,9,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1680 : NodeCoverage113 [36,18,9,9,9,9,6] 6 17 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1681 : NodeCoverage113 [36,18,9,9,9,9,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1682 : NodeCoverage113 [36,18,9,9,9,9,3] 3 20 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1683 : NodeCoverage113 [36,18,9,9,9,9] 9 23 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1677
    (ChildrenCoverage113.cons _ _ compact113_node_1678
    (ChildrenCoverage113.cons _ _ compact113_node_1679
    (ChildrenCoverage113.cons _ _ compact113_node_1680
    (ChildrenCoverage113.cons _ _ compact113_node_1681
    (ChildrenCoverage113.cons _ _ compact113_node_1682
    ChildrenCoverage113.nil))))))

theorem compact113_node_1684 : NodeCoverage113 [36,18,9,9,9,8] 8 24 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1685 : NodeCoverage113 [36,18,9,9,9,7] 7 25 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1686 : NodeCoverage113 [36,18,9,9,9,6] 6 26 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1687 : NodeCoverage113 [36,18,9,9,9,5] 5 27 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1688 : NodeCoverage113 [36,18,9,9,9,3] 3 29 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1689 : NodeCoverage113 [36,18,9,9,9] 9 32 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1683
    (ChildrenCoverage113.cons _ _ compact113_node_1684
    (ChildrenCoverage113.cons _ _ compact113_node_1685
    (ChildrenCoverage113.cons _ _ compact113_node_1686
    (ChildrenCoverage113.cons _ _ compact113_node_1687
    (ChildrenCoverage113.cons _ _ compact113_node_1688
    ChildrenCoverage113.nil))))))

theorem compact113_node_1690 : NodeCoverage113 [36,18,9,9,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1691 : NodeCoverage113 [36,18,9,9,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1692 : NodeCoverage113 [36,18,9,9,6] 6 35 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1693 : NodeCoverage113 [36,18,9,9,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1694 : NodeCoverage113 [36,18,9,9,3] 3 38 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1695 : NodeCoverage113 [36,18,9,9] 9 41 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1689
    (ChildrenCoverage113.cons _ _ compact113_node_1690
    (ChildrenCoverage113.cons _ _ compact113_node_1691
    (ChildrenCoverage113.cons _ _ compact113_node_1692
    (ChildrenCoverage113.cons _ _ compact113_node_1693
    (ChildrenCoverage113.cons _ _ compact113_node_1694
    ChildrenCoverage113.nil))))))

theorem compact113_node_1696 : NodeCoverage113 [36,18,9,8] 8 42 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1697 : NodeCoverage113 [36,18,9,7] 7 43 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1698 : NodeCoverage113 [36,18,9,6] 6 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1699 : NodeCoverage113 [36,18,9,5] 5 45 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1700 : NodeCoverage113 [36,18,9,3] 3 47 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1701 : NodeCoverage113 [36,18,9] 9 50 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1695
    (ChildrenCoverage113.cons _ _ compact113_node_1696
    (ChildrenCoverage113.cons _ _ compact113_node_1697
    (ChildrenCoverage113.cons _ _ compact113_node_1698
    (ChildrenCoverage113.cons _ _ compact113_node_1699
    (ChildrenCoverage113.cons _ _ compact113_node_1700
    ChildrenCoverage113.nil))))))

theorem compact113_node_1702 : NodeCoverage113 [36,18,8] 8 51 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.ExactCoverage113
import Symconf113.ProfileExclusions113
import Symconf113.Hamiltonian113
import Symconf113.ActualSieveInput

/-! Reduction of an unrestricted 113_11 incidence to two leave profiles.

Proved in Lean, with no hypotheses: every 113-by-113 binary matrix with
eleven ones in each row and column and pairwise row overlaps at most one has
common row/column leave profile `[113]` or `3+5+15^7`.

With the named Buratti–Stinson hypothesis `NoModularGolombRuler113`, the
profile `[113]` is excluded as well, leaving `3+5+15^7`. -/
namespace Symconf113
open Matrix Symconf59

abbrev Residual113 : List ℕ := [15,15,15,15,15,15,15,5,3]

theorem profiles19_split {P : List ℕ} (h : P∈profiles19) :
    P=[113] ∨ P=Residual113 ∨ P∈excludedProfiles17 := by
  simp only [profiles19, List.mem_cons, List.not_mem_nil, or_false] at h
  rcases h with h|h|h|h|h|h|h|h|h|h|h|h|h|h|h|h|h|h|h <;> subst h <;> decide

/-- Unconditional: only the Hamiltonian and the `3+5+15^7` profiles remain. -/
theorem incidence113_two_profiles {A : Int113} (hA : Incidence113 A) :
    ∃ P : List ℕ, (P=[113] ∨ P=Residual113) ∧
      ∃ _R : OrderedCycles (rowLeave A) P, ∃ _C : OrderedCycles (colLeave A) P,
        Nonempty (OriginalProfileFacts P) := by
  obtain ⟨P,hP,R,C,⟨F⟩⟩ := physical_profile_mem_parity_free hA
  have hc := exact_original_coverage113 P hP (true_profile_passes_sieve F)
  rcases profiles19_split hc with h|h|h
  · exact ⟨P,Or.inl h,R,C,⟨F⟩⟩
  · exact ⟨P,Or.inr h,R,C,⟨F⟩⟩
  · exact (excluded_profiles17 h F).elim

/-- With Buratti–Stinson as a named hypothesis: only `3+5+15^7` remains. -/
theorem incidence113_residual_profile (ruler : NoModularGolombRuler113)
    {A : Int113} (hA : Incidence113 A) :
    ∃ _R : OrderedCycles (rowLeave A) Residual113,
      ∃ _C : OrderedCycles (colLeave A) Residual113,
        Nonempty (OriginalProfileFacts Residual113) := by
  obtain ⟨P,hP,R,C,hF⟩ := incidence113_two_profiles hA
  rcases hP with rfl|rfl
  · exact (no_hamiltonian_incidence113 ruler hA R C).elim
  · exact ⟨R,C,hF⟩

end Symconf113

#print axioms Symconf113.incidence113_two_profiles
#print axioms Symconf113.incidence113_residual_profile

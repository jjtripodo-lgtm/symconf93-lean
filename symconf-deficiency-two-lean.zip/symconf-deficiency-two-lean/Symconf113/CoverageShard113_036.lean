import Symconf113.CoverageShard113_035

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1446 : NodeCoverage113 [37,18] 18 58 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1447 : NodeCoverage113 [37,17] 17 59 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1448 : NodeCoverage113 [37,16] 16 60 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1449 : NodeCoverage113 [37,15] 15 61 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1450 : NodeCoverage113 [37,14] 14 62 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1451 : NodeCoverage113 [37,13] 13 63 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1452 : NodeCoverage113 [37,12] 12 64 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1453 : NodeCoverage113 [37,11] 11 65 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1454 : NodeCoverage113 [37,10] 10 66 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1455 : NodeCoverage113 [37,9] 9 67 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1456 : NodeCoverage113 [37,8] 8 68 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1457 : NodeCoverage113 [37,7] 7 69 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1458 : NodeCoverage113 [37,6] 6 70 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1459 : NodeCoverage113 [37,5] 5 71 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1460 : NodeCoverage113 [37,3] 3 73 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1461 : NodeCoverage113 [37] 37 76 :=
  node_fork113 (B := [37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1427
    (ChildrenCoverage113.cons _ _ compact113_node_1428
    (ChildrenCoverage113.cons _ _ compact113_node_1429
    (ChildrenCoverage113.cons _ _ compact113_node_1430
    (ChildrenCoverage113.cons _ _ compact113_node_1431
    (ChildrenCoverage113.cons _ _ compact113_node_1432
    (ChildrenCoverage113.cons _ _ compact113_node_1433
    (ChildrenCoverage113.cons _ _ compact113_node_1434
    (ChildrenCoverage113.cons _ _ compact113_node_1435
    (ChildrenCoverage113.cons _ _ compact113_node_1436
    (ChildrenCoverage113.cons _ _ compact113_node_1437
    (ChildrenCoverage113.cons _ _ compact113_node_1438
    (ChildrenCoverage113.cons _ _ compact113_node_1439
    (ChildrenCoverage113.cons _ _ compact113_node_1440
    (ChildrenCoverage113.cons _ _ compact113_node_1441
    (ChildrenCoverage113.cons _ _ compact113_node_1442
    (ChildrenCoverage113.cons _ _ compact113_node_1443
    (ChildrenCoverage113.cons _ _ compact113_node_1444
    (ChildrenCoverage113.cons _ _ compact113_node_1445
    (ChildrenCoverage113.cons _ _ compact113_node_1446
    (ChildrenCoverage113.cons _ _ compact113_node_1447
    (ChildrenCoverage113.cons _ _ compact113_node_1448
    (ChildrenCoverage113.cons _ _ compact113_node_1449
    (ChildrenCoverage113.cons _ _ compact113_node_1450
    (ChildrenCoverage113.cons _ _ compact113_node_1451
    (ChildrenCoverage113.cons _ _ compact113_node_1452
    (ChildrenCoverage113.cons _ _ compact113_node_1453
    (ChildrenCoverage113.cons _ _ compact113_node_1454
    (ChildrenCoverage113.cons _ _ compact113_node_1455
    (ChildrenCoverage113.cons _ _ compact113_node_1456
    (ChildrenCoverage113.cons _ _ compact113_node_1457
    (ChildrenCoverage113.cons _ _ compact113_node_1458
    (ChildrenCoverage113.cons _ _ compact113_node_1459
    (ChildrenCoverage113.cons _ _ compact113_node_1460
    ChildrenCoverage113.nil))))))))))))))))))))))))))))))))))

theorem compact113_node_1462 : NodeCoverage113 [36,36,36] 36 5 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1463 : NodeCoverage113 [36,36,35] 35 6 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1464 : NodeCoverage113 [36,36,34] 34 7 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1465 : NodeCoverage113 [36,36,33] 33 8 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1466 : NodeCoverage113 [36,36,32] 32 9 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1467 : NodeCoverage113 [36,36,31] 31 10 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1468 : NodeCoverage113 [36,36,30] 30 11 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1469 : NodeCoverage113 [36,36,29] 29 12 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1470 : NodeCoverage113 [36,36,28] 28 13 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1471 : NodeCoverage113 [36,36,27] 27 14 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1472 : NodeCoverage113 [36,36,26] 26 15 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1473 : NodeCoverage113 [36,36,25] 25 16 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1474 : NodeCoverage113 [36,36,24] 24 17 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1475 : NodeCoverage113 [36,36,23] 23 18 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1476 : NodeCoverage113 [36,36,22] 22 19 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1477 : NodeCoverage113 [36,36,21] 21 20 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1478 : NodeCoverage113 [36,36,20] 20 21 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1479 : NodeCoverage113 [36,36,19] 19 22 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_029

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1234 : NodeCoverage113 [40,20,10,10,10,10,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1235 : NodeCoverage113 [40,20,10,10,10,10] 10 13 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1228
    (ChildrenCoverage113.cons _ _ compact113_node_1229
    (ChildrenCoverage113.cons _ _ compact113_node_1230
    (ChildrenCoverage113.cons _ _ compact113_node_1231
    (ChildrenCoverage113.cons _ _ compact113_node_1232
    (ChildrenCoverage113.cons _ _ compact113_node_1233
    (ChildrenCoverage113.cons _ _ compact113_node_1234
    ChildrenCoverage113.nil)))))))

theorem compact113_node_1236 : NodeCoverage113 [40,20,10,10,10,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1237 : NodeCoverage113 [40,20,10,10,10,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1238 : NodeCoverage113 [40,20,10,10,10,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1239 : NodeCoverage113 [40,20,10,10,10,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1240 : NodeCoverage113 [40,20,10,10,10,5] 5 18 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1241 : NodeCoverage113 [40,20,10,10,10,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1242 : NodeCoverage113 [40,20,10,10,10] 10 23 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1235
    (ChildrenCoverage113.cons _ _ compact113_node_1236
    (ChildrenCoverage113.cons _ _ compact113_node_1237
    (ChildrenCoverage113.cons _ _ compact113_node_1238
    (ChildrenCoverage113.cons _ _ compact113_node_1239
    (ChildrenCoverage113.cons _ _ compact113_node_1240
    (ChildrenCoverage113.cons _ _ compact113_node_1241
    ChildrenCoverage113.nil)))))))

theorem compact113_node_1243 : NodeCoverage113 [40,20,10,10,9] 9 24 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1244 : NodeCoverage113 [40,20,10,10,8] 8 25 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1245 : NodeCoverage113 [40,20,10,10,7] 7 26 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1246 : NodeCoverage113 [40,20,10,10,6] 6 27 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1247 : NodeCoverage113 [40,20,10,10,5] 5 28 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1248 : NodeCoverage113 [40,20,10,10,3] 3 30 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1249 : NodeCoverage113 [40,20,10,10] 10 33 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1242
    (ChildrenCoverage113.cons _ _ compact113_node_1243
    (ChildrenCoverage113.cons _ _ compact113_node_1244
    (ChildrenCoverage113.cons _ _ compact113_node_1245
    (ChildrenCoverage113.cons _ _ compact113_node_1246
    (ChildrenCoverage113.cons _ _ compact113_node_1247
    (ChildrenCoverage113.cons _ _ compact113_node_1248
    ChildrenCoverage113.nil)))))))

theorem compact113_node_1250 : NodeCoverage113 [40,20,10,9] 9 34 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1251 : NodeCoverage113 [40,20,10,8] 8 35 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1252 : NodeCoverage113 [40,20,10,7] 7 36 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1253 : NodeCoverage113 [40,20,10,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1254 : NodeCoverage113 [40,20,10,5] 5 38 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1255 : NodeCoverage113 [40,20,10,3] 3 40 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1256 : NodeCoverage113 [40,20,10] 10 43 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1249
    (ChildrenCoverage113.cons _ _ compact113_node_1250
    (ChildrenCoverage113.cons _ _ compact113_node_1251
    (ChildrenCoverage113.cons _ _ compact113_node_1252
    (ChildrenCoverage113.cons _ _ compact113_node_1253
    (ChildrenCoverage113.cons _ _ compact113_node_1254
    (ChildrenCoverage113.cons _ _ compact113_node_1255
    ChildrenCoverage113.nil)))))))

theorem compact113_node_1257 : NodeCoverage113 [40,20,9] 9 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1258 : NodeCoverage113 [40,20,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1259 : NodeCoverage113 [40,20,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1260 : NodeCoverage113 [40,20,6] 6 47 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1261 : NodeCoverage113 [40,20,5] 5 48 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1262 : NodeCoverage113 [40,20,3] 3 50 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1263 : NodeCoverage113 [40,20] 20 53 :=
  node_fork113 (B := [20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1218
    (ChildrenCoverage113.cons _ _ compact113_node_1219
    (ChildrenCoverage113.cons _ _ compact113_node_1220
    (ChildrenCoverage113.cons _ _ compact113_node_1221
    (ChildrenCoverage113.cons _ _ compact113_node_1222
    (ChildrenCoverage113.cons _ _ compact113_node_1223
    (ChildrenCoverage113.cons _ _ compact113_node_1224
    (ChildrenCoverage113.cons _ _ compact113_node_1225
    (ChildrenCoverage113.cons _ _ compact113_node_1226
    (ChildrenCoverage113.cons _ _ compact113_node_1227
    (ChildrenCoverage113.cons _ _ compact113_node_1256
    (ChildrenCoverage113.cons _ _ compact113_node_1257
    (ChildrenCoverage113.cons _ _ compact113_node_1258
    (ChildrenCoverage113.cons _ _ compact113_node_1259
    (ChildrenCoverage113.cons _ _ compact113_node_1260
    (ChildrenCoverage113.cons _ _ compact113_node_1261
    (ChildrenCoverage113.cons _ _ compact113_node_1262
    ChildrenCoverage113.nil)))))))))))))))))

theorem compact113_node_1264 : NodeCoverage113 [40,19] 19 54 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1265 : NodeCoverage113 [40,18] 18 55 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1266 : NodeCoverage113 [40,17] 17 56 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1267 : NodeCoverage113 [40,16] 16 57 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1268 : NodeCoverage113 [40,15] 15 58 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1269 : NodeCoverage113 [40,14] 14 59 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1270 : NodeCoverage113 [40,13] 13 60 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1271 : NodeCoverage113 [40,12] 12 61 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1272 : NodeCoverage113 [40,11] 11 62 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1273 : NodeCoverage113 [40,10,10,10,10,10,10,10] 10 3 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1274 : NodeCoverage113 [40,10,10,10,10,10,10,9] 9 4 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1275 : NodeCoverage113 [40,10,10,10,10,10,10,8] 8 5 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1276 : NodeCoverage113 [40,10,10,10,10,10,10,7] 7 6 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1277 : NodeCoverage113 [40,10,10,10,10,10,10,6] 6 7 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1278 : NodeCoverage113 [40,10,10,10,10,10,10,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1279 : NodeCoverage113 [40,10,10,10,10,10,10,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1278
    ChildrenCoverage113.nil)

theorem compact113_node_1280 : NodeCoverage113 [40,10,10,10,10,10,10,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1281 : NodeCoverage113 [40,10,10,10,10,10,10,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1279
    (ChildrenCoverage113.cons _ _ compact113_node_1280
    ChildrenCoverage113.nil))

theorem compact113_node_1282 : NodeCoverage113 [40,10,10,10,10,10,10,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1283 : NodeCoverage113 [40,10,10,10,10,10,10] 10 13 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1273
    (ChildrenCoverage113.cons _ _ compact113_node_1274
    (ChildrenCoverage113.cons _ _ compact113_node_1275
    (ChildrenCoverage113.cons _ _ compact113_node_1276
    (ChildrenCoverage113.cons _ _ compact113_node_1277
    (ChildrenCoverage113.cons _ _ compact113_node_1281
    (ChildrenCoverage113.cons _ _ compact113_node_1282
    ChildrenCoverage113.nil)))))))

end Symconf113

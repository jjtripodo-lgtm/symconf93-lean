import Symconf113.CoverageShard113_121
import Symconf113.CoverageShard113_122
import Symconf113.CoverageShard113_123
import Symconf113.CoverageShard113_124
import Symconf113.CoverageShard113_125
import Symconf113.CoverageShard113_126

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4967 : NodeCoverage113 [18,9,6] 6 80 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4968 : NodeCoverage113 [18,9,5] 5 81 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4969 : NodeCoverage113 [18,9,3] 3 83 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4970 : NodeCoverage113 [18,9] 9 86 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4964
    (ChildrenCoverage113.cons _ _ compact113_node_4965
    (ChildrenCoverage113.cons _ _ compact113_node_4966
    (ChildrenCoverage113.cons _ _ compact113_node_4967
    (ChildrenCoverage113.cons _ _ compact113_node_4968
    (ChildrenCoverage113.cons _ _ compact113_node_4969
    ChildrenCoverage113.nil))))))

theorem compact113_node_4971 : NodeCoverage113 [18,8] 8 87 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4972 : NodeCoverage113 [18,7] 7 88 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4973 : NodeCoverage113 [18,6] 6 89 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4974 : NodeCoverage113 [18,5] 5 90 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4975 : NodeCoverage113 [18,3] 3 92 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4976 : NodeCoverage113 [18] 18 95 :=
  node_fork113 (B := [18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4722
    (ChildrenCoverage113.cons _ _ compact113_node_4737
    (ChildrenCoverage113.cons _ _ compact113_node_4751
    (ChildrenCoverage113.cons _ _ compact113_node_4764
    (ChildrenCoverage113.cons _ _ compact113_node_4812
    (ChildrenCoverage113.cons _ _ compact113_node_4833
    (ChildrenCoverage113.cons _ _ compact113_node_4858
    (ChildrenCoverage113.cons _ _ compact113_node_4875
    (ChildrenCoverage113.cons _ _ compact113_node_4890
    (ChildrenCoverage113.cons _ _ compact113_node_4970
    (ChildrenCoverage113.cons _ _ compact113_node_4971
    (ChildrenCoverage113.cons _ _ compact113_node_4972
    (ChildrenCoverage113.cons _ _ compact113_node_4973
    (ChildrenCoverage113.cons _ _ compact113_node_4974
    (ChildrenCoverage113.cons _ _ compact113_node_4975
    ChildrenCoverage113.nil)))))))))))))))

theorem compact113_node_4977 : NodeCoverage113 [17,17,17,17,17,17,11] 11 0 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4978 : NodeCoverage113 [17,17,17,17,17,17,8] 8 3 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4979 : NodeCoverage113 [17,17,17,17,17,17,7] 7 4 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4980 : NodeCoverage113 [17,17,17,17,17,17,6] 6 5 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4981 : NodeCoverage113 [17,17,17,17,17,17,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4982 : NodeCoverage113 [17,17,17,17,17,17,3] 3 8 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4983 : NodeCoverage113 [17,17,17,17,17,17] 17 11 :=
  node_fork113 (B := [11,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4977
    (ChildrenCoverage113.cons _ _ compact113_node_4978
    (ChildrenCoverage113.cons _ _ compact113_node_4979
    (ChildrenCoverage113.cons _ _ compact113_node_4980
    (ChildrenCoverage113.cons _ _ compact113_node_4981
    (ChildrenCoverage113.cons _ _ compact113_node_4982
    ChildrenCoverage113.nil))))))

theorem compact113_node_4984 : NodeCoverage113 [17,17,17,17,17,16] 16 12 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4985 : NodeCoverage113 [17,17,17,17,17,15] 15 13 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4986 : NodeCoverage113 [17,17,17,17,17,14] 14 14 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4987 : NodeCoverage113 [17,17,17,17,17,13] 13 15 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4988 : NodeCoverage113 [17,17,17,17,17,12] 12 16 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4989 : NodeCoverage113 [17,17,17,17,17,11] 11 17 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4990 : NodeCoverage113 [17,17,17,17,17,10] 10 18 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4991 : NodeCoverage113 [17,17,17,17,17,9] 9 19 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4992 : NodeCoverage113 [17,17,17,17,17,8] 8 20 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4993 : NodeCoverage113 [17,17,17,17,17,7] 7 21 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4994 : NodeCoverage113 [17,17,17,17,17,6] 6 22 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4995 : NodeCoverage113 [17,17,17,17,17,5] 5 23 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4996 : NodeCoverage113 [17,17,17,17,17,3] 3 25 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4997 : NodeCoverage113 [17,17,17,17,17] 17 28 :=
  node_fork113 (B := [17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4983
    (ChildrenCoverage113.cons _ _ compact113_node_4984
    (ChildrenCoverage113.cons _ _ compact113_node_4985
    (ChildrenCoverage113.cons _ _ compact113_node_4986
    (ChildrenCoverage113.cons _ _ compact113_node_4987
    (ChildrenCoverage113.cons _ _ compact113_node_4988
    (ChildrenCoverage113.cons _ _ compact113_node_4989
    (ChildrenCoverage113.cons _ _ compact113_node_4990
    (ChildrenCoverage113.cons _ _ compact113_node_4991
    (ChildrenCoverage113.cons _ _ compact113_node_4992
    (ChildrenCoverage113.cons _ _ compact113_node_4993
    (ChildrenCoverage113.cons _ _ compact113_node_4994
    (ChildrenCoverage113.cons _ _ compact113_node_4995
    (ChildrenCoverage113.cons _ _ compact113_node_4996
    ChildrenCoverage113.nil))))))))))))))

theorem compact113_node_4998 : NodeCoverage113 [17,17,17,17,16] 16 29 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4999 : NodeCoverage113 [17,17,17,17,15] 15 30 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5000 : NodeCoverage113 [17,17,17,17,14] 14 31 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5001 : NodeCoverage113 [17,17,17,17,13] 13 32 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5002 : NodeCoverage113 [17,17,17,17,12] 12 33 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5003 : NodeCoverage113 [17,17,17,17,11] 11 34 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5004 : NodeCoverage113 [17,17,17,17,10] 10 35 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

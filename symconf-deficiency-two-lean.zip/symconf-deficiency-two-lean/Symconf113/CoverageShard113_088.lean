import Symconf113.CoverageShard113_085
import Symconf113.CoverageShard113_087

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3167 : NodeCoverage113 [24,24,7] 7 58 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3168 : NodeCoverage113 [24,24,6] 6 59 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3169 : NodeCoverage113 [24,24,5] 5 60 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3170 : NodeCoverage113 [24,24,3] 3 62 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3171 : NodeCoverage113 [24,24] 24 65 :=
  node_fork113 (B := [24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3078
    (ChildrenCoverage113.cons _ _ compact113_node_3079
    (ChildrenCoverage113.cons _ _ compact113_node_3080
    (ChildrenCoverage113.cons _ _ compact113_node_3081
    (ChildrenCoverage113.cons _ _ compact113_node_3082
    (ChildrenCoverage113.cons _ _ compact113_node_3083
    (ChildrenCoverage113.cons _ _ compact113_node_3084
    (ChildrenCoverage113.cons _ _ compact113_node_3085
    (ChildrenCoverage113.cons _ _ compact113_node_3086
    (ChildrenCoverage113.cons _ _ compact113_node_3087
    (ChildrenCoverage113.cons _ _ compact113_node_3088
    (ChildrenCoverage113.cons _ _ compact113_node_3089
    (ChildrenCoverage113.cons _ _ compact113_node_3162
    (ChildrenCoverage113.cons _ _ compact113_node_3163
    (ChildrenCoverage113.cons _ _ compact113_node_3164
    (ChildrenCoverage113.cons _ _ compact113_node_3165
    (ChildrenCoverage113.cons _ _ compact113_node_3166
    (ChildrenCoverage113.cons _ _ compact113_node_3167
    (ChildrenCoverage113.cons _ _ compact113_node_3168
    (ChildrenCoverage113.cons _ _ compact113_node_3169
    (ChildrenCoverage113.cons _ _ compact113_node_3170
    ChildrenCoverage113.nil)))))))))))))))))))))

theorem compact113_node_3172 : NodeCoverage113 [24,23] 23 66 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3173 : NodeCoverage113 [24,22] 22 67 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3174 : NodeCoverage113 [24,21] 21 68 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3175 : NodeCoverage113 [24,20] 20 69 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3176 : NodeCoverage113 [24,19] 19 70 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3177 : NodeCoverage113 [24,18,18] 18 53 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3178 : NodeCoverage113 [24,18,17] 17 54 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3179 : NodeCoverage113 [24,18,16] 16 55 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3180 : NodeCoverage113 [24,18,15] 15 56 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3181 : NodeCoverage113 [24,18,14] 14 57 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3182 : NodeCoverage113 [24,18,13] 13 58 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_003

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0175 : NodeCoverage113 [70,23] 23 20 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0176 : NodeCoverage113 [70,22] 22 21 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0177 : NodeCoverage113 [70,21] 21 22 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0178 : NodeCoverage113 [70,20] 20 23 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0179 : NodeCoverage113 [70,19] 19 24 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0180 : NodeCoverage113 [70,18] 18 25 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0181 : NodeCoverage113 [70,17] 17 26 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0182 : NodeCoverage113 [70,16] 16 27 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0183 : NodeCoverage113 [70,15] 15 28 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0184 : NodeCoverage113 [70,14,14] 14 15 :=
  demand_node_prune113 70 compact113_demands_070 compact113_demands_070_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0185 : NodeCoverage113 [70,14,13] 13 16 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0186 : NodeCoverage113 [70,14,12] 12 17 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0187 : NodeCoverage113 [70,14,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0188 : NodeCoverage113 [70,14,10,10,9] 9 0 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0189 : NodeCoverage113 [70,14,10,10,6] 6 3 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0190 : NodeCoverage113 [70,14,10,10,5] 5 4 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0191 : NodeCoverage113 [70,14,10,10,3] 3 6 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0192 : NodeCoverage113 [70,14,10,10] 10 9 :=
  node_fork113 (B := [9,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0188
    (ChildrenCoverage113.cons _ _ compact113_node_0189
    (ChildrenCoverage113.cons _ _ compact113_node_0190
    (ChildrenCoverage113.cons _ _ compact113_node_0191
    ChildrenCoverage113.nil))))

theorem compact113_node_0193 : NodeCoverage113 [70,14,10,9] 9 10 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0194 : NodeCoverage113 [70,14,10,8] 8 11 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0195 : NodeCoverage113 [70,14,10,7] 7 12 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0196 : NodeCoverage113 [70,14,10,6] 6 13 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0197 : NodeCoverage113 [70,14,10,5] 5 14 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0198 : NodeCoverage113 [70,14,10,3] 3 16 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0199 : NodeCoverage113 [70,14,10] 10 19 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0192
    (ChildrenCoverage113.cons _ _ compact113_node_0193
    (ChildrenCoverage113.cons _ _ compact113_node_0194
    (ChildrenCoverage113.cons _ _ compact113_node_0195
    (ChildrenCoverage113.cons _ _ compact113_node_0196
    (ChildrenCoverage113.cons _ _ compact113_node_0197
    (ChildrenCoverage113.cons _ _ compact113_node_0198
    ChildrenCoverage113.nil)))))))

theorem compact113_node_0200 : NodeCoverage113 [70,14,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0201 : NodeCoverage113 [70,14,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0202 : NodeCoverage113 [70,14,7] 7 22 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0203 : NodeCoverage113 [70,14,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0204 : NodeCoverage113 [70,14,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0205 : NodeCoverage113 [70,14,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0206 : NodeCoverage113 [70,14] 14 29 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0184
    (ChildrenCoverage113.cons _ _ compact113_node_0185
    (ChildrenCoverage113.cons _ _ compact113_node_0186
    (ChildrenCoverage113.cons _ _ compact113_node_0187
    (ChildrenCoverage113.cons _ _ compact113_node_0199
    (ChildrenCoverage113.cons _ _ compact113_node_0200
    (ChildrenCoverage113.cons _ _ compact113_node_0201
    (ChildrenCoverage113.cons _ _ compact113_node_0202
    (ChildrenCoverage113.cons _ _ compact113_node_0203
    (ChildrenCoverage113.cons _ _ compact113_node_0204
    (ChildrenCoverage113.cons _ _ compact113_node_0205
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_0207 : NodeCoverage113 [70,13] 13 30 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0208 : NodeCoverage113 [70,12] 12 31 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0209 : NodeCoverage113 [70,11] 11 32 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0210 : NodeCoverage113 [70,10] 10 33 :=
  demand_node_prune113 70 compact113_demands_070 compact113_demands_070_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0211 : NodeCoverage113 [70,9] 9 34 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0212 : NodeCoverage113 [70,8] 8 35 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0213 : NodeCoverage113 [70,7] 7 36 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0214 : NodeCoverage113 [70,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0215 : NodeCoverage113 [70,5] 5 38 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0216 : NodeCoverage113 [70,3] 3 40 :=
  demand_node_prune113 70 compact113_demands_070 compact113_demands_070_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0217 : NodeCoverage113 [70] 70 43 :=
  node_fork113 (B := [43,40,39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0157
    (ChildrenCoverage113.cons _ _ compact113_node_0158
    (ChildrenCoverage113.cons _ _ compact113_node_0159
    (ChildrenCoverage113.cons _ _ compact113_node_0160
    (ChildrenCoverage113.cons _ _ compact113_node_0161
    (ChildrenCoverage113.cons _ _ compact113_node_0162
    (ChildrenCoverage113.cons _ _ compact113_node_0163
    (ChildrenCoverage113.cons _ _ compact113_node_0164
    (ChildrenCoverage113.cons _ _ compact113_node_0165
    (ChildrenCoverage113.cons _ _ compact113_node_0166
    (ChildrenCoverage113.cons _ _ compact113_node_0167
    (ChildrenCoverage113.cons _ _ compact113_node_0168
    (ChildrenCoverage113.cons _ _ compact113_node_0169
    (ChildrenCoverage113.cons _ _ compact113_node_0170
    (ChildrenCoverage113.cons _ _ compact113_node_0171
    (ChildrenCoverage113.cons _ _ compact113_node_0172
    (ChildrenCoverage113.cons _ _ compact113_node_0173
    (ChildrenCoverage113.cons _ _ compact113_node_0174
    (ChildrenCoverage113.cons _ _ compact113_node_0175
    (ChildrenCoverage113.cons _ _ compact113_node_0176
    (ChildrenCoverage113.cons _ _ compact113_node_0177
    (ChildrenCoverage113.cons _ _ compact113_node_0178
    (ChildrenCoverage113.cons _ _ compact113_node_0179
    (ChildrenCoverage113.cons _ _ compact113_node_0180
    (ChildrenCoverage113.cons _ _ compact113_node_0181
    (ChildrenCoverage113.cons _ _ compact113_node_0182
    (ChildrenCoverage113.cons _ _ compact113_node_0183
    (ChildrenCoverage113.cons _ _ compact113_node_0206
    (ChildrenCoverage113.cons _ _ compact113_node_0207
    (ChildrenCoverage113.cons _ _ compact113_node_0208
    (ChildrenCoverage113.cons _ _ compact113_node_0209
    (ChildrenCoverage113.cons _ _ compact113_node_0210
    (ChildrenCoverage113.cons _ _ compact113_node_0211
    (ChildrenCoverage113.cons _ _ compact113_node_0212
    (ChildrenCoverage113.cons _ _ compact113_node_0213
    (ChildrenCoverage113.cons _ _ compact113_node_0214
    (ChildrenCoverage113.cons _ _ compact113_node_0215
    (ChildrenCoverage113.cons _ _ compact113_node_0216
    ChildrenCoverage113.nil))))))))))))))))))))))))))))))))))))))

theorem compact113_node_0218 : NodeCoverage113 [69] 69 44 :=
  demand_node_prune113 69 compact113_demands_069 compact113_demands_069_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0219 : NodeCoverage113 [68] 68 45 :=
  demand_node_prune113 68 compact113_demands_068 compact113_demands_068_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0220 : NodeCoverage113 [67] 67 46 :=
  demand_node_prune113 67 compact113_demands_067 compact113_demands_067_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0221 : NodeCoverage113 [66] 66 47 :=
  demand_node_prune113 66 compact113_demands_066 compact113_demands_066_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0222 : NodeCoverage113 [65] 65 48 :=
  demand_node_prune113 65 compact113_demands_065 compact113_demands_065_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0223 : NodeCoverage113 [64,49] 49 0 :=
  demand_node_prune113 49 compact113_demands_049 compact113_demands_049_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0224 : NodeCoverage113 [64,46] 46 3 :=
  demand_node_prune113 46 compact113_demands_046 compact113_demands_046_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0225 : NodeCoverage113 [64,45] 45 4 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0226 : NodeCoverage113 [64,44] 44 5 :=
  demand_node_prune113 44 compact113_demands_044 compact113_demands_044_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0227 : NodeCoverage113 [64,43] 43 6 :=
  demand_node_prune113 43 compact113_demands_043 compact113_demands_043_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0228 : NodeCoverage113 [64,42] 42 7 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0229 : NodeCoverage113 [64,41] 41 8 :=
  demand_node_prune113 41 compact113_demands_041 compact113_demands_041_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Mathlib.Data.ZMod.Basic

/-! Finite definitions for the residual `3+5+15^7` census. Rows and columns
of the 7×7 long quotient are in canonical type order `A,B,C,C,E,E,E`:
`A` meets both short cycles, `B` only the 3-cycle, `C` only the 5-cycle.
A signature is a length-7 list: entry `t` is the autocorrelation of a block's
first row at distance `t+1`. Nothing here is trusted; every search below is
proved sound in `ResidualCensusSound113`. -/
namespace Symconf113

/-- Cartesian product of a list of lists. -/
def prodL {α : Type} : List (List α) → List (List α)
  | [] => [[]]
  | l :: ls => l.flatMap fun a => (prodL ls).map (a :: ·)

def xF (i : ℕ) : ℕ := if i≤1 then 1 else 0
def yF (i : ℕ) : ℕ := if i=0 ∨ i=2 ∨ i=3 then 1 else 0

/-- Pre-cover of distance `t+1` by the short cycles at type `i`. -/
def preF (i t : ℕ) : ℕ := (if (t+1)%3=0 then xF i else 0)+(if (t+1)%5=0 then yF i else 0)

def fullF (t : ℕ) : ℕ := if t=0 then 0 else 1

def ofF (f : ℕ → ℕ) : List ℕ := List.ofFn fun t : Fin 7 => f t

def gd (l : List ℕ) (t : ℕ) : ℕ := l.getD t 0

def unitAt (ds : List ℕ) : List ℕ := ofF fun t => if (t+1)∈ds then 1 else 0

def triples7 : List (List ℕ) :=
  [[2,3,5],[2,4,6],[2,5,7],[2,6,7],[3,4,7],[3,5,7],[4,5,6]]

/-- Every signature a block of degree `k` can have (degree at most four). -/
def realList : ℕ → List (List ℕ)
  | 0 => [unitAt []]
  | 1 => [unitAt []]
  | 2 => [[2],[3],[4],[5],[6],[7]].map unitAt
  | 3 => triples7.map unitAt
  | 4 => [unitAt [2,3,4,5,6,7]]
  | _ => []

def disjL (a b : List ℕ) : Bool := (List.range 7).all fun t => gd a t*gd b t=0

/-- Pointwise sum of a list of signatures plus a pre-cover. -/
def coverL (ls : List (List ℕ)) (i : ℕ) : List ℕ := ofF fun t => (ls.map fun s => gd s t).sum+preF i t

def fullL : List ℕ := ofF fullF

/-- All signature rows for a degree row `v` of type `i`. -/
def rowSigCands (i : ℕ) (v : List ℕ) : List (List (List ℕ)) :=
  (prodL ((List.range 7).map fun j => (realList (gd v j)).filter fun s => disjL s (ofF (preF j)))).filter
    fun ss => coverL ss i=fullL

def rowOK (i : ℕ) (v : List ℕ) : Bool :=
  v.sum=11-xF i-yF i && (v.map fun a => a*a).sum=23-5*xF i-3*yF i && !(rowSigCands i v).isEmpty

def vecs : List (List ℕ) := prodL (List.replicate 7 (List.range 5))

def gramT (i k : ℕ) : ℕ := 15-5*xF i*xF k-3*yF i*yF k

def dotL (a b : List ℕ) : ℕ := ((List.range 7).map fun j => gd a j*gd b j).sum

/-- Depth-first search with forward checking. -/
def dfs {α : Type} (compat : α → α → Bool) (leaf : List α → Bool) :
    ℕ → List α → List (List α) → Bool
  | _, acc, [] => leaf acc.reverse
  | 0, _, _ :: _ => false
  | n+1, acc, L :: Ls => L.all fun a => dfs compat leaf n (a :: acc) (Ls.map fun l => l.filter (compat a))

def degCompat (a b : ℕ × List ℕ) : Bool := dotL a.2 b.2=gramT a.1 b.1

def colOf (rows : List (ℕ × List ℕ)) (j : ℕ) : List ℕ := rows.map fun r => gd r.2 j

def sigCompat (a b : ℕ × List (List ℕ)) : Bool :=
  (List.range 7).all fun j => disjL (a.2.getD j []) (b.2.getD j [])

/-- Column covers of a full signature matrix. -/
def colCover (sigs : List (ℕ × List (List ℕ))) : Bool :=
  (List.range 7).all fun j => coverL (sigs.map fun r => r.2.getD j []) j=fullL

/-- Index of the single distance in a degree-two signature, plus one. -/
def distOf (s : List ℕ) : ℕ := ((List.range 7).filter fun t => gd s t=1).headD 0+1

/-- `c(d)`: the signed distance congruent to `2 mod 3`, read mod 15. -/
def cD (d : ℕ) : ℕ := if d=2 then 2 else if d=4 then 11 else if d=5 then 5 else if d=7 then 8 else 99

/-- Rows `A` (index 0) and `B` (index 1) share only degree-(1,2) or (2,1)
blocks, each at a distance prime to 3, and the signed distances do not sum
to `10 mod 15`. -/
def abOK (rows : List (ℕ × List ℕ)) (sigs : List (ℕ × List (List ℕ))) : Bool :=
  let ra := (rows.getD 0 (0,[])).2
  let rb := (rows.getD 1 (0,[])).2
  let sa := (sigs.getD 0 (0,[])).2
  let sb := (sigs.getD 1 (0,[])).2
  let sh := (List.range 7).filter fun j => gd ra j*gd rb j≠0
  (sh.all fun j => (gd ra j=1 && gd rb j=2) || (gd ra j=2 && gd rb j=1)) &&
  (let ds := sh.map fun j => if gd ra j=2 then distOf (sa.getD j []) else distOf (sb.getD j [])
   (ds.all fun d => d=2 || d=4 || d=5 || d=7) && (ds.map cD).sum%15≠10)

def sigLeaf (rows : List (ℕ × List ℕ)) (sigs : List (ℕ × List (List ℕ))) : Bool :=
  !colCover sigs || abOK rows sigs

def sigStage (rows : List (ℕ × List ℕ)) : Bool :=
  dfs sigCompat (sigLeaf rows) 7 [] (rows.map fun r => (rowSigCands r.1 r.2).map ((r.1,·)))

def colOK (rows : List (ℕ × List ℕ)) : Bool :=
  ((List.range 7).all fun j => (colOf rows j).sum+xF j+yF j=11) &&
  ((List.range 7).all fun j => (List.range 7).all fun l => j==l || dotL (colOf rows j) (colOf rows l)=gramT j l)

def degLeaf (rows : List (ℕ × List ℕ)) : Bool := !colOK rows || sigStage rows

end Symconf113

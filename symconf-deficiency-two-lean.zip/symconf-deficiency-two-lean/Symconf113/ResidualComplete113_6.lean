import Symconf113.ResidualCands113

/-! Kernel check: every full row of type index 6 passing the row tests is listed. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem complete_6 : ∀ v ∈ vecs, rowOK 6 v=true → v ∈ candE := by decide +kernel
end Symconf113

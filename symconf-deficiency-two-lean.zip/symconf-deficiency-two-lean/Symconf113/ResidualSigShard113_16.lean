import Symconf113.ResidualLeaves113

/-! Kernel check: the signature stage refutes leaves 16 to 31. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem sigShard_16 : ((leaves.drop 16).take 16).all sigStage=true := by decide +kernel
end Symconf113

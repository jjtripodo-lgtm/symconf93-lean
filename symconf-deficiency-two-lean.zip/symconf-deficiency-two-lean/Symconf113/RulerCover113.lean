import Symconf113.RulerSearch113
import Mathlib.Tactic.Linarith

/-! A second kernel search for (113,11) modular Golomb rulers, normalized so
that the one missing difference pair is `±1` and `{0,2}` is in the ruler.
Every difference in `[2,111]` then occurs exactly once, so the smallest
uncovered difference `d` must be produced by a pair through a known element
(`opt1`) or by two new elements (`opt2`). This file holds the search and its
completeness; the kernel runs are in `RulerCoverShard113_*`. -/
namespace Symconf113.Ruler113

/-- The smallest `d ∈ [2,56]` whose bit in `m` is clear, or `0`. -/
def firstGap (m : ℕ) : ℕ := ((List.range' 2 55).find? (fun d => !m.testBit d)).getD 0

/-- Cover `d` from the known element `y`. -/
def opt1At (d : ℕ) (rec : List ℕ → ℕ → Bool) (s : List ℕ) (m y : ℕ) : Bool :=
  [(y+d)%113, (y+113-d)%113].any fun z =>
    match addDiffs z s m with
    | none => false
    | some m' => rec (z :: s) m'

/-- Cover `d` by the two new elements `a` and `a+d`. -/
def opt2At (d : ℕ) (rec : List ℕ → ℕ → Bool) (s : List ℕ) (m a : ℕ) : Bool :=
  match addDiffs a s m with
  | none => false
  | some m' => match addDiffs ((a+d)%113) (a :: s) m' with
    | none => false
    | some m'' => rec ((a+d)%113 :: a :: s) m''

def go : ℕ → List ℕ → ℕ → Bool
  | 0, _, m => firstGap m == 0
  | 1, s, m => firstGap m == 0 || s.any (opt1At (firstGap m) (go 0) s m)
  | k+2, s, m => firstGap m == 0 || s.any (opt1At (firstGap m) (go (k+1)) s m) ||
      (List.range' 0 113).any (opt2At (firstGap m) (go k) s m)

theorem firstGap_zero {m : ℕ} (h : firstGap m=0) : ∀ d, 2≤d → d≤56 → m.testBit d=true := by
  intro d h2 h56
  unfold firstGap at h
  cases hf : (List.range' 2 55).find? (fun d => !m.testBit d) with
  | none =>
    have := List.find?_eq_none.mp hf d (List.mem_range'_1.mpr ⟨h2,by omega⟩)
    simpa using this
  | some x =>
    rw [hf] at h
    have hx := List.mem_range'_1.mp (List.mem_of_find?_eq_some hf)
    simp at h; omega

theorem firstGap_pos {m : ℕ} (h : firstGap m≠0) :
    2≤firstGap m ∧ firstGap m≤56 ∧ m.testBit (firstGap m)=false := by
  unfold firstGap at h ⊢
  cases hf : (List.range' 2 55).find? (fun d => !m.testBit d) with
  | none => rw [hf] at h; simp at h
  | some x =>
    have hx := List.mem_range'_1.mp (List.mem_of_find?_eq_some hf)
    have hp := List.find?_some hf
    simp only [Option.getD_some]
    simp at hp
    exact ⟨by omega,by omega,hp⟩

theorem addDiffs_sup (x : ℕ) : ∀ (r : List ℕ) (m m' : ℕ), addDiffs x r m=some m' →
    (∀ e, m.testBit e=true → m'.testBit e=true) ∧
      ∀ y ∈ r, m'.testBit (dd x y)=true ∧ m'.testBit (dd y x)=true := by
  intro r
  induction r with
  | nil => intro m m' h; simp [addDiffs] at h; subst h; exact ⟨fun _ h => h,by simp⟩
  | cons y r ih =>
    intro m m' h
    simp only [addDiffs] at h
    split at h
    · simp at h
    · split at h
      · simp at h
      · obtain ⟨h1,h2⟩ := ih _ _ h
        refine ⟨fun e he => h1 e ?_,?_⟩
        · rw [testBit_or_pow, testBit_or_pow]; exact Or.inl (Or.inl he)
        · intro z hz
          rcases List.mem_cons.mp hz with rfl|hz
          · refine ⟨h1 _ ?_,h1 _ ?_⟩
            · rw [testBit_or_pow, testBit_or_pow]; exact Or.inl (Or.inr rfl)
            · rw [testBit_or_pow]; exact Or.inr rfl
          · exact h2 z hz

/-- The finished ruler, as a predicate on naturals. -/
structure Target (U : ℕ → Prop) : Prop where
  lt : ∀ a, U a → a<113
  good : GoodSet U
  forb : ∀ a b, U a → U b → a≠b → dd a b≠1 ∧ dd a b≠112
  cover : ∀ e, 2≤e → e≤111 → ∃ a b, U a ∧ U b ∧ a≠b ∧ dd a b=e

theorem Target.congr {U V : ℕ → Prop} (h : ∀ z, U z ↔ V z) (hU : Target U) : Target V where
  lt a ha := hU.lt a ((h a).mpr ha)
  good a b c e ha hb hc he := hU.good a b c e ((h a).mpr ha) ((h b).mpr hb) ((h c).mpr hc) ((h e).mpr he)
  forb a b ha hb := hU.forb a b ((h a).mpr ha) ((h b).mpr hb)
  cover e h2 h3 := by
    obtain ⟨a,b,ha,hb,hab,hd⟩ := hU.cover e h2 h3
    exact ⟨a,b,(h a).mp ha,(h b).mp hb,hab,hd⟩

/-- Invariants at a search node. -/
structure Node (T : Finset ℕ) (s : List ℕ) (m : ℕ) : Prop where
  disj : ∀ t ∈ T, t ∉ s
  nodup : s.Nodup
  tgt : Target (fun z => z ∈ T ∨ z ∈ s)
  bits : ∀ e, m.testBit e=true → Dl s e ∨ e=1 ∨ e=112
  full : ∀ e, Dl s e → m.testBit e=true

/-- Adding one element of `T` keeps the invariants. -/
theorem Node.step {T : Finset ℕ} {s : List ℕ} {m x : ℕ} (hN : Node T s m) (hx : x ∈ T) :
    ∃ m', addDiffs x s m=some m' ∧ Node (T.erase x) (x :: s) m' := by
  have hxs : x ∉ s := hN.disj x hx
  have hU := hN.tgt
  have hMx : x ∈ T ∨ x ∈ s := Or.inl hx
  have hne : ∀ y ∈ s, y≠x := fun y hy h => hxs (h ▸ hy)
  obtain ⟨m',hm',hres⟩ := addDiffs_ok x _ hU.good hMx s m (fun e => Dl s e ∨ e=1 ∨ e=112)
    (fun y hy => ⟨Or.inr hy,hne y hy⟩) hN.nodup hN.bits
    (by
      intro y hy
      have hy' : y ∈ T ∨ y ∈ s := Or.inr hy
      obtain ⟨f1,f2⟩ := hU.forb x y hMx hy' (hne y hy).symm
      obtain ⟨g1,g2⟩ := hU.forb y x hy' hMx (hne y hy)
      refine ⟨?_,?_⟩
      · rintro (⟨a,ha,b,hb,hab,h⟩|h|h)
        · exact hxs ((hU.good _ _ _ _ (Or.inr ha) (Or.inr hb) hMx hy' hab (hne y hy).symm h).1 ▸ ha)
        · exact f1 h
        · exact f2 h
      · rintro (⟨a,ha,b,hb,hab,h⟩|h|h)
        · exact hxs ((hU.good _ _ _ _ (Or.inr ha) (Or.inr hb) hy' hMx hab (hne y hy) h).2 ▸ hb)
        · exact g1 h
        · exact g2 h)
  obtain ⟨hsup,hnew⟩ := addDiffs_sup x s m m' hm'
  have hiff : ∀ z, (z ∈ T.erase x ∨ z ∈ x :: s) ↔ (z ∈ T ∨ z ∈ s) := by
    intro z
    simp only [Finset.mem_erase, List.mem_cons]
    constructor
    · rintro (⟨_,h⟩|h|h)
      · exact Or.inl h
      · exact Or.inl (h ▸ hx)
      · exact Or.inr h
    · rintro (h|h)
      · by_cases hz : z=x
        · exact Or.inr (Or.inl hz)
        · exact Or.inl ⟨hz,h⟩
      · exact Or.inr (Or.inr h)
  refine ⟨m',hm',⟨?_,?_,hU.congr (fun z => (hiff z).symm),?_,?_⟩⟩
  · intro t ht h
    obtain ⟨htx,htT⟩ := Finset.mem_erase.mp ht
    rcases List.mem_cons.mp h with h|h
    · exact htx h
    · exact hN.disj t htT h
  · exact List.nodup_cons.mpr ⟨hxs,hN.nodup⟩
  · intro e he
    rcases hres e he with (⟨a,ha,b,hb,hab,h⟩|h|h)|⟨y,hy,h|h⟩
    · exact Or.inl ⟨a,List.mem_cons_of_mem _ ha,b,List.mem_cons_of_mem _ hb,hab,h⟩
    · exact Or.inr (Or.inl h)
    · exact Or.inr (Or.inr h)
    · exact Or.inl ⟨x,List.mem_cons_self ..,y,List.mem_cons_of_mem _ hy,(hne y hy).symm,h.symm⟩
    · exact Or.inl ⟨y,List.mem_cons_of_mem _ hy,x,List.mem_cons_self ..,hne y hy,h.symm⟩
  · rintro e ⟨a,ha,b,hb,hab,h⟩
    rcases List.mem_cons.mp ha with rfl|ha' <;> rcases List.mem_cons.mp hb with rfl|hb'
    · exact absurd rfl hab
    · exact h ▸ (hnew b hb').1
    · exact h ▸ (hnew a ha').2
    · exact hsup e (hN.full e ⟨a,ha',b,hb',hab,h⟩)

theorem dd_fwd {a b d : ℕ} (ha : a<113) (hb : b<113) (h : dd a b=d) : a=(b+d)%113 := by
  unfold dd at h; omega

theorem dd_bwd {a b d : ℕ} (ha : a<113) (hb : b<113) (h : dd a b=d) : b=(a+113-d)%113 := by
  unfold dd at h; omega

theorem opt1At_of {d : ℕ} {rec : List ℕ → ℕ → Bool} {s : List ℕ} {m y z m' : ℕ}
    (hz : z=(y+d)%113 ∨ z=(y+113-d)%113) (ha : addDiffs z s m=some m') (hr : rec (z :: s) m'=true) :
    opt1At d rec s m y=true := by
  unfold opt1At
  rw [List.any_eq_true]
  refine ⟨z,by rcases hz with rfl|rfl <;> simp,?_⟩
  rw [ha]; exact hr

/-- Completeness of the search. -/
theorem go_complete : ∀ (k : ℕ) (T : Finset ℕ) (s : List ℕ) (m : ℕ),
    T.card=k → Node T s m → go k s m=true := by
  intro k
  induction k using Nat.strong_induction_on with
  | _ k ih =>
  intro T s m hc hN
  have hU := hN.tgt
  by_cases hd0 : firstGap m=0
  · match k with
    | 0 => simp [go, hd0]
    | 1 => simp [go, hd0]
    | k+2 => simp [go, hd0]
  obtain ⟨h2,h56,hbit⟩ := firstGap_pos hd0
  set d := firstGap m with hd
  have hnot : ¬ Dl s d := fun h => by rw [hN.full d h] at hbit; exact Bool.noConfusion hbit
  obtain ⟨a,b,ha,hb,hab,hdd⟩ := hU.cover d h2 (by omega)
  have hal := hU.lt a ha
  have hbl := hU.lt b hb
  -- the generic one-element branch
  have one : ∀ x ∈ T, ∀ y ∈ s, (x=(y+d)%113 ∨ x=(y+113-d)%113) → ∀ k', k=k'+1 →
      s.any (opt1At d (go k') s m)=true := by
    intro x hx y hy hxy k' hk
    obtain ⟨m',hm',hN'⟩ := hN.step hx
    have hrec := ih k' (by omega) (T.erase x) (x :: s) m' (by rw [Finset.card_erase_of_mem hx]; omega) hN'
    rw [List.any_eq_true]
    exact ⟨y,hy,opt1At_of hxy hm' hrec⟩
  rcases ha with haT|has <;> rcases hb with hbT|hbs
  · -- two new elements
    have hk : 2≤k := by
      rw [← hc]
      have : ({a,b} : Finset ℕ) ⊆ T := by
        intro z hz; simp at hz; rcases hz with rfl|rfl <;> assumption
      have := Finset.card_le_card this
      rw [Finset.card_pair hab] at this; exact this
    obtain ⟨k',rfl⟩ : ∃ k', k=k'+2 := ⟨k-2,by omega⟩
    obtain ⟨m',hm',hN'⟩ := hN.step hbT
    have haT' : a ∈ T.erase b := Finset.mem_erase.mpr ⟨hab,haT⟩
    obtain ⟨m'',hm'',hN''⟩ := hN'.step haT'
    have hrec := ih k' (by omega) ((T.erase b).erase a) (a :: b :: s) m''
      (by rw [Finset.card_erase_of_mem haT', Finset.card_erase_of_mem hbT]; omega) hN''
    have hfa := dd_fwd hal hbl hdd
    rw [go, ← hd]
    have : (List.range' 0 113).any (opt2At d (go k') s m)=true := by
      rw [List.any_eq_true]
      refine ⟨b,List.mem_range'_1.mpr ⟨by omega,by omega⟩,?_⟩
      unfold opt2At
      simp only [hm', ← hfa, hm'']
      exact hrec
    rw [this]; simp
  · -- new a, known b
    match k, hc with
    | 0, hc => rw [Finset.card_eq_zero] at hc; subst hc; simp at haT
    | 1, _ =>
      have := one a haT b hbs (Or.inl (dd_fwd hal hbl hdd)) 0 rfl
      rw [go, ← hd, this]; simp
    | k'+2, _ =>
      have := one a haT b hbs (Or.inl (dd_fwd hal hbl hdd)) (k'+1) rfl
      rw [go, ← hd, this]; simp
  · -- known a, new b
    match k, hc with
    | 0, hc => rw [Finset.card_eq_zero] at hc; subst hc; simp at hbT
    | 1, _ =>
      have := one b hbT a has (Or.inr (dd_bwd hal hbl hdd)) 0 rfl
      rw [go, ← hd, this]; simp
    | k'+2, _ =>
      have := one b hbT a has (Or.inr (dd_bwd hal hbl hdd)) (k'+1) rfl
      rw [go, ← hd, this]; simp
  · exact absurd ⟨a,has,b,hbs,hab,hdd⟩ hnot

end Symconf113.Ruler113

import Symconf113.CoverageShard113_137

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5555 : NodeCoverage113 [14,14,13,7] 7 65 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5556 : NodeCoverage113 [14,14,13,6] 6 66 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5557 : NodeCoverage113 [14,14,13,5] 5 67 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5558 : NodeCoverage113 [14,14,13,3] 3 69 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5559 : NodeCoverage113 [14,14,13] 13 72 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5549
    (ChildrenCoverage113.cons _ _ compact113_node_5550
    (ChildrenCoverage113.cons _ _ compact113_node_5551
    (ChildrenCoverage113.cons _ _ compact113_node_5552
    (ChildrenCoverage113.cons _ _ compact113_node_5553
    (ChildrenCoverage113.cons _ _ compact113_node_5554
    (ChildrenCoverage113.cons _ _ compact113_node_5555
    (ChildrenCoverage113.cons _ _ compact113_node_5556
    (ChildrenCoverage113.cons _ _ compact113_node_5557
    (ChildrenCoverage113.cons _ _ compact113_node_5558
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_5560 : NodeCoverage113 [14,14,12,12,12,12] 12 37 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5561 : NodeCoverage113 [14,14,12,12,12,11] 11 38 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5562 : NodeCoverage113 [14,14,12,12,12,10] 10 39 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5563 : NodeCoverage113 [14,14,12,12,12,9] 9 40 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5564 : NodeCoverage113 [14,14,12,12,12,8] 8 41 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5565 : NodeCoverage113 [14,14,12,12,12,7,7] 7 35 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5566 : NodeCoverage113 [14,14,12,12,12,7,6] 6 36 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5567 : NodeCoverage113 [14,14,12,12,12,7,5] 5 37 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5568 : NodeCoverage113 [14,14,12,12,12,7,3] 3 39 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5569 : NodeCoverage113 [14,14,12,12,12,7] 7 42 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5565
    (ChildrenCoverage113.cons _ _ compact113_node_5566
    (ChildrenCoverage113.cons _ _ compact113_node_5567
    (ChildrenCoverage113.cons _ _ compact113_node_5568
    ChildrenCoverage113.nil))))

theorem compact113_node_5570 : NodeCoverage113 [14,14,12,12,12,6] 6 43 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5571 : NodeCoverage113 [14,14,12,12,12,5] 5 44 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5572 : NodeCoverage113 [14,14,12,12,12,3] 3 46 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5573 : NodeCoverage113 [14,14,12,12,12] 12 49 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5560
    (ChildrenCoverage113.cons _ _ compact113_node_5561
    (ChildrenCoverage113.cons _ _ compact113_node_5562
    (ChildrenCoverage113.cons _ _ compact113_node_5563
    (ChildrenCoverage113.cons _ _ compact113_node_5564
    (ChildrenCoverage113.cons _ _ compact113_node_5569
    (ChildrenCoverage113.cons _ _ compact113_node_5570
    (ChildrenCoverage113.cons _ _ compact113_node_5571
    (ChildrenCoverage113.cons _ _ compact113_node_5572
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_5574 : NodeCoverage113 [14,14,12,12,11] 11 50 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5575 : NodeCoverage113 [14,14,12,12,10] 10 51 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5576 : NodeCoverage113 [14,14,12,12,9] 9 52 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5577 : NodeCoverage113 [14,14,12,12,8] 8 53 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5578 : NodeCoverage113 [14,14,12,12,7,7] 7 47 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5579 : NodeCoverage113 [14,14,12,12,7,6] 6 48 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5580 : NodeCoverage113 [14,14,12,12,7,5] 5 49 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5581 : NodeCoverage113 [14,14,12,12,7,3] 3 51 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5582 : NodeCoverage113 [14,14,12,12,7] 7 54 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5578
    (ChildrenCoverage113.cons _ _ compact113_node_5579
    (ChildrenCoverage113.cons _ _ compact113_node_5580
    (ChildrenCoverage113.cons _ _ compact113_node_5581
    ChildrenCoverage113.nil))))

theorem compact113_node_5583 : NodeCoverage113 [14,14,12,12,6] 6 55 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5584 : NodeCoverage113 [14,14,12,12,5] 5 56 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5585 : NodeCoverage113 [14,14,12,12,3] 3 58 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5586 : NodeCoverage113 [14,14,12,12] 12 61 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5573
    (ChildrenCoverage113.cons _ _ compact113_node_5574
    (ChildrenCoverage113.cons _ _ compact113_node_5575
    (ChildrenCoverage113.cons _ _ compact113_node_5576
    (ChildrenCoverage113.cons _ _ compact113_node_5577
    (ChildrenCoverage113.cons _ _ compact113_node_5582
    (ChildrenCoverage113.cons _ _ compact113_node_5583
    (ChildrenCoverage113.cons _ _ compact113_node_5584
    (ChildrenCoverage113.cons _ _ compact113_node_5585
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_5587 : NodeCoverage113 [14,14,12,11] 11 62 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5588 : NodeCoverage113 [14,14,12,10] 10 63 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5589 : NodeCoverage113 [14,14,12,9] 9 64 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5590 : NodeCoverage113 [14,14,12,8] 8 65 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5591 : NodeCoverage113 [14,14,12,7] 7 66 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5592 : NodeCoverage113 [14,14,12,6] 6 67 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5593 : NodeCoverage113 [14,14,12,5] 5 68 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5594 : NodeCoverage113 [14,14,12,3] 3 70 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5595 : NodeCoverage113 [14,14,12] 12 73 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5586
    (ChildrenCoverage113.cons _ _ compact113_node_5587
    (ChildrenCoverage113.cons _ _ compact113_node_5588
    (ChildrenCoverage113.cons _ _ compact113_node_5589
    (ChildrenCoverage113.cons _ _ compact113_node_5590
    (ChildrenCoverage113.cons _ _ compact113_node_5591
    (ChildrenCoverage113.cons _ _ compact113_node_5592
    (ChildrenCoverage113.cons _ _ compact113_node_5593
    (ChildrenCoverage113.cons _ _ compact113_node_5594
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_5596 : NodeCoverage113 [14,14,11,11,11,11] 11 41 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5597 : NodeCoverage113 [14,14,11,11,11,10] 10 42 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5598 : NodeCoverage113 [14,14,11,11,11,9] 9 43 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5599 : NodeCoverage113 [14,14,11,11,11,8] 8 44 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5600 : NodeCoverage113 [14,14,11,11,11,7] 7 45 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5601 : NodeCoverage113 [14,14,11,11,11,6] 6 46 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5602 : NodeCoverage113 [14,14,11,11,11,5] 5 47 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5603 : NodeCoverage113 [14,14,11,11,11,3] 3 49 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5604 : NodeCoverage113 [14,14,11,11,11] 11 52 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5596
    (ChildrenCoverage113.cons _ _ compact113_node_5597
    (ChildrenCoverage113.cons _ _ compact113_node_5598
    (ChildrenCoverage113.cons _ _ compact113_node_5599
    (ChildrenCoverage113.cons _ _ compact113_node_5600
    (ChildrenCoverage113.cons _ _ compact113_node_5601
    (ChildrenCoverage113.cons _ _ compact113_node_5602
    (ChildrenCoverage113.cons _ _ compact113_node_5603
    ChildrenCoverage113.nil))))))))

theorem compact113_node_5605 : NodeCoverage113 [14,14,11,11,10] 10 53 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5606 : NodeCoverage113 [14,14,11,11,9] 9 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5607 : NodeCoverage113 [14,14,11,11,8] 8 55 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5608 : NodeCoverage113 [14,14,11,11,7] 7 56 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

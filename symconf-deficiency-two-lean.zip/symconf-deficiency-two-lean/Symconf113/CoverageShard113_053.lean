import Symconf113.CoverageShard113_051
import Symconf113.CoverageShard113_052

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2162 : NodeCoverage113 [32,32,16,10] 10 23 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2163 : NodeCoverage113 [32,32,16,9] 9 24 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2164 : NodeCoverage113 [32,32,16,8] 8 25 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2165 : NodeCoverage113 [32,32,16,7] 7 26 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2166 : NodeCoverage113 [32,32,16,6] 6 27 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2167 : NodeCoverage113 [32,32,16,5] 5 28 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2168 : NodeCoverage113 [32,32,16,3] 3 30 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2169 : NodeCoverage113 [32,32,16] 16 33 :=
  node_fork113 (B := [16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2156
    (ChildrenCoverage113.cons _ _ compact113_node_2157
    (ChildrenCoverage113.cons _ _ compact113_node_2158
    (ChildrenCoverage113.cons _ _ compact113_node_2159
    (ChildrenCoverage113.cons _ _ compact113_node_2160
    (ChildrenCoverage113.cons _ _ compact113_node_2161
    (ChildrenCoverage113.cons _ _ compact113_node_2162
    (ChildrenCoverage113.cons _ _ compact113_node_2163
    (ChildrenCoverage113.cons _ _ compact113_node_2164
    (ChildrenCoverage113.cons _ _ compact113_node_2165
    (ChildrenCoverage113.cons _ _ compact113_node_2166
    (ChildrenCoverage113.cons _ _ compact113_node_2167
    (ChildrenCoverage113.cons _ _ compact113_node_2168
    ChildrenCoverage113.nil)))))))))))))

theorem compact113_node_2170 : NodeCoverage113 [32,32,15] 15 34 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2171 : NodeCoverage113 [32,32,14] 14 35 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2172 : NodeCoverage113 [32,32,13] 13 36 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2173 : NodeCoverage113 [32,32,12] 12 37 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2174 : NodeCoverage113 [32,32,11] 11 38 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2175 : NodeCoverage113 [32,32,10] 10 39 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2176 : NodeCoverage113 [32,32,9] 9 40 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2177 : NodeCoverage113 [32,32,8] 8 41 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2178 : NodeCoverage113 [32,32,7] 7 42 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2179 : NodeCoverage113 [32,32,6] 6 43 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2180 : NodeCoverage113 [32,32,5] 5 44 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2181 : NodeCoverage113 [32,32,3] 3 46 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2182 : NodeCoverage113 [32,32] 32 49 :=
  node_fork113 (B := [32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2129
    (ChildrenCoverage113.cons _ _ compact113_node_2130
    (ChildrenCoverage113.cons _ _ compact113_node_2131
    (ChildrenCoverage113.cons _ _ compact113_node_2132
    (ChildrenCoverage113.cons _ _ compact113_node_2133
    (ChildrenCoverage113.cons _ _ compact113_node_2134
    (ChildrenCoverage113.cons _ _ compact113_node_2135
    (ChildrenCoverage113.cons _ _ compact113_node_2136
    (ChildrenCoverage113.cons _ _ compact113_node_2137
    (ChildrenCoverage113.cons _ _ compact113_node_2138
    (ChildrenCoverage113.cons _ _ compact113_node_2139
    (ChildrenCoverage113.cons _ _ compact113_node_2140
    (ChildrenCoverage113.cons _ _ compact113_node_2141
    (ChildrenCoverage113.cons _ _ compact113_node_2142
    (ChildrenCoverage113.cons _ _ compact113_node_2143
    (ChildrenCoverage113.cons _ _ compact113_node_2144
    (ChildrenCoverage113.cons _ _ compact113_node_2169
    (ChildrenCoverage113.cons _ _ compact113_node_2170
    (ChildrenCoverage113.cons _ _ compact113_node_2171
    (ChildrenCoverage113.cons _ _ compact113_node_2172
    (ChildrenCoverage113.cons _ _ compact113_node_2173
    (ChildrenCoverage113.cons _ _ compact113_node_2174
    (ChildrenCoverage113.cons _ _ compact113_node_2175
    (ChildrenCoverage113.cons _ _ compact113_node_2176
    (ChildrenCoverage113.cons _ _ compact113_node_2177
    (ChildrenCoverage113.cons _ _ compact113_node_2178
    (ChildrenCoverage113.cons _ _ compact113_node_2179
    (ChildrenCoverage113.cons _ _ compact113_node_2180
    (ChildrenCoverage113.cons _ _ compact113_node_2181
    ChildrenCoverage113.nil)))))))))))))))))))))))))))))

theorem compact113_node_2183 : NodeCoverage113 [32,31] 31 50 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2184 : NodeCoverage113 [32,30] 30 51 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2185 : NodeCoverage113 [32,29] 29 52 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2186 : NodeCoverage113 [32,28] 28 53 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2187 : NodeCoverage113 [32,27] 27 54 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2188 : NodeCoverage113 [32,26] 26 55 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2189 : NodeCoverage113 [32,25] 25 56 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2190 : NodeCoverage113 [32,24] 24 57 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2191 : NodeCoverage113 [32,23] 23 58 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2192 : NodeCoverage113 [32,22] 22 59 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2193 : NodeCoverage113 [32,21] 21 60 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2194 : NodeCoverage113 [32,20] 20 61 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2195 : NodeCoverage113 [32,19] 19 62 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

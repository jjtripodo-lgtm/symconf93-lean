import Symconf113.CoverageShard113_042

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1741 : NodeCoverage113 [36,12,12,12,12,3] 3 26 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1742 : NodeCoverage113 [36,12,12,12,12] 12 29 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1733
    (ChildrenCoverage113.cons _ _ compact113_node_1734
    (ChildrenCoverage113.cons _ _ compact113_node_1735
    (ChildrenCoverage113.cons _ _ compact113_node_1736
    (ChildrenCoverage113.cons _ _ compact113_node_1737
    (ChildrenCoverage113.cons _ _ compact113_node_1738
    (ChildrenCoverage113.cons _ _ compact113_node_1739
    (ChildrenCoverage113.cons _ _ compact113_node_1740
    (ChildrenCoverage113.cons _ _ compact113_node_1741
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_1743 : NodeCoverage113 [36,12,12,12,11] 11 30 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1744 : NodeCoverage113 [36,12,12,12,10] 10 31 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1745 : NodeCoverage113 [36,12,12,12,9,9,9] 9 14 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1746 : NodeCoverage113 [36,12,12,12,9,9,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1747 : NodeCoverage113 [36,12,12,12,9,9,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1748 : NodeCoverage113 [36,12,12,12,9,9,6] 6 17 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1749 : NodeCoverage113 [36,12,12,12,9,9,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1750 : NodeCoverage113 [36,12,12,12,9,9,3] 3 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1751 : NodeCoverage113 [36,12,12,12,9,9] 9 23 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1745
    (ChildrenCoverage113.cons _ _ compact113_node_1746
    (ChildrenCoverage113.cons _ _ compact113_node_1747
    (ChildrenCoverage113.cons _ _ compact113_node_1748
    (ChildrenCoverage113.cons _ _ compact113_node_1749
    (ChildrenCoverage113.cons _ _ compact113_node_1750
    ChildrenCoverage113.nil))))))

theorem compact113_node_1752 : NodeCoverage113 [36,12,12,12,9,8] 8 24 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1753 : NodeCoverage113 [36,12,12,12,9,7] 7 25 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1754 : NodeCoverage113 [36,12,12,12,9,6] 6 26 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1755 : NodeCoverage113 [36,12,12,12,9,5] 5 27 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1756 : NodeCoverage113 [36,12,12,12,9,3] 3 29 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1757 : NodeCoverage113 [36,12,12,12,9] 9 32 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1751
    (ChildrenCoverage113.cons _ _ compact113_node_1752
    (ChildrenCoverage113.cons _ _ compact113_node_1753
    (ChildrenCoverage113.cons _ _ compact113_node_1754
    (ChildrenCoverage113.cons _ _ compact113_node_1755
    (ChildrenCoverage113.cons _ _ compact113_node_1756
    ChildrenCoverage113.nil))))))

theorem compact113_node_1758 : NodeCoverage113 [36,12,12,12,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1759 : NodeCoverage113 [36,12,12,12,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1760 : NodeCoverage113 [36,12,12,12,6] 6 35 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1761 : NodeCoverage113 [36,12,12,12,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1762 : NodeCoverage113 [36,12,12,12,3] 3 38 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1763 : NodeCoverage113 [36,12,12,12] 12 41 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1742
    (ChildrenCoverage113.cons _ _ compact113_node_1743
    (ChildrenCoverage113.cons _ _ compact113_node_1744
    (ChildrenCoverage113.cons _ _ compact113_node_1757
    (ChildrenCoverage113.cons _ _ compact113_node_1758
    (ChildrenCoverage113.cons _ _ compact113_node_1759
    (ChildrenCoverage113.cons _ _ compact113_node_1760
    (ChildrenCoverage113.cons _ _ compact113_node_1761
    (ChildrenCoverage113.cons _ _ compact113_node_1762
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_1764 : NodeCoverage113 [36,12,12,11] 11 42 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1765 : NodeCoverage113 [36,12,12,10] 10 43 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1766 : NodeCoverage113 [36,12,12,9,9,9,9] 9 17 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1767 : NodeCoverage113 [36,12,12,9,9,9,8] 8 18 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1768 : NodeCoverage113 [36,12,12,9,9,9,7] 7 19 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1769 : NodeCoverage113 [36,12,12,9,9,9,6] 6 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1770 : NodeCoverage113 [36,12,12,9,9,9,5] 5 21 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1771 : NodeCoverage113 [36,12,12,9,9,9,3] 3 23 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1772 : NodeCoverage113 [36,12,12,9,9,9] 9 26 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1766
    (ChildrenCoverage113.cons _ _ compact113_node_1767
    (ChildrenCoverage113.cons _ _ compact113_node_1768
    (ChildrenCoverage113.cons _ _ compact113_node_1769
    (ChildrenCoverage113.cons _ _ compact113_node_1770
    (ChildrenCoverage113.cons _ _ compact113_node_1771
    ChildrenCoverage113.nil))))))

theorem compact113_node_1773 : NodeCoverage113 [36,12,12,9,9,8] 8 27 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1774 : NodeCoverage113 [36,12,12,9,9,7] 7 28 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1775 : NodeCoverage113 [36,12,12,9,9,6] 6 29 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1776 : NodeCoverage113 [36,12,12,9,9,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1777 : NodeCoverage113 [36,12,12,9,9,3] 3 32 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1778 : NodeCoverage113 [36,12,12,9,9] 9 35 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1772
    (ChildrenCoverage113.cons _ _ compact113_node_1773
    (ChildrenCoverage113.cons _ _ compact113_node_1774
    (ChildrenCoverage113.cons _ _ compact113_node_1775
    (ChildrenCoverage113.cons _ _ compact113_node_1776
    (ChildrenCoverage113.cons _ _ compact113_node_1777
    ChildrenCoverage113.nil))))))

theorem compact113_node_1779 : NodeCoverage113 [36,12,12,9,8] 8 36 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1780 : NodeCoverage113 [36,12,12,9,7] 7 37 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1781 : NodeCoverage113 [36,12,12,9,6] 6 38 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1782 : NodeCoverage113 [36,12,12,9,5] 5 39 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1783 : NodeCoverage113 [36,12,12,9,3] 3 41 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1784 : NodeCoverage113 [36,12,12,9] 9 44 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1778
    (ChildrenCoverage113.cons _ _ compact113_node_1779
    (ChildrenCoverage113.cons _ _ compact113_node_1780
    (ChildrenCoverage113.cons _ _ compact113_node_1781
    (ChildrenCoverage113.cons _ _ compact113_node_1782
    (ChildrenCoverage113.cons _ _ compact113_node_1783
    ChildrenCoverage113.nil))))))

theorem compact113_node_1785 : NodeCoverage113 [36,12,12,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1786 : NodeCoverage113 [36,12,12,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1787 : NodeCoverage113 [36,12,12,6] 6 47 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1788 : NodeCoverage113 [36,12,12,5] 5 48 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

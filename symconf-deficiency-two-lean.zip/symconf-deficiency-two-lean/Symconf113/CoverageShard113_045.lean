import Symconf113.CoverageShard113_038
import Symconf113.CoverageShard113_039
import Symconf113.CoverageShard113_042
import Symconf113.CoverageShard113_044

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1843 : NodeCoverage113 [36,9,9,9,9,9,9,3] 3 20 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1844 : NodeCoverage113 [36,9,9,9,9,9,9] 9 23 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1838
    (ChildrenCoverage113.cons _ _ compact113_node_1839
    (ChildrenCoverage113.cons _ _ compact113_node_1840
    (ChildrenCoverage113.cons _ _ compact113_node_1841
    (ChildrenCoverage113.cons _ _ compact113_node_1842
    (ChildrenCoverage113.cons _ _ compact113_node_1843
    ChildrenCoverage113.nil))))))

theorem compact113_node_1845 : NodeCoverage113 [36,9,9,9,9,9,8] 8 24 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1846 : NodeCoverage113 [36,9,9,9,9,9,7] 7 25 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1847 : NodeCoverage113 [36,9,9,9,9,9,6] 6 26 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1848 : NodeCoverage113 [36,9,9,9,9,9,5] 5 27 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1849 : NodeCoverage113 [36,9,9,9,9,9,3] 3 29 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1850 : NodeCoverage113 [36,9,9,9,9,9] 9 32 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1844
    (ChildrenCoverage113.cons _ _ compact113_node_1845
    (ChildrenCoverage113.cons _ _ compact113_node_1846
    (ChildrenCoverage113.cons _ _ compact113_node_1847
    (ChildrenCoverage113.cons _ _ compact113_node_1848
    (ChildrenCoverage113.cons _ _ compact113_node_1849
    ChildrenCoverage113.nil))))))

theorem compact113_node_1851 : NodeCoverage113 [36,9,9,9,9,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1852 : NodeCoverage113 [36,9,9,9,9,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1853 : NodeCoverage113 [36,9,9,9,9,6] 6 35 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1854 : NodeCoverage113 [36,9,9,9,9,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1855 : NodeCoverage113 [36,9,9,9,9,3] 3 38 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1856 : NodeCoverage113 [36,9,9,9,9] 9 41 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1850
    (ChildrenCoverage113.cons _ _ compact113_node_1851
    (ChildrenCoverage113.cons _ _ compact113_node_1852
    (ChildrenCoverage113.cons _ _ compact113_node_1853
    (ChildrenCoverage113.cons _ _ compact113_node_1854
    (ChildrenCoverage113.cons _ _ compact113_node_1855
    ChildrenCoverage113.nil))))))

theorem compact113_node_1857 : NodeCoverage113 [36,9,9,9,8] 8 42 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1858 : NodeCoverage113 [36,9,9,9,7] 7 43 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1859 : NodeCoverage113 [36,9,9,9,6] 6 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1860 : NodeCoverage113 [36,9,9,9,5] 5 45 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1861 : NodeCoverage113 [36,9,9,9,3] 3 47 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1862 : NodeCoverage113 [36,9,9,9] 9 50 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1856
    (ChildrenCoverage113.cons _ _ compact113_node_1857
    (ChildrenCoverage113.cons _ _ compact113_node_1858
    (ChildrenCoverage113.cons _ _ compact113_node_1859
    (ChildrenCoverage113.cons _ _ compact113_node_1860
    (ChildrenCoverage113.cons _ _ compact113_node_1861
    ChildrenCoverage113.nil))))))

theorem compact113_node_1863 : NodeCoverage113 [36,9,9,8] 8 51 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1864 : NodeCoverage113 [36,9,9,7] 7 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1865 : NodeCoverage113 [36,9,9,6] 6 53 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1866 : NodeCoverage113 [36,9,9,5] 5 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1867 : NodeCoverage113 [36,9,9,3] 3 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1868 : NodeCoverage113 [36,9,9] 9 59 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1862
    (ChildrenCoverage113.cons _ _ compact113_node_1863
    (ChildrenCoverage113.cons _ _ compact113_node_1864
    (ChildrenCoverage113.cons _ _ compact113_node_1865
    (ChildrenCoverage113.cons _ _ compact113_node_1866
    (ChildrenCoverage113.cons _ _ compact113_node_1867
    ChildrenCoverage113.nil))))))

theorem compact113_node_1869 : NodeCoverage113 [36,9,8] 8 60 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1870 : NodeCoverage113 [36,9,7] 7 61 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1871 : NodeCoverage113 [36,9,6] 6 62 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1872 : NodeCoverage113 [36,9,5] 5 63 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1873 : NodeCoverage113 [36,9,3] 3 65 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1874 : NodeCoverage113 [36,9] 9 68 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1868
    (ChildrenCoverage113.cons _ _ compact113_node_1869
    (ChildrenCoverage113.cons _ _ compact113_node_1870
    (ChildrenCoverage113.cons _ _ compact113_node_1871
    (ChildrenCoverage113.cons _ _ compact113_node_1872
    (ChildrenCoverage113.cons _ _ compact113_node_1873
    ChildrenCoverage113.nil))))))

theorem compact113_node_1875 : NodeCoverage113 [36,8] 8 69 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1876 : NodeCoverage113 [36,7] 7 70 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1877 : NodeCoverage113 [36,6] 6 71 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1878 : NodeCoverage113 [36,5] 5 72 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1879 : NodeCoverage113 [36,3] 3 74 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1880 : NodeCoverage113 [36] 36 77 :=
  node_fork113 (B := [36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1587
    (ChildrenCoverage113.cons _ _ compact113_node_1588
    (ChildrenCoverage113.cons _ _ compact113_node_1589
    (ChildrenCoverage113.cons _ _ compact113_node_1590
    (ChildrenCoverage113.cons _ _ compact113_node_1591
    (ChildrenCoverage113.cons _ _ compact113_node_1592
    (ChildrenCoverage113.cons _ _ compact113_node_1593
    (ChildrenCoverage113.cons _ _ compact113_node_1594
    (ChildrenCoverage113.cons _ _ compact113_node_1595
    (ChildrenCoverage113.cons _ _ compact113_node_1596
    (ChildrenCoverage113.cons _ _ compact113_node_1597
    (ChildrenCoverage113.cons _ _ compact113_node_1598
    (ChildrenCoverage113.cons _ _ compact113_node_1599
    (ChildrenCoverage113.cons _ _ compact113_node_1600
    (ChildrenCoverage113.cons _ _ compact113_node_1601
    (ChildrenCoverage113.cons _ _ compact113_node_1602
    (ChildrenCoverage113.cons _ _ compact113_node_1603
    (ChildrenCoverage113.cons _ _ compact113_node_1604
    (ChildrenCoverage113.cons _ _ compact113_node_1707
    (ChildrenCoverage113.cons _ _ compact113_node_1708
    (ChildrenCoverage113.cons _ _ compact113_node_1709
    (ChildrenCoverage113.cons _ _ compact113_node_1710
    (ChildrenCoverage113.cons _ _ compact113_node_1722
    (ChildrenCoverage113.cons _ _ compact113_node_1723
    (ChildrenCoverage113.cons _ _ compact113_node_1811
    (ChildrenCoverage113.cons _ _ compact113_node_1820
    (ChildrenCoverage113.cons _ _ compact113_node_1828
    (ChildrenCoverage113.cons _ _ compact113_node_1874
    (ChildrenCoverage113.cons _ _ compact113_node_1875
    (ChildrenCoverage113.cons _ _ compact113_node_1876
    (ChildrenCoverage113.cons _ _ compact113_node_1877
    (ChildrenCoverage113.cons _ _ compact113_node_1878
    (ChildrenCoverage113.cons _ _ compact113_node_1879
    ChildrenCoverage113.nil)))))))))))))))))))))))))))))))))

theorem compact113_node_1881 : NodeCoverage113 [35,35,35,8] 8 0 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1882 : NodeCoverage113 [35,35,35,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1883 : NodeCoverage113 [35,35,35,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1884 : NodeCoverage113 [35,35,35] 35 8 :=
  node_fork113 (B := [8,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1881
    (ChildrenCoverage113.cons _ _ compact113_node_1882
    (ChildrenCoverage113.cons _ _ compact113_node_1883
    ChildrenCoverage113.nil)))

theorem compact113_node_1885 : NodeCoverage113 [35,35,34] 34 9 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

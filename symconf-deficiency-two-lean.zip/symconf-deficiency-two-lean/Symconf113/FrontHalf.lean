import Symconf113.OriginalCoordinates

/-! Kernel-checked front half for an arbitrary original 113-point incidence:
both leaves are unions of cycles with one common decreasing cycle profile,
the incidence splits into physical cyclic blocks with constant degrees, and
the profile satisfies every exact moment, cross-moment and period bound.
No cyclicity, automorphism or profile premise. The back half (profile sieve
and per-profile exclusions) is NOT formalized here. -/
namespace Symconf113
open scoped BigOperators

theorem original_front_half {A : Int113} (hA : Incidence113 A) :
    ∃ P : List ℕ, P.sum=113 ∧ (∀ a∈P,3≤a) ∧ P.Pairwise (· ≥ ·) ∧
      Nonempty (PhysicalBlocks A P) ∧ Nonempty (OriginalProfileFacts P) := by
  obtain ⟨P,hS,hpos,hsort,⟨R⟩,⟨C⟩⟩ := original_ordered_cycle_coords hA
  let G := physical_of_ordered_cycles hA hpos R C
  exact ⟨P,hS,hpos,hsort,⟨G⟩,⟨physical_blocks_to_profile hA G hS hpos hsort⟩⟩

end Symconf113

import Symconf113.CoverageShard113_165

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_7491 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 4 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7492 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3] 3 7 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7491
    ChildrenCoverage113.nil)

theorem compact113_node_7493 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3] 3 10 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7492
    ChildrenCoverage113.nil)

theorem compact113_node_7494 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3] 3 13 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7493
    ChildrenCoverage113.nil)

theorem compact113_node_7495 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3] 3 16 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7494
    ChildrenCoverage113.nil)

theorem compact113_node_7496 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3] 3 19 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7495
    ChildrenCoverage113.nil)

theorem compact113_node_7497 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3] 3 22 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7496
    ChildrenCoverage113.nil)

theorem compact113_node_7498 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3] 3 25 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7497
    ChildrenCoverage113.nil)

theorem compact113_node_7499 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3] 3 28 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7498
    ChildrenCoverage113.nil)

theorem compact113_node_7500 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3] 3 31 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7499
    ChildrenCoverage113.nil)

theorem compact113_node_7501 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3] 3 34 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7500
    ChildrenCoverage113.nil)

theorem compact113_node_7502 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3] 3 37 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7501
    ChildrenCoverage113.nil)

theorem compact113_node_7503 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,3] 3 40 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7502
    ChildrenCoverage113.nil)

theorem compact113_node_7504 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5] 5 43 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7490
    (ChildrenCoverage113.cons _ _ compact113_node_7503
    ChildrenCoverage113.nil))

theorem compact113_node_7505 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_7506 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7505
    ChildrenCoverage113.nil)

theorem compact113_node_7507 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7506
    ChildrenCoverage113.nil)

theorem compact113_node_7508 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7507
    ChildrenCoverage113.nil)

theorem compact113_node_7509 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7508
    ChildrenCoverage113.nil)

theorem compact113_node_7510 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7509
    ChildrenCoverage113.nil)

theorem compact113_node_7511 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3] 3 18 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7510
    ChildrenCoverage113.nil)

theorem compact113_node_7512 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3] 3 21 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7511
    ChildrenCoverage113.nil)

theorem compact113_node_7513 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3] 3 24 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7512
    ChildrenCoverage113.nil)

theorem compact113_node_7514 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3] 3 27 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7513
    ChildrenCoverage113.nil)

theorem compact113_node_7515 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3] 3 30 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7514
    ChildrenCoverage113.nil)

theorem compact113_node_7516 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3] 3 33 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7515
    ChildrenCoverage113.nil)

theorem compact113_node_7517 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3] 3 36 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7516
    ChildrenCoverage113.nil)

theorem compact113_node_7518 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3] 3 39 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7517
    ChildrenCoverage113.nil)

theorem compact113_node_7519 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3,3] 3 42 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7518
    ChildrenCoverage113.nil)

theorem compact113_node_7520 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,3] 3 45 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7519
    ChildrenCoverage113.nil)

theorem compact113_node_7521 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5] 5 48 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7504
    (ChildrenCoverage113.cons _ _ compact113_node_7520
    ChildrenCoverage113.nil))

theorem compact113_node_7522 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7523 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7522
    ChildrenCoverage113.nil)

theorem compact113_node_7524 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7523
    ChildrenCoverage113.nil)

theorem compact113_node_7525 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7524
    ChildrenCoverage113.nil)

theorem compact113_node_7526 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7525
    ChildrenCoverage113.nil)

theorem compact113_node_7527 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7526
    ChildrenCoverage113.nil)

theorem compact113_node_7528 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7527
    ChildrenCoverage113.nil)

theorem compact113_node_7529 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7528
    ChildrenCoverage113.nil)

theorem compact113_node_7530 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7529
    ChildrenCoverage113.nil)

theorem compact113_node_7531 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7530
    ChildrenCoverage113.nil)

theorem compact113_node_7532 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3] 3 35 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7531
    ChildrenCoverage113.nil)

theorem compact113_node_7533 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3] 3 38 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7532
    ChildrenCoverage113.nil)

theorem compact113_node_7534 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3] 3 41 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7533
    ChildrenCoverage113.nil)

theorem compact113_node_7535 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3,3,3] 3 44 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7534
    ChildrenCoverage113.nil)

theorem compact113_node_7536 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3,3] 3 47 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7535
    ChildrenCoverage113.nil)

theorem compact113_node_7537 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,3] 3 50 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7536
    ChildrenCoverage113.nil)

theorem compact113_node_7538 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5] 5 53 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7521
    (ChildrenCoverage113.cons _ _ compact113_node_7537
    ChildrenCoverage113.nil))

theorem compact113_node_7539 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 4 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7540 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 7 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7539
    ChildrenCoverage113.nil)

theorem compact113_node_7541 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 10 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7540
    ChildrenCoverage113.nil)

theorem compact113_node_7542 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 13 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7541
    ChildrenCoverage113.nil)

theorem compact113_node_7543 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 16 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7542
    ChildrenCoverage113.nil)

theorem compact113_node_7544 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 19 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7543
    ChildrenCoverage113.nil)

theorem compact113_node_7545 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3] 3 22 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7544
    ChildrenCoverage113.nil)

theorem compact113_node_7546 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3] 3 25 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7545
    ChildrenCoverage113.nil)

theorem compact113_node_7547 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3] 3 28 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7546
    ChildrenCoverage113.nil)

theorem compact113_node_7548 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3] 3 31 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7547
    ChildrenCoverage113.nil)

theorem compact113_node_7549 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3] 3 34 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7548
    ChildrenCoverage113.nil)

theorem compact113_node_7550 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3] 3 37 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7549
    ChildrenCoverage113.nil)

theorem compact113_node_7551 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3] 3 40 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7550
    ChildrenCoverage113.nil)

theorem compact113_node_7552 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3] 3 43 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7551
    ChildrenCoverage113.nil)

theorem compact113_node_7553 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3,3] 3 46 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7552
    ChildrenCoverage113.nil)

theorem compact113_node_7554 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3,3] 3 49 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7553
    ChildrenCoverage113.nil)

theorem compact113_node_7555 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3,3] 3 52 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7554
    ChildrenCoverage113.nil)

theorem compact113_node_7556 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,3] 3 55 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7555
    ChildrenCoverage113.nil)

theorem compact113_node_7557 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5] 5 58 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7538
    (ChildrenCoverage113.cons _ _ compact113_node_7556
    ChildrenCoverage113.nil))

theorem compact113_node_7558 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_7559 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7558
    ChildrenCoverage113.nil)

theorem compact113_node_7560 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7559
    ChildrenCoverage113.nil)

theorem compact113_node_7561 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7560
    ChildrenCoverage113.nil)

theorem compact113_node_7562 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7561
    ChildrenCoverage113.nil)

theorem compact113_node_7563 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7562
    ChildrenCoverage113.nil)

theorem compact113_node_7564 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 18 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7563
    ChildrenCoverage113.nil)

theorem compact113_node_7565 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 21 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7564
    ChildrenCoverage113.nil)

end Symconf113

import Symconf113.CoverageShard113_109

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4084 : NodeCoverage113 [20,20,10,10,10,5] 5 38 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4085 : NodeCoverage113 [20,20,10,10,10,3] 3 40 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4086 : NodeCoverage113 [20,20,10,10,10] 10 43 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4079
    (ChildrenCoverage113.cons _ _ compact113_node_4080
    (ChildrenCoverage113.cons _ _ compact113_node_4081
    (ChildrenCoverage113.cons _ _ compact113_node_4082
    (ChildrenCoverage113.cons _ _ compact113_node_4083
    (ChildrenCoverage113.cons _ _ compact113_node_4084
    (ChildrenCoverage113.cons _ _ compact113_node_4085
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4087 : NodeCoverage113 [20,20,10,10,9] 9 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4088 : NodeCoverage113 [20,20,10,10,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4089 : NodeCoverage113 [20,20,10,10,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4090 : NodeCoverage113 [20,20,10,10,6] 6 47 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4091 : NodeCoverage113 [20,20,10,10,5] 5 48 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4092 : NodeCoverage113 [20,20,10,10,3] 3 50 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4093 : NodeCoverage113 [20,20,10,10] 10 53 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4086
    (ChildrenCoverage113.cons _ _ compact113_node_4087
    (ChildrenCoverage113.cons _ _ compact113_node_4088
    (ChildrenCoverage113.cons _ _ compact113_node_4089
    (ChildrenCoverage113.cons _ _ compact113_node_4090
    (ChildrenCoverage113.cons _ _ compact113_node_4091
    (ChildrenCoverage113.cons _ _ compact113_node_4092
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4094 : NodeCoverage113 [20,20,10,9] 9 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4095 : NodeCoverage113 [20,20,10,8] 8 55 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4096 : NodeCoverage113 [20,20,10,7] 7 56 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4097 : NodeCoverage113 [20,20,10,6] 6 57 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4098 : NodeCoverage113 [20,20,10,5] 5 58 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4099 : NodeCoverage113 [20,20,10,3] 3 60 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4100 : NodeCoverage113 [20,20,10] 10 63 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4093
    (ChildrenCoverage113.cons _ _ compact113_node_4094
    (ChildrenCoverage113.cons _ _ compact113_node_4095
    (ChildrenCoverage113.cons _ _ compact113_node_4096
    (ChildrenCoverage113.cons _ _ compact113_node_4097
    (ChildrenCoverage113.cons _ _ compact113_node_4098
    (ChildrenCoverage113.cons _ _ compact113_node_4099
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4101 : NodeCoverage113 [20,20,9] 9 64 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4102 : NodeCoverage113 [20,20,8] 8 65 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4103 : NodeCoverage113 [20,20,7] 7 66 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4104 : NodeCoverage113 [20,20,6] 6 67 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4105 : NodeCoverage113 [20,20,5] 5 68 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4106 : NodeCoverage113 [20,20,3] 3 70 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4107 : NodeCoverage113 [20,20] 20 73 :=
  node_fork113 (B := [20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4027
    (ChildrenCoverage113.cons _ _ compact113_node_4028
    (ChildrenCoverage113.cons _ _ compact113_node_4029
    (ChildrenCoverage113.cons _ _ compact113_node_4030
    (ChildrenCoverage113.cons _ _ compact113_node_4031
    (ChildrenCoverage113.cons _ _ compact113_node_4032
    (ChildrenCoverage113.cons _ _ compact113_node_4033
    (ChildrenCoverage113.cons _ _ compact113_node_4034
    (ChildrenCoverage113.cons _ _ compact113_node_4035
    (ChildrenCoverage113.cons _ _ compact113_node_4036
    (ChildrenCoverage113.cons _ _ compact113_node_4100
    (ChildrenCoverage113.cons _ _ compact113_node_4101
    (ChildrenCoverage113.cons _ _ compact113_node_4102
    (ChildrenCoverage113.cons _ _ compact113_node_4103
    (ChildrenCoverage113.cons _ _ compact113_node_4104
    (ChildrenCoverage113.cons _ _ compact113_node_4105
    (ChildrenCoverage113.cons _ _ compact113_node_4106
    ChildrenCoverage113.nil)))))))))))))))))

theorem compact113_node_4108 : NodeCoverage113 [20,19] 19 74 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4109 : NodeCoverage113 [20,18,18] 18 57 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4110 : NodeCoverage113 [20,18,17] 17 58 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4111 : NodeCoverage113 [20,18,16] 16 59 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4112 : NodeCoverage113 [20,18,15] 15 60 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4113 : NodeCoverage113 [20,18,14] 14 61 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4114 : NodeCoverage113 [20,18,13] 13 62 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4115 : NodeCoverage113 [20,18,12] 12 63 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4116 : NodeCoverage113 [20,18,11] 11 64 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4117 : NodeCoverage113 [20,18,10] 10 65 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4118 : NodeCoverage113 [20,18,9] 9 66 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4119 : NodeCoverage113 [20,18,8] 8 67 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4120 : NodeCoverage113 [20,18,7] 7 68 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4121 : NodeCoverage113 [20,18,6] 6 69 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4122 : NodeCoverage113 [20,18,5] 5 70 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

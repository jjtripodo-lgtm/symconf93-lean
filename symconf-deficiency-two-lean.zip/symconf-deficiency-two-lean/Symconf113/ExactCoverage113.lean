import Symconf113.CoverageShard113_167
namespace Symconf113

/-- Exhaustive exact original coverage: every sieve-passing profile is one of
the nineteen listed in `profiles19`. -/
theorem exact_original_coverage113 : Coverage113 :=
  coverage113_of_root compact113_node_7634

end Symconf113

#print axioms Symconf113.exact_original_coverage113

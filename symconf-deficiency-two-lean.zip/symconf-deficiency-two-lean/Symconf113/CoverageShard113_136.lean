import Symconf113.CoverageShard113_135

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5405 : NodeCoverage113 [14,14,14,14,14,7,7,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5406 : NodeCoverage113 [14,14,14,14,14,7,7,7,7,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5407 : NodeCoverage113 [14,14,14,14,14,7,7,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5403
    (ChildrenCoverage113.cons _ _ compact113_node_5404
    (ChildrenCoverage113.cons _ _ compact113_node_5405
    (ChildrenCoverage113.cons _ _ compact113_node_5406
    ChildrenCoverage113.nil))))

theorem compact113_node_5408 : NodeCoverage113 [14,14,14,14,14,7,7,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5409 : NodeCoverage113 [14,14,14,14,14,7,7,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5410 : NodeCoverage113 [14,14,14,14,14,7,7,7,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5411 : NodeCoverage113 [14,14,14,14,14,7,7,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5407
    (ChildrenCoverage113.cons _ _ compact113_node_5408
    (ChildrenCoverage113.cons _ _ compact113_node_5409
    (ChildrenCoverage113.cons _ _ compact113_node_5410
    ChildrenCoverage113.nil))))

theorem compact113_node_5412 : NodeCoverage113 [14,14,14,14,14,7,7,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5413 : NodeCoverage113 [14,14,14,14,14,7,7,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5414 : NodeCoverage113 [14,14,14,14,14,7,7,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5415 : NodeCoverage113 [14,14,14,14,14,7,7] 7 29 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5411
    (ChildrenCoverage113.cons _ _ compact113_node_5412
    (ChildrenCoverage113.cons _ _ compact113_node_5413
    (ChildrenCoverage113.cons _ _ compact113_node_5414
    ChildrenCoverage113.nil))))

theorem compact113_node_5416 : NodeCoverage113 [14,14,14,14,14,7,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5417 : NodeCoverage113 [14,14,14,14,14,7,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5418 : NodeCoverage113 [14,14,14,14,14,7,3,3,3,3,3,3,3,3,3,3,3,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_5419 : NodeCoverage113 [14,14,14,14,14,7,3,3,3,3,3,3,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5418
    ChildrenCoverage113.nil)

theorem compact113_node_5420 : NodeCoverage113 [14,14,14,14,14,7,3,3,3,3,3,3,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5419
    ChildrenCoverage113.nil)

theorem compact113_node_5421 : NodeCoverage113 [14,14,14,14,14,7,3,3,3,3,3,3,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5420
    ChildrenCoverage113.nil)

theorem compact113_node_5422 : NodeCoverage113 [14,14,14,14,14,7,3,3,3,3,3,3,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5421
    ChildrenCoverage113.nil)

theorem compact113_node_5423 : NodeCoverage113 [14,14,14,14,14,7,3,3,3,3,3,3,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5422
    ChildrenCoverage113.nil)

theorem compact113_node_5424 : NodeCoverage113 [14,14,14,14,14,7,3,3,3,3,3,3] 3 18 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5423
    ChildrenCoverage113.nil)

theorem compact113_node_5425 : NodeCoverage113 [14,14,14,14,14,7,3,3,3,3,3] 3 21 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5424
    ChildrenCoverage113.nil)

theorem compact113_node_5426 : NodeCoverage113 [14,14,14,14,14,7,3,3,3,3] 3 24 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5425
    ChildrenCoverage113.nil)

theorem compact113_node_5427 : NodeCoverage113 [14,14,14,14,14,7,3,3,3] 3 27 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5426
    ChildrenCoverage113.nil)

theorem compact113_node_5428 : NodeCoverage113 [14,14,14,14,14,7,3,3] 3 30 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5427
    ChildrenCoverage113.nil)

theorem compact113_node_5429 : NodeCoverage113 [14,14,14,14,14,7,3] 3 33 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5428
    ChildrenCoverage113.nil)

theorem compact113_node_5430 : NodeCoverage113 [14,14,14,14,14,7] 7 36 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5415
    (ChildrenCoverage113.cons _ _ compact113_node_5416
    (ChildrenCoverage113.cons _ _ compact113_node_5417
    (ChildrenCoverage113.cons _ _ compact113_node_5429
    ChildrenCoverage113.nil))))

theorem compact113_node_5431 : NodeCoverage113 [14,14,14,14,14,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5432 : NodeCoverage113 [14,14,14,14,14,5] 5 38 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5433 : NodeCoverage113 [14,14,14,14,14,3] 3 40 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5434 : NodeCoverage113 [14,14,14,14,14] 14 43 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5394
    (ChildrenCoverage113.cons _ _ compact113_node_5395
    (ChildrenCoverage113.cons _ _ compact113_node_5396
    (ChildrenCoverage113.cons _ _ compact113_node_5397
    (ChildrenCoverage113.cons _ _ compact113_node_5398
    (ChildrenCoverage113.cons _ _ compact113_node_5399
    (ChildrenCoverage113.cons _ _ compact113_node_5400
    (ChildrenCoverage113.cons _ _ compact113_node_5430
    (ChildrenCoverage113.cons _ _ compact113_node_5431
    (ChildrenCoverage113.cons _ _ compact113_node_5432
    (ChildrenCoverage113.cons _ _ compact113_node_5433
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_5435 : NodeCoverage113 [14,14,14,14,13] 13 44 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5436 : NodeCoverage113 [14,14,14,14,12] 12 45 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5437 : NodeCoverage113 [14,14,14,14,11] 11 46 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5438 : NodeCoverage113 [14,14,14,14,10] 10 47 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5439 : NodeCoverage113 [14,14,14,14,9] 9 48 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5440 : NodeCoverage113 [14,14,14,14,8] 8 49 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5441 : NodeCoverage113 [14,14,14,14,7,7,7,7,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5442 : NodeCoverage113 [14,14,14,14,7,7,7,7,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5443 : NodeCoverage113 [14,14,14,14,7,7,7,7,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5441
    (ChildrenCoverage113.cons _ _ compact113_node_5442
    ChildrenCoverage113.nil))

theorem compact113_node_5444 : NodeCoverage113 [14,14,14,14,7,7,7,7,7,7,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5445 : NodeCoverage113 [14,14,14,14,7,7,7,7,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5446 : NodeCoverage113 [14,14,14,14,7,7,7,7,7,7,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5447 : NodeCoverage113 [14,14,14,14,7,7,7,7,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5443
    (ChildrenCoverage113.cons _ _ compact113_node_5444
    (ChildrenCoverage113.cons _ _ compact113_node_5445
    (ChildrenCoverage113.cons _ _ compact113_node_5446
    ChildrenCoverage113.nil))))

theorem compact113_node_5448 : NodeCoverage113 [14,14,14,14,7,7,7,7,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5449 : NodeCoverage113 [14,14,14,14,7,7,7,7,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5450 : NodeCoverage113 [14,14,14,14,7,7,7,7,7,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5451 : NodeCoverage113 [14,14,14,14,7,7,7,7,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5447
    (ChildrenCoverage113.cons _ _ compact113_node_5448
    (ChildrenCoverage113.cons _ _ compact113_node_5449
    (ChildrenCoverage113.cons _ _ compact113_node_5450
    ChildrenCoverage113.nil))))

theorem compact113_node_5452 : NodeCoverage113 [14,14,14,14,7,7,7,7,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5453 : NodeCoverage113 [14,14,14,14,7,7,7,7,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5454 : NodeCoverage113 [14,14,14,14,7,7,7,7,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5455 : NodeCoverage113 [14,14,14,14,7,7,7,7] 7 29 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5451
    (ChildrenCoverage113.cons _ _ compact113_node_5452
    (ChildrenCoverage113.cons _ _ compact113_node_5453
    (ChildrenCoverage113.cons _ _ compact113_node_5454
    ChildrenCoverage113.nil))))

theorem compact113_node_5456 : NodeCoverage113 [14,14,14,14,7,7,7,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5457 : NodeCoverage113 [14,14,14,14,7,7,7,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5458 : NodeCoverage113 [14,14,14,14,7,7,7,3,3,3,3,3,3,3,3,3,3,3,3] 3 0 :=
  node_no_weak_demand113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5459 : NodeCoverage113 [14,14,14,14,7,7,7,3,3,3,3,3,3,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5458
    ChildrenCoverage113.nil)

theorem compact113_node_5460 : NodeCoverage113 [14,14,14,14,7,7,7,3,3,3,3,3,3,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5459
    ChildrenCoverage113.nil)

theorem compact113_node_5461 : NodeCoverage113 [14,14,14,14,7,7,7,3,3,3,3,3,3,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5460
    ChildrenCoverage113.nil)

theorem compact113_node_5462 : NodeCoverage113 [14,14,14,14,7,7,7,3,3,3,3,3,3,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5461
    ChildrenCoverage113.nil)

theorem compact113_node_5463 : NodeCoverage113 [14,14,14,14,7,7,7,3,3,3,3,3,3,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5462
    ChildrenCoverage113.nil)

theorem compact113_node_5464 : NodeCoverage113 [14,14,14,14,7,7,7,3,3,3,3,3,3] 3 18 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5463
    ChildrenCoverage113.nil)

theorem compact113_node_5465 : NodeCoverage113 [14,14,14,14,7,7,7,3,3,3,3,3] 3 21 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5464
    ChildrenCoverage113.nil)

theorem compact113_node_5466 : NodeCoverage113 [14,14,14,14,7,7,7,3,3,3,3] 3 24 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5465
    ChildrenCoverage113.nil)

theorem compact113_node_5467 : NodeCoverage113 [14,14,14,14,7,7,7,3,3,3] 3 27 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5466
    ChildrenCoverage113.nil)

theorem compact113_node_5468 : NodeCoverage113 [14,14,14,14,7,7,7,3,3] 3 30 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5467
    ChildrenCoverage113.nil)

theorem compact113_node_5469 : NodeCoverage113 [14,14,14,14,7,7,7,3] 3 33 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5468
    ChildrenCoverage113.nil)

theorem compact113_node_5470 : NodeCoverage113 [14,14,14,14,7,7,7] 7 36 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5455
    (ChildrenCoverage113.cons _ _ compact113_node_5456
    (ChildrenCoverage113.cons _ _ compact113_node_5457
    (ChildrenCoverage113.cons _ _ compact113_node_5469
    ChildrenCoverage113.nil))))

theorem compact113_node_5471 : NodeCoverage113 [14,14,14,14,7,7,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5472 : NodeCoverage113 [14,14,14,14,7,7,5] 5 38 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5473 : NodeCoverage113 [14,14,14,14,7,7,3] 3 40 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5474 : NodeCoverage113 [14,14,14,14,7,7] 7 43 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5470
    (ChildrenCoverage113.cons _ _ compact113_node_5471
    (ChildrenCoverage113.cons _ _ compact113_node_5472
    (ChildrenCoverage113.cons _ _ compact113_node_5473
    ChildrenCoverage113.nil))))

theorem compact113_node_5475 : NodeCoverage113 [14,14,14,14,7,6] 6 44 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5476 : NodeCoverage113 [14,14,14,14,7,5] 5 45 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5477 : NodeCoverage113 [14,14,14,14,7,3] 3 47 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5478 : NodeCoverage113 [14,14,14,14,7] 7 50 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5474
    (ChildrenCoverage113.cons _ _ compact113_node_5475
    (ChildrenCoverage113.cons _ _ compact113_node_5476
    (ChildrenCoverage113.cons _ _ compact113_node_5477
    ChildrenCoverage113.nil))))

theorem compact113_node_5479 : NodeCoverage113 [14,14,14,14,6] 6 51 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

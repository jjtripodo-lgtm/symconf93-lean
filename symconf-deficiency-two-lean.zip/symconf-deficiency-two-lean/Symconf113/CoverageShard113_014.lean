import Symconf113.CoverageShard113_013

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0612 : NodeCoverage113 [53,21] 21 39 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0613 : NodeCoverage113 [53,20] 20 40 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0614 : NodeCoverage113 [53,19] 19 41 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0615 : NodeCoverage113 [53,18] 18 42 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0616 : NodeCoverage113 [53,17] 17 43 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0617 : NodeCoverage113 [53,16] 16 44 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0618 : NodeCoverage113 [53,15] 15 45 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0619 : NodeCoverage113 [53,14] 14 46 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0620 : NodeCoverage113 [53,13] 13 47 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0621 : NodeCoverage113 [53,12] 12 48 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0622 : NodeCoverage113 [53,11] 11 49 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0623 : NodeCoverage113 [53,10] 10 50 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0624 : NodeCoverage113 [53,9] 9 51 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0625 : NodeCoverage113 [53,8] 8 52 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0626 : NodeCoverage113 [53,7] 7 53 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0627 : NodeCoverage113 [53,6] 6 54 :=
  demand_node_prune113 53 compact113_demands_053 compact113_demands_053_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0628 : NodeCoverage113 [53,5] 5 55 :=
  demand_node_prune113 53 compact113_demands_053 compact113_demands_053_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0629 : NodeCoverage113 [53,3] 3 57 :=
  demand_node_prune113 53 compact113_demands_053 compact113_demands_053_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0630 : NodeCoverage113 [53] 53 60 :=
  node_fork113 (B := [53,52,51,50,49,48,47,46,45,44,43,42,41,40,39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0580
    (ChildrenCoverage113.cons _ _ compact113_node_0581
    (ChildrenCoverage113.cons _ _ compact113_node_0582
    (ChildrenCoverage113.cons _ _ compact113_node_0583
    (ChildrenCoverage113.cons _ _ compact113_node_0584
    (ChildrenCoverage113.cons _ _ compact113_node_0585
    (ChildrenCoverage113.cons _ _ compact113_node_0586
    (ChildrenCoverage113.cons _ _ compact113_node_0587
    (ChildrenCoverage113.cons _ _ compact113_node_0588
    (ChildrenCoverage113.cons _ _ compact113_node_0589
    (ChildrenCoverage113.cons _ _ compact113_node_0590
    (ChildrenCoverage113.cons _ _ compact113_node_0591
    (ChildrenCoverage113.cons _ _ compact113_node_0592
    (ChildrenCoverage113.cons _ _ compact113_node_0593
    (ChildrenCoverage113.cons _ _ compact113_node_0594
    (ChildrenCoverage113.cons _ _ compact113_node_0595
    (ChildrenCoverage113.cons _ _ compact113_node_0596
    (ChildrenCoverage113.cons _ _ compact113_node_0597
    (ChildrenCoverage113.cons _ _ compact113_node_0598
    (ChildrenCoverage113.cons _ _ compact113_node_0599
    (ChildrenCoverage113.cons _ _ compact113_node_0600
    (ChildrenCoverage113.cons _ _ compact113_node_0601
    (ChildrenCoverage113.cons _ _ compact113_node_0602
    (ChildrenCoverage113.cons _ _ compact113_node_0603
    (ChildrenCoverage113.cons _ _ compact113_node_0604
    (ChildrenCoverage113.cons _ _ compact113_node_0605
    (ChildrenCoverage113.cons _ _ compact113_node_0606
    (ChildrenCoverage113.cons _ _ compact113_node_0607
    (ChildrenCoverage113.cons _ _ compact113_node_0608
    (ChildrenCoverage113.cons _ _ compact113_node_0609
    (ChildrenCoverage113.cons _ _ compact113_node_0610
    (ChildrenCoverage113.cons _ _ compact113_node_0611
    (ChildrenCoverage113.cons _ _ compact113_node_0612
    (ChildrenCoverage113.cons _ _ compact113_node_0613
    (ChildrenCoverage113.cons _ _ compact113_node_0614
    (ChildrenCoverage113.cons _ _ compact113_node_0615
    (ChildrenCoverage113.cons _ _ compact113_node_0616
    (ChildrenCoverage113.cons _ _ compact113_node_0617
    (ChildrenCoverage113.cons _ _ compact113_node_0618
    (ChildrenCoverage113.cons _ _ compact113_node_0619
    (ChildrenCoverage113.cons _ _ compact113_node_0620
    (ChildrenCoverage113.cons _ _ compact113_node_0621
    (ChildrenCoverage113.cons _ _ compact113_node_0622
    (ChildrenCoverage113.cons _ _ compact113_node_0623
    (ChildrenCoverage113.cons _ _ compact113_node_0624
    (ChildrenCoverage113.cons _ _ compact113_node_0625
    (ChildrenCoverage113.cons _ _ compact113_node_0626
    (ChildrenCoverage113.cons _ _ compact113_node_0627
    (ChildrenCoverage113.cons _ _ compact113_node_0628
    (ChildrenCoverage113.cons _ _ compact113_node_0629
    ChildrenCoverage113.nil))))))))))))))))))))))))))))))))))))))))))))))))))

theorem compact113_node_0631 : NodeCoverage113 [52] 52 61 :=
  demand_node_prune113 52 compact113_demands_052 compact113_demands_052_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0632 : NodeCoverage113 [51] 51 62 :=
  demand_node_prune113 51 compact113_demands_051 compact113_demands_051_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0633 : NodeCoverage113 [50] 50 63 :=
  demand_node_prune113 50 compact113_demands_050 compact113_demands_050_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0634 : NodeCoverage113 [49,49,15] 15 0 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0635 : NodeCoverage113 [49,49,12] 12 3 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0636 : NodeCoverage113 [49,49,11] 11 4 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0637 : NodeCoverage113 [49,49,10] 10 5 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0638 : NodeCoverage113 [49,49,9] 9 6 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0639 : NodeCoverage113 [49,49,8] 8 7 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0640 : NodeCoverage113 [49,49,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0641 : NodeCoverage113 [49,49,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0642 : NodeCoverage113 [49,49,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0640
    (ChildrenCoverage113.cons _ _ compact113_node_0641
    ChildrenCoverage113.nil))

theorem compact113_node_0643 : NodeCoverage113 [49,49,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0644 : NodeCoverage113 [49,49,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0645 : NodeCoverage113 [49,49,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0646 : NodeCoverage113 [49,49] 49 15 :=
  node_fork113 (B := [15,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0634
    (ChildrenCoverage113.cons _ _ compact113_node_0635
    (ChildrenCoverage113.cons _ _ compact113_node_0636
    (ChildrenCoverage113.cons _ _ compact113_node_0637
    (ChildrenCoverage113.cons _ _ compact113_node_0638
    (ChildrenCoverage113.cons _ _ compact113_node_0639
    (ChildrenCoverage113.cons _ _ compact113_node_0642
    (ChildrenCoverage113.cons _ _ compact113_node_0643
    (ChildrenCoverage113.cons _ _ compact113_node_0644
    (ChildrenCoverage113.cons _ _ compact113_node_0645
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_0647 : NodeCoverage113 [49,48] 48 16 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0648 : NodeCoverage113 [49,47] 47 17 :=
  demand_node_prune113 47 compact113_demands_047 compact113_demands_047_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0649 : NodeCoverage113 [49,46] 46 18 :=
  demand_node_prune113 46 compact113_demands_046 compact113_demands_046_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0650 : NodeCoverage113 [49,45] 45 19 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0651 : NodeCoverage113 [49,44] 44 20 :=
  demand_node_prune113 44 compact113_demands_044 compact113_demands_044_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0652 : NodeCoverage113 [49,43] 43 21 :=
  demand_node_prune113 43 compact113_demands_043 compact113_demands_043_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0653 : NodeCoverage113 [49,42] 42 22 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0654 : NodeCoverage113 [49,41] 41 23 :=
  demand_node_prune113 41 compact113_demands_041 compact113_demands_041_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0655 : NodeCoverage113 [49,40] 40 24 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0656 : NodeCoverage113 [49,39] 39 25 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0657 : NodeCoverage113 [49,38] 38 26 :=
  demand_node_prune113 38 compact113_demands_038 compact113_demands_038_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0658 : NodeCoverage113 [49,37] 37 27 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

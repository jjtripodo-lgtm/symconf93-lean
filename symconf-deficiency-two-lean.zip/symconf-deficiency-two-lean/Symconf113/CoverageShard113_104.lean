import Symconf113.CoverageShard113_103

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3772 : NodeCoverage113 [21,21,21,18] 18 32 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3773 : NodeCoverage113 [21,21,21,17] 17 33 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3774 : NodeCoverage113 [21,21,21,16] 16 34 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3775 : NodeCoverage113 [21,21,21,15] 15 35 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3776 : NodeCoverage113 [21,21,21,14] 14 36 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3777 : NodeCoverage113 [21,21,21,13] 13 37 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3778 : NodeCoverage113 [21,21,21,12] 12 38 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3779 : NodeCoverage113 [21,21,21,11] 11 39 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3780 : NodeCoverage113 [21,21,21,10] 10 40 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3781 : NodeCoverage113 [21,21,21,9] 9 41 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3782 : NodeCoverage113 [21,21,21,8] 8 42 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3783 : NodeCoverage113 [21,21,21,7,7,7,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3784 : NodeCoverage113 [21,21,21,7,7,7,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3785 : NodeCoverage113 [21,21,21,7,7,7,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3783
    (ChildrenCoverage113.cons _ _ compact113_node_3784
    ChildrenCoverage113.nil))

theorem compact113_node_3786 : NodeCoverage113 [21,21,21,7,7,7,7,7,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3787 : NodeCoverage113 [21,21,21,7,7,7,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3788 : NodeCoverage113 [21,21,21,7,7,7,7,7,3,3,3,3,3] 3 0 :=
  node_no_weak_demand113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3789 : NodeCoverage113 [21,21,21,7,7,7,7,7,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3788
    ChildrenCoverage113.nil)

theorem compact113_node_3790 : NodeCoverage113 [21,21,21,7,7,7,7,7,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3789
    ChildrenCoverage113.nil)

theorem compact113_node_3791 : NodeCoverage113 [21,21,21,7,7,7,7,7,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3790
    ChildrenCoverage113.nil)

theorem compact113_node_3792 : NodeCoverage113 [21,21,21,7,7,7,7,7,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3791
    ChildrenCoverage113.nil)

theorem compact113_node_3793 : NodeCoverage113 [21,21,21,7,7,7,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3785
    (ChildrenCoverage113.cons _ _ compact113_node_3786
    (ChildrenCoverage113.cons _ _ compact113_node_3787
    (ChildrenCoverage113.cons _ _ compact113_node_3792
    ChildrenCoverage113.nil))))

theorem compact113_node_3794 : NodeCoverage113 [21,21,21,7,7,7,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3795 : NodeCoverage113 [21,21,21,7,7,7,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3796 : NodeCoverage113 [21,21,21,7,7,7,7,3,3,3,3,3,3] 3 4 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_3797 : NodeCoverage113 [21,21,21,7,7,7,7,3,3,3,3,3] 3 7 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3796
    ChildrenCoverage113.nil)

theorem compact113_node_3798 : NodeCoverage113 [21,21,21,7,7,7,7,3,3,3,3] 3 10 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3797
    ChildrenCoverage113.nil)

theorem compact113_node_3799 : NodeCoverage113 [21,21,21,7,7,7,7,3,3,3] 3 13 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3798
    ChildrenCoverage113.nil)

theorem compact113_node_3800 : NodeCoverage113 [21,21,21,7,7,7,7,3,3] 3 16 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3799
    ChildrenCoverage113.nil)

theorem compact113_node_3801 : NodeCoverage113 [21,21,21,7,7,7,7,3] 3 19 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3800
    ChildrenCoverage113.nil)

theorem compact113_node_3802 : NodeCoverage113 [21,21,21,7,7,7,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3793
    (ChildrenCoverage113.cons _ _ compact113_node_3794
    (ChildrenCoverage113.cons _ _ compact113_node_3795
    (ChildrenCoverage113.cons _ _ compact113_node_3801
    ChildrenCoverage113.nil))))

theorem compact113_node_3803 : NodeCoverage113 [21,21,21,7,7,7,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3804 : NodeCoverage113 [21,21,21,7,7,7,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3805 : NodeCoverage113 [21,21,21,7,7,7,3] 3 26 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3806 : NodeCoverage113 [21,21,21,7,7,7] 7 29 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3802
    (ChildrenCoverage113.cons _ _ compact113_node_3803
    (ChildrenCoverage113.cons _ _ compact113_node_3804
    (ChildrenCoverage113.cons _ _ compact113_node_3805
    ChildrenCoverage113.nil))))

theorem compact113_node_3807 : NodeCoverage113 [21,21,21,7,7,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3808 : NodeCoverage113 [21,21,21,7,7,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3809 : NodeCoverage113 [21,21,21,7,7,3] 3 33 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3810 : NodeCoverage113 [21,21,21,7,7] 7 36 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3806
    (ChildrenCoverage113.cons _ _ compact113_node_3807
    (ChildrenCoverage113.cons _ _ compact113_node_3808
    (ChildrenCoverage113.cons _ _ compact113_node_3809
    ChildrenCoverage113.nil))))

theorem compact113_node_3811 : NodeCoverage113 [21,21,21,7,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3812 : NodeCoverage113 [21,21,21,7,5] 5 38 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3813 : NodeCoverage113 [21,21,21,7,3] 3 40 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3814 : NodeCoverage113 [21,21,21,7] 7 43 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3810
    (ChildrenCoverage113.cons _ _ compact113_node_3811
    (ChildrenCoverage113.cons _ _ compact113_node_3812
    (ChildrenCoverage113.cons _ _ compact113_node_3813
    ChildrenCoverage113.nil))))

theorem compact113_node_3815 : NodeCoverage113 [21,21,21,6] 6 44 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3816 : NodeCoverage113 [21,21,21,5] 5 45 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3817 : NodeCoverage113 [21,21,21,3] 3 47 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3818 : NodeCoverage113 [21,21,21] 21 50 :=
  node_fork113 (B := [21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3769
    (ChildrenCoverage113.cons _ _ compact113_node_3770
    (ChildrenCoverage113.cons _ _ compact113_node_3771
    (ChildrenCoverage113.cons _ _ compact113_node_3772
    (ChildrenCoverage113.cons _ _ compact113_node_3773
    (ChildrenCoverage113.cons _ _ compact113_node_3774
    (ChildrenCoverage113.cons _ _ compact113_node_3775
    (ChildrenCoverage113.cons _ _ compact113_node_3776
    (ChildrenCoverage113.cons _ _ compact113_node_3777
    (ChildrenCoverage113.cons _ _ compact113_node_3778
    (ChildrenCoverage113.cons _ _ compact113_node_3779
    (ChildrenCoverage113.cons _ _ compact113_node_3780
    (ChildrenCoverage113.cons _ _ compact113_node_3781
    (ChildrenCoverage113.cons _ _ compact113_node_3782
    (ChildrenCoverage113.cons _ _ compact113_node_3814
    (ChildrenCoverage113.cons _ _ compact113_node_3815
    (ChildrenCoverage113.cons _ _ compact113_node_3816
    (ChildrenCoverage113.cons _ _ compact113_node_3817
    ChildrenCoverage113.nil))))))))))))))))))

theorem compact113_node_3819 : NodeCoverage113 [21,21,20] 20 51 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3820 : NodeCoverage113 [21,21,19] 19 52 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3821 : NodeCoverage113 [21,21,18] 18 53 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3822 : NodeCoverage113 [21,21,17] 17 54 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3823 : NodeCoverage113 [21,21,16] 16 55 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

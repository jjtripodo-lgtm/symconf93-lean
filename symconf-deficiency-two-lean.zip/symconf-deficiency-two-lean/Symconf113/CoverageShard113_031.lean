import Symconf113.CoverageShard113_030

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1284 : NodeCoverage113 [40,10,10,10,10,10,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1285 : NodeCoverage113 [40,10,10,10,10,10,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1286 : NodeCoverage113 [40,10,10,10,10,10,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1287 : NodeCoverage113 [40,10,10,10,10,10,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1288 : NodeCoverage113 [40,10,10,10,10,10,5] 5 18 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1289 : NodeCoverage113 [40,10,10,10,10,10,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1290 : NodeCoverage113 [40,10,10,10,10,10] 10 23 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1283
    (ChildrenCoverage113.cons _ _ compact113_node_1284
    (ChildrenCoverage113.cons _ _ compact113_node_1285
    (ChildrenCoverage113.cons _ _ compact113_node_1286
    (ChildrenCoverage113.cons _ _ compact113_node_1287
    (ChildrenCoverage113.cons _ _ compact113_node_1288
    (ChildrenCoverage113.cons _ _ compact113_node_1289
    ChildrenCoverage113.nil)))))))

theorem compact113_node_1291 : NodeCoverage113 [40,10,10,10,10,9] 9 24 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1292 : NodeCoverage113 [40,10,10,10,10,8] 8 25 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1293 : NodeCoverage113 [40,10,10,10,10,7] 7 26 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1294 : NodeCoverage113 [40,10,10,10,10,6] 6 27 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1295 : NodeCoverage113 [40,10,10,10,10,5] 5 28 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1296 : NodeCoverage113 [40,10,10,10,10,3] 3 30 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1297 : NodeCoverage113 [40,10,10,10,10] 10 33 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1290
    (ChildrenCoverage113.cons _ _ compact113_node_1291
    (ChildrenCoverage113.cons _ _ compact113_node_1292
    (ChildrenCoverage113.cons _ _ compact113_node_1293
    (ChildrenCoverage113.cons _ _ compact113_node_1294
    (ChildrenCoverage113.cons _ _ compact113_node_1295
    (ChildrenCoverage113.cons _ _ compact113_node_1296
    ChildrenCoverage113.nil)))))))

theorem compact113_node_1298 : NodeCoverage113 [40,10,10,10,9] 9 34 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1299 : NodeCoverage113 [40,10,10,10,8] 8 35 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1300 : NodeCoverage113 [40,10,10,10,7] 7 36 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1301 : NodeCoverage113 [40,10,10,10,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1302 : NodeCoverage113 [40,10,10,10,5] 5 38 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1303 : NodeCoverage113 [40,10,10,10,3] 3 40 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1304 : NodeCoverage113 [40,10,10,10] 10 43 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1297
    (ChildrenCoverage113.cons _ _ compact113_node_1298
    (ChildrenCoverage113.cons _ _ compact113_node_1299
    (ChildrenCoverage113.cons _ _ compact113_node_1300
    (ChildrenCoverage113.cons _ _ compact113_node_1301
    (ChildrenCoverage113.cons _ _ compact113_node_1302
    (ChildrenCoverage113.cons _ _ compact113_node_1303
    ChildrenCoverage113.nil)))))))

theorem compact113_node_1305 : NodeCoverage113 [40,10,10,9] 9 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1306 : NodeCoverage113 [40,10,10,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1307 : NodeCoverage113 [40,10,10,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1308 : NodeCoverage113 [40,10,10,6] 6 47 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1309 : NodeCoverage113 [40,10,10,5] 5 48 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1310 : NodeCoverage113 [40,10,10,3] 3 50 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1311 : NodeCoverage113 [40,10,10] 10 53 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1304
    (ChildrenCoverage113.cons _ _ compact113_node_1305
    (ChildrenCoverage113.cons _ _ compact113_node_1306
    (ChildrenCoverage113.cons _ _ compact113_node_1307
    (ChildrenCoverage113.cons _ _ compact113_node_1308
    (ChildrenCoverage113.cons _ _ compact113_node_1309
    (ChildrenCoverage113.cons _ _ compact113_node_1310
    ChildrenCoverage113.nil)))))))

theorem compact113_node_1312 : NodeCoverage113 [40,10,9] 9 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1313 : NodeCoverage113 [40,10,8] 8 55 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1314 : NodeCoverage113 [40,10,7] 7 56 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1315 : NodeCoverage113 [40,10,6] 6 57 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1316 : NodeCoverage113 [40,10,5] 5 58 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1317 : NodeCoverage113 [40,10,3] 3 60 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1318 : NodeCoverage113 [40,10] 10 63 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1311
    (ChildrenCoverage113.cons _ _ compact113_node_1312
    (ChildrenCoverage113.cons _ _ compact113_node_1313
    (ChildrenCoverage113.cons _ _ compact113_node_1314
    (ChildrenCoverage113.cons _ _ compact113_node_1315
    (ChildrenCoverage113.cons _ _ compact113_node_1316
    (ChildrenCoverage113.cons _ _ compact113_node_1317
    ChildrenCoverage113.nil)))))))

theorem compact113_node_1319 : NodeCoverage113 [40,9] 9 64 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1320 : NodeCoverage113 [40,8] 8 65 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1321 : NodeCoverage113 [40,7] 7 66 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

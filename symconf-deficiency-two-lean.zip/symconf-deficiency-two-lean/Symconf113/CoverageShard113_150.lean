import Symconf113.CoverageShard113_148
import Symconf113.CoverageShard113_149

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_6355 : NodeCoverage113 [12,12,12,7,7,7,5] 5 51 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6356 : NodeCoverage113 [12,12,12,7,7,7,3] 3 53 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6357 : NodeCoverage113 [12,12,12,7,7,7] 7 56 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6353
    (ChildrenCoverage113.cons _ _ compact113_node_6354
    (ChildrenCoverage113.cons _ _ compact113_node_6355
    (ChildrenCoverage113.cons _ _ compact113_node_6356
    ChildrenCoverage113.nil))))

theorem compact113_node_6358 : NodeCoverage113 [12,12,12,7,7,6] 6 57 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6359 : NodeCoverage113 [12,12,12,7,7,5] 5 58 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6360 : NodeCoverage113 [12,12,12,7,7,3] 3 60 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6361 : NodeCoverage113 [12,12,12,7,7] 7 63 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6357
    (ChildrenCoverage113.cons _ _ compact113_node_6358
    (ChildrenCoverage113.cons _ _ compact113_node_6359
    (ChildrenCoverage113.cons _ _ compact113_node_6360
    ChildrenCoverage113.nil))))

theorem compact113_node_6362 : NodeCoverage113 [12,12,12,7,6] 6 64 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6363 : NodeCoverage113 [12,12,12,7,5] 5 65 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6364 : NodeCoverage113 [12,12,12,7,3] 3 67 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6365 : NodeCoverage113 [12,12,12,7] 7 70 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6361
    (ChildrenCoverage113.cons _ _ compact113_node_6362
    (ChildrenCoverage113.cons _ _ compact113_node_6363
    (ChildrenCoverage113.cons _ _ compact113_node_6364
    ChildrenCoverage113.nil))))

theorem compact113_node_6366 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6367 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6366
    ChildrenCoverage113.nil)

theorem compact113_node_6368 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6369 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6370 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6369
    ChildrenCoverage113.nil)

theorem compact113_node_6371 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6367
    (ChildrenCoverage113.cons _ _ compact113_node_6368
    (ChildrenCoverage113.cons _ _ compact113_node_6370
    ChildrenCoverage113.nil)))

theorem compact113_node_6372 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6373 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,6,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6374 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,6,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6373
    ChildrenCoverage113.nil)

theorem compact113_node_6375 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,6,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6374
    ChildrenCoverage113.nil)

theorem compact113_node_6376 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,6,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6375
    ChildrenCoverage113.nil)

theorem compact113_node_6377 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6371
    (ChildrenCoverage113.cons _ _ compact113_node_6372
    (ChildrenCoverage113.cons _ _ compact113_node_6376
    ChildrenCoverage113.nil)))

theorem compact113_node_6378 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6379 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6380 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6379
    ChildrenCoverage113.nil)

theorem compact113_node_6381 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6380
    ChildrenCoverage113.nil)

theorem compact113_node_6382 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6381
    ChildrenCoverage113.nil)

theorem compact113_node_6383 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6382
    ChildrenCoverage113.nil)

theorem compact113_node_6384 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6383
    ChildrenCoverage113.nil)

theorem compact113_node_6385 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,6] 6 23 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6377
    (ChildrenCoverage113.cons _ _ compact113_node_6378
    (ChildrenCoverage113.cons _ _ compact113_node_6384
    ChildrenCoverage113.nil)))

theorem compact113_node_6386 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6387 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6388 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6387
    ChildrenCoverage113.nil)

theorem compact113_node_6389 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6388
    ChildrenCoverage113.nil)

theorem compact113_node_6390 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6389
    ChildrenCoverage113.nil)

theorem compact113_node_6391 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6390
    ChildrenCoverage113.nil)

theorem compact113_node_6392 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6391
    ChildrenCoverage113.nil)

theorem compact113_node_6393 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6392
    ChildrenCoverage113.nil)

theorem compact113_node_6394 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6393
    ChildrenCoverage113.nil)

theorem compact113_node_6395 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,6] 6 29 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6385
    (ChildrenCoverage113.cons _ _ compact113_node_6386
    (ChildrenCoverage113.cons _ _ compact113_node_6394
    ChildrenCoverage113.nil)))

theorem compact113_node_6396 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6397 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6398 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6397
    ChildrenCoverage113.nil)

theorem compact113_node_6399 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6398
    ChildrenCoverage113.nil)

theorem compact113_node_6400 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6399
    ChildrenCoverage113.nil)

theorem compact113_node_6401 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6400
    ChildrenCoverage113.nil)

theorem compact113_node_6402 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6401
    ChildrenCoverage113.nil)

theorem compact113_node_6403 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6402
    ChildrenCoverage113.nil)

theorem compact113_node_6404 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6403
    ChildrenCoverage113.nil)

theorem compact113_node_6405 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6404
    ChildrenCoverage113.nil)

theorem compact113_node_6406 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6405
    ChildrenCoverage113.nil)

theorem compact113_node_6407 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,6] 6 35 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6395
    (ChildrenCoverage113.cons _ _ compact113_node_6396
    (ChildrenCoverage113.cons _ _ compact113_node_6406
    ChildrenCoverage113.nil)))

theorem compact113_node_6408 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6409 : NodeCoverage113 [12,12,12,6,6,6,6,6,6,3] 3 38 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6410 : NodeCoverage113 [12,12,12,6,6,6,6,6,6] 6 41 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6407
    (ChildrenCoverage113.cons _ _ compact113_node_6408
    (ChildrenCoverage113.cons _ _ compact113_node_6409
    ChildrenCoverage113.nil)))

theorem compact113_node_6411 : NodeCoverage113 [12,12,12,6,6,6,6,6,5] 5 42 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6412 : NodeCoverage113 [12,12,12,6,6,6,6,6,3] 3 44 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6413 : NodeCoverage113 [12,12,12,6,6,6,6,6] 6 47 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6410
    (ChildrenCoverage113.cons _ _ compact113_node_6411
    (ChildrenCoverage113.cons _ _ compact113_node_6412
    ChildrenCoverage113.nil)))

theorem compact113_node_6414 : NodeCoverage113 [12,12,12,6,6,6,6,5] 5 48 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6415 : NodeCoverage113 [12,12,12,6,6,6,6,3] 3 50 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6416 : NodeCoverage113 [12,12,12,6,6,6,6] 6 53 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6413
    (ChildrenCoverage113.cons _ _ compact113_node_6414
    (ChildrenCoverage113.cons _ _ compact113_node_6415
    ChildrenCoverage113.nil)))

theorem compact113_node_6417 : NodeCoverage113 [12,12,12,6,6,6,5] 5 54 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6418 : NodeCoverage113 [12,12,12,6,6,6,3] 3 56 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6419 : NodeCoverage113 [12,12,12,6,6,6] 6 59 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6416
    (ChildrenCoverage113.cons _ _ compact113_node_6417
    (ChildrenCoverage113.cons _ _ compact113_node_6418
    ChildrenCoverage113.nil)))

theorem compact113_node_6420 : NodeCoverage113 [12,12,12,6,6,5] 5 60 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6421 : NodeCoverage113 [12,12,12,6,6,3] 3 62 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6422 : NodeCoverage113 [12,12,12,6,6] 6 65 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6419
    (ChildrenCoverage113.cons _ _ compact113_node_6420
    (ChildrenCoverage113.cons _ _ compact113_node_6421
    ChildrenCoverage113.nil)))

theorem compact113_node_6423 : NodeCoverage113 [12,12,12,6,5] 5 66 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6424 : NodeCoverage113 [12,12,12,6,3] 3 68 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6425 : NodeCoverage113 [12,12,12,6] 6 71 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6422
    (ChildrenCoverage113.cons _ _ compact113_node_6423
    (ChildrenCoverage113.cons _ _ compact113_node_6424
    ChildrenCoverage113.nil)))

theorem compact113_node_6426 : NodeCoverage113 [12,12,12,5] 5 72 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6427 : NodeCoverage113 [12,12,12,3] 3 74 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6428 : NodeCoverage113 [12,12,12] 12 77 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6277
    (ChildrenCoverage113.cons _ _ compact113_node_6302
    (ChildrenCoverage113.cons _ _ compact113_node_6324
    (ChildrenCoverage113.cons _ _ compact113_node_6343
    (ChildrenCoverage113.cons _ _ compact113_node_6344
    (ChildrenCoverage113.cons _ _ compact113_node_6365
    (ChildrenCoverage113.cons _ _ compact113_node_6425
    (ChildrenCoverage113.cons _ _ compact113_node_6426
    (ChildrenCoverage113.cons _ _ compact113_node_6427
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_6429 : NodeCoverage113 [12,12,11,11,11,11] 11 45 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.ResidualDegShard113_0
import Symconf113.ResidualDegShard113_2
import Symconf113.ResidualDegShard113_4
import Symconf113.ResidualDegShard113_6
import Symconf113.ResidualDegShard113_8
import Symconf113.ResidualDegShard113_10
import Symconf113.ResidualDegShard113_12
import Symconf113.ResidualDegShard113_14
import Symconf113.ResidualDegShard113_16
import Symconf113.ResidualDegShard113_18
import Symconf113.ResidualDegShard113_20
import Symconf113.ResidualDegShard113_22
import Symconf113.ResidualDegShard113_24
import Symconf113.ResidualDegShard113_26
import Symconf113.ResidualDegShard113_28
import Symconf113.ResidualDegShard113_30
import Symconf113.ResidualDegShard113_32
import Symconf113.ResidualDegShard113_34
import Symconf113.ResidualDegShard113_36
import Symconf113.ResidualDegShard113_38
import Symconf113.ResidualDegShard113_40
import Symconf113.ResidualDegShard113_42
import Symconf113.ResidualDegShard113_44
import Symconf113.ResidualDegShard113_46
import Symconf113.ResidualDegShard113_48
import Symconf113.ResidualDegShard113_50
import Symconf113.ResidualDegShard113_52
import Symconf113.ResidualDegShard113_54
import Symconf113.ResidualDegShard113_56
import Symconf113.ResidualDegShard113_58
import Symconf113.ResidualDegShard113_60
import Symconf113.ResidualDegShard113_62
import Symconf113.ResidualDegShard113_64
import Symconf113.ResidualDegShard113_66
import Symconf113.ResidualDegShard113_68
import Symconf113.ResidualDegShard113_70
import Symconf113.ResidualDegShard113_72
import Symconf113.ResidualDegShard113_74
import Symconf113.ResidualDegShard113_76
import Symconf113.ResidualDegShard113_78
import Symconf113.ResidualDegShard113_80
import Symconf113.ResidualDegShard113_82
import Symconf113.ResidualDegShard113_84
import Symconf113.ResidualDegShard113_86
import Symconf113.ResidualDegShard113_88
import Symconf113.ResidualDegShard113_90
import Symconf113.ResidualDegShard113_92
import Symconf113.ResidualDegShard113_94
import Symconf113.ResidualDegShard113_96
import Symconf113.ResidualDegShard113_98
import Symconf113.ResidualDegShard113_100
import Symconf113.ResidualDegShard113_102
import Symconf113.ResidualDegShard113_104
import Symconf113.ResidualDegShard113_106
import Symconf113.ResidualDegShard113_108
import Symconf113.ResidualDegShard113_110
import Symconf113.ResidualDegShard113_112
import Symconf113.ResidualDegShard113_114
import Symconf113.ResidualDegShard113_116
import Symconf113.ResidualDegShard113_118
import Symconf113.ResidualDegShard113_120
import Symconf113.ResidualDegShard113_122
import Symconf113.ResidualDegShard113_124
import Symconf113.ResidualDegShard113_126
import Symconf113.ResidualDegShard113_128
import Symconf113.ResidualDegShard113_130
import Symconf113.ResidualDegShard113_132
import Symconf113.ResidualDegShard113_134
import Symconf113.ResidualDegShard113_136
import Symconf113.ResidualDegShard113_138

/-! Kernel check, assembled from seventy shards of two type-`A` rows each:
every full degree quotient passing the column tests is one of the listed
`leaves`. -/
namespace Symconf113

theorem degTopList_drop_end : degTopList.drop 140=[] := by decide

theorem degree_leaves : dfs degCompat leafIn 7 [] degLists=true := by
  rw [degree_unfold, ← List.drop_zero (l := degTopList)]
  rw [all_drop_split _ _ 0 2, degShard_0, Bool.true_and,
    all_drop_split _ _ 2 2, degShard_2, Bool.true_and,
    all_drop_split _ _ 4 2, degShard_4, Bool.true_and,
    all_drop_split _ _ 6 2, degShard_6, Bool.true_and,
    all_drop_split _ _ 8 2, degShard_8, Bool.true_and,
    all_drop_split _ _ 10 2, degShard_10, Bool.true_and,
    all_drop_split _ _ 12 2, degShard_12, Bool.true_and,
    all_drop_split _ _ 14 2, degShard_14, Bool.true_and,
    all_drop_split _ _ 16 2, degShard_16, Bool.true_and,
    all_drop_split _ _ 18 2, degShard_18, Bool.true_and,
    all_drop_split _ _ 20 2, degShard_20, Bool.true_and,
    all_drop_split _ _ 22 2, degShard_22, Bool.true_and,
    all_drop_split _ _ 24 2, degShard_24, Bool.true_and,
    all_drop_split _ _ 26 2, degShard_26, Bool.true_and,
    all_drop_split _ _ 28 2, degShard_28, Bool.true_and,
    all_drop_split _ _ 30 2, degShard_30, Bool.true_and,
    all_drop_split _ _ 32 2, degShard_32, Bool.true_and,
    all_drop_split _ _ 34 2, degShard_34, Bool.true_and,
    all_drop_split _ _ 36 2, degShard_36, Bool.true_and,
    all_drop_split _ _ 38 2, degShard_38, Bool.true_and,
    all_drop_split _ _ 40 2, degShard_40, Bool.true_and,
    all_drop_split _ _ 42 2, degShard_42, Bool.true_and,
    all_drop_split _ _ 44 2, degShard_44, Bool.true_and,
    all_drop_split _ _ 46 2, degShard_46, Bool.true_and,
    all_drop_split _ _ 48 2, degShard_48, Bool.true_and,
    all_drop_split _ _ 50 2, degShard_50, Bool.true_and,
    all_drop_split _ _ 52 2, degShard_52, Bool.true_and,
    all_drop_split _ _ 54 2, degShard_54, Bool.true_and,
    all_drop_split _ _ 56 2, degShard_56, Bool.true_and,
    all_drop_split _ _ 58 2, degShard_58, Bool.true_and,
    all_drop_split _ _ 60 2, degShard_60, Bool.true_and,
    all_drop_split _ _ 62 2, degShard_62, Bool.true_and,
    all_drop_split _ _ 64 2, degShard_64, Bool.true_and,
    all_drop_split _ _ 66 2, degShard_66, Bool.true_and,
    all_drop_split _ _ 68 2, degShard_68, Bool.true_and,
    all_drop_split _ _ 70 2, degShard_70, Bool.true_and,
    all_drop_split _ _ 72 2, degShard_72, Bool.true_and,
    all_drop_split _ _ 74 2, degShard_74, Bool.true_and,
    all_drop_split _ _ 76 2, degShard_76, Bool.true_and,
    all_drop_split _ _ 78 2, degShard_78, Bool.true_and,
    all_drop_split _ _ 80 2, degShard_80, Bool.true_and,
    all_drop_split _ _ 82 2, degShard_82, Bool.true_and,
    all_drop_split _ _ 84 2, degShard_84, Bool.true_and,
    all_drop_split _ _ 86 2, degShard_86, Bool.true_and,
    all_drop_split _ _ 88 2, degShard_88, Bool.true_and,
    all_drop_split _ _ 90 2, degShard_90, Bool.true_and,
    all_drop_split _ _ 92 2, degShard_92, Bool.true_and,
    all_drop_split _ _ 94 2, degShard_94, Bool.true_and,
    all_drop_split _ _ 96 2, degShard_96, Bool.true_and,
    all_drop_split _ _ 98 2, degShard_98, Bool.true_and,
    all_drop_split _ _ 100 2, degShard_100, Bool.true_and,
    all_drop_split _ _ 102 2, degShard_102, Bool.true_and,
    all_drop_split _ _ 104 2, degShard_104, Bool.true_and,
    all_drop_split _ _ 106 2, degShard_106, Bool.true_and,
    all_drop_split _ _ 108 2, degShard_108, Bool.true_and,
    all_drop_split _ _ 110 2, degShard_110, Bool.true_and,
    all_drop_split _ _ 112 2, degShard_112, Bool.true_and,
    all_drop_split _ _ 114 2, degShard_114, Bool.true_and,
    all_drop_split _ _ 116 2, degShard_116, Bool.true_and,
    all_drop_split _ _ 118 2, degShard_118, Bool.true_and,
    all_drop_split _ _ 120 2, degShard_120, Bool.true_and,
    all_drop_split _ _ 122 2, degShard_122, Bool.true_and,
    all_drop_split _ _ 124 2, degShard_124, Bool.true_and,
    all_drop_split _ _ 126 2, degShard_126, Bool.true_and,
    all_drop_split _ _ 128 2, degShard_128, Bool.true_and,
    all_drop_split _ _ 130 2, degShard_130, Bool.true_and,
    all_drop_split _ _ 132 2, degShard_132, Bool.true_and,
    all_drop_split _ _ 134 2, degShard_134, Bool.true_and,
    all_drop_split _ _ 136 2, degShard_136, Bool.true_and,
    all_drop_split _ _ 138 2, degShard_138, Bool.true_and]
  rw [degTopList_drop_end]; rfl

end Symconf113

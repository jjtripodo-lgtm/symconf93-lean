import Symconf113.CoverageShard113_100

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3571 : NodeCoverage113 [22,22,14] 14 55 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3572 : NodeCoverage113 [22,22,13] 13 56 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3573 : NodeCoverage113 [22,22,12] 12 57 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3574 : NodeCoverage113 [22,22,11,11,11,11,11,11,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3575 : NodeCoverage113 [22,22,11,11,11,11,11,11] 11 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3574
    ChildrenCoverage113.nil)

theorem compact113_node_3576 : NodeCoverage113 [22,22,11,11,11,11,11,10] 10 4 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3577 : NodeCoverage113 [22,22,11,11,11,11,11,9] 9 5 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3578 : NodeCoverage113 [22,22,11,11,11,11,11,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3579 : NodeCoverage113 [22,22,11,11,11,11,11,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3580 : NodeCoverage113 [22,22,11,11,11,11,11,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3581 : NodeCoverage113 [22,22,11,11,11,11,11,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3582 : NodeCoverage113 [22,22,11,11,11,11,11,3] 3 11 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3583 : NodeCoverage113 [22,22,11,11,11,11,11] 11 14 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3575
    (ChildrenCoverage113.cons _ _ compact113_node_3576
    (ChildrenCoverage113.cons _ _ compact113_node_3577
    (ChildrenCoverage113.cons _ _ compact113_node_3578
    (ChildrenCoverage113.cons _ _ compact113_node_3579
    (ChildrenCoverage113.cons _ _ compact113_node_3580
    (ChildrenCoverage113.cons _ _ compact113_node_3581
    (ChildrenCoverage113.cons _ _ compact113_node_3582
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3584 : NodeCoverage113 [22,22,11,11,11,11,10] 10 15 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3585 : NodeCoverage113 [22,22,11,11,11,11,9] 9 16 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3586 : NodeCoverage113 [22,22,11,11,11,11,8] 8 17 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3587 : NodeCoverage113 [22,22,11,11,11,11,7] 7 18 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3588 : NodeCoverage113 [22,22,11,11,11,11,6] 6 19 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3589 : NodeCoverage113 [22,22,11,11,11,11,5] 5 20 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3590 : NodeCoverage113 [22,22,11,11,11,11,3] 3 22 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3591 : NodeCoverage113 [22,22,11,11,11,11] 11 25 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3583
    (ChildrenCoverage113.cons _ _ compact113_node_3584
    (ChildrenCoverage113.cons _ _ compact113_node_3585
    (ChildrenCoverage113.cons _ _ compact113_node_3586
    (ChildrenCoverage113.cons _ _ compact113_node_3587
    (ChildrenCoverage113.cons _ _ compact113_node_3588
    (ChildrenCoverage113.cons _ _ compact113_node_3589
    (ChildrenCoverage113.cons _ _ compact113_node_3590
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3592 : NodeCoverage113 [22,22,11,11,11,10] 10 26 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3593 : NodeCoverage113 [22,22,11,11,11,9] 9 27 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3594 : NodeCoverage113 [22,22,11,11,11,8] 8 28 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3595 : NodeCoverage113 [22,22,11,11,11,7] 7 29 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3596 : NodeCoverage113 [22,22,11,11,11,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3597 : NodeCoverage113 [22,22,11,11,11,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3598 : NodeCoverage113 [22,22,11,11,11,3] 3 33 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3599 : NodeCoverage113 [22,22,11,11,11] 11 36 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3591
    (ChildrenCoverage113.cons _ _ compact113_node_3592
    (ChildrenCoverage113.cons _ _ compact113_node_3593
    (ChildrenCoverage113.cons _ _ compact113_node_3594
    (ChildrenCoverage113.cons _ _ compact113_node_3595
    (ChildrenCoverage113.cons _ _ compact113_node_3596
    (ChildrenCoverage113.cons _ _ compact113_node_3597
    (ChildrenCoverage113.cons _ _ compact113_node_3598
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3600 : NodeCoverage113 [22,22,11,11,10] 10 37 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3601 : NodeCoverage113 [22,22,11,11,9] 9 38 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3602 : NodeCoverage113 [22,22,11,11,8] 8 39 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3603 : NodeCoverage113 [22,22,11,11,7] 7 40 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3604 : NodeCoverage113 [22,22,11,11,6] 6 41 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3605 : NodeCoverage113 [22,22,11,11,5] 5 42 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3606 : NodeCoverage113 [22,22,11,11,3] 3 44 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3607 : NodeCoverage113 [22,22,11,11] 11 47 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3599
    (ChildrenCoverage113.cons _ _ compact113_node_3600
    (ChildrenCoverage113.cons _ _ compact113_node_3601
    (ChildrenCoverage113.cons _ _ compact113_node_3602
    (ChildrenCoverage113.cons _ _ compact113_node_3603
    (ChildrenCoverage113.cons _ _ compact113_node_3604
    (ChildrenCoverage113.cons _ _ compact113_node_3605
    (ChildrenCoverage113.cons _ _ compact113_node_3606
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3608 : NodeCoverage113 [22,22,11,10] 10 48 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3609 : NodeCoverage113 [22,22,11,9] 9 49 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3610 : NodeCoverage113 [22,22,11,8] 8 50 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3611 : NodeCoverage113 [22,22,11,7] 7 51 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3612 : NodeCoverage113 [22,22,11,6] 6 52 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3613 : NodeCoverage113 [22,22,11,5] 5 53 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3614 : NodeCoverage113 [22,22,11,3] 3 55 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3615 : NodeCoverage113 [22,22,11] 11 58 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3607
    (ChildrenCoverage113.cons _ _ compact113_node_3608
    (ChildrenCoverage113.cons _ _ compact113_node_3609
    (ChildrenCoverage113.cons _ _ compact113_node_3610
    (ChildrenCoverage113.cons _ _ compact113_node_3611
    (ChildrenCoverage113.cons _ _ compact113_node_3612
    (ChildrenCoverage113.cons _ _ compact113_node_3613
    (ChildrenCoverage113.cons _ _ compact113_node_3614
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3616 : NodeCoverage113 [22,22,10] 10 59 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3617 : NodeCoverage113 [22,22,9] 9 60 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3618 : NodeCoverage113 [22,22,8] 8 61 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3619 : NodeCoverage113 [22,22,7] 7 62 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3620 : NodeCoverage113 [22,22,6] 6 63 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3621 : NodeCoverage113 [22,22,5] 5 64 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3622 : NodeCoverage113 [22,22,3] 3 66 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3623 : NodeCoverage113 [22,22] 22 69 :=
  node_fork113 (B := [22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3563
    (ChildrenCoverage113.cons _ _ compact113_node_3564
    (ChildrenCoverage113.cons _ _ compact113_node_3565
    (ChildrenCoverage113.cons _ _ compact113_node_3566
    (ChildrenCoverage113.cons _ _ compact113_node_3567
    (ChildrenCoverage113.cons _ _ compact113_node_3568
    (ChildrenCoverage113.cons _ _ compact113_node_3569
    (ChildrenCoverage113.cons _ _ compact113_node_3570
    (ChildrenCoverage113.cons _ _ compact113_node_3571
    (ChildrenCoverage113.cons _ _ compact113_node_3572
    (ChildrenCoverage113.cons _ _ compact113_node_3573
    (ChildrenCoverage113.cons _ _ compact113_node_3615
    (ChildrenCoverage113.cons _ _ compact113_node_3616
    (ChildrenCoverage113.cons _ _ compact113_node_3617
    (ChildrenCoverage113.cons _ _ compact113_node_3618
    (ChildrenCoverage113.cons _ _ compact113_node_3619
    (ChildrenCoverage113.cons _ _ compact113_node_3620
    (ChildrenCoverage113.cons _ _ compact113_node_3621
    (ChildrenCoverage113.cons _ _ compact113_node_3622
    ChildrenCoverage113.nil)))))))))))))))))))

theorem compact113_node_3624 : NodeCoverage113 [22,21] 21 70 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3625 : NodeCoverage113 [22,20] 20 71 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3626 : NodeCoverage113 [22,19] 19 72 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3627 : NodeCoverage113 [22,18] 18 73 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3628 : NodeCoverage113 [22,17] 17 74 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3629 : NodeCoverage113 [22,16] 16 75 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3630 : NodeCoverage113 [22,15] 15 76 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3631 : NodeCoverage113 [22,14,14] 14 63 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3632 : NodeCoverage113 [22,14,13] 13 64 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3633 : NodeCoverage113 [22,14,12] 12 65 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3634 : NodeCoverage113 [22,14,11,11] 11 55 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3635 : NodeCoverage113 [22,14,11,10] 10 56 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3636 : NodeCoverage113 [22,14,11,9] 9 57 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3637 : NodeCoverage113 [22,14,11,8] 8 58 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3638 : NodeCoverage113 [22,14,11,7] 7 59 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3639 : NodeCoverage113 [22,14,11,6] 6 60 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3640 : NodeCoverage113 [22,14,11,5] 5 61 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3641 : NodeCoverage113 [22,14,11,3] 3 63 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3642 : NodeCoverage113 [22,14,11] 11 66 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3634
    (ChildrenCoverage113.cons _ _ compact113_node_3635
    (ChildrenCoverage113.cons _ _ compact113_node_3636
    (ChildrenCoverage113.cons _ _ compact113_node_3637
    (ChildrenCoverage113.cons _ _ compact113_node_3638
    (ChildrenCoverage113.cons _ _ compact113_node_3639
    (ChildrenCoverage113.cons _ _ compact113_node_3640
    (ChildrenCoverage113.cons _ _ compact113_node_3641
    ChildrenCoverage113.nil))))))))

end Symconf113

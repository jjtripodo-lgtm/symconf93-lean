import Symconf113.CoverageShard113_124

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4850 : NodeCoverage113 [18,12,11] 11 72 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4851 : NodeCoverage113 [18,12,10] 10 73 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4852 : NodeCoverage113 [18,12,9] 9 74 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4853 : NodeCoverage113 [18,12,8] 8 75 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4854 : NodeCoverage113 [18,12,7] 7 76 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4855 : NodeCoverage113 [18,12,6] 6 77 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4856 : NodeCoverage113 [18,12,5] 5 78 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4857 : NodeCoverage113 [18,12,3] 3 80 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4858 : NodeCoverage113 [18,12] 12 83 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4849
    (ChildrenCoverage113.cons _ _ compact113_node_4850
    (ChildrenCoverage113.cons _ _ compact113_node_4851
    (ChildrenCoverage113.cons _ _ compact113_node_4852
    (ChildrenCoverage113.cons _ _ compact113_node_4853
    (ChildrenCoverage113.cons _ _ compact113_node_4854
    (ChildrenCoverage113.cons _ _ compact113_node_4855
    (ChildrenCoverage113.cons _ _ compact113_node_4856
    (ChildrenCoverage113.cons _ _ compact113_node_4857
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_4859 : NodeCoverage113 [18,11,11,11] 11 62 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4860 : NodeCoverage113 [18,11,11,10] 10 63 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4861 : NodeCoverage113 [18,11,11,9] 9 64 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4862 : NodeCoverage113 [18,11,11,8] 8 65 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4863 : NodeCoverage113 [18,11,11,7] 7 66 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4864 : NodeCoverage113 [18,11,11,6] 6 67 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4865 : NodeCoverage113 [18,11,11,5] 5 68 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4866 : NodeCoverage113 [18,11,11,3] 3 70 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4867 : NodeCoverage113 [18,11,11] 11 73 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4859
    (ChildrenCoverage113.cons _ _ compact113_node_4860
    (ChildrenCoverage113.cons _ _ compact113_node_4861
    (ChildrenCoverage113.cons _ _ compact113_node_4862
    (ChildrenCoverage113.cons _ _ compact113_node_4863
    (ChildrenCoverage113.cons _ _ compact113_node_4864
    (ChildrenCoverage113.cons _ _ compact113_node_4865
    (ChildrenCoverage113.cons _ _ compact113_node_4866
    ChildrenCoverage113.nil))))))))

theorem compact113_node_4868 : NodeCoverage113 [18,11,10] 10 74 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4869 : NodeCoverage113 [18,11,9] 9 75 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4870 : NodeCoverage113 [18,11,8] 8 76 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4871 : NodeCoverage113 [18,11,7] 7 77 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4872 : NodeCoverage113 [18,11,6] 6 78 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4873 : NodeCoverage113 [18,11,5] 5 79 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4874 : NodeCoverage113 [18,11,3] 3 81 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4875 : NodeCoverage113 [18,11] 11 84 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4867
    (ChildrenCoverage113.cons _ _ compact113_node_4868
    (ChildrenCoverage113.cons _ _ compact113_node_4869
    (ChildrenCoverage113.cons _ _ compact113_node_4870
    (ChildrenCoverage113.cons _ _ compact113_node_4871
    (ChildrenCoverage113.cons _ _ compact113_node_4872
    (ChildrenCoverage113.cons _ _ compact113_node_4873
    (ChildrenCoverage113.cons _ _ compact113_node_4874
    ChildrenCoverage113.nil))))))))

theorem compact113_node_4876 : NodeCoverage113 [18,10,10,10] 10 65 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4877 : NodeCoverage113 [18,10,10,9] 9 66 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4878 : NodeCoverage113 [18,10,10,8] 8 67 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4879 : NodeCoverage113 [18,10,10,7] 7 68 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4880 : NodeCoverage113 [18,10,10,6] 6 69 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4881 : NodeCoverage113 [18,10,10,5] 5 70 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4882 : NodeCoverage113 [18,10,10,3] 3 72 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4883 : NodeCoverage113 [18,10,10] 10 75 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4876
    (ChildrenCoverage113.cons _ _ compact113_node_4877
    (ChildrenCoverage113.cons _ _ compact113_node_4878
    (ChildrenCoverage113.cons _ _ compact113_node_4879
    (ChildrenCoverage113.cons _ _ compact113_node_4880
    (ChildrenCoverage113.cons _ _ compact113_node_4881
    (ChildrenCoverage113.cons _ _ compact113_node_4882
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4884 : NodeCoverage113 [18,10,9] 9 76 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4885 : NodeCoverage113 [18,10,8] 8 77 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4886 : NodeCoverage113 [18,10,7] 7 78 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4887 : NodeCoverage113 [18,10,6] 6 79 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4888 : NodeCoverage113 [18,10,5] 5 80 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4889 : NodeCoverage113 [18,10,3] 3 82 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4890 : NodeCoverage113 [18,10] 10 85 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4883
    (ChildrenCoverage113.cons _ _ compact113_node_4884
    (ChildrenCoverage113.cons _ _ compact113_node_4885
    (ChildrenCoverage113.cons _ _ compact113_node_4886
    (ChildrenCoverage113.cons _ _ compact113_node_4887
    (ChildrenCoverage113.cons _ _ compact113_node_4888
    (ChildrenCoverage113.cons _ _ compact113_node_4889
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4891 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,9,9,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4892 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,9,9] 9 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4891
    ChildrenCoverage113.nil)

theorem compact113_node_4893 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,9,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4894 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,9,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4895 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,9,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4896 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,9,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4897 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,9,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4898 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,9,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4897
    ChildrenCoverage113.nil)

theorem compact113_node_4899 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,9,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4898
    ChildrenCoverage113.nil)

theorem compact113_node_4900 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,9] 9 14 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4892
    (ChildrenCoverage113.cons _ _ compact113_node_4893
    (ChildrenCoverage113.cons _ _ compact113_node_4894
    (ChildrenCoverage113.cons _ _ compact113_node_4895
    (ChildrenCoverage113.cons _ _ compact113_node_4896
    (ChildrenCoverage113.cons _ _ compact113_node_4899
    ChildrenCoverage113.nil))))))

theorem compact113_node_4901 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4902 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4903 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4904 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4905 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4906 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4905
    ChildrenCoverage113.nil)

theorem compact113_node_4907 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4906
    ChildrenCoverage113.nil)

theorem compact113_node_4908 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4907
    ChildrenCoverage113.nil)

theorem compact113_node_4909 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4908
    ChildrenCoverage113.nil)

theorem compact113_node_4910 : NodeCoverage113 [18,9,9,9,9,9,9,9,9,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4909
    ChildrenCoverage113.nil)

theorem compact113_node_4911 : NodeCoverage113 [18,9,9,9,9,9,9,9,9] 9 23 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4900
    (ChildrenCoverage113.cons _ _ compact113_node_4901
    (ChildrenCoverage113.cons _ _ compact113_node_4902
    (ChildrenCoverage113.cons _ _ compact113_node_4903
    (ChildrenCoverage113.cons _ _ compact113_node_4904
    (ChildrenCoverage113.cons _ _ compact113_node_4910
    ChildrenCoverage113.nil))))))

theorem compact113_node_4912 : NodeCoverage113 [18,9,9,9,9,9,9,9,8] 8 24 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4913 : NodeCoverage113 [18,9,9,9,9,9,9,9,7] 7 25 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

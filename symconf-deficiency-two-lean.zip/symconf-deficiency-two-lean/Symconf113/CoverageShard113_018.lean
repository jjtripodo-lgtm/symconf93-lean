import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0777 : NodeCoverage113 [48,15] 15 50 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0778 : NodeCoverage113 [48,14] 14 51 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0779 : NodeCoverage113 [48,13] 13 52 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0780 : NodeCoverage113 [48,12,12,12,12,12,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0781 : NodeCoverage113 [48,12,12,12,12,12] 12 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0780
    ChildrenCoverage113.nil)

theorem compact113_node_0782 : NodeCoverage113 [48,12,12,12,12,11] 11 6 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0783 : NodeCoverage113 [48,12,12,12,12,10] 10 7 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0784 : NodeCoverage113 [48,12,12,12,12,9] 9 8 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0785 : NodeCoverage113 [48,12,12,12,12,8] 8 9 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0786 : NodeCoverage113 [48,12,12,12,12,7] 7 10 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0787 : NodeCoverage113 [48,12,12,12,12,6] 6 11 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0788 : NodeCoverage113 [48,12,12,12,12,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0789 : NodeCoverage113 [48,12,12,12,12,3] 3 14 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0790 : NodeCoverage113 [48,12,12,12,12] 12 17 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0781
    (ChildrenCoverage113.cons _ _ compact113_node_0782
    (ChildrenCoverage113.cons _ _ compact113_node_0783
    (ChildrenCoverage113.cons _ _ compact113_node_0784
    (ChildrenCoverage113.cons _ _ compact113_node_0785
    (ChildrenCoverage113.cons _ _ compact113_node_0786
    (ChildrenCoverage113.cons _ _ compact113_node_0787
    (ChildrenCoverage113.cons _ _ compact113_node_0788
    (ChildrenCoverage113.cons _ _ compact113_node_0789
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_0791 : NodeCoverage113 [48,12,12,12,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0792 : NodeCoverage113 [48,12,12,12,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0793 : NodeCoverage113 [48,12,12,12,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0794 : NodeCoverage113 [48,12,12,12,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0795 : NodeCoverage113 [48,12,12,12,7] 7 22 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0796 : NodeCoverage113 [48,12,12,12,6] 6 23 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0797 : NodeCoverage113 [48,12,12,12,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0798 : NodeCoverage113 [48,12,12,12,3] 3 26 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0799 : NodeCoverage113 [48,12,12,12] 12 29 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0790
    (ChildrenCoverage113.cons _ _ compact113_node_0791
    (ChildrenCoverage113.cons _ _ compact113_node_0792
    (ChildrenCoverage113.cons _ _ compact113_node_0793
    (ChildrenCoverage113.cons _ _ compact113_node_0794
    (ChildrenCoverage113.cons _ _ compact113_node_0795
    (ChildrenCoverage113.cons _ _ compact113_node_0796
    (ChildrenCoverage113.cons _ _ compact113_node_0797
    (ChildrenCoverage113.cons _ _ compact113_node_0798
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_0800 : NodeCoverage113 [48,12,12,11] 11 30 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0801 : NodeCoverage113 [48,12,12,10] 10 31 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0802 : NodeCoverage113 [48,12,12,9] 9 32 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0803 : NodeCoverage113 [48,12,12,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0804 : NodeCoverage113 [48,12,12,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0805 : NodeCoverage113 [48,12,12,6] 6 35 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0806 : NodeCoverage113 [48,12,12,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0807 : NodeCoverage113 [48,12,12,3] 3 38 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0808 : NodeCoverage113 [48,12,12] 12 41 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0799
    (ChildrenCoverage113.cons _ _ compact113_node_0800
    (ChildrenCoverage113.cons _ _ compact113_node_0801
    (ChildrenCoverage113.cons _ _ compact113_node_0802
    (ChildrenCoverage113.cons _ _ compact113_node_0803
    (ChildrenCoverage113.cons _ _ compact113_node_0804
    (ChildrenCoverage113.cons _ _ compact113_node_0805
    (ChildrenCoverage113.cons _ _ compact113_node_0806
    (ChildrenCoverage113.cons _ _ compact113_node_0807
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_0809 : NodeCoverage113 [48,12,11] 11 42 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0810 : NodeCoverage113 [48,12,10] 10 43 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0811 : NodeCoverage113 [48,12,9] 9 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0812 : NodeCoverage113 [48,12,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0813 : NodeCoverage113 [48,12,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0814 : NodeCoverage113 [48,12,6] 6 47 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

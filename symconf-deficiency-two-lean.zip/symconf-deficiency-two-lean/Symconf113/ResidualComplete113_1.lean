import Symconf113.ResidualCands113

/-! Kernel check: every full row of type index 1 passing the row tests is listed. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem complete_1 : ∀ v ∈ vecs, rowOK 1 v=true → v ∈ candB := by decide +kernel
end Symconf113

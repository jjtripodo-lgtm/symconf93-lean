import Symconf113.CoverageShard113_138

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5609 : NodeCoverage113 [14,14,11,11,6] 6 57 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5610 : NodeCoverage113 [14,14,11,11,5] 5 58 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5611 : NodeCoverage113 [14,14,11,11,3] 3 60 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5612 : NodeCoverage113 [14,14,11,11] 11 63 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5604
    (ChildrenCoverage113.cons _ _ compact113_node_5605
    (ChildrenCoverage113.cons _ _ compact113_node_5606
    (ChildrenCoverage113.cons _ _ compact113_node_5607
    (ChildrenCoverage113.cons _ _ compact113_node_5608
    (ChildrenCoverage113.cons _ _ compact113_node_5609
    (ChildrenCoverage113.cons _ _ compact113_node_5610
    (ChildrenCoverage113.cons _ _ compact113_node_5611
    ChildrenCoverage113.nil))))))))

theorem compact113_node_5613 : NodeCoverage113 [14,14,11,10] 10 64 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5614 : NodeCoverage113 [14,14,11,9] 9 65 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5615 : NodeCoverage113 [14,14,11,8] 8 66 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5616 : NodeCoverage113 [14,14,11,7] 7 67 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5617 : NodeCoverage113 [14,14,11,6] 6 68 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5618 : NodeCoverage113 [14,14,11,5] 5 69 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5619 : NodeCoverage113 [14,14,11,3] 3 71 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5620 : NodeCoverage113 [14,14,11] 11 74 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5612
    (ChildrenCoverage113.cons _ _ compact113_node_5613
    (ChildrenCoverage113.cons _ _ compact113_node_5614
    (ChildrenCoverage113.cons _ _ compact113_node_5615
    (ChildrenCoverage113.cons _ _ compact113_node_5616
    (ChildrenCoverage113.cons _ _ compact113_node_5617
    (ChildrenCoverage113.cons _ _ compact113_node_5618
    (ChildrenCoverage113.cons _ _ compact113_node_5619
    ChildrenCoverage113.nil))))))))

theorem compact113_node_5621 : NodeCoverage113 [14,14,10,10,10,10] 10 45 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5622 : NodeCoverage113 [14,14,10,10,10,9] 9 46 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5623 : NodeCoverage113 [14,14,10,10,10,8] 8 47 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5624 : NodeCoverage113 [14,14,10,10,10,7] 7 48 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5625 : NodeCoverage113 [14,14,10,10,10,6] 6 49 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5626 : NodeCoverage113 [14,14,10,10,10,5] 5 50 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5627 : NodeCoverage113 [14,14,10,10,10,3] 3 52 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5628 : NodeCoverage113 [14,14,10,10,10] 10 55 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5621
    (ChildrenCoverage113.cons _ _ compact113_node_5622
    (ChildrenCoverage113.cons _ _ compact113_node_5623
    (ChildrenCoverage113.cons _ _ compact113_node_5624
    (ChildrenCoverage113.cons _ _ compact113_node_5625
    (ChildrenCoverage113.cons _ _ compact113_node_5626
    (ChildrenCoverage113.cons _ _ compact113_node_5627
    ChildrenCoverage113.nil)))))))

theorem compact113_node_5629 : NodeCoverage113 [14,14,10,10,9] 9 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5630 : NodeCoverage113 [14,14,10,10,8] 8 57 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5631 : NodeCoverage113 [14,14,10,10,7] 7 58 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5632 : NodeCoverage113 [14,14,10,10,6] 6 59 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5633 : NodeCoverage113 [14,14,10,10,5] 5 60 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5634 : NodeCoverage113 [14,14,10,10,3] 3 62 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5635 : NodeCoverage113 [14,14,10,10] 10 65 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5628
    (ChildrenCoverage113.cons _ _ compact113_node_5629
    (ChildrenCoverage113.cons _ _ compact113_node_5630
    (ChildrenCoverage113.cons _ _ compact113_node_5631
    (ChildrenCoverage113.cons _ _ compact113_node_5632
    (ChildrenCoverage113.cons _ _ compact113_node_5633
    (ChildrenCoverage113.cons _ _ compact113_node_5634
    ChildrenCoverage113.nil)))))))

theorem compact113_node_5636 : NodeCoverage113 [14,14,10,9] 9 66 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5637 : NodeCoverage113 [14,14,10,8] 8 67 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5638 : NodeCoverage113 [14,14,10,7] 7 68 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5639 : NodeCoverage113 [14,14,10,6] 6 69 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5640 : NodeCoverage113 [14,14,10,5] 5 70 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5641 : NodeCoverage113 [14,14,10,3] 3 72 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5642 : NodeCoverage113 [14,14,10] 10 75 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5635
    (ChildrenCoverage113.cons _ _ compact113_node_5636
    (ChildrenCoverage113.cons _ _ compact113_node_5637
    (ChildrenCoverage113.cons _ _ compact113_node_5638
    (ChildrenCoverage113.cons _ _ compact113_node_5639
    (ChildrenCoverage113.cons _ _ compact113_node_5640
    (ChildrenCoverage113.cons _ _ compact113_node_5641
    ChildrenCoverage113.nil)))))))

theorem compact113_node_5643 : NodeCoverage113 [14,14,9,9,9,9,9] 9 40 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5644 : NodeCoverage113 [14,14,9,9,9,9,8] 8 41 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5645 : NodeCoverage113 [14,14,9,9,9,9,7] 7 42 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5646 : NodeCoverage113 [14,14,9,9,9,9,6] 6 43 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5647 : NodeCoverage113 [14,14,9,9,9,9,5] 5 44 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5648 : NodeCoverage113 [14,14,9,9,9,9,3] 3 46 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5649 : NodeCoverage113 [14,14,9,9,9,9] 9 49 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5643
    (ChildrenCoverage113.cons _ _ compact113_node_5644
    (ChildrenCoverage113.cons _ _ compact113_node_5645
    (ChildrenCoverage113.cons _ _ compact113_node_5646
    (ChildrenCoverage113.cons _ _ compact113_node_5647
    (ChildrenCoverage113.cons _ _ compact113_node_5648
    ChildrenCoverage113.nil))))))

theorem compact113_node_5650 : NodeCoverage113 [14,14,9,9,9,8] 8 50 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5651 : NodeCoverage113 [14,14,9,9,9,7] 7 51 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5652 : NodeCoverage113 [14,14,9,9,9,6] 6 52 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5653 : NodeCoverage113 [14,14,9,9,9,5] 5 53 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5654 : NodeCoverage113 [14,14,9,9,9,3] 3 55 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5655 : NodeCoverage113 [14,14,9,9,9] 9 58 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5649
    (ChildrenCoverage113.cons _ _ compact113_node_5650
    (ChildrenCoverage113.cons _ _ compact113_node_5651
    (ChildrenCoverage113.cons _ _ compact113_node_5652
    (ChildrenCoverage113.cons _ _ compact113_node_5653
    (ChildrenCoverage113.cons _ _ compact113_node_5654
    ChildrenCoverage113.nil))))))

theorem compact113_node_5656 : NodeCoverage113 [14,14,9,9,8] 8 59 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5657 : NodeCoverage113 [14,14,9,9,7] 7 60 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5658 : NodeCoverage113 [14,14,9,9,6] 6 61 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5659 : NodeCoverage113 [14,14,9,9,5] 5 62 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5660 : NodeCoverage113 [14,14,9,9,3] 3 64 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5661 : NodeCoverage113 [14,14,9,9] 9 67 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5655
    (ChildrenCoverage113.cons _ _ compact113_node_5656
    (ChildrenCoverage113.cons _ _ compact113_node_5657
    (ChildrenCoverage113.cons _ _ compact113_node_5658
    (ChildrenCoverage113.cons _ _ compact113_node_5659
    (ChildrenCoverage113.cons _ _ compact113_node_5660
    ChildrenCoverage113.nil))))))

theorem compact113_node_5662 : NodeCoverage113 [14,14,9,8] 8 68 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5663 : NodeCoverage113 [14,14,9,7] 7 69 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5664 : NodeCoverage113 [14,14,9,6] 6 70 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5665 : NodeCoverage113 [14,14,9,5] 5 71 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

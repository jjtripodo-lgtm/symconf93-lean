import Symconf113.ResidualLeaves113

/-! Kernel check: the signature stage refutes leaves 192 to 207. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem sigShard_192 : ((leaves.drop 192).take 16).all sigStage=true := by decide +kernel
end Symconf113

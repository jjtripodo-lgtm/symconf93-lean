import Symconf113.CoverageShard113_074

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2605 : NodeCoverage113 [28,28,14,14,7,7,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2606 : NodeCoverage113 [28,28,14,14,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2602
    (ChildrenCoverage113.cons _ _ compact113_node_2603
    (ChildrenCoverage113.cons _ _ compact113_node_2604
    (ChildrenCoverage113.cons _ _ compact113_node_2605
    ChildrenCoverage113.nil))))

theorem compact113_node_2607 : NodeCoverage113 [28,28,14,14,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2608 : NodeCoverage113 [28,28,14,14,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2609 : NodeCoverage113 [28,28,14,14,7,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2610 : NodeCoverage113 [28,28,14,14,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2606
    (ChildrenCoverage113.cons _ _ compact113_node_2607
    (ChildrenCoverage113.cons _ _ compact113_node_2608
    (ChildrenCoverage113.cons _ _ compact113_node_2609
    ChildrenCoverage113.nil))))

theorem compact113_node_2611 : NodeCoverage113 [28,28,14,14,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2612 : NodeCoverage113 [28,28,14,14,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2613 : NodeCoverage113 [28,28,14,14,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2614 : NodeCoverage113 [28,28,14,14] 14 29 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2593
    (ChildrenCoverage113.cons _ _ compact113_node_2594
    (ChildrenCoverage113.cons _ _ compact113_node_2595
    (ChildrenCoverage113.cons _ _ compact113_node_2596
    (ChildrenCoverage113.cons _ _ compact113_node_2597
    (ChildrenCoverage113.cons _ _ compact113_node_2598
    (ChildrenCoverage113.cons _ _ compact113_node_2599
    (ChildrenCoverage113.cons _ _ compact113_node_2610
    (ChildrenCoverage113.cons _ _ compact113_node_2611
    (ChildrenCoverage113.cons _ _ compact113_node_2612
    (ChildrenCoverage113.cons _ _ compact113_node_2613
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_2615 : NodeCoverage113 [28,28,14,13] 13 30 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2616 : NodeCoverage113 [28,28,14,12] 12 31 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2617 : NodeCoverage113 [28,28,14,11] 11 32 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2618 : NodeCoverage113 [28,28,14,10] 10 33 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2619 : NodeCoverage113 [28,28,14,9] 9 34 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2620 : NodeCoverage113 [28,28,14,8] 8 35 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2621 : NodeCoverage113 [28,28,14,7,7,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2622 : NodeCoverage113 [28,28,14,7,7,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2623 : NodeCoverage113 [28,28,14,7,7,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2621
    (ChildrenCoverage113.cons _ _ compact113_node_2622
    ChildrenCoverage113.nil))

theorem compact113_node_2624 : NodeCoverage113 [28,28,14,7,7,7,7,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2625 : NodeCoverage113 [28,28,14,7,7,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2626 : NodeCoverage113 [28,28,14,7,7,7,7,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2627 : NodeCoverage113 [28,28,14,7,7,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2623
    (ChildrenCoverage113.cons _ _ compact113_node_2624
    (ChildrenCoverage113.cons _ _ compact113_node_2625
    (ChildrenCoverage113.cons _ _ compact113_node_2626
    ChildrenCoverage113.nil))))

theorem compact113_node_2628 : NodeCoverage113 [28,28,14,7,7,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2629 : NodeCoverage113 [28,28,14,7,7,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2630 : NodeCoverage113 [28,28,14,7,7,7,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2631 : NodeCoverage113 [28,28,14,7,7,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2627
    (ChildrenCoverage113.cons _ _ compact113_node_2628
    (ChildrenCoverage113.cons _ _ compact113_node_2629
    (ChildrenCoverage113.cons _ _ compact113_node_2630
    ChildrenCoverage113.nil))))

theorem compact113_node_2632 : NodeCoverage113 [28,28,14,7,7,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2633 : NodeCoverage113 [28,28,14,7,7,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2634 : NodeCoverage113 [28,28,14,7,7,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2635 : NodeCoverage113 [28,28,14,7,7] 7 29 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2631
    (ChildrenCoverage113.cons _ _ compact113_node_2632
    (ChildrenCoverage113.cons _ _ compact113_node_2633
    (ChildrenCoverage113.cons _ _ compact113_node_2634
    ChildrenCoverage113.nil))))

theorem compact113_node_2636 : NodeCoverage113 [28,28,14,7,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2637 : NodeCoverage113 [28,28,14,7,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2638 : NodeCoverage113 [28,28,14,7,3] 3 33 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2639 : NodeCoverage113 [28,28,14,7] 7 36 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2635
    (ChildrenCoverage113.cons _ _ compact113_node_2636
    (ChildrenCoverage113.cons _ _ compact113_node_2637
    (ChildrenCoverage113.cons _ _ compact113_node_2638
    ChildrenCoverage113.nil))))

theorem compact113_node_2640 : NodeCoverage113 [28,28,14,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2641 : NodeCoverage113 [28,28,14,5] 5 38 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2642 : NodeCoverage113 [28,28,14,3] 3 40 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2643 : NodeCoverage113 [28,28,14] 14 43 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2614
    (ChildrenCoverage113.cons _ _ compact113_node_2615
    (ChildrenCoverage113.cons _ _ compact113_node_2616
    (ChildrenCoverage113.cons _ _ compact113_node_2617
    (ChildrenCoverage113.cons _ _ compact113_node_2618
    (ChildrenCoverage113.cons _ _ compact113_node_2619
    (ChildrenCoverage113.cons _ _ compact113_node_2620
    (ChildrenCoverage113.cons _ _ compact113_node_2639
    (ChildrenCoverage113.cons _ _ compact113_node_2640
    (ChildrenCoverage113.cons _ _ compact113_node_2641
    (ChildrenCoverage113.cons _ _ compact113_node_2642
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_2644 : NodeCoverage113 [28,28,13] 13 44 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2645 : NodeCoverage113 [28,28,12] 12 45 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2646 : NodeCoverage113 [28,28,11] 11 46 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2647 : NodeCoverage113 [28,28,10] 10 47 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2648 : NodeCoverage113 [28,28,9] 9 48 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2649 : NodeCoverage113 [28,28,8] 8 49 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2650 : NodeCoverage113 [28,28,7,7,7,7,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2651 : NodeCoverage113 [28,28,7,7,7,7,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2652 : NodeCoverage113 [28,28,7,7,7,7,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2650
    (ChildrenCoverage113.cons _ _ compact113_node_2651
    ChildrenCoverage113.nil))

theorem compact113_node_2653 : NodeCoverage113 [28,28,7,7,7,7,7,7,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2654 : NodeCoverage113 [28,28,7,7,7,7,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2655 : NodeCoverage113 [28,28,7,7,7,7,7,7,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2656 : NodeCoverage113 [28,28,7,7,7,7,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2652
    (ChildrenCoverage113.cons _ _ compact113_node_2653
    (ChildrenCoverage113.cons _ _ compact113_node_2654
    (ChildrenCoverage113.cons _ _ compact113_node_2655
    ChildrenCoverage113.nil))))

theorem compact113_node_2657 : NodeCoverage113 [28,28,7,7,7,7,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2658 : NodeCoverage113 [28,28,7,7,7,7,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2659 : NodeCoverage113 [28,28,7,7,7,7,7,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2660 : NodeCoverage113 [28,28,7,7,7,7,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2656
    (ChildrenCoverage113.cons _ _ compact113_node_2657
    (ChildrenCoverage113.cons _ _ compact113_node_2658
    (ChildrenCoverage113.cons _ _ compact113_node_2659
    ChildrenCoverage113.nil))))

theorem compact113_node_2661 : NodeCoverage113 [28,28,7,7,7,7,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2662 : NodeCoverage113 [28,28,7,7,7,7,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2663 : NodeCoverage113 [28,28,7,7,7,7,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2664 : NodeCoverage113 [28,28,7,7,7,7] 7 29 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2660
    (ChildrenCoverage113.cons _ _ compact113_node_2661
    (ChildrenCoverage113.cons _ _ compact113_node_2662
    (ChildrenCoverage113.cons _ _ compact113_node_2663
    ChildrenCoverage113.nil))))

theorem compact113_node_2665 : NodeCoverage113 [28,28,7,7,7,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2666 : NodeCoverage113 [28,28,7,7,7,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2667 : NodeCoverage113 [28,28,7,7,7,3] 3 33 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2668 : NodeCoverage113 [28,28,7,7,7] 7 36 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2664
    (ChildrenCoverage113.cons _ _ compact113_node_2665
    (ChildrenCoverage113.cons _ _ compact113_node_2666
    (ChildrenCoverage113.cons _ _ compact113_node_2667
    ChildrenCoverage113.nil))))

theorem compact113_node_2669 : NodeCoverage113 [28,28,7,7,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2670 : NodeCoverage113 [28,28,7,7,5] 5 38 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2671 : NodeCoverage113 [28,28,7,7,3] 3 40 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2672 : NodeCoverage113 [28,28,7,7] 7 43 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2668
    (ChildrenCoverage113.cons _ _ compact113_node_2669
    (ChildrenCoverage113.cons _ _ compact113_node_2670
    (ChildrenCoverage113.cons _ _ compact113_node_2671
    ChildrenCoverage113.nil))))

theorem compact113_node_2673 : NodeCoverage113 [28,28,7,6] 6 44 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2674 : NodeCoverage113 [28,28,7,5] 5 45 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

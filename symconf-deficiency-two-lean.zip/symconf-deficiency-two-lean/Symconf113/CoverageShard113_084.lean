import Symconf113.CoverageShard113_083

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3048 : NodeCoverage113 [24,24,24,12,6,3] 3 20 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3049 : NodeCoverage113 [24,24,24,12,6] 6 23 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3046
    (ChildrenCoverage113.cons _ _ compact113_node_3047
    (ChildrenCoverage113.cons _ _ compact113_node_3048
    ChildrenCoverage113.nil)))

theorem compact113_node_3050 : NodeCoverage113 [24,24,24,12,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3051 : NodeCoverage113 [24,24,24,12,3] 3 26 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3052 : NodeCoverage113 [24,24,24,12] 12 29 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3029
    (ChildrenCoverage113.cons _ _ compact113_node_3030
    (ChildrenCoverage113.cons _ _ compact113_node_3031
    (ChildrenCoverage113.cons _ _ compact113_node_3032
    (ChildrenCoverage113.cons _ _ compact113_node_3033
    (ChildrenCoverage113.cons _ _ compact113_node_3034
    (ChildrenCoverage113.cons _ _ compact113_node_3049
    (ChildrenCoverage113.cons _ _ compact113_node_3050
    (ChildrenCoverage113.cons _ _ compact113_node_3051
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_3053 : NodeCoverage113 [24,24,24,11] 11 30 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3054 : NodeCoverage113 [24,24,24,10] 10 31 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3055 : NodeCoverage113 [24,24,24,9] 9 32 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3056 : NodeCoverage113 [24,24,24,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3057 : NodeCoverage113 [24,24,24,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3058 : NodeCoverage113 [24,24,24,6,6,6,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3059 : NodeCoverage113 [24,24,24,6,6,6,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3058
    ChildrenCoverage113.nil)

theorem compact113_node_3060 : NodeCoverage113 [24,24,24,6,6,6,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3061 : NodeCoverage113 [24,24,24,6,6,6,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_3062 : NodeCoverage113 [24,24,24,6,6,6,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3061
    ChildrenCoverage113.nil)

theorem compact113_node_3063 : NodeCoverage113 [24,24,24,6,6,6,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3059
    (ChildrenCoverage113.cons _ _ compact113_node_3060
    (ChildrenCoverage113.cons _ _ compact113_node_3062
    ChildrenCoverage113.nil)))

theorem compact113_node_3064 : NodeCoverage113 [24,24,24,6,6,6,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3065 : NodeCoverage113 [24,24,24,6,6,6,6,3] 3 14 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3066 : NodeCoverage113 [24,24,24,6,6,6,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3063
    (ChildrenCoverage113.cons _ _ compact113_node_3064
    (ChildrenCoverage113.cons _ _ compact113_node_3065
    ChildrenCoverage113.nil)))

theorem compact113_node_3067 : NodeCoverage113 [24,24,24,6,6,6,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3068 : NodeCoverage113 [24,24,24,6,6,6,3] 3 20 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3069 : NodeCoverage113 [24,24,24,6,6,6] 6 23 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3066
    (ChildrenCoverage113.cons _ _ compact113_node_3067
    (ChildrenCoverage113.cons _ _ compact113_node_3068
    ChildrenCoverage113.nil)))

theorem compact113_node_3070 : NodeCoverage113 [24,24,24,6,6,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3071 : NodeCoverage113 [24,24,24,6,6,3] 3 26 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3072 : NodeCoverage113 [24,24,24,6,6] 6 29 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3069
    (ChildrenCoverage113.cons _ _ compact113_node_3070
    (ChildrenCoverage113.cons _ _ compact113_node_3071
    ChildrenCoverage113.nil)))

theorem compact113_node_3073 : NodeCoverage113 [24,24,24,6,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_006

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0304 : NodeCoverage113 [63,25] 25 25 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0305 : NodeCoverage113 [63,24] 24 26 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0306 : NodeCoverage113 [63,23] 23 27 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0307 : NodeCoverage113 [63,22] 22 28 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0308 : NodeCoverage113 [63,21] 21 29 :=
  demand_node_prune113 63 compact113_demands_063 compact113_demands_063_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0309 : NodeCoverage113 [63,20] 20 30 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0310 : NodeCoverage113 [63,19] 19 31 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0311 : NodeCoverage113 [63,18] 18 32 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0312 : NodeCoverage113 [63,17] 17 33 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0313 : NodeCoverage113 [63,16] 16 34 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0314 : NodeCoverage113 [63,15] 15 35 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0315 : NodeCoverage113 [63,14] 14 36 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0316 : NodeCoverage113 [63,13] 13 37 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0317 : NodeCoverage113 [63,12] 12 38 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0318 : NodeCoverage113 [63,11] 11 39 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0319 : NodeCoverage113 [63,10] 10 40 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0320 : NodeCoverage113 [63,9,9,9,9,9,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0321 : NodeCoverage113 [63,9,9,9,9,9] 9 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0320
    ChildrenCoverage113.nil)

theorem compact113_node_0322 : NodeCoverage113 [63,9,9,9,9,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0323 : NodeCoverage113 [63,9,9,9,9,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0324 : NodeCoverage113 [63,9,9,9,9,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0325 : NodeCoverage113 [63,9,9,9,9,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0326 : NodeCoverage113 [63,9,9,9,9,3] 3 11 :=
  demand_node_prune113 63 compact113_demands_063 compact113_demands_063_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0327 : NodeCoverage113 [63,9,9,9,9] 9 14 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0321
    (ChildrenCoverage113.cons _ _ compact113_node_0322
    (ChildrenCoverage113.cons _ _ compact113_node_0323
    (ChildrenCoverage113.cons _ _ compact113_node_0324
    (ChildrenCoverage113.cons _ _ compact113_node_0325
    (ChildrenCoverage113.cons _ _ compact113_node_0326
    ChildrenCoverage113.nil))))))

theorem compact113_node_0328 : NodeCoverage113 [63,9,9,9,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0329 : NodeCoverage113 [63,9,9,9,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0330 : NodeCoverage113 [63,9,9,9,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0331 : NodeCoverage113 [63,9,9,9,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0332 : NodeCoverage113 [63,9,9,9,3] 3 20 :=
  demand_node_prune113 63 compact113_demands_063 compact113_demands_063_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0333 : NodeCoverage113 [63,9,9,9] 9 23 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0327
    (ChildrenCoverage113.cons _ _ compact113_node_0328
    (ChildrenCoverage113.cons _ _ compact113_node_0329
    (ChildrenCoverage113.cons _ _ compact113_node_0330
    (ChildrenCoverage113.cons _ _ compact113_node_0331
    (ChildrenCoverage113.cons _ _ compact113_node_0332
    ChildrenCoverage113.nil))))))

theorem compact113_node_0334 : NodeCoverage113 [63,9,9,8] 8 24 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0335 : NodeCoverage113 [63,9,9,7] 7 25 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0336 : NodeCoverage113 [63,9,9,6] 6 26 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0337 : NodeCoverage113 [63,9,9,5] 5 27 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0338 : NodeCoverage113 [63,9,9,3] 3 29 :=
  demand_node_prune113 63 compact113_demands_063 compact113_demands_063_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0339 : NodeCoverage113 [63,9,9] 9 32 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0333
    (ChildrenCoverage113.cons _ _ compact113_node_0334
    (ChildrenCoverage113.cons _ _ compact113_node_0335
    (ChildrenCoverage113.cons _ _ compact113_node_0336
    (ChildrenCoverage113.cons _ _ compact113_node_0337
    (ChildrenCoverage113.cons _ _ compact113_node_0338
    ChildrenCoverage113.nil))))))

theorem compact113_node_0340 : NodeCoverage113 [63,9,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0341 : NodeCoverage113 [63,9,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0342 : NodeCoverage113 [63,9,6] 6 35 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0343 : NodeCoverage113 [63,9,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0344 : NodeCoverage113 [63,9,3] 3 38 :=
  demand_node_prune113 63 compact113_demands_063 compact113_demands_063_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0345 : NodeCoverage113 [63,9] 9 41 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0339
    (ChildrenCoverage113.cons _ _ compact113_node_0340
    (ChildrenCoverage113.cons _ _ compact113_node_0341
    (ChildrenCoverage113.cons _ _ compact113_node_0342
    (ChildrenCoverage113.cons _ _ compact113_node_0343
    (ChildrenCoverage113.cons _ _ compact113_node_0344
    ChildrenCoverage113.nil))))))

theorem compact113_node_0346 : NodeCoverage113 [63,8] 8 42 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0347 : NodeCoverage113 [63,7] 7 43 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0348 : NodeCoverage113 [63,6] 6 44 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0349 : NodeCoverage113 [63,5] 5 45 :=
  demand_node_prune113 63 compact113_demands_063 compact113_demands_063_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0350 : NodeCoverage113 [63,3] 3 47 :=
  demand_node_prune113 63 compact113_demands_063 compact113_demands_063_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0351 : NodeCoverage113 [63] 63 50 :=
  node_fork113 (B := [50,47,46,45,44,43,42,41,40,39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0281
    (ChildrenCoverage113.cons _ _ compact113_node_0282
    (ChildrenCoverage113.cons _ _ compact113_node_0283
    (ChildrenCoverage113.cons _ _ compact113_node_0284
    (ChildrenCoverage113.cons _ _ compact113_node_0285
    (ChildrenCoverage113.cons _ _ compact113_node_0286
    (ChildrenCoverage113.cons _ _ compact113_node_0287
    (ChildrenCoverage113.cons _ _ compact113_node_0288
    (ChildrenCoverage113.cons _ _ compact113_node_0289
    (ChildrenCoverage113.cons _ _ compact113_node_0290
    (ChildrenCoverage113.cons _ _ compact113_node_0291
    (ChildrenCoverage113.cons _ _ compact113_node_0292
    (ChildrenCoverage113.cons _ _ compact113_node_0293
    (ChildrenCoverage113.cons _ _ compact113_node_0294
    (ChildrenCoverage113.cons _ _ compact113_node_0295
    (ChildrenCoverage113.cons _ _ compact113_node_0296
    (ChildrenCoverage113.cons _ _ compact113_node_0297
    (ChildrenCoverage113.cons _ _ compact113_node_0298
    (ChildrenCoverage113.cons _ _ compact113_node_0299
    (ChildrenCoverage113.cons _ _ compact113_node_0300
    (ChildrenCoverage113.cons _ _ compact113_node_0301
    (ChildrenCoverage113.cons _ _ compact113_node_0302
    (ChildrenCoverage113.cons _ _ compact113_node_0303
    (ChildrenCoverage113.cons _ _ compact113_node_0304
    (ChildrenCoverage113.cons _ _ compact113_node_0305
    (ChildrenCoverage113.cons _ _ compact113_node_0306
    (ChildrenCoverage113.cons _ _ compact113_node_0307
    (ChildrenCoverage113.cons _ _ compact113_node_0308
    (ChildrenCoverage113.cons _ _ compact113_node_0309
    (ChildrenCoverage113.cons _ _ compact113_node_0310
    (ChildrenCoverage113.cons _ _ compact113_node_0311
    (ChildrenCoverage113.cons _ _ compact113_node_0312
    (ChildrenCoverage113.cons _ _ compact113_node_0313
    (ChildrenCoverage113.cons _ _ compact113_node_0314
    (ChildrenCoverage113.cons _ _ compact113_node_0315
    (ChildrenCoverage113.cons _ _ compact113_node_0316
    (ChildrenCoverage113.cons _ _ compact113_node_0317
    (ChildrenCoverage113.cons _ _ compact113_node_0318
    (ChildrenCoverage113.cons _ _ compact113_node_0319
    (ChildrenCoverage113.cons _ _ compact113_node_0345
    (ChildrenCoverage113.cons _ _ compact113_node_0346
    (ChildrenCoverage113.cons _ _ compact113_node_0347
    (ChildrenCoverage113.cons _ _ compact113_node_0348
    (ChildrenCoverage113.cons _ _ compact113_node_0349
    (ChildrenCoverage113.cons _ _ compact113_node_0350
    ChildrenCoverage113.nil)))))))))))))))))))))))))))))))))))))))))))))

theorem compact113_node_0352 : NodeCoverage113 [62] 62 51 :=
  demand_node_prune113 62 compact113_demands_062 compact113_demands_062_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0353 : NodeCoverage113 [61] 61 52 :=
  demand_node_prune113 61 compact113_demands_061 compact113_demands_061_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0354 : NodeCoverage113 [60,53] 53 0 :=
  demand_node_prune113 53 compact113_demands_053 compact113_demands_053_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0355 : NodeCoverage113 [60,50] 50 3 :=
  demand_node_prune113 50 compact113_demands_050 compact113_demands_050_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0356 : NodeCoverage113 [60,49] 49 4 :=
  demand_node_prune113 49 compact113_demands_049 compact113_demands_049_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0357 : NodeCoverage113 [60,48] 48 5 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0358 : NodeCoverage113 [60,47] 47 6 :=
  demand_node_prune113 47 compact113_demands_047 compact113_demands_047_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0359 : NodeCoverage113 [60,46] 46 7 :=
  demand_node_prune113 46 compact113_demands_046 compact113_demands_046_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0360 : NodeCoverage113 [60,45] 45 8 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0361 : NodeCoverage113 [60,44] 44 9 :=
  demand_node_prune113 44 compact113_demands_044 compact113_demands_044_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0362 : NodeCoverage113 [60,43] 43 10 :=
  demand_node_prune113 43 compact113_demands_043 compact113_demands_043_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

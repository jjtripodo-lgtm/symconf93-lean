import Symconf113.ProfileSieve113

/-! The nineteen order-113 profiles that pass the weak-period row sieve, and
the coverage statement the generated prefix cover proves. Unlike order 93,
no Gram factor is needed downstream: seventeen profiles fall to finite
row-pair checks, one is handled by the residual argument and `[113]` is the
Hamiltonian case. -/
namespace Symconf113

def profiles19 : List (List ℕ) := [
  [113],
  [33, 33, 33, 11, 3],
  [30, 30, 30, 15, 5, 3],
  [15, 15, 15, 15, 15, 15, 15, 5, 3],
  [15, 15, 15, 15, 15, 15, 5, 5, 5, 5, 3],
  [15, 15, 15, 15, 15, 15, 5, 3, 3, 3, 3, 3, 3],
  [15, 15, 15, 15, 15, 5, 5, 5, 5, 5, 5, 5, 3],
  [15, 15, 15, 15, 15, 5, 5, 5, 5, 3, 3, 3, 3, 3, 3],
  [15, 15, 15, 15, 15, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3],
  [14, 14, 14, 14, 14, 7, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3],
  [11, 11, 11, 11, 11, 11, 11, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3],
  [10, 10, 10, 10, 10, 10, 10, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3],
  [7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3],
  [7, 7, 7, 7, 7, 7, 7, 7, 7, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5],
  [6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3],
  [6, 6, 6, 6, 6, 6, 6, 6, 6, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 3, 3],
  [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3],
  [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3],
  [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3]
]

def Coverage113 : Prop := ∀ P : List ℕ,
  P∈Symconf59.partitionLists 37 113 113 → profileSieve113 P=true → P∈profiles19

end Symconf113

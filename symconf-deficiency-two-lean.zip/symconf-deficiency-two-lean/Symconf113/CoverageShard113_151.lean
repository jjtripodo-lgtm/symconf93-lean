import Symconf113.CoverageShard113_150

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_6430 : NodeCoverage113 [12,12,11,11,11,10] 10 46 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6431 : NodeCoverage113 [12,12,11,11,11,9] 9 47 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6432 : NodeCoverage113 [12,12,11,11,11,8] 8 48 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6433 : NodeCoverage113 [12,12,11,11,11,7] 7 49 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6434 : NodeCoverage113 [12,12,11,11,11,6] 6 50 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6435 : NodeCoverage113 [12,12,11,11,11,5] 5 51 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6436 : NodeCoverage113 [12,12,11,11,11,3] 3 53 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6437 : NodeCoverage113 [12,12,11,11,11] 11 56 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6429
    (ChildrenCoverage113.cons _ _ compact113_node_6430
    (ChildrenCoverage113.cons _ _ compact113_node_6431
    (ChildrenCoverage113.cons _ _ compact113_node_6432
    (ChildrenCoverage113.cons _ _ compact113_node_6433
    (ChildrenCoverage113.cons _ _ compact113_node_6434
    (ChildrenCoverage113.cons _ _ compact113_node_6435
    (ChildrenCoverage113.cons _ _ compact113_node_6436
    ChildrenCoverage113.nil))))))))

theorem compact113_node_6438 : NodeCoverage113 [12,12,11,11,10] 10 57 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6439 : NodeCoverage113 [12,12,11,11,9] 9 58 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6440 : NodeCoverage113 [12,12,11,11,8] 8 59 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6441 : NodeCoverage113 [12,12,11,11,7] 7 60 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6442 : NodeCoverage113 [12,12,11,11,6] 6 61 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6443 : NodeCoverage113 [12,12,11,11,5] 5 62 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6444 : NodeCoverage113 [12,12,11,11,3] 3 64 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6445 : NodeCoverage113 [12,12,11,11] 11 67 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6437
    (ChildrenCoverage113.cons _ _ compact113_node_6438
    (ChildrenCoverage113.cons _ _ compact113_node_6439
    (ChildrenCoverage113.cons _ _ compact113_node_6440
    (ChildrenCoverage113.cons _ _ compact113_node_6441
    (ChildrenCoverage113.cons _ _ compact113_node_6442
    (ChildrenCoverage113.cons _ _ compact113_node_6443
    (ChildrenCoverage113.cons _ _ compact113_node_6444
    ChildrenCoverage113.nil))))))))

theorem compact113_node_6446 : NodeCoverage113 [12,12,11,10] 10 68 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6447 : NodeCoverage113 [12,12,11,9] 9 69 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6448 : NodeCoverage113 [12,12,11,8] 8 70 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6449 : NodeCoverage113 [12,12,11,7] 7 71 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6450 : NodeCoverage113 [12,12,11,6] 6 72 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6451 : NodeCoverage113 [12,12,11,5] 5 73 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6452 : NodeCoverage113 [12,12,11,3] 3 75 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6453 : NodeCoverage113 [12,12,11] 11 78 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6445
    (ChildrenCoverage113.cons _ _ compact113_node_6446
    (ChildrenCoverage113.cons _ _ compact113_node_6447
    (ChildrenCoverage113.cons _ _ compact113_node_6448
    (ChildrenCoverage113.cons _ _ compact113_node_6449
    (ChildrenCoverage113.cons _ _ compact113_node_6450
    (ChildrenCoverage113.cons _ _ compact113_node_6451
    (ChildrenCoverage113.cons _ _ compact113_node_6452
    ChildrenCoverage113.nil))))))))

theorem compact113_node_6454 : NodeCoverage113 [12,12,10,10,10,10] 10 49 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6455 : NodeCoverage113 [12,12,10,10,10,9] 9 50 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6456 : NodeCoverage113 [12,12,10,10,10,8] 8 51 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6457 : NodeCoverage113 [12,12,10,10,10,7] 7 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6458 : NodeCoverage113 [12,12,10,10,10,6] 6 53 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6459 : NodeCoverage113 [12,12,10,10,10,5] 5 54 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6460 : NodeCoverage113 [12,12,10,10,10,3] 3 56 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6461 : NodeCoverage113 [12,12,10,10,10] 10 59 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6454
    (ChildrenCoverage113.cons _ _ compact113_node_6455
    (ChildrenCoverage113.cons _ _ compact113_node_6456
    (ChildrenCoverage113.cons _ _ compact113_node_6457
    (ChildrenCoverage113.cons _ _ compact113_node_6458
    (ChildrenCoverage113.cons _ _ compact113_node_6459
    (ChildrenCoverage113.cons _ _ compact113_node_6460
    ChildrenCoverage113.nil)))))))

theorem compact113_node_6462 : NodeCoverage113 [12,12,10,10,9] 9 60 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6463 : NodeCoverage113 [12,12,10,10,8] 8 61 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6464 : NodeCoverage113 [12,12,10,10,7] 7 62 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6465 : NodeCoverage113 [12,12,10,10,6] 6 63 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6466 : NodeCoverage113 [12,12,10,10,5] 5 64 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6467 : NodeCoverage113 [12,12,10,10,3] 3 66 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6468 : NodeCoverage113 [12,12,10,10] 10 69 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6461
    (ChildrenCoverage113.cons _ _ compact113_node_6462
    (ChildrenCoverage113.cons _ _ compact113_node_6463
    (ChildrenCoverage113.cons _ _ compact113_node_6464
    (ChildrenCoverage113.cons _ _ compact113_node_6465
    (ChildrenCoverage113.cons _ _ compact113_node_6466
    (ChildrenCoverage113.cons _ _ compact113_node_6467
    ChildrenCoverage113.nil)))))))

theorem compact113_node_6469 : NodeCoverage113 [12,12,10,9] 9 70 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6470 : NodeCoverage113 [12,12,10,8] 8 71 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6471 : NodeCoverage113 [12,12,10,7] 7 72 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6472 : NodeCoverage113 [12,12,10,6] 6 73 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6473 : NodeCoverage113 [12,12,10,5] 5 74 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6474 : NodeCoverage113 [12,12,10,3] 3 76 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6475 : NodeCoverage113 [12,12,10] 10 79 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6468
    (ChildrenCoverage113.cons _ _ compact113_node_6469
    (ChildrenCoverage113.cons _ _ compact113_node_6470
    (ChildrenCoverage113.cons _ _ compact113_node_6471
    (ChildrenCoverage113.cons _ _ compact113_node_6472
    (ChildrenCoverage113.cons _ _ compact113_node_6473
    (ChildrenCoverage113.cons _ _ compact113_node_6474
    ChildrenCoverage113.nil)))))))

theorem compact113_node_6476 : NodeCoverage113 [12,12,9,9,9,9] 9 53 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6477 : NodeCoverage113 [12,12,9,9,9,8] 8 54 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6478 : NodeCoverage113 [12,12,9,9,9,7] 7 55 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6479 : NodeCoverage113 [12,12,9,9,9,6] 6 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6480 : NodeCoverage113 [12,12,9,9,9,5] 5 57 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6481 : NodeCoverage113 [12,12,9,9,9,3] 3 59 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6482 : NodeCoverage113 [12,12,9,9,9] 9 62 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6476
    (ChildrenCoverage113.cons _ _ compact113_node_6477
    (ChildrenCoverage113.cons _ _ compact113_node_6478
    (ChildrenCoverage113.cons _ _ compact113_node_6479
    (ChildrenCoverage113.cons _ _ compact113_node_6480
    (ChildrenCoverage113.cons _ _ compact113_node_6481
    ChildrenCoverage113.nil))))))

theorem compact113_node_6483 : NodeCoverage113 [12,12,9,9,8] 8 63 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6484 : NodeCoverage113 [12,12,9,9,7] 7 64 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6485 : NodeCoverage113 [12,12,9,9,6] 6 65 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6486 : NodeCoverage113 [12,12,9,9,5] 5 66 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6487 : NodeCoverage113 [12,12,9,9,3] 3 68 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6488 : NodeCoverage113 [12,12,9,9] 9 71 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6482
    (ChildrenCoverage113.cons _ _ compact113_node_6483
    (ChildrenCoverage113.cons _ _ compact113_node_6484
    (ChildrenCoverage113.cons _ _ compact113_node_6485
    (ChildrenCoverage113.cons _ _ compact113_node_6486
    (ChildrenCoverage113.cons _ _ compact113_node_6487
    ChildrenCoverage113.nil))))))

theorem compact113_node_6489 : NodeCoverage113 [12,12,9,8] 8 72 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.LeafDemand113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

def compact113_demands_092 : List (List Nat) := [

]
theorem compact113_demands_092_exact : rowDemand113 92=compact113_demands_092 := by decide +kernel

def compact113_demands_093 : List (List Nat) := [
  [93,93]
]
theorem compact113_demands_093_exact : rowDemand113 93=compact113_demands_093 := by decide +kernel

def compact113_demands_094 : List (List Nat) := [
  [94,47]
]
theorem compact113_demands_094_exact : rowDemand113 94=compact113_demands_094 := by decide +kernel

def compact113_demands_095 : List (List Nat) := [

]
theorem compact113_demands_095_exact : rowDemand113 95=compact113_demands_095 := by decide +kernel

def compact113_demands_096 : List (List Nat) := [
  [96,24]
]
theorem compact113_demands_096_exact : rowDemand113 96=compact113_demands_096 := by decide +kernel

def compact113_demands_097 : List (List Nat) := [

]
theorem compact113_demands_097_exact : rowDemand113 97=compact113_demands_097 := by decide +kernel

def compact113_demands_098 : List (List Nat) := [

]
theorem compact113_demands_098_exact : rowDemand113 98=compact113_demands_098 := by decide +kernel

def compact113_demands_099 : List (List Nat) := [
  [9,9,9,9,11,11,11,11,11,11,11],
  [9,9,9,9,9,9,9,11,11,11,33],
  [9,9,9,9,9,9,9,9,11,11,99]
]
theorem compact113_demands_099_exact : rowDemand113 99=compact113_demands_099 := by decide +kernel

end Symconf113

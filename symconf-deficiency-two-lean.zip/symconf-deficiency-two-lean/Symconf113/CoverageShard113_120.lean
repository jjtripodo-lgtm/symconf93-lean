import Symconf113.CoverageShard113_119

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4626 : NodeCoverage113 [18,18,9,9,9,9,9,9,9,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4627 : NodeCoverage113 [18,18,9,9,9,9,9,9,9,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4628 : NodeCoverage113 [18,18,9,9,9,9,9,9,9,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4627
    ChildrenCoverage113.nil)

theorem compact113_node_4629 : NodeCoverage113 [18,18,9,9,9,9,9,9,9,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4628
    ChildrenCoverage113.nil)

theorem compact113_node_4630 : NodeCoverage113 [18,18,9,9,9,9,9,9,9] 9 14 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4622
    (ChildrenCoverage113.cons _ _ compact113_node_4623
    (ChildrenCoverage113.cons _ _ compact113_node_4624
    (ChildrenCoverage113.cons _ _ compact113_node_4625
    (ChildrenCoverage113.cons _ _ compact113_node_4626
    (ChildrenCoverage113.cons _ _ compact113_node_4629
    ChildrenCoverage113.nil))))))

theorem compact113_node_4631 : NodeCoverage113 [18,18,9,9,9,9,9,9,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4632 : NodeCoverage113 [18,18,9,9,9,9,9,9,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4633 : NodeCoverage113 [18,18,9,9,9,9,9,9,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4634 : NodeCoverage113 [18,18,9,9,9,9,9,9,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4633
    ChildrenCoverage113.nil)

theorem compact113_node_4635 : NodeCoverage113 [18,18,9,9,9,9,9,9,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4636 : NodeCoverage113 [18,18,9,9,9,9,9,9,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4637 : NodeCoverage113 [18,18,9,9,9,9,9,9,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4636
    ChildrenCoverage113.nil)

theorem compact113_node_4638 : NodeCoverage113 [18,18,9,9,9,9,9,9,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4634
    (ChildrenCoverage113.cons _ _ compact113_node_4635
    (ChildrenCoverage113.cons _ _ compact113_node_4637
    ChildrenCoverage113.nil)))

theorem compact113_node_4639 : NodeCoverage113 [18,18,9,9,9,9,9,9,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4640 : NodeCoverage113 [18,18,9,9,9,9,9,9,6,3] 3 14 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4641 : NodeCoverage113 [18,18,9,9,9,9,9,9,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4638
    (ChildrenCoverage113.cons _ _ compact113_node_4639
    (ChildrenCoverage113.cons _ _ compact113_node_4640
    ChildrenCoverage113.nil)))

theorem compact113_node_4642 : NodeCoverage113 [18,18,9,9,9,9,9,9,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4643 : NodeCoverage113 [18,18,9,9,9,9,9,9,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4644 : NodeCoverage113 [18,18,9,9,9,9,9,9,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4643
    ChildrenCoverage113.nil)

theorem compact113_node_4645 : NodeCoverage113 [18,18,9,9,9,9,9,9,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4644
    ChildrenCoverage113.nil)

theorem compact113_node_4646 : NodeCoverage113 [18,18,9,9,9,9,9,9,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4645
    ChildrenCoverage113.nil)

theorem compact113_node_4647 : NodeCoverage113 [18,18,9,9,9,9,9,9,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4646
    ChildrenCoverage113.nil)

theorem compact113_node_4648 : NodeCoverage113 [18,18,9,9,9,9,9,9,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4647
    ChildrenCoverage113.nil)

theorem compact113_node_4649 : NodeCoverage113 [18,18,9,9,9,9,9,9] 9 23 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4630
    (ChildrenCoverage113.cons _ _ compact113_node_4631
    (ChildrenCoverage113.cons _ _ compact113_node_4632
    (ChildrenCoverage113.cons _ _ compact113_node_4641
    (ChildrenCoverage113.cons _ _ compact113_node_4642
    (ChildrenCoverage113.cons _ _ compact113_node_4648
    ChildrenCoverage113.nil))))))

theorem compact113_node_4650 : NodeCoverage113 [18,18,9,9,9,9,9,8] 8 24 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4651 : NodeCoverage113 [18,18,9,9,9,9,9,7] 7 25 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4652 : NodeCoverage113 [18,18,9,9,9,9,9,6,6,6,6,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4653 : NodeCoverage113 [18,18,9,9,9,9,9,6,6,6,6,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4654 : NodeCoverage113 [18,18,9,9,9,9,9,6,6,6,6] 6 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4652
    (ChildrenCoverage113.cons _ _ compact113_node_4653
    ChildrenCoverage113.nil))

theorem compact113_node_4655 : NodeCoverage113 [18,18,9,9,9,9,9,6,6,6,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4656 : NodeCoverage113 [18,18,9,9,9,9,9,6,6,6,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4657 : NodeCoverage113 [18,18,9,9,9,9,9,6,6,6,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4656
    ChildrenCoverage113.nil)

theorem compact113_node_4658 : NodeCoverage113 [18,18,9,9,9,9,9,6,6,6,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4657
    ChildrenCoverage113.nil)

theorem compact113_node_4659 : NodeCoverage113 [18,18,9,9,9,9,9,6,6,6] 6 14 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4654
    (ChildrenCoverage113.cons _ _ compact113_node_4655
    (ChildrenCoverage113.cons _ _ compact113_node_4658
    ChildrenCoverage113.nil)))

theorem compact113_node_4660 : NodeCoverage113 [18,18,9,9,9,9,9,6,6,5] 5 15 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4661 : NodeCoverage113 [18,18,9,9,9,9,9,6,6,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4662 : NodeCoverage113 [18,18,9,9,9,9,9,6,6,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4661
    ChildrenCoverage113.nil)

theorem compact113_node_4663 : NodeCoverage113 [18,18,9,9,9,9,9,6,6,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4662
    ChildrenCoverage113.nil)

theorem compact113_node_4664 : NodeCoverage113 [18,18,9,9,9,9,9,6,6,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4663
    ChildrenCoverage113.nil)

theorem compact113_node_4665 : NodeCoverage113 [18,18,9,9,9,9,9,6,6,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4664
    ChildrenCoverage113.nil)

theorem compact113_node_4666 : NodeCoverage113 [18,18,9,9,9,9,9,6,6] 6 20 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4659
    (ChildrenCoverage113.cons _ _ compact113_node_4660
    (ChildrenCoverage113.cons _ _ compact113_node_4665
    ChildrenCoverage113.nil)))

theorem compact113_node_4667 : NodeCoverage113 [18,18,9,9,9,9,9,6,5] 5 21 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4668 : NodeCoverage113 [18,18,9,9,9,9,9,6,3] 3 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4669 : NodeCoverage113 [18,18,9,9,9,9,9,6] 6 26 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4666
    (ChildrenCoverage113.cons _ _ compact113_node_4667
    (ChildrenCoverage113.cons _ _ compact113_node_4668
    ChildrenCoverage113.nil)))

theorem compact113_node_4670 : NodeCoverage113 [18,18,9,9,9,9,9,5] 5 27 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4671 : NodeCoverage113 [18,18,9,9,9,9,9,3] 3 29 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4672 : NodeCoverage113 [18,18,9,9,9,9,9] 9 32 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4649
    (ChildrenCoverage113.cons _ _ compact113_node_4650
    (ChildrenCoverage113.cons _ _ compact113_node_4651
    (ChildrenCoverage113.cons _ _ compact113_node_4669
    (ChildrenCoverage113.cons _ _ compact113_node_4670
    (ChildrenCoverage113.cons _ _ compact113_node_4671
    ChildrenCoverage113.nil))))))

theorem compact113_node_4673 : NodeCoverage113 [18,18,9,9,9,9,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4674 : NodeCoverage113 [18,18,9,9,9,9,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4675 : NodeCoverage113 [18,18,9,9,9,9,6,6,6,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4676 : NodeCoverage113 [18,18,9,9,9,9,6,6,6,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4675
    ChildrenCoverage113.nil)

theorem compact113_node_4677 : NodeCoverage113 [18,18,9,9,9,9,6,6,6,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4678 : NodeCoverage113 [18,18,9,9,9,9,6,6,6,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4679 : NodeCoverage113 [18,18,9,9,9,9,6,6,6,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4678
    ChildrenCoverage113.nil)

theorem compact113_node_4680 : NodeCoverage113 [18,18,9,9,9,9,6,6,6,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4676
    (ChildrenCoverage113.cons _ _ compact113_node_4677
    (ChildrenCoverage113.cons _ _ compact113_node_4679
    ChildrenCoverage113.nil)))

theorem compact113_node_4681 : NodeCoverage113 [18,18,9,9,9,9,6,6,6,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4682 : NodeCoverage113 [18,18,9,9,9,9,6,6,6,6,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4683 : NodeCoverage113 [18,18,9,9,9,9,6,6,6,6,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4682
    ChildrenCoverage113.nil)

theorem compact113_node_4684 : NodeCoverage113 [18,18,9,9,9,9,6,6,6,6,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4683
    ChildrenCoverage113.nil)

theorem compact113_node_4685 : NodeCoverage113 [18,18,9,9,9,9,6,6,6,6,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4684
    ChildrenCoverage113.nil)

theorem compact113_node_4686 : NodeCoverage113 [18,18,9,9,9,9,6,6,6,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4680
    (ChildrenCoverage113.cons _ _ compact113_node_4681
    (ChildrenCoverage113.cons _ _ compact113_node_4685
    ChildrenCoverage113.nil)))

theorem compact113_node_4687 : NodeCoverage113 [18,18,9,9,9,9,6,6,6,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4688 : NodeCoverage113 [18,18,9,9,9,9,6,6,6,3] 3 20 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4689 : NodeCoverage113 [18,18,9,9,9,9,6,6,6] 6 23 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4686
    (ChildrenCoverage113.cons _ _ compact113_node_4687
    (ChildrenCoverage113.cons _ _ compact113_node_4688
    ChildrenCoverage113.nil)))

theorem compact113_node_4690 : NodeCoverage113 [18,18,9,9,9,9,6,6,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4691 : NodeCoverage113 [18,18,9,9,9,9,6,6,3] 3 26 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4692 : NodeCoverage113 [18,18,9,9,9,9,6,6] 6 29 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4689
    (ChildrenCoverage113.cons _ _ compact113_node_4690
    (ChildrenCoverage113.cons _ _ compact113_node_4691
    ChildrenCoverage113.nil)))

theorem compact113_node_4693 : NodeCoverage113 [18,18,9,9,9,9,6,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4694 : NodeCoverage113 [18,18,9,9,9,9,6,3] 3 32 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4695 : NodeCoverage113 [18,18,9,9,9,9,6] 6 35 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4692
    (ChildrenCoverage113.cons _ _ compact113_node_4693
    (ChildrenCoverage113.cons _ _ compact113_node_4694
    ChildrenCoverage113.nil)))

theorem compact113_node_4696 : NodeCoverage113 [18,18,9,9,9,9,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4697 : NodeCoverage113 [18,18,9,9,9,9,3] 3 38 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4698 : NodeCoverage113 [18,18,9,9,9,9] 9 41 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4672
    (ChildrenCoverage113.cons _ _ compact113_node_4673
    (ChildrenCoverage113.cons _ _ compact113_node_4674
    (ChildrenCoverage113.cons _ _ compact113_node_4695
    (ChildrenCoverage113.cons _ _ compact113_node_4696
    (ChildrenCoverage113.cons _ _ compact113_node_4697
    ChildrenCoverage113.nil))))))

theorem compact113_node_4699 : NodeCoverage113 [18,18,9,9,9,8] 8 42 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4700 : NodeCoverage113 [18,18,9,9,9,7] 7 43 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_023

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1010 : NodeCoverage113 [44,21] 21 48 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1011 : NodeCoverage113 [44,20] 20 49 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1012 : NodeCoverage113 [44,19] 19 50 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1013 : NodeCoverage113 [44,18] 18 51 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1014 : NodeCoverage113 [44,17] 17 52 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1015 : NodeCoverage113 [44,16] 16 53 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1016 : NodeCoverage113 [44,15] 15 54 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1017 : NodeCoverage113 [44,14] 14 55 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1018 : NodeCoverage113 [44,13] 13 56 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1019 : NodeCoverage113 [44,12] 12 57 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1020 : NodeCoverage113 [44,11] 11 58 :=
  demand_node_prune113 44 compact113_demands_044 compact113_demands_044_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1021 : NodeCoverage113 [44,10] 10 59 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1022 : NodeCoverage113 [44,9] 9 60 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1023 : NodeCoverage113 [44,8] 8 61 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1024 : NodeCoverage113 [44,7] 7 62 :=
  demand_node_prune113 44 compact113_demands_044 compact113_demands_044_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1025 : NodeCoverage113 [44,6] 6 63 :=
  demand_node_prune113 44 compact113_demands_044 compact113_demands_044_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1026 : NodeCoverage113 [44,5] 5 64 :=
  demand_node_prune113 44 compact113_demands_044 compact113_demands_044_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1027 : NodeCoverage113 [44,3] 3 66 :=
  demand_node_prune113 44 compact113_demands_044 compact113_demands_044_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1028 : NodeCoverage113 [44] 44 69 :=
  node_fork113 (B := [44,43,42,41,40,39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0987
    (ChildrenCoverage113.cons _ _ compact113_node_0988
    (ChildrenCoverage113.cons _ _ compact113_node_0989
    (ChildrenCoverage113.cons _ _ compact113_node_0990
    (ChildrenCoverage113.cons _ _ compact113_node_0991
    (ChildrenCoverage113.cons _ _ compact113_node_0992
    (ChildrenCoverage113.cons _ _ compact113_node_0993
    (ChildrenCoverage113.cons _ _ compact113_node_0994
    (ChildrenCoverage113.cons _ _ compact113_node_0995
    (ChildrenCoverage113.cons _ _ compact113_node_0996
    (ChildrenCoverage113.cons _ _ compact113_node_0997
    (ChildrenCoverage113.cons _ _ compact113_node_0998
    (ChildrenCoverage113.cons _ _ compact113_node_0999
    (ChildrenCoverage113.cons _ _ compact113_node_1000
    (ChildrenCoverage113.cons _ _ compact113_node_1001
    (ChildrenCoverage113.cons _ _ compact113_node_1002
    (ChildrenCoverage113.cons _ _ compact113_node_1003
    (ChildrenCoverage113.cons _ _ compact113_node_1004
    (ChildrenCoverage113.cons _ _ compact113_node_1005
    (ChildrenCoverage113.cons _ _ compact113_node_1006
    (ChildrenCoverage113.cons _ _ compact113_node_1007
    (ChildrenCoverage113.cons _ _ compact113_node_1008
    (ChildrenCoverage113.cons _ _ compact113_node_1009
    (ChildrenCoverage113.cons _ _ compact113_node_1010
    (ChildrenCoverage113.cons _ _ compact113_node_1011
    (ChildrenCoverage113.cons _ _ compact113_node_1012
    (ChildrenCoverage113.cons _ _ compact113_node_1013
    (ChildrenCoverage113.cons _ _ compact113_node_1014
    (ChildrenCoverage113.cons _ _ compact113_node_1015
    (ChildrenCoverage113.cons _ _ compact113_node_1016
    (ChildrenCoverage113.cons _ _ compact113_node_1017
    (ChildrenCoverage113.cons _ _ compact113_node_1018
    (ChildrenCoverage113.cons _ _ compact113_node_1019
    (ChildrenCoverage113.cons _ _ compact113_node_1020
    (ChildrenCoverage113.cons _ _ compact113_node_1021
    (ChildrenCoverage113.cons _ _ compact113_node_1022
    (ChildrenCoverage113.cons _ _ compact113_node_1023
    (ChildrenCoverage113.cons _ _ compact113_node_1024
    (ChildrenCoverage113.cons _ _ compact113_node_1025
    (ChildrenCoverage113.cons _ _ compact113_node_1026
    (ChildrenCoverage113.cons _ _ compact113_node_1027
    ChildrenCoverage113.nil)))))))))))))))))))))))))))))))))))))))))

theorem compact113_node_1029 : NodeCoverage113 [43] 43 70 :=
  demand_node_prune113 43 compact113_demands_043 compact113_demands_043_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1030 : NodeCoverage113 [42,42,29] 29 0 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1031 : NodeCoverage113 [42,42,26] 26 3 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1032 : NodeCoverage113 [42,42,25] 25 4 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1033 : NodeCoverage113 [42,42,24] 24 5 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1034 : NodeCoverage113 [42,42,23] 23 6 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1035 : NodeCoverage113 [42,42,22] 22 7 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1036 : NodeCoverage113 [42,42,21,8] 8 0 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1037 : NodeCoverage113 [42,42,21,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1038 : NodeCoverage113 [42,42,21,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1039 : NodeCoverage113 [42,42,21] 21 8 :=
  node_fork113 (B := [8,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1036
    (ChildrenCoverage113.cons _ _ compact113_node_1037
    (ChildrenCoverage113.cons _ _ compact113_node_1038
    ChildrenCoverage113.nil)))

theorem compact113_node_1040 : NodeCoverage113 [42,42,20] 20 9 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1041 : NodeCoverage113 [42,42,19] 19 10 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1042 : NodeCoverage113 [42,42,18] 18 11 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1043 : NodeCoverage113 [42,42,17] 17 12 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1044 : NodeCoverage113 [42,42,16] 16 13 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1045 : NodeCoverage113 [42,42,15] 15 14 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1046 : NodeCoverage113 [42,42,14] 14 15 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1047 : NodeCoverage113 [42,42,13] 13 16 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1048 : NodeCoverage113 [42,42,12] 12 17 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1049 : NodeCoverage113 [42,42,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1050 : NodeCoverage113 [42,42,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1051 : NodeCoverage113 [42,42,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1052 : NodeCoverage113 [42,42,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1053 : NodeCoverage113 [42,42,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

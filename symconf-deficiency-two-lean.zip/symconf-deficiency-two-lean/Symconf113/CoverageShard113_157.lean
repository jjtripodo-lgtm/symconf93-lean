import Symconf113.CoverageShard113_156

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_6831 : NodeCoverage113 [10,10,10,10,10,6,6,6,6,5] 5 34 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6832 : NodeCoverage113 [10,10,10,10,10,6,6,6,6,3] 3 36 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6833 : NodeCoverage113 [10,10,10,10,10,6,6,6,6] 6 39 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6830
    (ChildrenCoverage113.cons _ _ compact113_node_6831
    (ChildrenCoverage113.cons _ _ compact113_node_6832
    ChildrenCoverage113.nil)))

theorem compact113_node_6834 : NodeCoverage113 [10,10,10,10,10,6,6,6,5] 5 40 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6835 : NodeCoverage113 [10,10,10,10,10,6,6,6,3] 3 42 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6836 : NodeCoverage113 [10,10,10,10,10,6,6,6] 6 45 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6833
    (ChildrenCoverage113.cons _ _ compact113_node_6834
    (ChildrenCoverage113.cons _ _ compact113_node_6835
    ChildrenCoverage113.nil)))

theorem compact113_node_6837 : NodeCoverage113 [10,10,10,10,10,6,6,5] 5 46 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6838 : NodeCoverage113 [10,10,10,10,10,6,6,3] 3 48 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6839 : NodeCoverage113 [10,10,10,10,10,6,6] 6 51 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6836
    (ChildrenCoverage113.cons _ _ compact113_node_6837
    (ChildrenCoverage113.cons _ _ compact113_node_6838
    ChildrenCoverage113.nil)))

theorem compact113_node_6840 : NodeCoverage113 [10,10,10,10,10,6,5] 5 52 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6841 : NodeCoverage113 [10,10,10,10,10,6,3] 3 54 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6842 : NodeCoverage113 [10,10,10,10,10,6] 6 57 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6839
    (ChildrenCoverage113.cons _ _ compact113_node_6840
    (ChildrenCoverage113.cons _ _ compact113_node_6841
    ChildrenCoverage113.nil)))

theorem compact113_node_6843 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,5,5,5,5,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6844 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,5,5,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6843
    ChildrenCoverage113.nil)

theorem compact113_node_6845 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,5,5,5,5,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6846 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,5,5,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6844
    (ChildrenCoverage113.cons _ _ compact113_node_6845
    ChildrenCoverage113.nil))

theorem compact113_node_6847 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,5,5,5,5,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6848 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,5,5,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6846
    (ChildrenCoverage113.cons _ _ compact113_node_6847
    ChildrenCoverage113.nil))

theorem compact113_node_6849 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,5,5,5,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6850 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,5,5,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6848
    (ChildrenCoverage113.cons _ _ compact113_node_6849
    ChildrenCoverage113.nil))

theorem compact113_node_6851 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,5,5,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6852 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,5,5] 5 23 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6850
    (ChildrenCoverage113.cons _ _ compact113_node_6851
    ChildrenCoverage113.nil))

theorem compact113_node_6853 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,5,3] 3 25 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6854 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,5] 5 28 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6852
    (ChildrenCoverage113.cons _ _ compact113_node_6853
    ChildrenCoverage113.nil))

theorem compact113_node_6855 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3] 3 0 :=
  node_no_weak_demand113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6856 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6855
    ChildrenCoverage113.nil)

theorem compact113_node_6857 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6856
    ChildrenCoverage113.nil)

theorem compact113_node_6858 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,3,3,3,3,3,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6857
    ChildrenCoverage113.nil)

theorem compact113_node_6859 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,3,3,3,3,3,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6858
    ChildrenCoverage113.nil)

theorem compact113_node_6860 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,3,3,3,3,3,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6859
    ChildrenCoverage113.nil)

theorem compact113_node_6861 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,3,3,3,3,3] 3 18 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6860
    ChildrenCoverage113.nil)

theorem compact113_node_6862 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,3,3,3,3] 3 21 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6861
    ChildrenCoverage113.nil)

theorem compact113_node_6863 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,3,3,3] 3 24 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6862
    ChildrenCoverage113.nil)

theorem compact113_node_6864 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,3,3] 3 27 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6863
    ChildrenCoverage113.nil)

theorem compact113_node_6865 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5,3] 3 30 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6864
    ChildrenCoverage113.nil)

theorem compact113_node_6866 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,5] 5 33 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6854
    (ChildrenCoverage113.cons _ _ compact113_node_6865
    ChildrenCoverage113.nil))

theorem compact113_node_6867 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6868 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6867
    ChildrenCoverage113.nil)

theorem compact113_node_6869 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,3,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6868
    ChildrenCoverage113.nil)

theorem compact113_node_6870 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,3,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6869
    ChildrenCoverage113.nil)

theorem compact113_node_6871 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,3,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6870
    ChildrenCoverage113.nil)

theorem compact113_node_6872 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,3,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6871
    ChildrenCoverage113.nil)

theorem compact113_node_6873 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,3,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6872
    ChildrenCoverage113.nil)

theorem compact113_node_6874 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,3,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6873
    ChildrenCoverage113.nil)

theorem compact113_node_6875 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,3,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6874
    ChildrenCoverage113.nil)

theorem compact113_node_6876 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,3,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6875
    ChildrenCoverage113.nil)

theorem compact113_node_6877 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5,3] 3 35 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6876
    ChildrenCoverage113.nil)

theorem compact113_node_6878 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,5] 5 38 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6866
    (ChildrenCoverage113.cons _ _ compact113_node_6877
    ChildrenCoverage113.nil))

theorem compact113_node_6879 : NodeCoverage113 [10,10,10,10,10,5,5,5,5,3] 3 40 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6880 : NodeCoverage113 [10,10,10,10,10,5,5,5,5] 5 43 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6878
    (ChildrenCoverage113.cons _ _ compact113_node_6879
    ChildrenCoverage113.nil))

theorem compact113_node_6881 : NodeCoverage113 [10,10,10,10,10,5,5,5,3] 3 45 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6882 : NodeCoverage113 [10,10,10,10,10,5,5,5] 5 48 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6880
    (ChildrenCoverage113.cons _ _ compact113_node_6881
    ChildrenCoverage113.nil))

theorem compact113_node_6883 : NodeCoverage113 [10,10,10,10,10,5,5,3] 3 50 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6884 : NodeCoverage113 [10,10,10,10,10,5,5] 5 53 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6882
    (ChildrenCoverage113.cons _ _ compact113_node_6883
    ChildrenCoverage113.nil))

theorem compact113_node_6885 : NodeCoverage113 [10,10,10,10,10,5,3] 3 55 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6886 : NodeCoverage113 [10,10,10,10,10,5] 5 58 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6884
    (ChildrenCoverage113.cons _ _ compact113_node_6885
    ChildrenCoverage113.nil))

theorem compact113_node_6887 : NodeCoverage113 [10,10,10,10,10,3] 3 60 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6888 : NodeCoverage113 [10,10,10,10,10] 10 63 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6800
    (ChildrenCoverage113.cons _ _ compact113_node_6801
    (ChildrenCoverage113.cons _ _ compact113_node_6802
    (ChildrenCoverage113.cons _ _ compact113_node_6823
    (ChildrenCoverage113.cons _ _ compact113_node_6842
    (ChildrenCoverage113.cons _ _ compact113_node_6886
    (ChildrenCoverage113.cons _ _ compact113_node_6887
    ChildrenCoverage113.nil)))))))

theorem compact113_node_6889 : NodeCoverage113 [10,10,10,10,9,9,9,9,9] 9 28 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6890 : NodeCoverage113 [10,10,10,10,9,9,9,9,8] 8 29 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6891 : NodeCoverage113 [10,10,10,10,9,9,9,9,7] 7 30 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6892 : NodeCoverage113 [10,10,10,10,9,9,9,9,6] 6 31 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6893 : NodeCoverage113 [10,10,10,10,9,9,9,9,5] 5 32 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6894 : NodeCoverage113 [10,10,10,10,9,9,9,9,3] 3 34 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6895 : NodeCoverage113 [10,10,10,10,9,9,9,9] 9 37 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6889
    (ChildrenCoverage113.cons _ _ compact113_node_6890
    (ChildrenCoverage113.cons _ _ compact113_node_6891
    (ChildrenCoverage113.cons _ _ compact113_node_6892
    (ChildrenCoverage113.cons _ _ compact113_node_6893
    (ChildrenCoverage113.cons _ _ compact113_node_6894
    ChildrenCoverage113.nil))))))

theorem compact113_node_6896 : NodeCoverage113 [10,10,10,10,9,9,9,8] 8 38 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6897 : NodeCoverage113 [10,10,10,10,9,9,9,7] 7 39 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6898 : NodeCoverage113 [10,10,10,10,9,9,9,6] 6 40 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6899 : NodeCoverage113 [10,10,10,10,9,9,9,5] 5 41 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6900 : NodeCoverage113 [10,10,10,10,9,9,9,3] 3 43 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6901 : NodeCoverage113 [10,10,10,10,9,9,9] 9 46 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6895
    (ChildrenCoverage113.cons _ _ compact113_node_6896
    (ChildrenCoverage113.cons _ _ compact113_node_6897
    (ChildrenCoverage113.cons _ _ compact113_node_6898
    (ChildrenCoverage113.cons _ _ compact113_node_6899
    (ChildrenCoverage113.cons _ _ compact113_node_6900
    ChildrenCoverage113.nil))))))

theorem compact113_node_6902 : NodeCoverage113 [10,10,10,10,9,9,8] 8 47 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6903 : NodeCoverage113 [10,10,10,10,9,9,7] 7 48 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6904 : NodeCoverage113 [10,10,10,10,9,9,6] 6 49 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6905 : NodeCoverage113 [10,10,10,10,9,9,5] 5 50 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf59.CyclicBlock
import Mathlib.Tactic.Ring

/-! Odd-length version of the discrete-wave orientation lemma: a square
0/1 block on `ZMod n` that intertwines the cycle adjacency is circulant or
reverse-circulant whenever `2` is invertible. Same proof as the order-31
lemma of the 93 development, with `16` replaced by an inverse `c` of `2`. -/
namespace Symconf113
open Symconf59

variable {n : ℕ} [NeZero n]

private theorem all_two_step {α : Type*} {c : ZMod n} (hc : (2:ZMod n)*c=1)
    (h : ZMod n → α) (hs : ∀ a, h (a+2)=h a) : ∀ a,h a=h 0 := by
  intro a
  have hn (k : ℕ) (x : ZMod n) : h (x+2*(k:ZMod n))=h x := by
    induction k with
    | zero => simp
    | succ k ih =>
      rw [Nat.cast_succ, mul_add, mul_one, ← add_assoc, hs, ih]
  have h₂ := hn (a*c).val 0
  rw [zero_add, ZMod.natCast_zmod_val] at h₂
  have he : (2:ZMod n)*(a*c)=a := by
    rw [mul_left_comm, hc, mul_one]
  rwa [he] at h₂

theorem binary_block_orientation {c : ZMod n} (hc : (2:ZMod n)*c=1)
    (f : ZMod n → ZMod n → ℤ) (hw : BlockWave f) (hb : ∀ i j, f i j=0 ∨ f i j=1) :
    (∀ i j, f i j = f 0 (j-i)) ∨ (∀ i j, f i j = f 0 (j+i)) := by
  let g (u v : ZMod n) := f (c*(u-v)) (c*(u+v))
  have zw (u v : ZMod n) :
      g (u+2) v+g u (v+2)=g (u+2) (v+2)+g u v := by
    have hh := hw (c*(u-v)) (c*(u+v)+1)
    change f (c*(u-v)+1) (c*(u+v)+1)+f (c*(u-v)-1) (c*(u+v)+1) =
      f (c*(u-v)) (c*(u+v)+1+1)+f (c*(u-v)) (c*(u+v)+1-1) at hh
    have h32 : c*2=1 := by rw [mul_comm]; exact hc
    change f (c*(u+2-v)) (c*(u+2+v))+
      f (c*(u-(v+2))) (c*(u+(v+2))) =
        f (c*(u+2-(v+2))) (c*(u+2+(v+2)))+f (c*(u-v)) (c*(u+v))
    have hv1 : c*(u+2-v)=c*(u-v)+1 := by
      rw [show u+2-v=u-v+2 by ring,mul_add,h32]
    have hv2 : c*(u-(v+2))=c*(u-v)-1 := by
      rw [show u-(v+2)=u-v-2 by ring,mul_sub,h32]
    have hv3 : c*(u+2+v)=c*(u+v)+1 := by
      rw [show u+2+v=u+v+2 by ring,mul_add,h32]
    have hv4 : c*(u+(v+2))=c*(u+v)+1 := by
      rw [show u+(v+2)=u+v+2 by ring,mul_add,h32]
    have hv5 : c*(u+2-(v+2))=c*(u-v) := by ring
    have hv6 : c*(u+2+(v+2))=c*(u+v)+1+1 := by
      rw [show u+2+(v+2)=u+v+2+2 by ring,mul_add,mul_add,h32]
    rw [hv1,hv2,hv3,hv4,hv5,hv6]
    simpa only [add_sub_cancel_right] using hh
  have eq1 (u v : ZMod n) :
      g u (v+2)-g u v = g 0 (v+2)-g 0 v := by
    apply all_two_step hc (fun u => g u (v+2)-g u v) _ u
    intro t
    exact sub_eq_sub_iff_add_eq_add.mpr ((zw t v).symm.trans (add_comm _ _))
  have eq2 (u v : ZMod n) :
      g u v - g 0 v = g u 0 - g 0 0 := by
    apply all_two_step hc (fun v => g u v - g 0 v) _ v
    intro t
    have hh := eq1 u t
    omega
  have gbin (u v : ZMod n) : g u v=0 ∨ g u v=1 := hb _ _
  have back (i j : ZMod n) : g (j+i) (j-i)=f i j := by
    have h32 : c*2=1 := by rw [mul_comm]; exact hc
    have hi : c*(j+i-(j-i))=i := by
      rw [show j+i-(j-i)=2*i by ring, ← mul_assoc,h32, one_mul]
    have hj : c*(j+i+(j-i))=j := by
      rw [show j+i+(j-i)=2*j by ring, ← mul_assoc,h32, one_mul]
    simp only [g,hi,hj]
  have circ_or_rev :
      (∃ e : ZMod n → ℤ, ∀ i j, f i j = e (j-i)) ∨
      (∃ e : ZMod n → ℤ, ∀ i j, f i j = e (j+i)) := by
    by_cases hh : ∀ u : ZMod n, g u 0=g 0 0
    · left
      refine ⟨g 0,fun i j => ?_⟩
      have hs := eq2 (j+i) (j-i)
      rw [hh, sub_self, sub_eq_zero,back] at hs
      exact hs
    · right
      push Not at hh
      obtain ⟨u,hu⟩ := hh
      refine ⟨fun z => g z 0,fun i j => ?_⟩
      have hv (v : ZMod n) : g 0 v=g 0 0 := by
        have hh := eq2 u v
        rcases gbin u 0 with h0|h0 <;> rcases gbin 0 0 with h1|h1 <;>
          rcases gbin u v with he|he <;> rcases gbin 0 v with hf|hf <;> omega
      change f i j = g (j+i) 0
      have he := eq2 (j+i) (j-i)
      rw [hv,back] at he
      omega
  rcases circ_or_rev with ⟨e,he⟩ | ⟨e,he⟩
  · left
    intro i j
    rw [he, he, sub_zero]
  · right
    intro i j
    rw [he, he, add_zero]

end Symconf113

#print axioms Symconf113.binary_block_orientation

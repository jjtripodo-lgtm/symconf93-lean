import Symconf113.ResidualSide113
import Symconf113.ResidualPerm113
import Symconf113.ResidualRealize113

/-! From a residual-profile incidence to the abstract census conditions
`CanonGood`: sort the long row cycles and the long column cycles into type
order, and read off degrees and signatures of the 7×7 long blocks. Column
facts are the row facts of the transpose. -/
namespace Symconf113
open Matrix Symconf59
open scoped BigOperators

def toF (i : ℕ) : Fin 7 := ⟨i%7, Nat.mod_lt _ (by norm_num)⟩

theorem toF_val (i : Fin 7) : toF i.val=i := Fin.ext (Nat.mod_eq_of_lt i.isLt)

theorem toF_lt {i : ℕ} (hi : i<7) : (toF i).val=i := Nat.mod_eq_of_lt hi

theorem rs7_cast (f : ℕ → ℕ) (G : Fin 7 → ℤ) (h : ∀ j : Fin 7, (f j : ℤ)=G j) :
    (rs7 f : ℤ)=∑ j, G j := by
  rw [rs7_eq, Nat.cast_sum, ← Fin.sum_univ_eq_sum_range (fun j => (f j : ℤ)) 7]
  exact Finset.sum_congr rfl (fun j _ => h j)

theorem degZ_cast {e : ZMod 15 → ℤ} (hb : ∀ u, e u=0 ∨ e u=1) : (degZ e : ℤ)=∑ u, e u :=
  Int.toNat_of_nonneg (Finset.sum_nonneg (fun u _ => bin_nonneg (hb u)))

theorem acZ_nonneg {e : ZMod 15 → ℤ} (hb : ∀ u, e u=0 ∨ e u=1) (d : ZMod 15) : 0≤acZ e d :=
  Finset.sum_nonneg (fun u _ => mul_nonneg (bin_nonneg (hb u)) (bin_nonneg (hb _)))

theorem gd_sigZ_cast {e : ZMod 15 → ℤ} (hb : ∀ u, e u=0 ∨ e u=1) {t : ℕ} (ht : t<7) :
    (gd (sigZ e) t : ℤ)=acZ e ((t+1 : ℕ) : ZMod 15) := by
  unfold sigZ; rw [gd_ofF _ ht]; exact Int.toNat_of_nonneg (acZ_nonneg hb _)

section Canon
variable {A : Int113} (R : OrderedCycles (rowLeave A) RP) (C : OrderedCycles (colLeave A) RP)

/-- Short degrees of the long column cycles: the row quantities of `Aᵀ`. -/
def d3C (j : Fin 7) : ℤ := d3R (A := Aᵀ) C R j
def d5C (j : Fin 7) : ℤ := d5R (A := Aᵀ) C R j

def Vc (σ τ : Fin 7 ≃ Fin 7) (i j : ℕ) : ℕ := degZ (eR R C (σ (toF i)) (τ (toF j)))
def Sc (σ τ : Fin 7 ≃ Fin 7) (i j : ℕ) : List ℕ := sigZ (eR R C (σ (toF i)) (τ (toF j)))

variable (hA : Incidence113 A)
include hA

theorem col_deg (i j : Fin 7) : (∑ y, eR (A := Aᵀ) C R j i y)=∑ y, eR R C i j y :=
  (side_col R C hA i j).1

theorem col_ac (i j : Fin 7) (δ : ZMod 15) : acZ (eR (A := Aᵀ) C R j i) δ=acZ (eR R C i j) δ :=
  (side_col R C hA i j).2 δ

theorem col_rowSum (j : Fin 7) : (∑ i, ∑ y, eR R C i j y)+d5C R C j+d3C R C j=11 := by
  have h := side_rowSum (A := Aᵀ) C R hA.transpose j
  simp only [col_deg R C hA] at h
  exact h

theorem col_gram {j l : Fin 7} (hjl : j≠l) :
    (∑ i, (∑ y, eR R C i j y)*(∑ y, eR R C i l y))+3*d5C R C j*d5C R C l+
      5*d3C R C j*d3C R C l=15 := by
  have h := side_gram (A := Aᵀ) C R hA.transpose hjl
  simp only [col_deg R C hA] at h
  exact h

theorem col_sig (j : Fin 7) (t : ℕ) (ht : t<7) :
    (∑ i, acZ (eR R C i j) ((t+1 : ℕ) : ZMod 15))+(if (t+1)%5=0 then d5C R C j else 0)+
      (if (t+1)%3=0 then d3C R C j else 0)=if t=0 then 0 else 1 := by
  have h := side_sig (A := Aᵀ) C R hA.transpose j t ht
  simp only [col_ac R C hA] at h
  exact h

theorem canon_exists : ∃ σ τ : Fin 7 ≃ Fin 7,
    (∀ i, d3R R C (σ i)=xF i ∧ d5R R C (σ i)=yF i) ∧
      (∀ j, d3C R C (τ j)=xF j ∧ d5C R C (τ j)=yF j) := by
  have hT := hA.transpose
  have b3 : ∀ i, d3R R C i=0 ∨ d3R R C i=1 := fun i => by
    have := d3_le R C hA i; have := d3_nonneg R C hA i; omega
  have b5 : ∀ i, d5R R C i=0 ∨ d5R R C i=1 := fun i => by
    have := d5_le R C hA i; have := d5_nonneg R C hA i; omega
  have c3 : ∀ j, d3C R C j=0 ∨ d3C R C j=1 := fun j => by
    have := d3_le (A := Aᵀ) C R hT j; have := d3_nonneg (A := Aᵀ) C R hT j
    unfold d3C; omega
  have c5 : ∀ j, d5C R C j=0 ∨ d5C R C j=1 := fun j => by
    have := d5_le (A := Aᵀ) C R hT j; have := d5_nonneg (A := Aᵀ) C R hT j
    unfold d5C; omega
  obtain ⟨σ,hσ⟩ := exists_canon _ _ b3 b5 (count3 R C hA) (count5 R C hA) (count35 R C hA)
  obtain ⟨τ,hτ⟩ := exists_canon _ _ c3 c5 (count3 (A := Aᵀ) C R hT) (count5 (A := Aᵀ) C R hT)
    (count35 (A := Aᵀ) C R hT)
  exact ⟨σ,τ,hσ,hτ⟩

section Good
variable (σ τ : Fin 7 ≃ Fin 7) (hσ : ∀ i, d3R R C (σ i)=xF i ∧ d5R R C (σ i)=yF i)
  (hτ : ∀ j, d3C R C (τ j)=xF j ∧ d5C R C (τ j)=yF j)
include hσ hτ

theorem Vc_cast (i j : ℕ) : (Vc R C σ τ i j : ℤ)=∑ y, eR R C (σ (toF i)) (τ (toF j)) y :=
  degZ_cast (side_ebin R C hA _ _)

theorem row_types {i : ℕ} (hi : i<7) :
    d3R R C (σ (toF i))=xF i ∧ d5R R C (σ (toF i))=yF i := by
  have h := hσ (toF i); rw [toF_lt hi] at h; exact h

theorem col_types {j : ℕ} (hj : j<7) :
    d3C R C (τ (toF j))=xF j ∧ d5C R C (τ (toF j))=yF j := by
  have h := hτ (toF j); rw [toF_lt hj] at h; exact h

theorem canon_good : CanonGood (Vc R C σ τ) (Sc R C σ τ) where
  rowSum := by
    intro i hi
    have hs : (rs7 (Vc R C σ τ i) : ℤ)=∑ j, ∑ y, eR R C (σ (toF i)) j y := by
      rw [rs7_cast _ (fun j => ∑ y, eR R C (σ (toF i)) (τ j) y)
        (fun j => by rw [Vc_cast R C hA σ τ hσ hτ, toF_val])]
      exact Equiv.sum_comp τ (fun j => ∑ y, eR R C (σ (toF i)) j y)
    have h := side_rowSum R C hA (σ (toF i))
    obtain ⟨h3,h5⟩ := row_types R C hA σ τ hσ hτ hi
    have : ((rs7 (Vc R C σ τ i)+xF i+yF i : ℕ) : ℤ)=11 := by
      push_cast; rw [hs, ← h3, ← h5]; linarith
    exact_mod_cast this
  colSum := by
    intro j hj
    have hs : (rs7 (fun i => Vc R C σ τ i j) : ℤ)=∑ i, ∑ y, eR R C i (τ (toF j)) y := by
      rw [rs7_cast _ (fun i => ∑ y, eR R C (σ i) (τ (toF j)) y)
        (fun i => by rw [Vc_cast R C hA σ τ hσ hτ, toF_val])]
      exact Equiv.sum_comp σ (fun i => ∑ y, eR R C i (τ (toF j)) y)
    have h := col_rowSum R C hA (τ (toF j))
    obtain ⟨h3,h5⟩ := col_types R C hA σ τ hσ hτ hj
    have : ((rs7 (fun i => Vc R C σ τ i j)+xF j+yF j : ℕ) : ℤ)=11 := by
      push_cast; rw [hs, ← h3, ← h5]; linarith
    exact_mod_cast this
  rowGram := by
    intro i hi k hk hik
    have hs : (rs7 (fun j => Vc R C σ τ i j*Vc R C σ τ k j) : ℤ)=
        ∑ j, (∑ y, eR R C (σ (toF i)) j y)*(∑ y, eR R C (σ (toF k)) j y) := by
      rw [rs7_cast _ (fun j => (∑ y, eR R C (σ (toF i)) (τ j) y)*(∑ y, eR R C (σ (toF k)) (τ j) y))
        (fun j => by push_cast; rw [Vc_cast R C hA σ τ hσ hτ, Vc_cast R C hA σ τ hσ hτ, toF_val])]
      exact Equiv.sum_comp τ (fun j => (∑ y, eR R C (σ (toF i)) j y)*(∑ y, eR R C (σ (toF k)) j y))
    have hne : σ (toF i)≠σ (toF k) := fun h => hik (by
      have := congrArg Fin.val (σ.injective h); rwa [toF_lt hi, toF_lt hk] at this)
    have h := side_gram R C hA hne
    obtain ⟨h3,h5⟩ := row_types R C hA σ τ hσ hτ hi
    obtain ⟨h3',h5'⟩ := row_types R C hA σ τ hσ hτ hk
    have : ((rs7 (fun j => Vc R C σ τ i j*Vc R C σ τ k j)+5*xF i*xF k+3*yF i*yF k : ℕ) : ℤ)=15 := by
      push_cast; rw [hs, ← h3, ← h5, ← h3', ← h5']; linarith
    have h' : rs7 (fun j => Vc R C σ τ i j*Vc R C σ τ k j)+5*xF i*xF k+3*yF i*yF k=15 := by
      exact_mod_cast this
    unfold gramT; omega
  colGram := by
    intro j hj l hl hjl
    have hs : (rs7 (fun i => Vc R C σ τ i j*Vc R C σ τ i l) : ℤ)=
        ∑ i, (∑ y, eR R C i (τ (toF j)) y)*(∑ y, eR R C i (τ (toF l)) y) := by
      rw [rs7_cast _ (fun i => (∑ y, eR R C (σ i) (τ (toF j)) y)*(∑ y, eR R C (σ i) (τ (toF l)) y))
        (fun i => by push_cast; rw [Vc_cast R C hA σ τ hσ hτ, Vc_cast R C hA σ τ hσ hτ, toF_val])]
      exact Equiv.sum_comp σ (fun i => (∑ y, eR R C i (τ (toF j)) y)*(∑ y, eR R C i (τ (toF l)) y))
    have hne : τ (toF j)≠τ (toF l) := fun h => hjl (by
      have := congrArg Fin.val (τ.injective h); rwa [toF_lt hj, toF_lt hl] at this)
    have h := col_gram R C hA hne
    obtain ⟨h3,h5⟩ := col_types R C hA σ τ hσ hτ hj
    obtain ⟨h3',h5'⟩ := col_types R C hA σ τ hσ hτ hl
    have : ((rs7 (fun i => Vc R C σ τ i j*Vc R C σ τ i l)+5*xF j*xF l+3*yF j*yF l : ℕ) : ℤ)=15 := by
      push_cast; rw [hs, ← h3, ← h5, ← h3', ← h5']; linarith
    have h' : rs7 (fun i => Vc R C σ τ i j*Vc R C σ τ i l)+5*xF j*xF l+3*yF j*yF l=15 := by
      exact_mod_cast this
    unfold gramT; omega
  real := by
    intro i _ j _
    exact realizable _ (side_ebin R C hA _ _) (side_ac1 R C hA _ _) (fun d hd => side_acle R C hA _ _ d hd)
  rowSig := by
    intro i hi t ht
    have hs : (rs7 (fun j => gd (Sc R C σ τ i j) t) : ℤ)=
        ∑ j, acZ (eR R C (σ (toF i)) j) ((t+1 : ℕ) : ZMod 15) := by
      rw [rs7_cast _ (fun j => acZ (eR R C (σ (toF i)) (τ j)) ((t+1 : ℕ) : ZMod 15))
        (fun j => by unfold Sc; rw [gd_sigZ_cast (side_ebin R C hA _ _) ht, toF_val])]
      exact Equiv.sum_comp τ (fun j => acZ (eR R C (σ (toF i)) j) ((t+1 : ℕ) : ZMod 15))
    have h := side_sig R C hA (σ (toF i)) t ht
    obtain ⟨h3,h5⟩ := row_types R C hA σ τ hσ hτ hi
    have : ((rs7 (fun j => gd (Sc R C σ τ i j) t)+preF i t : ℕ) : ℤ)=(fullF t : ℤ) := by
      unfold preF fullF; push_cast; rw [hs, ← h3, ← h5]
      split_ifs at h ⊢ <;> linarith
    exact_mod_cast this
  colSig := by
    intro j hj t ht
    have hs : (rs7 (fun i => gd (Sc R C σ τ i j) t) : ℤ)=
        ∑ i, acZ (eR R C i (τ (toF j))) ((t+1 : ℕ) : ZMod 15) := by
      rw [rs7_cast _ (fun i => acZ (eR R C (σ i) (τ (toF j))) ((t+1 : ℕ) : ZMod 15))
        (fun i => by unfold Sc; rw [gd_sigZ_cast (side_ebin R C hA _ _) ht, toF_val])]
      exact Equiv.sum_comp σ (fun i => acZ (eR R C i (τ (toF j))) ((t+1 : ℕ) : ZMod 15))
    have h := col_sig R C hA (τ (toF j)) t ht
    obtain ⟨h3,h5⟩ := col_types R C hA σ τ hσ hτ hj
    have : ((rs7 (fun i => gd (Sc R C σ τ i j) t)+preF j t : ℕ) : ℤ)=(fullF t : ℤ) := by
      unfold preF fullF; push_cast; rw [hs, ← h3, ← h5]
      split_ifs at h ⊢ <;> linarith
    exact_mod_cast this

end Good

end Canon
end Symconf113

import Symconf113.CoverageShard113_148

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_6301 : NodeCoverage113 [12,12,12,11,3] 3 63 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6302 : NodeCoverage113 [12,12,12,11] 11 66 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6294
    (ChildrenCoverage113.cons _ _ compact113_node_6295
    (ChildrenCoverage113.cons _ _ compact113_node_6296
    (ChildrenCoverage113.cons _ _ compact113_node_6297
    (ChildrenCoverage113.cons _ _ compact113_node_6298
    (ChildrenCoverage113.cons _ _ compact113_node_6299
    (ChildrenCoverage113.cons _ _ compact113_node_6300
    (ChildrenCoverage113.cons _ _ compact113_node_6301
    ChildrenCoverage113.nil))))))))

theorem compact113_node_6303 : NodeCoverage113 [12,12,12,10,10,10,10] 10 37 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6304 : NodeCoverage113 [12,12,12,10,10,10,9] 9 38 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6305 : NodeCoverage113 [12,12,12,10,10,10,8] 8 39 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6306 : NodeCoverage113 [12,12,12,10,10,10,7] 7 40 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6307 : NodeCoverage113 [12,12,12,10,10,10,6] 6 41 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6308 : NodeCoverage113 [12,12,12,10,10,10,5] 5 42 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6309 : NodeCoverage113 [12,12,12,10,10,10,3] 3 44 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6310 : NodeCoverage113 [12,12,12,10,10,10] 10 47 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6303
    (ChildrenCoverage113.cons _ _ compact113_node_6304
    (ChildrenCoverage113.cons _ _ compact113_node_6305
    (ChildrenCoverage113.cons _ _ compact113_node_6306
    (ChildrenCoverage113.cons _ _ compact113_node_6307
    (ChildrenCoverage113.cons _ _ compact113_node_6308
    (ChildrenCoverage113.cons _ _ compact113_node_6309
    ChildrenCoverage113.nil)))))))

theorem compact113_node_6311 : NodeCoverage113 [12,12,12,10,10,9] 9 48 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6312 : NodeCoverage113 [12,12,12,10,10,8] 8 49 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6313 : NodeCoverage113 [12,12,12,10,10,7] 7 50 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6314 : NodeCoverage113 [12,12,12,10,10,6] 6 51 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6315 : NodeCoverage113 [12,12,12,10,10,5] 5 52 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6316 : NodeCoverage113 [12,12,12,10,10,3] 3 54 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6317 : NodeCoverage113 [12,12,12,10,10] 10 57 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6310
    (ChildrenCoverage113.cons _ _ compact113_node_6311
    (ChildrenCoverage113.cons _ _ compact113_node_6312
    (ChildrenCoverage113.cons _ _ compact113_node_6313
    (ChildrenCoverage113.cons _ _ compact113_node_6314
    (ChildrenCoverage113.cons _ _ compact113_node_6315
    (ChildrenCoverage113.cons _ _ compact113_node_6316
    ChildrenCoverage113.nil)))))))

theorem compact113_node_6318 : NodeCoverage113 [12,12,12,10,9] 9 58 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6319 : NodeCoverage113 [12,12,12,10,8] 8 59 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6320 : NodeCoverage113 [12,12,12,10,7] 7 60 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6321 : NodeCoverage113 [12,12,12,10,6] 6 61 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6322 : NodeCoverage113 [12,12,12,10,5] 5 62 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6323 : NodeCoverage113 [12,12,12,10,3] 3 64 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6324 : NodeCoverage113 [12,12,12,10] 10 67 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6317
    (ChildrenCoverage113.cons _ _ compact113_node_6318
    (ChildrenCoverage113.cons _ _ compact113_node_6319
    (ChildrenCoverage113.cons _ _ compact113_node_6320
    (ChildrenCoverage113.cons _ _ compact113_node_6321
    (ChildrenCoverage113.cons _ _ compact113_node_6322
    (ChildrenCoverage113.cons _ _ compact113_node_6323
    ChildrenCoverage113.nil)))))))

theorem compact113_node_6325 : NodeCoverage113 [12,12,12,9,9,9,9] 9 41 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6326 : NodeCoverage113 [12,12,12,9,9,9,8] 8 42 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6327 : NodeCoverage113 [12,12,12,9,9,9,7] 7 43 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6328 : NodeCoverage113 [12,12,12,9,9,9,6] 6 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6329 : NodeCoverage113 [12,12,12,9,9,9,5] 5 45 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6330 : NodeCoverage113 [12,12,12,9,9,9,3] 3 47 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6331 : NodeCoverage113 [12,12,12,9,9,9] 9 50 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6325
    (ChildrenCoverage113.cons _ _ compact113_node_6326
    (ChildrenCoverage113.cons _ _ compact113_node_6327
    (ChildrenCoverage113.cons _ _ compact113_node_6328
    (ChildrenCoverage113.cons _ _ compact113_node_6329
    (ChildrenCoverage113.cons _ _ compact113_node_6330
    ChildrenCoverage113.nil))))))

theorem compact113_node_6332 : NodeCoverage113 [12,12,12,9,9,8] 8 51 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6333 : NodeCoverage113 [12,12,12,9,9,7] 7 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6334 : NodeCoverage113 [12,12,12,9,9,6] 6 53 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6335 : NodeCoverage113 [12,12,12,9,9,5] 5 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6336 : NodeCoverage113 [12,12,12,9,9,3] 3 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6337 : NodeCoverage113 [12,12,12,9,9] 9 59 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6331
    (ChildrenCoverage113.cons _ _ compact113_node_6332
    (ChildrenCoverage113.cons _ _ compact113_node_6333
    (ChildrenCoverage113.cons _ _ compact113_node_6334
    (ChildrenCoverage113.cons _ _ compact113_node_6335
    (ChildrenCoverage113.cons _ _ compact113_node_6336
    ChildrenCoverage113.nil))))))

theorem compact113_node_6338 : NodeCoverage113 [12,12,12,9,8] 8 60 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6339 : NodeCoverage113 [12,12,12,9,7] 7 61 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6340 : NodeCoverage113 [12,12,12,9,6] 6 62 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6341 : NodeCoverage113 [12,12,12,9,5] 5 63 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6342 : NodeCoverage113 [12,12,12,9,3] 3 65 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6343 : NodeCoverage113 [12,12,12,9] 9 68 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6337
    (ChildrenCoverage113.cons _ _ compact113_node_6338
    (ChildrenCoverage113.cons _ _ compact113_node_6339
    (ChildrenCoverage113.cons _ _ compact113_node_6340
    (ChildrenCoverage113.cons _ _ compact113_node_6341
    (ChildrenCoverage113.cons _ _ compact113_node_6342
    ChildrenCoverage113.nil))))))

theorem compact113_node_6344 : NodeCoverage113 [12,12,12,8] 8 69 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6345 : NodeCoverage113 [12,12,12,7,7,7,7,7,7] 7 35 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6346 : NodeCoverage113 [12,12,12,7,7,7,7,7,6] 6 36 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6347 : NodeCoverage113 [12,12,12,7,7,7,7,7,5] 5 37 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6348 : NodeCoverage113 [12,12,12,7,7,7,7,7,3] 3 39 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6349 : NodeCoverage113 [12,12,12,7,7,7,7,7] 7 42 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6345
    (ChildrenCoverage113.cons _ _ compact113_node_6346
    (ChildrenCoverage113.cons _ _ compact113_node_6347
    (ChildrenCoverage113.cons _ _ compact113_node_6348
    ChildrenCoverage113.nil))))

theorem compact113_node_6350 : NodeCoverage113 [12,12,12,7,7,7,7,6] 6 43 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6351 : NodeCoverage113 [12,12,12,7,7,7,7,5] 5 44 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6352 : NodeCoverage113 [12,12,12,7,7,7,7,3] 3 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6353 : NodeCoverage113 [12,12,12,7,7,7,7] 7 49 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6349
    (ChildrenCoverage113.cons _ _ compact113_node_6350
    (ChildrenCoverage113.cons _ _ compact113_node_6351
    (ChildrenCoverage113.cons _ _ compact113_node_6352
    ChildrenCoverage113.nil))))

theorem compact113_node_6354 : NodeCoverage113 [12,12,12,7,7,7,6] 6 50 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

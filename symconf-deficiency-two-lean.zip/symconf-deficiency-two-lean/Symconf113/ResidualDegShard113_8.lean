import Symconf113.ResidualDegDefs113

/-! Kernel check: the degree search below type-`A` rows 8 and 9. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem degShard_8 : ((degTopList.drop 8).take 2).all degTop=true := by decide +kernel
end Symconf113

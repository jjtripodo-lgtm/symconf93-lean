import Symconf113.CoverageShard113_157
import Symconf113.CoverageShard113_158

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_6981 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6980
    ChildrenCoverage113.nil)

theorem compact113_node_6982 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6981
    ChildrenCoverage113.nil)

theorem compact113_node_6983 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,3,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6982
    ChildrenCoverage113.nil)

theorem compact113_node_6984 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,3,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6983
    ChildrenCoverage113.nil)

theorem compact113_node_6985 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,3,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6984
    ChildrenCoverage113.nil)

theorem compact113_node_6986 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,3,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6985
    ChildrenCoverage113.nil)

theorem compact113_node_6987 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,3,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6986
    ChildrenCoverage113.nil)

theorem compact113_node_6988 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,3,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6987
    ChildrenCoverage113.nil)

theorem compact113_node_6989 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,3] 3 35 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6988
    ChildrenCoverage113.nil)

theorem compact113_node_6990 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5] 5 38 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6978
    (ChildrenCoverage113.cons _ _ compact113_node_6989
    ChildrenCoverage113.nil))

theorem compact113_node_6991 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,3] 3 40 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6992 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5] 5 43 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6990
    (ChildrenCoverage113.cons _ _ compact113_node_6991
    ChildrenCoverage113.nil))

theorem compact113_node_6993 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,3] 3 45 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6994 : NodeCoverage113 [10,10,10,10,5,5,5,5,5] 5 48 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6992
    (ChildrenCoverage113.cons _ _ compact113_node_6993
    ChildrenCoverage113.nil))

theorem compact113_node_6995 : NodeCoverage113 [10,10,10,10,5,5,5,5,3] 3 50 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6996 : NodeCoverage113 [10,10,10,10,5,5,5,5] 5 53 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6994
    (ChildrenCoverage113.cons _ _ compact113_node_6995
    ChildrenCoverage113.nil))

theorem compact113_node_6997 : NodeCoverage113 [10,10,10,10,5,5,5,3] 3 55 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6998 : NodeCoverage113 [10,10,10,10,5,5,5] 5 58 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6996
    (ChildrenCoverage113.cons _ _ compact113_node_6997
    ChildrenCoverage113.nil))

theorem compact113_node_6999 : NodeCoverage113 [10,10,10,10,5,5,3] 3 60 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7000 : NodeCoverage113 [10,10,10,10,5,5] 5 63 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6998
    (ChildrenCoverage113.cons _ _ compact113_node_6999
    ChildrenCoverage113.nil))

theorem compact113_node_7001 : NodeCoverage113 [10,10,10,10,5,3] 3 65 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7002 : NodeCoverage113 [10,10,10,10,5] 5 68 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7000
    (ChildrenCoverage113.cons _ _ compact113_node_7001
    ChildrenCoverage113.nil))

theorem compact113_node_7003 : NodeCoverage113 [10,10,10,10,3] 3 70 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7004 : NodeCoverage113 [10,10,10,10] 10 73 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6888
    (ChildrenCoverage113.cons _ _ compact113_node_6913
    (ChildrenCoverage113.cons _ _ compact113_node_6914
    (ChildrenCoverage113.cons _ _ compact113_node_6935
    (ChildrenCoverage113.cons _ _ compact113_node_6954
    (ChildrenCoverage113.cons _ _ compact113_node_7002
    (ChildrenCoverage113.cons _ _ compact113_node_7003
    ChildrenCoverage113.nil)))))))

theorem compact113_node_7005 : NodeCoverage113 [10,10,10,9] 9 74 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7006 : NodeCoverage113 [10,10,10,8] 8 75 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7007 : NodeCoverage113 [10,10,10,7] 7 76 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7008 : NodeCoverage113 [10,10,10,6] 6 77 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7009 : NodeCoverage113 [10,10,10,5] 5 78 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7010 : NodeCoverage113 [10,10,10,3] 3 80 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7011 : NodeCoverage113 [10,10,10] 10 83 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7004
    (ChildrenCoverage113.cons _ _ compact113_node_7005
    (ChildrenCoverage113.cons _ _ compact113_node_7006
    (ChildrenCoverage113.cons _ _ compact113_node_7007
    (ChildrenCoverage113.cons _ _ compact113_node_7008
    (ChildrenCoverage113.cons _ _ compact113_node_7009
    (ChildrenCoverage113.cons _ _ compact113_node_7010
    ChildrenCoverage113.nil)))))))

theorem compact113_node_7012 : NodeCoverage113 [10,10,9] 9 84 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7013 : NodeCoverage113 [10,10,8] 8 85 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7014 : NodeCoverage113 [10,10,7] 7 86 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7015 : NodeCoverage113 [10,10,6] 6 87 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7016 : NodeCoverage113 [10,10,5] 5 88 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7017 : NodeCoverage113 [10,10,3] 3 90 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7018 : NodeCoverage113 [10,10] 10 93 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7011
    (ChildrenCoverage113.cons _ _ compact113_node_7012
    (ChildrenCoverage113.cons _ _ compact113_node_7013
    (ChildrenCoverage113.cons _ _ compact113_node_7014
    (ChildrenCoverage113.cons _ _ compact113_node_7015
    (ChildrenCoverage113.cons _ _ compact113_node_7016
    (ChildrenCoverage113.cons _ _ compact113_node_7017
    ChildrenCoverage113.nil)))))))

theorem compact113_node_7019 : NodeCoverage113 [10,9] 9 94 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7020 : NodeCoverage113 [10,8] 8 95 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7021 : NodeCoverage113 [10,7] 7 96 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7022 : NodeCoverage113 [10,6] 6 97 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7023 : NodeCoverage113 [10,5] 5 98 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7024 : NodeCoverage113 [10,3] 3 100 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7025 : NodeCoverage113 [10] 10 103 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7018
    (ChildrenCoverage113.cons _ _ compact113_node_7019
    (ChildrenCoverage113.cons _ _ compact113_node_7020
    (ChildrenCoverage113.cons _ _ compact113_node_7021
    (ChildrenCoverage113.cons _ _ compact113_node_7022
    (ChildrenCoverage113.cons _ _ compact113_node_7023
    (ChildrenCoverage113.cons _ _ compact113_node_7024
    ChildrenCoverage113.nil)))))))

theorem compact113_node_7026 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,9,9,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7027 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,9,9] 9 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7026
    ChildrenCoverage113.nil)

theorem compact113_node_7028 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,9,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7029 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,9,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7030 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,9,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7031 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,9,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7032 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,9,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7033 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,9,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7032
    ChildrenCoverage113.nil)

theorem compact113_node_7034 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,9,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7033
    ChildrenCoverage113.nil)

theorem compact113_node_7035 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,9] 9 14 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7027
    (ChildrenCoverage113.cons _ _ compact113_node_7028
    (ChildrenCoverage113.cons _ _ compact113_node_7029
    (ChildrenCoverage113.cons _ _ compact113_node_7030
    (ChildrenCoverage113.cons _ _ compact113_node_7031
    (ChildrenCoverage113.cons _ _ compact113_node_7034
    ChildrenCoverage113.nil))))))

theorem compact113_node_7036 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7037 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7038 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7039 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7040 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7041 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7040
    ChildrenCoverage113.nil)

theorem compact113_node_7042 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7041
    ChildrenCoverage113.nil)

theorem compact113_node_7043 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7042
    ChildrenCoverage113.nil)

theorem compact113_node_7044 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7043
    ChildrenCoverage113.nil)

theorem compact113_node_7045 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7044
    ChildrenCoverage113.nil)

theorem compact113_node_7046 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,9] 9 23 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7035
    (ChildrenCoverage113.cons _ _ compact113_node_7036
    (ChildrenCoverage113.cons _ _ compact113_node_7037
    (ChildrenCoverage113.cons _ _ compact113_node_7038
    (ChildrenCoverage113.cons _ _ compact113_node_7039
    (ChildrenCoverage113.cons _ _ compact113_node_7045
    ChildrenCoverage113.nil))))))

theorem compact113_node_7047 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,8] 8 24 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7048 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,7] 7 25 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7049 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,6] 6 26 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7050 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,5] 5 27 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7051 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7052 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7051
    ChildrenCoverage113.nil)

theorem compact113_node_7053 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7052
    ChildrenCoverage113.nil)

theorem compact113_node_7054 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7053
    ChildrenCoverage113.nil)

theorem compact113_node_7055 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7054
    ChildrenCoverage113.nil)

end Symconf113

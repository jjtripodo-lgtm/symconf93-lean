import Symconf113.OriginalCoordinates
import Symconf59.ProfileSieve

namespace Symconf113
open Matrix Symconf59
open scoped BigOperators

/-- The arithmetic input consists exclusively of both actual ordered
leave charts of the literal integer incidence matrix. -/
theorem actual_incidence_profile {A : Int113} (hA : Incidence113 A) :
    ∃ P : List ℕ, ∃ _R : OrderedCycles (rowLeave A) P,
      ∃ _C : OrderedCycles (colLeave A) P, Nonempty (OriginalProfileFacts P) := by
  obtain ⟨P,hs,hmin,hord,⟨R⟩,⟨C⟩⟩ := original_ordered_cycle_coords hA
  exact ⟨P,R,C,⟨physical_blocks_to_profile hA
    (physical_of_ordered_cycles hA hmin R C) hs hmin hord⟩⟩

/-- Exact parity-free enumeration domain.  Neither a small divisor
test nor cycle-count parity is assumed of the literal incidence. -/
theorem physical_profile_mem_parity_free {A : Int113} (hA : Incidence113 A) :
    ∃ P : List ℕ, P ∈ Symconf59.partitionLists 37 113 113 ∧
      ∃ _R : OrderedCycles (rowLeave A) P, ∃ _C : OrderedCycles (colLeave A) P,
        Nonempty (OriginalProfileFacts P) := by
  obtain ⟨P,R,C,⟨F⟩⟩ := actual_incidence_profile hA
  have hl (Q : List ℕ) (hQ : ∀ a∈Q,3≤a) : 3*Q.length≤Q.sum := by
    induction Q with
    | nil => decide
    | cons a L ih =>
      have ha := hQ a (by simp)
      have ht := ih (fun b hb => hQ b (List.mem_cons_of_mem _ hb))
      simp only [List.length_cons,List.sum_cons]
      omega
  have hlen := hl P F.positive
  have hn : P.length ≤ 37 := by rw [F.total] at hlen; omega
  have hb : ∀ b∈P,b≤113 := by
    intro b h
    simpa only [F.total] using Symconf59.member_le_sum h
  have he := Symconf59.partitionLists_complete P 37 113 hn F.positive hb F.ordered
  exact ⟨P,by simpa only [F.total] using he,R,C,⟨F⟩⟩

end Symconf113

#print axioms Symconf113.actual_incidence_profile
#print axioms Symconf113.physical_profile_mem_parity_free

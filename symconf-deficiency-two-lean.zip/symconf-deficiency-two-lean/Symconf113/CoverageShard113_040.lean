import Symconf113.CoverageShard113_039

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1623 : NodeCoverage113 [36,18,18,9,9,6] 6 17 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1624 : NodeCoverage113 [36,18,18,9,9,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1625 : NodeCoverage113 [36,18,18,9,9,3] 3 20 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1626 : NodeCoverage113 [36,18,18,9,9] 9 23 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1620
    (ChildrenCoverage113.cons _ _ compact113_node_1621
    (ChildrenCoverage113.cons _ _ compact113_node_1622
    (ChildrenCoverage113.cons _ _ compact113_node_1623
    (ChildrenCoverage113.cons _ _ compact113_node_1624
    (ChildrenCoverage113.cons _ _ compact113_node_1625
    ChildrenCoverage113.nil))))))

theorem compact113_node_1627 : NodeCoverage113 [36,18,18,9,8] 8 24 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1628 : NodeCoverage113 [36,18,18,9,7] 7 25 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1629 : NodeCoverage113 [36,18,18,9,6] 6 26 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1630 : NodeCoverage113 [36,18,18,9,5] 5 27 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1631 : NodeCoverage113 [36,18,18,9,3] 3 29 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1632 : NodeCoverage113 [36,18,18,9] 9 32 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1626
    (ChildrenCoverage113.cons _ _ compact113_node_1627
    (ChildrenCoverage113.cons _ _ compact113_node_1628
    (ChildrenCoverage113.cons _ _ compact113_node_1629
    (ChildrenCoverage113.cons _ _ compact113_node_1630
    (ChildrenCoverage113.cons _ _ compact113_node_1631
    ChildrenCoverage113.nil))))))

theorem compact113_node_1633 : NodeCoverage113 [36,18,18,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1634 : NodeCoverage113 [36,18,18,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1635 : NodeCoverage113 [36,18,18,6] 6 35 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1636 : NodeCoverage113 [36,18,18,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1637 : NodeCoverage113 [36,18,18,3] 3 38 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1638 : NodeCoverage113 [36,18,18] 18 41 :=
  node_fork113 (B := [18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1605
    (ChildrenCoverage113.cons _ _ compact113_node_1606
    (ChildrenCoverage113.cons _ _ compact113_node_1607
    (ChildrenCoverage113.cons _ _ compact113_node_1608
    (ChildrenCoverage113.cons _ _ compact113_node_1609
    (ChildrenCoverage113.cons _ _ compact113_node_1610
    (ChildrenCoverage113.cons _ _ compact113_node_1611
    (ChildrenCoverage113.cons _ _ compact113_node_1612
    (ChildrenCoverage113.cons _ _ compact113_node_1613
    (ChildrenCoverage113.cons _ _ compact113_node_1632
    (ChildrenCoverage113.cons _ _ compact113_node_1633
    (ChildrenCoverage113.cons _ _ compact113_node_1634
    (ChildrenCoverage113.cons _ _ compact113_node_1635
    (ChildrenCoverage113.cons _ _ compact113_node_1636
    (ChildrenCoverage113.cons _ _ compact113_node_1637
    ChildrenCoverage113.nil)))))))))))))))

theorem compact113_node_1639 : NodeCoverage113 [36,18,17] 17 42 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1640 : NodeCoverage113 [36,18,16] 16 43 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1641 : NodeCoverage113 [36,18,15] 15 44 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1642 : NodeCoverage113 [36,18,14] 14 45 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1643 : NodeCoverage113 [36,18,13] 13 46 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1644 : NodeCoverage113 [36,18,12,12,12] 12 23 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1645 : NodeCoverage113 [36,18,12,12,11] 11 24 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1646 : NodeCoverage113 [36,18,12,12,10] 10 25 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1647 : NodeCoverage113 [36,18,12,12,9,9] 9 17 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1648 : NodeCoverage113 [36,18,12,12,9,8] 8 18 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1649 : NodeCoverage113 [36,18,12,12,9,7] 7 19 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1650 : NodeCoverage113 [36,18,12,12,9,6] 6 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1651 : NodeCoverage113 [36,18,12,12,9,5] 5 21 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1652 : NodeCoverage113 [36,18,12,12,9,3] 3 23 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1653 : NodeCoverage113 [36,18,12,12,9] 9 26 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1647
    (ChildrenCoverage113.cons _ _ compact113_node_1648
    (ChildrenCoverage113.cons _ _ compact113_node_1649
    (ChildrenCoverage113.cons _ _ compact113_node_1650
    (ChildrenCoverage113.cons _ _ compact113_node_1651
    (ChildrenCoverage113.cons _ _ compact113_node_1652
    ChildrenCoverage113.nil))))))

theorem compact113_node_1654 : NodeCoverage113 [36,18,12,12,8] 8 27 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1655 : NodeCoverage113 [36,18,12,12,7] 7 28 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1656 : NodeCoverage113 [36,18,12,12,6] 6 29 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1657 : NodeCoverage113 [36,18,12,12,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1658 : NodeCoverage113 [36,18,12,12,3] 3 32 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1659 : NodeCoverage113 [36,18,12,12] 12 35 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1644
    (ChildrenCoverage113.cons _ _ compact113_node_1645
    (ChildrenCoverage113.cons _ _ compact113_node_1646
    (ChildrenCoverage113.cons _ _ compact113_node_1653
    (ChildrenCoverage113.cons _ _ compact113_node_1654
    (ChildrenCoverage113.cons _ _ compact113_node_1655
    (ChildrenCoverage113.cons _ _ compact113_node_1656
    (ChildrenCoverage113.cons _ _ compact113_node_1657
    (ChildrenCoverage113.cons _ _ compact113_node_1658
    ChildrenCoverage113.nil)))))))))

end Symconf113

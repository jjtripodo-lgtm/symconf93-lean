import Symconf113.ResidualCands113

/-! Soundness of the residual census searches: the abstract quotient
conditions `CanonGood` force every full row and signature row into the
searched lists, so a `true` search result constrains every real quotient. -/
namespace Symconf113

/-! ### Generic list facts -/

theorem mem_prodL {α : Type} : ∀ (Ls : List (List α)) (l : List α),
    List.Forall₂ (fun a L => a ∈ L) l Ls → l ∈ prodL Ls
  | [], _, h => by cases h; simp [prodL]
  | L :: Ls, l, h => by
    cases h with
    | cons ha ht =>
      simp only [prodL, List.mem_flatMap, List.mem_map]
      exact ⟨_,ha,_,mem_prodL Ls _ ht,rfl⟩

theorem forall₂_filter {α : Type} (p : α → Bool) : ∀ {rs : List α} {Ls : List (List α)},
    List.Forall₂ (fun a L => a ∈ L) rs Ls → (∀ b ∈ rs, p b=true) →
      List.Forall₂ (fun a L => a ∈ L) rs (Ls.map fun l => l.filter p)
  | _, _, .nil, _ => .nil
  | _, _, .cons ha ht, h => .cons (List.mem_filter.mpr ⟨ha,h _ (by simp)⟩)
      (forall₂_filter p ht (fun b hb => h b (by simp [hb])))

theorem dfs_sound {α : Type} (compat : α → α → Bool) (leaf : List α → Bool) :
    ∀ (n : ℕ) (acc : List α) (Ls : List (List α)) (rs : List α), Ls.length≤n →
      List.Forall₂ (fun a L => a ∈ L) rs Ls →
      List.Pairwise (fun a b => compat a b=true) (acc.reverse++rs) →
      dfs compat leaf n acc Ls=true → leaf (acc.reverse++rs)=true
  | n, acc, [], rs, _, hF, _, hd => by
    cases hF; simpa [dfs] using hd
  | 0, acc, L :: Ls, rs, hn, _, _, _ => by simp at hn
  | n+1, acc, L :: Ls, rs, hn, hF, hP, hd => by
    cases hF with
    | @cons r L rs' Ls hr ht =>
      simp only [dfs, List.all_eq_true] at hd
      have hd' := hd r hr
      have hP' : List.Pairwise (fun a b => compat a b=true) ((r :: acc).reverse++rs') := by
        simpa [List.reverse_cons, List.append_assoc] using hP
      have hc : ∀ b ∈ rs', compat r b=true := by
        intro b hb
        rw [List.pairwise_append] at hP
        have h2 := hP.2.1
        rw [List.pairwise_cons] at h2
        exact h2.1 b hb
      have hF' : List.Forall₂ (fun a L => a ∈ L) rs' (Ls.map fun l => l.filter (compat r)) := by
        exact forall₂_filter _ ht hc
      have := dfs_sound compat leaf n (r :: acc) _ rs' (by simp at hn ⊢; omega) hF' hP' hd'
      simpa [List.reverse_cons, List.append_assoc] using this

theorem forall₂_map_range {α β : Type} (R : α → β → Prop) (f : ℕ → α) (g : ℕ → β) (n : ℕ)
    (h : ∀ j<n, R (f j) (g j)) : List.Forall₂ R ((List.range n).map f) ((List.range n).map g) := by
  rw [List.forall₂_map_left_iff, List.forall₂_map_right_iff, List.forall₂_same]
  intro j hj
  exact h j (List.mem_range.mp hj)

theorem gd_map_range (f : ℕ → ℕ) {t n : ℕ} (ht : t<n) : gd ((List.range n).map f) t=f t := by
  simp [gd, List.getD_eq_getElem?_getD, ht]

theorem getD_map_range {α : Type} (f : ℕ → α) (d : α) {t n : ℕ} (ht : t<n) :
    ((List.range n).map f).getD t d=f t := by
  simp [List.getD_eq_getElem?_getD, ht]

theorem ofF_eq (f : ℕ → ℕ) : ofF f=(List.range 7).map f := rfl

theorem sum_ofF (f : ℕ → ℕ) : (ofF f).sum=((List.range 7).map f).sum := rfl

theorem map_ofF (f : ℕ → ℕ) (g : ℕ → ℕ) : (ofF f).map g=ofF (fun t => g (f t)) := by
  rw [ofF_eq, ofF_eq, List.map_map]; rfl

theorem gd_ofF (f : ℕ → ℕ) {t : ℕ} (ht : t<7) : gd (ofF f) t=f t := by
  rw [ofF_eq]; exact gd_map_range f ht

theorem ofF_ext {f g : ℕ → ℕ} (h : ∀ t<7, f t=g t) : ofF f=ofF g := by
  unfold ofF; congr 1; funext t; exact h t t.isLt

/-- Sum over `0..6` as a list. -/
def rs7 (f : ℕ → ℕ) : ℕ := ((List.range 7).map f).sum

theorem rs7_eq (f : ℕ → ℕ) : rs7 f=∑ j ∈ Finset.range 7, f j := by
  simp [rs7, List.range_succ, Finset.sum_range_succ]; omega

theorem le_rs7 (f : ℕ → ℕ) {j : ℕ} (hj : j<7) : f j≤rs7 f := by
  rw [rs7_eq]
  exact Finset.single_le_sum (fun _ _ => Nat.zero_le _) (Finset.mem_range.mpr hj)

theorem two_le_rs7 (f : ℕ → ℕ) {j k : ℕ} (hj : j<7) (hk : k<7) (hjk : j≠k) :
    f j+f k≤rs7 f := by
  rw [rs7_eq, ← Finset.sum_pair hjk]
  apply Finset.sum_le_sum_of_subset
  intro a ha
  simp only [Finset.mem_insert, Finset.mem_singleton] at ha
  rcases ha with rfl|rfl <;> simpa using ‹_›

theorem rs7_expand (f : ℕ → ℕ) : rs7 f=f 0+f 1+f 2+f 3+f 4+f 5+f 6 := by
  simp [rs7, List.range_succ]; omega

theorem rs7_congr {f g : ℕ → ℕ} (h : ∀ j<7, f j=g j) : rs7 f=rs7 g := by
  rw [rs7_eq,rs7_eq]; exact Finset.sum_congr rfl (fun j hj => h j (Finset.mem_range.mp hj))

theorem rs7_add (f g : ℕ → ℕ) : rs7 (fun j => f j+g j)=rs7 f+rs7 g := by
  simp only [rs7_eq, Finset.sum_add_distrib]

theorem rs7_comm (f : ℕ → ℕ → ℕ) : rs7 (fun t => rs7 (fun j => f j t))=rs7 (fun j => rs7 (f j)) := by
  simp only [rs7_eq]; exact Finset.sum_comm

theorem dotL_ofF (f g : ℕ → ℕ) : dotL (ofF f) (ofF g)=rs7 (fun j => f j*g j) := by
  unfold dotL; exact rs7_congr (fun j hj => by rw [gd_ofF f hj, gd_ofF g hj])

/-! ### The abstract quotient conditions -/

structure CanonGood (V : ℕ → ℕ → ℕ) (S : ℕ → ℕ → List ℕ) : Prop where
  rowSum : ∀ i<7, rs7 (V i)+xF i+yF i=11
  colSum : ∀ j<7, rs7 (fun i => V i j)+xF j+yF j=11
  rowGram : ∀ i<7, ∀ k<7, i≠k → rs7 (fun j => V i j*V k j)=gramT i k
  colGram : ∀ j<7, ∀ l<7, j≠l → rs7 (fun i => V i j*V i l)=gramT j l
  real : ∀ i<7, ∀ j<7, S i j ∈ realList (V i j)
  rowSig : ∀ i<7, ∀ t<7, rs7 (fun j => gd (S i j) t)+preF i t=fullF t
  colSig : ∀ j<7, ∀ t<7, rs7 (fun i => gd (S i j) t)+preF j t=fullF t

def rowsOf (V : ℕ → ℕ → ℕ) : List (ℕ × List ℕ) := (List.range 7).map fun i => (i,ofF (V i))
def sigsOf (S : ℕ → ℕ → List ℕ) : List (ℕ × List (List ℕ)) :=
  (List.range 7).map fun i => (i,(List.range 7).map (S i))

def degLists : List (List (ℕ × List ℕ)) :=
  [candA.map ((0,·)),candB.map ((1,·)),candC.map ((2,·)),candC.map ((3,·)),
   candE.map ((4,·)),candE.map ((5,·)),candE.map ((6,·))]

theorem real_le4 : ∀ (k : ℕ) (s : List ℕ), s ∈ realList k → k≤4
  | 0,_,_ | 1,_,_ | 2,_,_ | 3,_,_ | 4,_,_ => by omega
  | _+5,_,h => by simp [realList] at h

theorem real_sum_small : ∀ k<5, ∀ s ∈ realList k, 2*rs7 (gd s)+k=k*k := by decide

theorem real_sum {k : ℕ} {s : List ℕ} (h : s ∈ realList k) : 2*rs7 (gd s)+k=k*k :=
  real_sum_small k (by have := real_le4 k s h; omega) s h

theorem pre_sum : ∀ i<7, rs7 (preF i)=2*xF i+yF i := by decide
theorem full_sum : rs7 fullF=6 := by decide

section Good
variable {V : ℕ → ℕ → ℕ} {S : ℕ → ℕ → List ℕ} (G : CanonGood V S)
include G

theorem good_sig_total {i : ℕ} (hi : i<7) : rs7 (fun j => rs7 (gd (S i j)))+2*xF i+yF i=6 := by
  have h := rs7_congr (fun t ht => G.rowSig i hi t ht)
  rw [rs7_add, rs7_comm, pre_sum i hi, full_sum] at h
  omega

theorem good_moment {i : ℕ} (hi : i<7) : rs7 (fun j => V i j*V i j)=23-5*xF i-3*yF i := by
  have h1 := good_sig_total G hi
  have h2 : rs7 (fun j => V i j*V i j)=rs7 (fun j => 2*rs7 (gd (S i j))+V i j) :=
    rs7_congr (fun j hj => (real_sum (G.real i hi j hj)).symm)
  have h3 : rs7 (fun j => 2*rs7 (gd (S i j))+V i j)=2*rs7 (fun j => rs7 (gd (S i j)))+rs7 (V i) := by
    rw [rs7_add]; congr 1; simp only [rs7_expand]; omega
  have h4 := G.rowSum i hi
  have hx : xF i≤1 := by unfold xF; split <;> omega
  have hy : yF i≤1 := by unfold yF; split <;> omega
  rw [h2,h3]; omega

theorem good_row_vecs {i : ℕ} (hi : i<7) : ofF (V i) ∈ vecs := by
  apply mem_prodL
  have : List.replicate 7 (List.range 5)=(List.range 7).map (fun _ => List.range 5) := by simp
  rw [this, ofF_eq]
  exact forall₂_map_range _ _ _ 7 (fun j hj =>
    List.mem_range.mpr (by have := real_le4 _ _ (G.real i hi j hj); omega))

theorem good_pre_disj {i j : ℕ} (hi : i<7) (hj : j<7) : disjL (S i j) (ofF (preF j))=true := by
  unfold disjL
  rw [List.all_eq_true]
  intro t ht
  have ht' := List.mem_range.mp ht
  have h1 := G.colSig j hj t ht'
  have h2 := le_rs7 (fun i => gd (S i j) t) hi
  have hf : fullF t≤1 := by unfold fullF; split <;> omega
  rw [gd_ofF _ ht']
  simp only [decide_eq_true_eq]
  rcases Nat.eq_zero_or_pos (preF j t) with h|h
  · rw [h, Nat.mul_zero]
  · have : gd (S i j) t=0 := by omega
    rw [this, Nat.zero_mul]

theorem good_sig_cand {i : ℕ} (hi : i<7) : (List.range 7).map (S i) ∈ rowSigCands i (ofF (V i)) := by
  unfold rowSigCands
  rw [List.mem_filter]
  constructor
  · apply mem_prodL
    exact forall₂_map_range _ _ _ 7 (fun j hj => List.mem_filter.mpr
      ⟨by rw [gd_ofF _ hj]; exact G.real i hi j hj, good_pre_disj G hi hj⟩)
  · simp only [decide_eq_true_eq]
    unfold coverL fullL
    apply ofF_ext
    intro t ht
    rw [← G.rowSig i hi t ht, List.map_map]
    rfl

theorem good_rowOK {i : ℕ} (hi : i<7) : rowOK i (ofF (V i))=true := by
  unfold rowOK
  have hne : (rowSigCands i (ofF (V i))).isEmpty=false := by
    cases h : rowSigCands i (ofF (V i)) with
    | nil => have := good_sig_cand G hi; rw [h] at this; simp at this
    | cons _ _ => rfl
  have h1 := G.rowSum i hi
  have h2 := good_moment G hi
  have hx : xF i≤1 := by unfold xF; split <;> omega
  have hy : yF i≤1 := by unfold yF; split <;> omega
  rw [hne, map_ofF, sum_ofF, sum_ofF]
  simp only [Bool.not_false, Bool.and_true, Bool.and_eq_true, decide_eq_true_eq]
  constructor
  · unfold rs7 at h1; omega
  · unfold rs7 at h2; omega

end Good

/-! ### The two-stage census is sound -/

theorem degLists_eq : degLists=(List.range 7).map (fun i => degLists.getD i []) := rfl

theorem pairwise_range7 {α : Type} (f : ℕ → α) (P : α → α → Prop)
    (h : ∀ i<7, ∀ k<7, i<k → P (f i) (f k)) : List.Pairwise P ((List.range 7).map f) := by
  rw [List.pairwise_map]
  exact (List.pairwise_lt_range (n := 7)).imp_of_mem
    (fun ha hb hab => h _ (List.mem_range.mp ha) _ (List.mem_range.mp hb) hab)

theorem colOf_rowsOf (V : ℕ → ℕ → ℕ) {j : ℕ} (hj : j<7) :
    colOf (rowsOf V) j=ofF (fun i => V i j) := by
  unfold colOf rowsOf
  rw [List.map_map, ofF_eq]
  apply List.map_congr_left
  intro i hi
  exact gd_ofF _ hj

theorem sigs_col (S : ℕ → ℕ → List ℕ) {j : ℕ} (hj : j<7) :
    ((sigsOf S).map fun r => r.2.getD j [])=(List.range 7).map (fun i => S i j) := by
  unfold sigsOf
  rw [List.map_map]
  apply List.map_congr_left
  intro i hi
  exact getD_map_range (S i) [] hj

section Good
variable {V : ℕ → ℕ → ℕ} {S : ℕ → ℕ → List ℕ} (G : CanonGood V S)
include G

theorem good_colOK : colOK (rowsOf V)=true := by
  unfold colOK
  simp only [Bool.and_eq_true, List.all_eq_true, List.mem_range, Bool.or_eq_true,
    beq_iff_eq, decide_eq_true_eq]
  refine ⟨fun j hj => ?_, fun j hj l hl => ?_⟩
  · rw [colOf_rowsOf V hj, sum_ofF]; exact G.colSum j hj
  · by_cases hjl : j=l
    · exact Or.inl hjl
    · right
      rw [colOf_rowsOf V hj, colOf_rowsOf V hl, dotL_ofF]
      exact G.colGram j hj l hl hjl

theorem good_colCover : colCover (sigsOf S)=true := by
  unfold colCover
  simp only [List.all_eq_true, List.mem_range, decide_eq_true_eq]
  intro j hj
  rw [sigs_col S hj]
  unfold coverL fullL
  apply ofF_ext
  intro t ht
  rw [← G.colSig j hj t ht, List.map_map]
  rfl

theorem good_sigCompat {i k : ℕ} (hi : i<7) (hk : k<7) (hik : i≠k) :
    sigCompat (i,(List.range 7).map (S i)) (k,(List.range 7).map (S k))=true := by
  unfold sigCompat disjL
  simp only [List.all_eq_true, List.mem_range, decide_eq_true_eq]
  intro j hj t ht
  rw [getD_map_range _ _ hj, getD_map_range _ _ hj]
  have h1 := G.colSig j hj t ht
  have h2 := two_le_rs7 (fun i => gd (S i j) t) hi hk hik
  have hf : fullF t≤1 := by unfold fullF; split <;> omega
  rcases Nat.eq_zero_or_pos (gd (S i j) t) with h|h
  · rw [h, Nat.zero_mul]
  · have : gd (S k j) t=0 := by omega
    rw [this, Nat.mul_zero]

theorem good_sigStage : sigStage (rowsOf V)=true → abOK (rowsOf V) (sigsOf S)=true := by
  intro hs
  have hF : List.Forall₂ (fun a L => a ∈ L) (sigsOf S)
      ((rowsOf V).map fun r => (rowSigCands r.1 r.2).map ((r.1,·))) := by
    unfold sigsOf rowsOf
    rw [List.map_map]
    exact forall₂_map_range _ _ _ 7 (fun i hi => List.mem_map.mpr ⟨_,good_sig_cand G hi,rfl⟩)
  have hP : List.Pairwise (fun a b => sigCompat a b=true) (sigsOf S) :=
    pairwise_range7 _ _ (fun i hi k hk hik => good_sigCompat G hi hk (by omega))
  have := dfs_sound sigCompat (sigLeaf (rowsOf V)) 7 [] _ (sigsOf S) (by simp [rowsOf]) hF
    (by simpa using hP) hs
  simp only [List.reverse_nil, List.nil_append, sigLeaf, good_colCover G, Bool.not_true,
    Bool.false_or] at this
  exact this

theorem canon_census
    (hcomp : ∀ i<7, ∀ v ∈ vecs, rowOK i v=true → (i,v) ∈ degLists.getD i [])
    (hcen : dfs degCompat degLeaf 7 [] degLists=true) :
    abOK (rowsOf V) (sigsOf S)=true := by
  have hF : List.Forall₂ (fun a L => a ∈ L) (rowsOf V) degLists := by
    rw [degLists_eq]
    exact forall₂_map_range _ _ _ 7 (fun i hi =>
      hcomp i hi _ (good_row_vecs G hi) (good_rowOK G hi))
  have hP : List.Pairwise (fun a b => degCompat a b=true) (rowsOf V) := by
    apply pairwise_range7
    intro i hi k hk hik
    unfold degCompat
    simp only [decide_eq_true_eq]
    rw [dotL_ofF]
    exact G.rowGram i hi k hk (by omega)
  have := dfs_sound degCompat degLeaf 7 [] degLists (rowsOf V) (by rfl) hF (by simpa using hP) hcen
  simp only [List.reverse_nil, List.nil_append, degLeaf, good_colOK G, Bool.not_true,
    Bool.false_or] at this
  exact good_sigStage G this

end Good

end Symconf113

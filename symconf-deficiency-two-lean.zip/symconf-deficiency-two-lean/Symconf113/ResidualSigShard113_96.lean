import Symconf113.ResidualLeaves113

/-! Kernel check: the signature stage refutes leaves 96 to 111. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem sigShard_96 : ((leaves.drop 96).take 16).all sigStage=true := by decide +kernel
end Symconf113

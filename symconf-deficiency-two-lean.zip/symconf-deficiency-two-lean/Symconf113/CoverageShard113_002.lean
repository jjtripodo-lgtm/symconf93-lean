import Symconf113.CoverageShard113_001

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0087 : NodeCoverage113 [77,9] 9 27 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0088 : NodeCoverage113 [77,8] 8 28 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0089 : NodeCoverage113 [77,7] 7 29 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0090 : NodeCoverage113 [77,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0091 : NodeCoverage113 [77,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0092 : NodeCoverage113 [77,3] 3 33 :=
  demand_node_prune113 77 compact113_demands_077 compact113_demands_077_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0093 : NodeCoverage113 [77] 77 36 :=
  node_fork113 (B := [36,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0062
    (ChildrenCoverage113.cons _ _ compact113_node_0063
    (ChildrenCoverage113.cons _ _ compact113_node_0064
    (ChildrenCoverage113.cons _ _ compact113_node_0065
    (ChildrenCoverage113.cons _ _ compact113_node_0066
    (ChildrenCoverage113.cons _ _ compact113_node_0067
    (ChildrenCoverage113.cons _ _ compact113_node_0068
    (ChildrenCoverage113.cons _ _ compact113_node_0069
    (ChildrenCoverage113.cons _ _ compact113_node_0070
    (ChildrenCoverage113.cons _ _ compact113_node_0071
    (ChildrenCoverage113.cons _ _ compact113_node_0072
    (ChildrenCoverage113.cons _ _ compact113_node_0073
    (ChildrenCoverage113.cons _ _ compact113_node_0074
    (ChildrenCoverage113.cons _ _ compact113_node_0075
    (ChildrenCoverage113.cons _ _ compact113_node_0076
    (ChildrenCoverage113.cons _ _ compact113_node_0077
    (ChildrenCoverage113.cons _ _ compact113_node_0078
    (ChildrenCoverage113.cons _ _ compact113_node_0079
    (ChildrenCoverage113.cons _ _ compact113_node_0080
    (ChildrenCoverage113.cons _ _ compact113_node_0081
    (ChildrenCoverage113.cons _ _ compact113_node_0082
    (ChildrenCoverage113.cons _ _ compact113_node_0083
    (ChildrenCoverage113.cons _ _ compact113_node_0084
    (ChildrenCoverage113.cons _ _ compact113_node_0085
    (ChildrenCoverage113.cons _ _ compact113_node_0086
    (ChildrenCoverage113.cons _ _ compact113_node_0087
    (ChildrenCoverage113.cons _ _ compact113_node_0088
    (ChildrenCoverage113.cons _ _ compact113_node_0089
    (ChildrenCoverage113.cons _ _ compact113_node_0090
    (ChildrenCoverage113.cons _ _ compact113_node_0091
    (ChildrenCoverage113.cons _ _ compact113_node_0092
    ChildrenCoverage113.nil)))))))))))))))))))))))))))))))

theorem compact113_node_0094 : NodeCoverage113 [76] 76 37 :=
  demand_node_prune113 76 compact113_demands_076 compact113_demands_076_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0095 : NodeCoverage113 [75] 75 38 :=
  demand_node_prune113 75 compact113_demands_075 compact113_demands_075_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0096 : NodeCoverage113 [74] 74 39 :=
  demand_node_prune113 74 compact113_demands_074 compact113_demands_074_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0097 : NodeCoverage113 [73] 73 40 :=
  demand_node_prune113 73 compact113_demands_073 compact113_demands_073_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0098 : NodeCoverage113 [72,41] 41 0 :=
  demand_node_prune113 41 compact113_demands_041 compact113_demands_041_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0099 : NodeCoverage113 [72,38] 38 3 :=
  demand_node_prune113 38 compact113_demands_038 compact113_demands_038_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0100 : NodeCoverage113 [72,37] 37 4 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0101 : NodeCoverage113 [72,36] 36 5 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0102 : NodeCoverage113 [72,35] 35 6 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0103 : NodeCoverage113 [72,34] 34 7 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0104 : NodeCoverage113 [72,33] 33 8 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0105 : NodeCoverage113 [72,32] 32 9 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0106 : NodeCoverage113 [72,31] 31 10 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0107 : NodeCoverage113 [72,30] 30 11 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0108 : NodeCoverage113 [72,29] 29 12 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0109 : NodeCoverage113 [72,28] 28 13 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0110 : NodeCoverage113 [72,27] 27 14 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0111 : NodeCoverage113 [72,26] 26 15 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0112 : NodeCoverage113 [72,25] 25 16 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0113 : NodeCoverage113 [72,24] 24 17 :=
  demand_node_prune113 72 compact113_demands_072 compact113_demands_072_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0114 : NodeCoverage113 [72,23] 23 18 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0115 : NodeCoverage113 [72,22] 22 19 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0116 : NodeCoverage113 [72,21] 21 20 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0117 : NodeCoverage113 [72,20] 20 21 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0118 : NodeCoverage113 [72,19] 19 22 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0119 : NodeCoverage113 [72,18] 18 23 :=
  demand_node_prune113 72 compact113_demands_072 compact113_demands_072_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0120 : NodeCoverage113 [72,17] 17 24 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0121 : NodeCoverage113 [72,16] 16 25 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0122 : NodeCoverage113 [72,15] 15 26 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0123 : NodeCoverage113 [72,14] 14 27 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0124 : NodeCoverage113 [72,13] 13 28 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0125 : NodeCoverage113 [72,12,12] 12 17 :=
  demand_node_prune113 72 compact113_demands_072 compact113_demands_072_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0126 : NodeCoverage113 [72,12,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0127 : NodeCoverage113 [72,12,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0128 : NodeCoverage113 [72,12,9,9] 9 11 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0129 : NodeCoverage113 [72,12,9,8] 8 12 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0130 : NodeCoverage113 [72,12,9,7] 7 13 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0131 : NodeCoverage113 [72,12,9,6] 6 14 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0132 : NodeCoverage113 [72,12,9,5] 5 15 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

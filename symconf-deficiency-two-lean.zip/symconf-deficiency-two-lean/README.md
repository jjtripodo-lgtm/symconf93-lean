# symconf-deficiency-two-lean

Standalone Lake project for the deficiency-two symmetric configurations
v_k with v = k^2 - k + 3. It builds from a clean clone with a pinned toolchain
and no prebuilt private files.

Ancillary Lean development for the article *There is no symmetric configuration 93_10* (John Tripodo). Source snapshot from commit 4e3f62418e6a048ff755c2d189343dbacd28b90a.

## Status (24 Nov 2026)

| Order | Lean status | Endpoint | Hypotheses |
| --- | --- | --- | --- |
| 59_8 | **proved in Lean** | `Symconf59.no_unrestricted_incidence59` | none |
| 93_10 | **proved in Lean** | `Symconf93.no_unrestricted_incidence93` | none |
| 113_11 | **proved in Lean under one named hypothesis**; the residual profile 3+5+15^7 is excluded with no hypothesis | `Symconf113.no_unrestricted_incidence113` (no incidence); `Symconf113.no_residual_incidence113` (no incidence with profile 3+5+15^7); `Symconf113.incidence113_two_profiles` (only [113] or 3+5+15^7) | `no_unrestricted_incidence113` assumes `NoModularGolombRuler113` (Buratti-Stinson 2021: no (113,11) modular Golomb ruler); the other two use none |
| 75_9 | **reduced in Lean to 14 leave profiles** (front half, 33-profile cover, 18 exclusions, and no (75,9) modular Golomb ruler, which kills [75]); 4 of the 14 are separately **proved impossible in Lean** by vector cliques, and 2 more ([6^11,3^3], [6^9,3^7]) by 3-adic determinant parity (`EvenParity75`, 14 to 12); more written (see below) | `Symconf75.incidence75_fourteen_profiles`; `Symconf75.noModularGolombRuler75`; `Symconf75.VecClique.no_profile15`, `no_profile12a`, `no_profile12b`, `no_profile10`; `Symconf75.no_ordered_profileSix11`, `no_ordered_profileSix9`, `incidence75_twelve_profiles` | none (reduction only) |

"Proved in Lean" means: the theorem compiles from this directory with
`lake build`, has no `sorry`, and `#print axioms` lists only `propext`,
`Classical.choice` and `Quot.sound` (see `AuditAxioms.lean` and
`BUILD_RECEIPT.txt`).

The front halves for 113 and 75 show, for an arbitrary original incidence
matrix with no cyclicity or automorphism premise, that both disjointness
graphs are cycle unions with one common decreasing profile P, that the matrix
splits into physical cyclic blocks with constant degrees, and that P satisfies
every exact moment, cross-moment and period bound (`OriginalProfileFacts P`).
They are a mechanical port of the 93 front half (constants k and k-1 changed).

### What the back halves still need

- **113_11.** Everything except the Buratti-Stinson ruler theorem is now in
  Lean: the 7,635-node profile cover (`ExactCoverage113`, 19 profiles), the
  exclusion of 17 profiles from two or three rows (`ProfileExclusions113`),
  the reduction of the Hamiltonian profile [113] to a (113,11) modular Golomb
  ruler (`Hamiltonian113`), and the residual profile 3+5+15^7
  (`Residual*113`, 146 modules): circulant 15-blocks, a sharded kernel
  degree census over the canonical row/column types (`ResidualDegShard113_*`,
  `ResidualComplete113_*`), realizability of distance triples
  (`ResidualRealize*`), and the mod-15 class-sum contradiction
  (`ResidualFinalAB113`). The residual shards were produced by one-off
  generators (`tools/residual113/` keeps the census replay and the list
  generator); Lean re-checks every shard with `decide +kernel`.
- **75_9.** Profile coverage (235,858 partitions -> 11 profiles), Hasse
  replacements at 2, 3 and 449, the compatibility-graph enumerations, the
  5+35^2 difference argument, and the 3^25 case, which imports Denniston's
  classification of the 78 symmetric 2-(25,9,3) designs (explicit hypothesis).

### Checkpoint 24 Nov 2026, 10:30 PM Pacific: written, not yet in the lake build

Apart from the first item, nothing in this list is "proved in Lean" yet. Each item says how far it got.
`bash tools/resume_builds.sh` builds the rest one module at a time (never two
kernel pieces at once: a piece peaks near 11.4 GB and the build machine killed
processes at about 13.5 GB).

- **Now built and proved (moved to the table above):** `NoRuler75` (all 49
  pieces `RulerShard75_*` built by lake), `Hamiltonian75`, `Reduction75`
  (14 profiles left) and `VecCliqueChecks75` ([15^4,5^3], [12^6,3],
  [12^5,6,6,3], [10^6,5^3] impossible). Standard axioms only. Not yet done:
  one theorem combining these into a 10-profile reduction.
- **[9^7,3^4].** `VecCliqueV9_75`, 27 pieces `VecCliqueShard9_*` and
  `VecCliqueChecks75_9` (`tools/gen_clique9_75.py`). The one-theorem version
  ran out of memory, hence the pieces. Not built yet. `Reduction9_75` would
  leave 9 profiles.
- **[6^8,3^9] by a two-length clique.** `VecClique2_75` (generic two-length
  exclusion) compiles. `VecClique2C*` (`tools/gen_clique2c_75.py`): 4 of the
  151 search pieces were compiled singly and pass in about 5 s each; the
  kernel check that the listed vectors equal `vecs` ran out of memory as one
  theorem and must be split by leading entries before `VecClique2CChecks75`
  can build. `VecSplit75` drafts the splitting lemmas (not compiled yet).
- **113 ruler.** `RulerSearch113`, `RulerCover113` and `NoRulerCore113`
  compile. `RulerCoverDefs113`, 120 pieces `RulerCoverShard113_*`,
  `NoRuler113` and `Final113` (`no_incidence113` with no hypothesis) are
  written, not built. If they build, the Buratti-Stinson hypothesis drops out.
- **Exploration (untrusted).** CP-SAT finds the joint two-length system
  infeasible also for [6^10,3^5] and [6^9,3^7], but the plain Lean search order
  takes over 3 billion steps there; [9^8,3], [35,35,5] and [5^15] have joint
  solutions and need other arguments; [6^12,3], [6^11,3^3] and [3^25] are
  undecided by these tests.

### Findings from this pass (tools/)

- 113 back half generators: `tools/make_compact_coverage113.py` (cover),
  `tools/gen_profile_exclusions113.py` (17 exclusions). Both are untrusted;
  Lean re-checks every node and every exclusion with `decide +kernel`.
  `tools/exploration/` holds the untrusted CP-SAT scripts that found which
  row pairs or triples suffice, and a first look at 75_9: its cover has 33
  profiles and row pairs or triples settle 17 of them, two more fall to all
  rows together, and 14 survive row facts alone.

- The 59-style mod p^2 anisotropy argument does **not** remove the
  Buratti-Stinson import for the 113-cycle. det(10I+J-Z_113) = 11^2 q^2 with
  q a 56-digit prime, q = 1 mod 113; the kernel of G mod q is 2-dimensional but
  the induced form is isotropic (and the circulant eigenvectors are
  isotropic lines), so no contradiction. The same simple test kills none of
  the 15 periodic 113 profiles at odd primes. Control: it reproduces the
  p = 353 anisotropic certificate for the 59-cycle. (`tools/aniso.py`,
  `tools/ham.py`)
- Independent exhaustive search (`tools/mgr.c`, normalized so 0,1 are in the
  ruler) finds **no (113,11) modular Golomb ruler** (35,173,975 nodes), in
  agreement with Buratti-Stinson. Controls: (31,6) and (91,10) rulers are
  found; (59,8) and (93,10) give none.
- Forward-citation check (web search only; scholarly APIs were unreachable):
  nothing found that settles 75_9, 93_10 or 113_11. Philbrook-Peet
  (arXiv 2404.17514, Involve 2026) remains at v2 with a conditional k=3
  cycle-parity result; Boza (arXiv 2409.12770 v2, 2026) gives the ordinary
  Ramsey number R(C4, K_{1,67}) = 76, which is not the bipartite b(67) of the
  lab's 75_9 corollary. This is not a worldwide priority clearance.

## Build

```
lake build            # default target SymconfDeficiencyTwo (59 + 93)
lake build Symconf113 Symconf75
lake env lean AuditAxioms.lean
```

Toolchain `leanprover/lean4:v4.31.0-rc1` (commit fd009949), Mathlib
`0ed37c9258f123a2c76a2175596f75c2bd50f941`; all transitive dependencies are
pinned in `lake-manifest.json`. Where the Mathlib cache is reachable,
`lake exe cache get` saves the Mathlib compile; otherwise Mathlib builds from
source (see `BUILD_RECEIPT.txt` for the time on a 4-core machine).

## Provenance

`Symconf59/` and `Symconf93/` (plus `Symconf93DegreeNormalize.lean`,
`Symconf93OffsetMoments.lean`) are byte-identical copies of the sources under
`symconf59-lean/audit/*/`; `PROVENANCE.txt` lists each file's SHA-256 and
origin. Nothing in those files was edited. `Symconf113/` and `Symconf75/` are
new.

import Symconf113.CoverageShard113_020

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0887 : NodeCoverage113 [45,15,15,15,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0888 : NodeCoverage113 [45,15,15,15,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0889 : NodeCoverage113 [45,15,15,15,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0890 : NodeCoverage113 [45,15,15,15,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0891 : NodeCoverage113 [45,15,15,15,5] 5 18 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0892 : NodeCoverage113 [45,15,15,15,3] 3 20 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0893 : NodeCoverage113 [45,15,15,15] 15 23 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0881
    (ChildrenCoverage113.cons _ _ compact113_node_0882
    (ChildrenCoverage113.cons _ _ compact113_node_0883
    (ChildrenCoverage113.cons _ _ compact113_node_0884
    (ChildrenCoverage113.cons _ _ compact113_node_0885
    (ChildrenCoverage113.cons _ _ compact113_node_0886
    (ChildrenCoverage113.cons _ _ compact113_node_0887
    (ChildrenCoverage113.cons _ _ compact113_node_0888
    (ChildrenCoverage113.cons _ _ compact113_node_0889
    (ChildrenCoverage113.cons _ _ compact113_node_0890
    (ChildrenCoverage113.cons _ _ compact113_node_0891
    (ChildrenCoverage113.cons _ _ compact113_node_0892
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_0894 : NodeCoverage113 [45,15,15,14] 14 24 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0895 : NodeCoverage113 [45,15,15,13] 13 25 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0896 : NodeCoverage113 [45,15,15,12] 12 26 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0897 : NodeCoverage113 [45,15,15,11] 11 27 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0898 : NodeCoverage113 [45,15,15,10] 10 28 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0899 : NodeCoverage113 [45,15,15,9] 9 29 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0900 : NodeCoverage113 [45,15,15,8] 8 30 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0901 : NodeCoverage113 [45,15,15,7] 7 31 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0902 : NodeCoverage113 [45,15,15,6] 6 32 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0903 : NodeCoverage113 [45,15,15,5] 5 33 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0904 : NodeCoverage113 [45,15,15,3] 3 35 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0905 : NodeCoverage113 [45,15,15] 15 38 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0893
    (ChildrenCoverage113.cons _ _ compact113_node_0894
    (ChildrenCoverage113.cons _ _ compact113_node_0895
    (ChildrenCoverage113.cons _ _ compact113_node_0896
    (ChildrenCoverage113.cons _ _ compact113_node_0897
    (ChildrenCoverage113.cons _ _ compact113_node_0898
    (ChildrenCoverage113.cons _ _ compact113_node_0899
    (ChildrenCoverage113.cons _ _ compact113_node_0900
    (ChildrenCoverage113.cons _ _ compact113_node_0901
    (ChildrenCoverage113.cons _ _ compact113_node_0902
    (ChildrenCoverage113.cons _ _ compact113_node_0903
    (ChildrenCoverage113.cons _ _ compact113_node_0904
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_0906 : NodeCoverage113 [45,15,14] 14 39 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0907 : NodeCoverage113 [45,15,13] 13 40 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0908 : NodeCoverage113 [45,15,12] 12 41 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0909 : NodeCoverage113 [45,15,11] 11 42 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0910 : NodeCoverage113 [45,15,10] 10 43 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0911 : NodeCoverage113 [45,15,9] 9 44 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0912 : NodeCoverage113 [45,15,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0913 : NodeCoverage113 [45,15,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0914 : NodeCoverage113 [45,15,6] 6 47 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0915 : NodeCoverage113 [45,15,5] 5 48 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0916 : NodeCoverage113 [45,15,3] 3 50 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0917 : NodeCoverage113 [45,15] 15 53 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0905
    (ChildrenCoverage113.cons _ _ compact113_node_0906
    (ChildrenCoverage113.cons _ _ compact113_node_0907
    (ChildrenCoverage113.cons _ _ compact113_node_0908
    (ChildrenCoverage113.cons _ _ compact113_node_0909
    (ChildrenCoverage113.cons _ _ compact113_node_0910
    (ChildrenCoverage113.cons _ _ compact113_node_0911
    (ChildrenCoverage113.cons _ _ compact113_node_0912
    (ChildrenCoverage113.cons _ _ compact113_node_0913
    (ChildrenCoverage113.cons _ _ compact113_node_0914
    (ChildrenCoverage113.cons _ _ compact113_node_0915
    (ChildrenCoverage113.cons _ _ compact113_node_0916
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_0918 : NodeCoverage113 [45,14] 14 54 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0919 : NodeCoverage113 [45,13] 13 55 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0920 : NodeCoverage113 [45,12] 12 56 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0921 : NodeCoverage113 [45,11] 11 57 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0922 : NodeCoverage113 [45,10] 10 58 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0923 : NodeCoverage113 [45,9,9,9,9,9,9,9,5] 5 0 :=
  node_no_weak_demand113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0924 : NodeCoverage113 [45,9,9,9,9,9,9,9] 9 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0923
    ChildrenCoverage113.nil)

theorem compact113_node_0925 : NodeCoverage113 [45,9,9,9,9,9,9,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0926 : NodeCoverage113 [45,9,9,9,9,9,9,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0927 : NodeCoverage113 [45,9,9,9,9,9,9,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0928 : NodeCoverage113 [45,9,9,9,9,9,9,5] 5 9 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_150
import Symconf113.CoverageShard113_151
import Symconf113.CoverageShard113_152

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_6565 : NodeCoverage113 [12,12,6,6,6,6,6,6,5] 5 48 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6566 : NodeCoverage113 [12,12,6,6,6,6,6,6,3] 3 50 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6567 : NodeCoverage113 [12,12,6,6,6,6,6,6] 6 53 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6564
    (ChildrenCoverage113.cons _ _ compact113_node_6565
    (ChildrenCoverage113.cons _ _ compact113_node_6566
    ChildrenCoverage113.nil)))

theorem compact113_node_6568 : NodeCoverage113 [12,12,6,6,6,6,6,5] 5 54 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6569 : NodeCoverage113 [12,12,6,6,6,6,6,3] 3 56 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6570 : NodeCoverage113 [12,12,6,6,6,6,6] 6 59 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6567
    (ChildrenCoverage113.cons _ _ compact113_node_6568
    (ChildrenCoverage113.cons _ _ compact113_node_6569
    ChildrenCoverage113.nil)))

theorem compact113_node_6571 : NodeCoverage113 [12,12,6,6,6,6,5] 5 60 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6572 : NodeCoverage113 [12,12,6,6,6,6,3] 3 62 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6573 : NodeCoverage113 [12,12,6,6,6,6] 6 65 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6570
    (ChildrenCoverage113.cons _ _ compact113_node_6571
    (ChildrenCoverage113.cons _ _ compact113_node_6572
    ChildrenCoverage113.nil)))

theorem compact113_node_6574 : NodeCoverage113 [12,12,6,6,6,5] 5 66 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6575 : NodeCoverage113 [12,12,6,6,6,3] 3 68 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6576 : NodeCoverage113 [12,12,6,6,6] 6 71 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6573
    (ChildrenCoverage113.cons _ _ compact113_node_6574
    (ChildrenCoverage113.cons _ _ compact113_node_6575
    ChildrenCoverage113.nil)))

theorem compact113_node_6577 : NodeCoverage113 [12,12,6,6,5] 5 72 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6578 : NodeCoverage113 [12,12,6,6,3] 3 74 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6579 : NodeCoverage113 [12,12,6,6] 6 77 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6576
    (ChildrenCoverage113.cons _ _ compact113_node_6577
    (ChildrenCoverage113.cons _ _ compact113_node_6578
    ChildrenCoverage113.nil)))

theorem compact113_node_6580 : NodeCoverage113 [12,12,6,5] 5 78 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6581 : NodeCoverage113 [12,12,6,3] 3 80 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6582 : NodeCoverage113 [12,12,6] 6 83 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6579
    (ChildrenCoverage113.cons _ _ compact113_node_6580
    (ChildrenCoverage113.cons _ _ compact113_node_6581
    ChildrenCoverage113.nil)))

theorem compact113_node_6583 : NodeCoverage113 [12,12,5] 5 84 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6584 : NodeCoverage113 [12,12,3] 3 86 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6585 : NodeCoverage113 [12,12] 12 89 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6428
    (ChildrenCoverage113.cons _ _ compact113_node_6453
    (ChildrenCoverage113.cons _ _ compact113_node_6475
    (ChildrenCoverage113.cons _ _ compact113_node_6494
    (ChildrenCoverage113.cons _ _ compact113_node_6495
    (ChildrenCoverage113.cons _ _ compact113_node_6516
    (ChildrenCoverage113.cons _ _ compact113_node_6582
    (ChildrenCoverage113.cons _ _ compact113_node_6583
    (ChildrenCoverage113.cons _ _ compact113_node_6584
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_6586 : NodeCoverage113 [12,11] 11 90 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6587 : NodeCoverage113 [12,10] 10 91 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6588 : NodeCoverage113 [12,9] 9 92 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6589 : NodeCoverage113 [12,8] 8 93 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6590 : NodeCoverage113 [12,7] 7 94 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6591 : NodeCoverage113 [12,6] 6 95 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6592 : NodeCoverage113 [12,5] 5 96 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6593 : NodeCoverage113 [12,3] 3 98 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6594 : NodeCoverage113 [12] 12 101 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6585
    (ChildrenCoverage113.cons _ _ compact113_node_6586
    (ChildrenCoverage113.cons _ _ compact113_node_6587
    (ChildrenCoverage113.cons _ _ compact113_node_6588
    (ChildrenCoverage113.cons _ _ compact113_node_6589
    (ChildrenCoverage113.cons _ _ compact113_node_6590
    (ChildrenCoverage113.cons _ _ compact113_node_6591
    (ChildrenCoverage113.cons _ _ compact113_node_6592
    (ChildrenCoverage113.cons _ _ compact113_node_6593
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_6595 : NodeCoverage113 [11,11,11,11,11,11,11,11,11,11,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6596 : NodeCoverage113 [11,11,11,11,11,11,11,11,11,11] 11 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6595
    ChildrenCoverage113.nil)

theorem compact113_node_6597 : NodeCoverage113 [11,11,11,11,11,11,11,11,11,10] 10 4 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6598 : NodeCoverage113 [11,11,11,11,11,11,11,11,11,9] 9 5 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6599 : NodeCoverage113 [11,11,11,11,11,11,11,11,11,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6600 : NodeCoverage113 [11,11,11,11,11,11,11,11,11,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6601 : NodeCoverage113 [11,11,11,11,11,11,11,11,11,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6602 : NodeCoverage113 [11,11,11,11,11,11,11,11,11,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6603 : NodeCoverage113 [11,11,11,11,11,11,11,11,11,3] 3 11 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6604 : NodeCoverage113 [11,11,11,11,11,11,11,11,11] 11 14 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6596
    (ChildrenCoverage113.cons _ _ compact113_node_6597
    (ChildrenCoverage113.cons _ _ compact113_node_6598
    (ChildrenCoverage113.cons _ _ compact113_node_6599
    (ChildrenCoverage113.cons _ _ compact113_node_6600
    (ChildrenCoverage113.cons _ _ compact113_node_6601
    (ChildrenCoverage113.cons _ _ compact113_node_6602
    (ChildrenCoverage113.cons _ _ compact113_node_6603
    ChildrenCoverage113.nil))))))))

theorem compact113_node_6605 : NodeCoverage113 [11,11,11,11,11,11,11,11,10] 10 15 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

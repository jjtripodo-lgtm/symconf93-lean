import Symconf113.RulerCover113
import Symconf113.Hamiltonian113
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.LinearCombination

/-! From a (113,11) modular Golomb ruler to a node of the cover search.
The 110 differences miss exactly one pair `±d`; scaling by the inverse of `d` makes the
missing pair `±1`, so every other nonzero residue is a difference, and a
translation puts `0` and `2` in the ruler. -/
namespace Symconf113.Ruler113
open scoped BigOperators

def RulerZ (D : Finset (ZMod 113)) : Prop :=
  ∀ a ∈ D, ∀ b ∈ D, ∀ c ∈ D, ∀ e ∈ D, a≠b → a-b=c-e → a=c ∧ b=e

/-- The nonzero differences of `D`. -/
def diffs (D : Finset (ZMod 113)) : Finset (ZMod 113) := D.offDiag.image fun p => p.1-p.2

theorem mem_diffs {D : Finset (ZMod 113)} {e : ZMod 113} :
    e ∈ diffs D ↔ ∃ a ∈ D, ∃ b ∈ D, a≠b ∧ a-b=e := by
  unfold diffs
  simp only [Finset.mem_image, Finset.mem_offDiag, Prod.exists]
  constructor
  · rintro ⟨a,b,⟨ha,hb,hab⟩,rfl⟩; exact ⟨a,ha,b,hb,hab,rfl⟩
  · rintro ⟨a,ha,b,hb,hab,rfl⟩; exact ⟨a,b,⟨ha,hb,hab⟩,rfl⟩

theorem diffs_card {D : Finset (ZMod 113)} (hD : RulerZ D) (h : D.card=11) : (diffs D).card=110 := by
  unfold diffs
  rw [Finset.card_image_of_injOn, Finset.offDiag_card, h]
  intro p hp q hq hpq
  obtain ⟨p1,p2,hp12⟩ := Finset.mem_offDiag.mp hp
  obtain ⟨q1,q2,_⟩ := Finset.mem_offDiag.mp hq
  obtain ⟨h1,h2⟩ := hD _ p1 _ p2 _ q1 _ q2 hp12 hpq
  exact Prod.ext h1 h2

theorem exists_inv : ∀ x : ZMod 113, x≠0 → ∃ v, v*x=1 := by decide +kernel

/-- An affine image `z ↦ u*z+t` with `u` invertible. -/
theorem affine_image (D : Finset (ZMod 113)) (hD : RulerZ D) (h : D.card=11) (u t v : ZMod 113)
    (hv : v*u=1) :
    RulerZ (D.image fun z => u*z+t) ∧ (D.image fun z => u*z+t).card=11 ∧
      ∀ e, e ∈ diffs (D.image fun z => u*z+t) ↔ v*e ∈ diffs D := by
  have hc : ∀ x y : ZMod 113, u*x=u*y → x=y := fun x y hxy => by
    have := congrArg (v*·) hxy
    simpa [← mul_assoc, hv] using this
  have hinj : Function.Injective fun z => u*z+t := fun x y hxy => hc x y (by simpa using hxy)
  refine ⟨?_,by rw [Finset.card_image_of_injective _ hinj, h],?_⟩
  · intro p hp q hq r hr w hw hpq hd
    obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp hp
    obtain ⟨y,hy,rfl⟩ := Finset.mem_image.mp hq
    obtain ⟨z,hz,rfl⟩ := Finset.mem_image.mp hr
    obtain ⟨w',hw',rfl⟩ := Finset.mem_image.mp hw
    have hxy : x≠y := fun e => hpq (by rw [e])
    obtain ⟨e1,e2⟩ := hD _ hx _ hy _ hz _ hw' hxy (hc _ _ (by linear_combination hd))
    exact ⟨by rw [e1],by rw [e2]⟩
  · intro e
    rw [mem_diffs, mem_diffs]
    constructor
    · rintro ⟨p,hp,q,hq,hpq,rfl⟩
      obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp hp
      obtain ⟨y,hy,rfl⟩ := Finset.mem_image.mp hq
      refine ⟨x,hx,y,hy,fun e => hpq (by rw [e]),?_⟩
      linear_combination (y-x)*hv
    · rintro ⟨x,hx,y,hy,hxy,he⟩
      refine ⟨u*x+t,Finset.mem_image_of_mem _ hx,u*y+t,Finset.mem_image_of_mem _ hy,
        fun h' => hxy (hinj h'),?_⟩
      have : e=u*(v*e) := by linear_combination (-e)*hv
      rw [this, ← he]; ring

def bad3 : Finset (ZMod 113) := ((Finset.univ.erase 0).erase 1).erase (-1)

theorem bad3_card : bad3.card=110 := by decide

/-- Normalization of a ruler. -/
theorem normalize (D : Finset (ZMod 113)) (hD : RulerZ D) (h : D.card=11) :
    ∃ D' : Finset (ZMod 113), RulerZ D' ∧ D'.card=11 ∧ (0 : ZMod 113) ∈ D' ∧ (2 : ZMod 113) ∈ D' ∧
      ∀ e, e ∈ diffs D' ↔ e ∈ bad3 := by
  -- a missing nonzero difference
  have hsub : diffs D ⊆ Finset.univ.erase 0 := by
    intro e he
    obtain ⟨a,_,b,_,hab,rfl⟩ := mem_diffs.mp he
    exact Finset.mem_erase.mpr ⟨sub_ne_zero.mpr hab,Finset.mem_univ _⟩
  obtain ⟨d,hd,hdD⟩ : ∃ d ∈ Finset.univ.erase (0 : ZMod 113), d ∉ diffs D := by
    by_contra hcon
    simp only [not_exists, not_and, not_not] at hcon
    have := Finset.card_le_card (fun e he => hcon e he : Finset.univ.erase (0 : ZMod 113) ⊆ diffs D)
    rw [diffs_card hD h, Finset.card_erase_of_mem (Finset.mem_univ _)] at this
    simp at this
  have hd0 : d≠0 := (Finset.mem_erase.mp hd).1
  -- scale by the inverse of d
  obtain ⟨w,hw⟩ := exists_inv d hd0
  obtain ⟨hR1,hc1,hdf1⟩ := affine_image D hD h w 0 d (by rw [mul_comm]; exact hw)
  set D1 := D.image fun z => w*z+0
  have hcov1 : ∀ e, e ∈ diffs D1 ↔ e ∈ bad3 := by
    have hs : diffs D1 ⊆ bad3 := by
      intro e he
      have hne0 : e≠0 := by
        obtain ⟨a,_,b,_,hab,rfl⟩ := mem_diffs.mp he; exact sub_ne_zero.mpr hab
      have hv := (hdf1 e).mp he
      simp only [bad3, Finset.mem_erase, Finset.mem_univ, and_true]
      refine ⟨?_,?_,hne0⟩
      · rintro rfl
        obtain ⟨a,ha,b,hb,hab,hab'⟩ := mem_diffs.mp hv
        exact hdD (mem_diffs.mpr ⟨b,hb,a,ha,Ne.symm hab,by linear_combination -hab'⟩)
      · rintro rfl
        exact hdD (by simpa using hv)
    have heq := Finset.eq_of_subset_of_card_le hs (by rw [bad3_card, diffs_card hR1 hc1])
    intro e; rw [heq]
  -- translate a pair with difference 2 to {0,2}
  obtain ⟨a0,ha0,b0,hb0,_,h2⟩ := mem_diffs.mp ((hcov1 2).mpr (by decide))
  obtain ⟨hR2,hc2,hdf2⟩ := affine_image D1 hR1 hc1 1 (-b0) 1 (by ring)
  refine ⟨_,hR2,hc2,Finset.mem_image.mpr ⟨b0,hb0,by ring⟩,
    Finset.mem_image.mpr ⟨a0,ha0,by rw [← h2]; ring⟩,fun e => ?_⟩
  rw [hdf2, one_mul, hcov1]


theorem ruler_of_g (g : ZMod 113 → ℤ) (hb : ∀ z, g z=0 ∨ g z=1)
    (hov : ∀ d : ZMod 113, d≠0 → (∑ z, g z*g (z+d))≤1) :
    RulerZ (Finset.univ.filter fun z => g z=1) := by
  intro a ha b hb' c hc e he hab h
  simp only [Finset.mem_filter, Finset.mem_univ, true_and] at ha hb' hc he
  have hd : a-b≠0 := sub_ne_zero.mpr hab
  have hnn : ∀ z, 0≤g z*g (z+(a-b)) := fun z => by
    rcases hb z with h1|h1 <;> rcases hb (z+(a-b)) with h2|h2 <;> simp [h1,h2]
  have hba : b+(a-b)=a := by ring
  have hec : e+(a-b)=c := by rw [h]; ring
  by_cases hbe : b=e
  · refine ⟨?_,hbe⟩
    rw [← hba, ← hec, hbe]
  · exfalso
    have hsub : ({b,e} : Finset (ZMod 113)) ⊆ Finset.univ := Finset.subset_univ _
    have h2 := Finset.sum_le_sum_of_subset_of_nonneg hsub (fun z _ _ => hnn z)
    rw [Finset.sum_pair hbe, hba, hec, ha, hb', hc, he] at h2
    have := hov _ hd
    linarith

theorem card_of_g (g : ZMod 113 → ℤ) (hb : ∀ z, g z=0 ∨ g z=1) (hs : (∑ z,g z)=11) :
    (Finset.univ.filter fun z => g z=1).card=11 := by
  have h : (∑ z, g z)=∑ z, (if g z=1 then (1:ℤ) else 0) :=
    Finset.sum_congr rfl fun z _ => by rcases hb z with h|h <;> simp [h]
  rw [Finset.sum_boole] at h
  have : ((Finset.univ.filter fun z => g z=1).card : ℤ)=11 := by rw [← h, hs]
  exact_mod_cast this

theorem dd_val {a b : ℕ} (hb : b<113) : dd a b=(((a : ZMod 113))-((b : ZMod 113))).val := by
  unfold dd
  have h : ((a+113-b : ℕ) : ZMod 113)=(a : ZMod 113)-(b : ZMod 113) := by
    rw [Nat.cast_sub (by omega), Nat.cast_add, ZMod.natCast_self, add_zero]
  rw [← h, ZMod.val_natCast]

theorem mem_bad3_of_val : ∀ x : ZMod 113, 2≤x.val → x.val≤111 → x ∈ bad3 := by decide +kernel

theorem val_of_mem_bad3 : ∀ x ∈ bad3, x.val≠1 ∧ x.val≠112 := by decide +kernel

/-- The difference mask of the start `{0,2}`. -/
def m0 : ℕ := 2^1 ||| 2^112 ||| 2^2 ||| 2^111

theorem m0_bits (e : ℕ) (h : m0.testBit e=true) : Dl [2,0] e ∨ e=1 ∨ e=112 := by
  unfold m0 at h
  rcases (testBit_or_pow _ _ _).mp h with h|h
  · rcases (testBit_or_pow _ _ _).mp h with h|h
    · rcases (testBit_or_pow _ _ _).mp h with h|h
      · rw [Nat.testBit_two_pow] at h
        right; left; simp at h; omega
      · right; right; exact h.symm
    · left; exact ⟨2,by simp,0,by simp,by decide,by rw [← h]; rfl⟩
  · left; exact ⟨0,by simp,2,by simp,by decide,by rw [← h]; rfl⟩

theorem m0_full (e : ℕ) (h : Dl [2,0] e) : m0.testBit e=true := by
  obtain ⟨a,ha,b,hb,hab,rfl⟩ := h
  simp only [List.mem_cons, List.not_mem_nil, or_false] at ha hb
  rcases ha with rfl|rfl <;> rcases hb with rfl|rfl <;> first | exact absurd rfl hab | decide

/-- A normalized ruler makes the cover search succeed. -/
theorem go_of_ruler (D : Finset (ZMod 113)) (hD : RulerZ D) (h11 : D.card=11)
    (h0 : (0 : ZMod 113) ∈ D) (h2 : (2 : ZMod 113) ∈ D) (hdf : ∀ e, e ∈ diffs D ↔ e ∈ bad3) :
    go 9 [2,0] m0=true := by
  let N : Finset ℕ := D.image ZMod.val
  have hN11 : N.card=11 := by
    rw [Finset.card_image_of_injective _ (ZMod.val_injective 113), h11]
  have hN0 : 0 ∈ N := Finset.mem_image.mpr ⟨0,h0,rfl⟩
  have hN2 : 2 ∈ N := Finset.mem_image.mpr ⟨2,h2,rfl⟩
  have hlt : ∀ t ∈ N, t<113 := fun t ht => by
    obtain ⟨x,_,rfl⟩ := Finset.mem_image.mp ht; exact ZMod.val_lt x
  have hmemD : ∀ t ∈ N, (t : ZMod 113) ∈ D := fun t ht => by
    obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp ht; rwa [ZMod.natCast_zmod_val]
  have hcastinj : ∀ a ∈ N, ∀ b ∈ N, a≠b → (a : ZMod 113)≠(b : ZMod 113) := fun a ha b hb hab h' =>
    hab (by
      have := congrArg ZMod.val h'
      rwa [ZMod.val_natCast_of_lt (hlt a ha), ZMod.val_natCast_of_lt (hlt b hb)] at this)
  let T := (N.erase 0).erase 2
  have hT : ∀ z, (z ∈ T ∨ z ∈ [2,0]) ↔ z ∈ N := by
    intro z
    simp only [T, Finset.mem_erase, List.mem_cons, List.not_mem_nil, or_false]
    constructor
    · rintro (⟨_,_,h⟩|rfl|rfl)
      · exact h
      · exact hN2
      · exact hN0
    · intro h
      by_cases h2' : z=2
      · exact Or.inr (Or.inl h2')
      · by_cases h0' : z=0
        · exact Or.inr (Or.inr h0')
        · exact Or.inl ⟨h2',h0',h⟩
  have tgtN : Target (fun z => z ∈ N) := by
    refine ⟨hlt,?_,?_,?_⟩
    · intro a b c e ha hb hc he hab hce h
      rw [dd_val (hlt b hb), dd_val (hlt e he)] at h
      obtain ⟨e1,e2⟩ := hD _ (hmemD a ha) _ (hmemD b hb) _ (hmemD c hc) _ (hmemD e he)
        (hcastinj a ha b hb hab) (ZMod.val_injective 113 h)
      have v1 := congrArg ZMod.val e1
      have v2 := congrArg ZMod.val e2
      rw [ZMod.val_natCast_of_lt (hlt a ha), ZMod.val_natCast_of_lt (hlt c hc)] at v1
      rw [ZMod.val_natCast_of_lt (hlt b hb), ZMod.val_natCast_of_lt (hlt e he)] at v2
      exact ⟨v1,v2⟩
    · intro a b ha hb hab
      rw [dd_val (hlt b hb)]
      apply val_of_mem_bad3
      rw [← hdf]
      exact mem_diffs.mpr ⟨_,hmemD a ha,_,hmemD b hb,hcastinj a ha b hb hab,rfl⟩
    · intro e he1 he2
      have hv : ((e : ℕ) : ZMod 113).val=e := ZMod.val_natCast_of_lt (by omega)
      have hm := (hdf _).mpr (mem_bad3_of_val (e : ZMod 113) (by rw [hv]; omega) (by rw [hv]; omega))
      obtain ⟨x,hx,y,hy,hxy,hxye⟩ := mem_diffs.mp hm
      refine ⟨x.val,y.val,Finset.mem_image_of_mem _ hx,Finset.mem_image_of_mem _ hy,
        fun h' => hxy (ZMod.val_injective 113 h'),?_⟩
      rw [dd_val (ZMod.val_lt y), ZMod.natCast_zmod_val, ZMod.natCast_zmod_val, hxye, hv]
  apply go_complete 9 T [2,0] m0
  · simp only [T]
    rw [Finset.card_erase_of_mem (Finset.mem_erase.mpr ⟨by decide,hN2⟩),
      Finset.card_erase_of_mem hN0, hN11]
  · refine ⟨?_,by decide,tgtN.congr (fun z => (hT z).symm),m0_bits,m0_full⟩
    intro t ht
    simp only [T, Finset.mem_erase] at ht
    simp only [List.mem_cons, List.not_mem_nil, or_false]
    omega

theorem no_ruler_of_cover (hs : go 9 [2,0] m0=false) : NoModularGolombRuler113 := by
  rintro ⟨g,hb,hsum,hov⟩
  obtain ⟨D',hR,h11,h0,h2,hdf⟩ := normalize _ (ruler_of_g g hb hov) (card_of_g g hb hsum)
  have := go_of_ruler D' hR h11 h0 h2 hdf
  rw [hs] at this
  exact Bool.false_ne_true this

end Symconf113.Ruler113

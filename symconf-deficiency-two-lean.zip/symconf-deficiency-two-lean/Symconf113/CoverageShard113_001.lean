import Symconf113.CoverageShard113_000

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0055 : NodeCoverage113 [80,7] 7 26 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0056 : NodeCoverage113 [80,6] 6 27 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0057 : NodeCoverage113 [80,5] 5 28 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0058 : NodeCoverage113 [80,3] 3 30 :=
  demand_node_prune113 80 compact113_demands_080 compact113_demands_080_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0059 : NodeCoverage113 [80] 80 33 :=
  node_fork113 (B := [33,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0031
    (ChildrenCoverage113.cons _ _ compact113_node_0032
    (ChildrenCoverage113.cons _ _ compact113_node_0033
    (ChildrenCoverage113.cons _ _ compact113_node_0034
    (ChildrenCoverage113.cons _ _ compact113_node_0035
    (ChildrenCoverage113.cons _ _ compact113_node_0036
    (ChildrenCoverage113.cons _ _ compact113_node_0037
    (ChildrenCoverage113.cons _ _ compact113_node_0038
    (ChildrenCoverage113.cons _ _ compact113_node_0039
    (ChildrenCoverage113.cons _ _ compact113_node_0040
    (ChildrenCoverage113.cons _ _ compact113_node_0041
    (ChildrenCoverage113.cons _ _ compact113_node_0042
    (ChildrenCoverage113.cons _ _ compact113_node_0043
    (ChildrenCoverage113.cons _ _ compact113_node_0044
    (ChildrenCoverage113.cons _ _ compact113_node_0045
    (ChildrenCoverage113.cons _ _ compact113_node_0046
    (ChildrenCoverage113.cons _ _ compact113_node_0047
    (ChildrenCoverage113.cons _ _ compact113_node_0048
    (ChildrenCoverage113.cons _ _ compact113_node_0049
    (ChildrenCoverage113.cons _ _ compact113_node_0050
    (ChildrenCoverage113.cons _ _ compact113_node_0051
    (ChildrenCoverage113.cons _ _ compact113_node_0052
    (ChildrenCoverage113.cons _ _ compact113_node_0053
    (ChildrenCoverage113.cons _ _ compact113_node_0054
    (ChildrenCoverage113.cons _ _ compact113_node_0055
    (ChildrenCoverage113.cons _ _ compact113_node_0056
    (ChildrenCoverage113.cons _ _ compact113_node_0057
    (ChildrenCoverage113.cons _ _ compact113_node_0058
    ChildrenCoverage113.nil))))))))))))))))))))))))))))

theorem compact113_node_0060 : NodeCoverage113 [79] 79 34 :=
  demand_node_prune113 79 compact113_demands_079 compact113_demands_079_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0061 : NodeCoverage113 [78] 78 35 :=
  demand_node_prune113 78 compact113_demands_078 compact113_demands_078_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0062 : NodeCoverage113 [77,36] 36 0 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0063 : NodeCoverage113 [77,33] 33 3 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0064 : NodeCoverage113 [77,32] 32 4 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0065 : NodeCoverage113 [77,31] 31 5 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0066 : NodeCoverage113 [77,30] 30 6 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0067 : NodeCoverage113 [77,29] 29 7 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0068 : NodeCoverage113 [77,28] 28 8 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0069 : NodeCoverage113 [77,27] 27 9 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0070 : NodeCoverage113 [77,26] 26 10 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0071 : NodeCoverage113 [77,25] 25 11 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0072 : NodeCoverage113 [77,24] 24 12 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0073 : NodeCoverage113 [77,23] 23 13 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0074 : NodeCoverage113 [77,22] 22 14 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0075 : NodeCoverage113 [77,21] 21 15 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0076 : NodeCoverage113 [77,20] 20 16 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0077 : NodeCoverage113 [77,19] 19 17 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0078 : NodeCoverage113 [77,18] 18 18 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0079 : NodeCoverage113 [77,17] 17 19 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0080 : NodeCoverage113 [77,16] 16 20 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0081 : NodeCoverage113 [77,15] 15 21 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0082 : NodeCoverage113 [77,14] 14 22 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0083 : NodeCoverage113 [77,13] 13 23 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0084 : NodeCoverage113 [77,12] 12 24 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0085 : NodeCoverage113 [77,11] 11 25 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0086 : NodeCoverage113 [77,10] 10 26 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_160

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_7116 : NodeCoverage113 [9,6] 6 98 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7117 : NodeCoverage113 [9,5] 5 99 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7118 : NodeCoverage113 [9,3] 3 101 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7119 : NodeCoverage113 [9] 9 104 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7113
    (ChildrenCoverage113.cons _ _ compact113_node_7114
    (ChildrenCoverage113.cons _ _ compact113_node_7115
    (ChildrenCoverage113.cons _ _ compact113_node_7116
    (ChildrenCoverage113.cons _ _ compact113_node_7117
    (ChildrenCoverage113.cons _ _ compact113_node_7118
    ChildrenCoverage113.nil))))))

theorem compact113_node_7120 : NodeCoverage113 [8] 8 105 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7121 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7122 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7123 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,7,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7121
    (ChildrenCoverage113.cons _ _ compact113_node_7122
    ChildrenCoverage113.nil))

theorem compact113_node_7124 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,7,7,7,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7125 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,7,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7126 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,7,7,7,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7127 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,7,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7123
    (ChildrenCoverage113.cons _ _ compact113_node_7124
    (ChildrenCoverage113.cons _ _ compact113_node_7125
    (ChildrenCoverage113.cons _ _ compact113_node_7126
    ChildrenCoverage113.nil))))

theorem compact113_node_7128 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,7,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7129 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,7,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7130 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,7,7,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7131 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,7,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7127
    (ChildrenCoverage113.cons _ _ compact113_node_7128
    (ChildrenCoverage113.cons _ _ compact113_node_7129
    (ChildrenCoverage113.cons _ _ compact113_node_7130
    ChildrenCoverage113.nil))))

theorem compact113_node_7132 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,7,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7133 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,7,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7134 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,7,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7135 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,7] 7 29 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7131
    (ChildrenCoverage113.cons _ _ compact113_node_7132
    (ChildrenCoverage113.cons _ _ compact113_node_7133
    (ChildrenCoverage113.cons _ _ compact113_node_7134
    ChildrenCoverage113.nil))))

theorem compact113_node_7136 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7137 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7138 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_7139 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7138
    ChildrenCoverage113.nil)

theorem compact113_node_7140 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7139
    ChildrenCoverage113.nil)

theorem compact113_node_7141 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7140
    ChildrenCoverage113.nil)

theorem compact113_node_7142 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7141
    ChildrenCoverage113.nil)

theorem compact113_node_7143 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7142
    ChildrenCoverage113.nil)

theorem compact113_node_7144 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3] 3 18 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7143
    ChildrenCoverage113.nil)

theorem compact113_node_7145 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,3,3,3,3,3] 3 21 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7144
    ChildrenCoverage113.nil)

theorem compact113_node_7146 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,3,3,3,3] 3 24 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7145
    ChildrenCoverage113.nil)

theorem compact113_node_7147 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,3,3,3] 3 27 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7146
    ChildrenCoverage113.nil)

theorem compact113_node_7148 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,3,3] 3 30 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7147
    ChildrenCoverage113.nil)

theorem compact113_node_7149 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7,3] 3 33 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7148
    ChildrenCoverage113.nil)

theorem compact113_node_7150 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,7] 7 36 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7135
    (ChildrenCoverage113.cons _ _ compact113_node_7136
    (ChildrenCoverage113.cons _ _ compact113_node_7137
    (ChildrenCoverage113.cons _ _ compact113_node_7149
    ChildrenCoverage113.nil))))

theorem compact113_node_7151 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7152 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,5] 5 38 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7153 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 4 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7154 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3,3] 3 7 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7153
    ChildrenCoverage113.nil)

theorem compact113_node_7155 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3] 3 10 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7154
    ChildrenCoverage113.nil)

theorem compact113_node_7156 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3] 3 13 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7155
    ChildrenCoverage113.nil)

theorem compact113_node_7157 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3] 3 16 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7156
    ChildrenCoverage113.nil)

theorem compact113_node_7158 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3] 3 19 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7157
    ChildrenCoverage113.nil)

theorem compact113_node_7159 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3] 3 22 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7158
    ChildrenCoverage113.nil)

theorem compact113_node_7160 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3] 3 25 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7159
    ChildrenCoverage113.nil)

theorem compact113_node_7161 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,3,3,3,3,3] 3 28 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7160
    ChildrenCoverage113.nil)

theorem compact113_node_7162 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,3,3,3,3] 3 31 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7161
    ChildrenCoverage113.nil)

theorem compact113_node_7163 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,3,3,3] 3 34 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7162
    ChildrenCoverage113.nil)

theorem compact113_node_7164 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,3,3] 3 37 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7163
    ChildrenCoverage113.nil)

theorem compact113_node_7165 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7,3] 3 40 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7164
    ChildrenCoverage113.nil)

theorem compact113_node_7166 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,7] 7 43 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7150
    (ChildrenCoverage113.cons _ _ compact113_node_7151
    (ChildrenCoverage113.cons _ _ compact113_node_7152
    (ChildrenCoverage113.cons _ _ compact113_node_7165
    ChildrenCoverage113.nil))))

theorem compact113_node_7167 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,6] 6 44 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7168 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5,5,5,5,5,5,5,5,5] 5 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_7169 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5,5,5,5,5,5,5,5] 5 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7168
    ChildrenCoverage113.nil)

theorem compact113_node_7170 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5,5,5,5,5,5,5,3] 3 7 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7171 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5,5,5,5,5,5,5] 5 10 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7169
    (ChildrenCoverage113.cons _ _ compact113_node_7170
    ChildrenCoverage113.nil))

theorem compact113_node_7172 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5,5,5,5,5,5,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7173 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5,5,5,5,5,5] 5 15 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7171
    (ChildrenCoverage113.cons _ _ compact113_node_7172
    ChildrenCoverage113.nil))

theorem compact113_node_7174 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5,5,5,5,5,3] 3 17 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7175 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5,5,5,5,5] 5 20 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7173
    (ChildrenCoverage113.cons _ _ compact113_node_7174
    ChildrenCoverage113.nil))

theorem compact113_node_7176 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5,5,5,5,3] 3 22 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7177 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5,5,5,5] 5 25 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7175
    (ChildrenCoverage113.cons _ _ compact113_node_7176
    ChildrenCoverage113.nil))

theorem compact113_node_7178 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5,5,5,3] 3 27 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7179 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5,5,5] 5 30 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7177
    (ChildrenCoverage113.cons _ _ compact113_node_7178
    ChildrenCoverage113.nil))

theorem compact113_node_7180 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5,5,3] 3 32 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7181 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5,5] 5 35 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7179
    (ChildrenCoverage113.cons _ _ compact113_node_7180
    ChildrenCoverage113.nil))

theorem compact113_node_7182 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5,3] 3 37 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7183 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,5] 5 40 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7181
    (ChildrenCoverage113.cons _ _ compact113_node_7182
    ChildrenCoverage113.nil))

theorem compact113_node_7184 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5,3] 3 42 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7185 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,5] 5 45 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7183
    (ChildrenCoverage113.cons _ _ compact113_node_7184
    ChildrenCoverage113.nil))

theorem compact113_node_7186 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7187 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7186
    ChildrenCoverage113.nil)

theorem compact113_node_7188 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7187
    ChildrenCoverage113.nil)

theorem compact113_node_7189 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7188
    ChildrenCoverage113.nil)

theorem compact113_node_7190 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7189
    ChildrenCoverage113.nil)

end Symconf113

import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0363 : NodeCoverage113 [60,42] 42 11 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0364 : NodeCoverage113 [60,41] 41 12 :=
  demand_node_prune113 41 compact113_demands_041 compact113_demands_041_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0365 : NodeCoverage113 [60,40] 40 13 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0366 : NodeCoverage113 [60,39] 39 14 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0367 : NodeCoverage113 [60,38] 38 15 :=
  demand_node_prune113 38 compact113_demands_038 compact113_demands_038_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0368 : NodeCoverage113 [60,37] 37 16 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0369 : NodeCoverage113 [60,36] 36 17 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0370 : NodeCoverage113 [60,35] 35 18 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0371 : NodeCoverage113 [60,34] 34 19 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0372 : NodeCoverage113 [60,33] 33 20 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0373 : NodeCoverage113 [60,32] 32 21 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0374 : NodeCoverage113 [60,31] 31 22 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0375 : NodeCoverage113 [60,30] 30 23 :=
  demand_node_prune113 60 compact113_demands_060 compact113_demands_060_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0376 : NodeCoverage113 [60,29] 29 24 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0377 : NodeCoverage113 [60,28] 28 25 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0378 : NodeCoverage113 [60,27] 27 26 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0379 : NodeCoverage113 [60,26] 26 27 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0380 : NodeCoverage113 [60,25] 25 28 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0381 : NodeCoverage113 [60,24] 24 29 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0382 : NodeCoverage113 [60,23] 23 30 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0383 : NodeCoverage113 [60,22] 22 31 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0384 : NodeCoverage113 [60,21] 21 32 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0385 : NodeCoverage113 [60,20] 20 33 :=
  demand_node_prune113 60 compact113_demands_060 compact113_demands_060_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0386 : NodeCoverage113 [60,19] 19 34 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0387 : NodeCoverage113 [60,18] 18 35 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0388 : NodeCoverage113 [60,17] 17 36 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0389 : NodeCoverage113 [60,16] 16 37 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0390 : NodeCoverage113 [60,15,15,15] 15 8 :=
  demand_node_prune113 60 compact113_demands_060 compact113_demands_060_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0391 : NodeCoverage113 [60,15,15,14] 14 9 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0392 : NodeCoverage113 [60,15,15,13] 13 10 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0393 : NodeCoverage113 [60,15,15,12] 12 11 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0394 : NodeCoverage113 [60,15,15,11] 11 12 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0395 : NodeCoverage113 [60,15,15,10] 10 13 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0396 : NodeCoverage113 [60,15,15,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0397 : NodeCoverage113 [60,15,15,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0398 : NodeCoverage113 [60,15,15,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0399 : NodeCoverage113 [60,15,15,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

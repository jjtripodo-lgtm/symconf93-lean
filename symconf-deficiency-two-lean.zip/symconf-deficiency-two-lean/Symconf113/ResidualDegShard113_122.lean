import Symconf113.ResidualDegDefs113

/-! Kernel check: the degree search below type-`A` rows 122 and 123. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem degShard_122 : ((degTopList.drop 122).take 2).all degTop=true := by decide +kernel
end Symconf113

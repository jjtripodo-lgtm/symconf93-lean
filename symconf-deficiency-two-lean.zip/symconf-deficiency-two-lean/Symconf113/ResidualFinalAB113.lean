import Symconf113.ResidualCanon113
import Symconf113.ResidualFinalPure113
import Mathlib.Algebra.BigOperators.Ring.Finset
namespace Symconf113
open Matrix Symconf59
open scoped BigOperators

theorem rowsOf_get (V : ℕ → ℕ → ℕ) {i : ℕ} (hi : i<7) : ((rowsOf V).getD i (0,[])).2=ofF (V i) := by
  unfold rowsOf; rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_range hi]; rfl

theorem sigsOf_get (S : ℕ → ℕ → List ℕ) {i : ℕ} (hi : i<7) :
    ((sigsOf S).getD i (0,[])).2=(List.range 7).map (S i) := by
  unfold sigsOf; rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_range hi]; rfl

def dsel (V : ℕ → ℕ → ℕ) (S : ℕ → ℕ → List ℕ) (j : ℕ) : ℕ :=
  if V 0 j=2 then distOf (S 0 j) else distOf (S 1 j)

theorem filter_map_sum (q : ℕ → Bool) (f : ℕ → ℕ) :
    ∀ l : List ℕ, ((l.filter q).map f).sum=(l.map fun j => if q j then f j else 0).sum
  | [] => rfl
  | a :: l => by
    rw [List.filter_cons]
    cases h : q a <;> simp [h, filter_map_sum q f l]

theorem range7_sum (g : ℕ → ℕ) : ((List.range 7).map g).sum=∑ j : Fin 7, g j := by
  rw [Fin.sum_univ_eq_sum_range g 7, ← rs7_eq]; rfl

theorem abOK_spec (V : ℕ → ℕ → ℕ) (S : ℕ → ℕ → List ℕ) (h : abOK (rowsOf V) (sigsOf S)=true) :
    (∀ j : Fin 7, V 0 j*V 1 j≠0 → (V 0 j=1 ∧ V 1 j=2) ∨ (V 0 j=2 ∧ V 1 j=1)) ∧
    (∀ j : Fin 7, V 0 j*V 1 j≠0 → dsel V S j ∈ [2,4,5,7]) ∧
    (∑ j : Fin 7, if V 0 j*V 1 j≠0 then (cD (dsel V S j) : ℤ) else 0)%15≠10 := by
  simp only [abOK, rowsOf_get V (by decide : 0<7), rowsOf_get V (by decide : 1<7),
    sigsOf_get S (by decide : 0<7), sigsOf_get S (by decide : 1<7), Bool.and_eq_true,
    List.all_eq_true] at h
  obtain ⟨h1,h2,h3⟩ := h
  have hmem : ∀ j : Fin 7, V 0 j*V 1 j≠0 →
      (j : ℕ) ∈ List.filter (fun j => decide (gd (ofF (V 0)) j*gd (ofF (V 1)) j≠0)) (List.range 7) := by
    intro j hj
    rw [List.mem_filter]
    exact ⟨List.mem_range.mpr j.isLt, by rw [gd_ofF _ j.isLt, gd_ofF _ j.isLt]; simpa using hj⟩
  refine ⟨fun j hj => ?_, fun j hj => ?_, ?_⟩
  · have := h1 j (hmem j hj)
    rw [gd_ofF _ j.isLt, gd_ofF _ j.isLt] at this
    simpa using this
  · have := h2 (dsel V S j) (List.mem_map.mpr ⟨j, hmem j hj, by
      rw [gd_ofF _ j.isLt, getD_map_range _ _ j.isLt, getD_map_range _ _ j.isLt]; rfl⟩)
    simp only [Bool.or_eq_true, decide_eq_true_eq] at this
    simp only [List.mem_cons, List.not_mem_nil, or_false]
    tauto
  · rw [List.map_map, filter_map_sum, range7_sum] at h3
    have e : (∑ j : Fin 7, (fun j => if decide (gd (ofF (V 0)) j*gd (ofF (V 1)) j≠0)=true then
        (cD ∘ fun j => if gd (ofF (V 0)) j=2 then distOf ((List.map (S 0) (List.range 7)).getD j [])
          else distOf ((List.map (S 1) (List.range 7)).getD j [])) j else 0) (j : ℕ))=
        ∑ j : Fin 7, if V 0 j*V 1 j≠0 then cD (dsel V S j) else 0 := by
      apply Finset.sum_congr rfl; intro j _
      simp only [gd_ofF _ j.isLt, getD_map_range _ _ j.isLt, Function.comp, decide_eq_true_eq, dsel]
    rw [e] at h3
    have hc : ((∑ j : Fin 7, if V 0 j*V 1 j≠0 then cD (dsel V S j) else 0 : ℕ) : ℤ)=
        ∑ j : Fin 7, if V 0 j*V 1 j≠0 then (cD (dsel V S j) : ℤ) else 0 := by
      rw [Nat.cast_sum]; apply Finset.sum_congr rfl; intro j _; split_ifs <;> simp
    rw [← hc]
    simp only [decide_eq_true_eq] at h3
    omega

theorem ac_dist (e : ZMod 15 → ℤ) (hb : ∀ u, e u=0 ∨ e u=1) (hs : sigZ e ∈ realList 2) :
    1≤distOf (sigZ e) ∧ distOf (sigZ e)≤7 ∧ acZ e (distOf (sigZ e) : ZMod 15)=1 := by
  obtain ⟨h1,h7,hg⟩ := dist_two _ hs
  refine ⟨h1,h7,?_⟩
  have := gd_sigZ_cast hb (show distOf (sigZ e)-1<7 by omega)
  rw [hg, Nat.sub_add_cancel h1, Nat.cast_one] at this
  exact this.symm

section Final
variable {A : Int113} (R : OrderedCycles (rowLeave A) RP) (C : OrderedCycles (colLeave A) RP)
  (hA : Incidence113 A) (σ τ : Fin 7 ≃ Fin 7)
  (hσ : ∀ i, d3R R C (σ i)=xF i ∧ d5R R C (σ i)=yF i)
  (hτ : ∀ j, d3C R C (τ j)=xF j ∧ d5C R C (τ j)=yF j)
include hA hσ hτ

/-- Rows of types `A` and `B` cannot meet the `abOK` conditions: their
overlaps force a partition of `ZMod 15` whose signed distances sum to `10`. -/
theorem abOK_false (hab : abOK (rowsOf (Vc R C σ τ)) (sigsOf (Sc R C σ τ))=true) : False := by
  obtain ⟨hdeg,hdist,hsum⟩ := abOK_spec _ _ hab
  have hne : σ (toF 0)≠σ (toF 1) := fun h => by
    have := congrArg Fin.val (σ.injective h); simp [toF] at this
  have ht0 := row_types R C hA σ τ hσ hτ (show 0<7 by decide)
  have ht1 := row_types R C hA σ τ hσ hτ (show 1<7 by decide)
  have h30 : d3R R C (σ (toF 0))=1 := by rw [ht0.1]; simp [xF]
  have h31 : d3R R C (σ (toF 1))=1 := by rw [ht1.1]; simp [xF]
  have h51 : d5R R C (σ (toF 1))=0 := by rw [ht1.2]; simp [yF]
  have hz5 := zero_supp (B5 R C (σ (toF 1)) 0) (B5_bin R C hA _ 0) (by unfold d5R at h51; exact h51)
  obtain ⟨c1,hc1⟩ := single_supp (B3 R C (σ (toF 1)) 0) (B3_bin R C hA _ 0)
    (by unfold d3R at h31; exact h31)
  have hper := cyclic_block_binary_gcd_period (B3 R C (σ (toF 0))) (B3_wave R C hA _)
    (B3_bin R C hA _) 3 (by norm_num)
  obtain ⟨r,hr,hg⟩ := class_ind (fun x => B3 R C (σ (toF 0)) x c1) (fun x => B3_bin R C hA _ x c1)
    (fun x => hper x c1) (by rw [B3_colsum R C hA, h30]; norm_num)
  -- orientation of each long block of row cycle `a0`
  have hor : ∀ j : Fin 7, ∃ o : ZMod 15, (o=1 ∨ o=-1) ∧
      ∀ x y, LB R C (σ (toF 0)) (τ j) x y=LB R C (σ (toF 0)) (τ j) 0 (y-o*x) := by
    intro j
    rcases long_shape _ (LB_wave R C hA (σ (toF 0)) (τ j)) (LB_bin R C hA _ _) with h|h
    · exact ⟨1,Or.inl rfl,fun x y => by rw [h, one_mul]⟩
    · exact ⟨-1,Or.inr rfl,fun x y => by rw [h, neg_one_mul, sub_neg_eq_add]⟩
  choose o ho hsh using hor
  -- the overlap identity at every row point `x` of `a0`
  have hx : ∀ x : ZMod 15, (∑ j : Fin 7, ∑ y, eR R C (σ (toF 0)) (τ j) (y-o j*x)*
      eR R C (σ (toF 1)) (τ j) y)+(if x.val%3=r then 1 else 0)=1 := by
    intro x
    have hov := ovR_long_diff R C hA hne x 0
    rw [ovR_split R C hA] at hov
    have hL : (∑ c : Fin 7, ∑ y, A (sL R (σ (toF 0)) x) (sL C c y)*A (sL R (σ (toF 1)) 0) (sL C c y))=
        ∑ j : Fin 7, ∑ y, eR R C (σ (toF 0)) (τ j) (y-o j*x)*eR R C (σ (toF 1)) (τ j) y :=
      (Equiv.sum_comp τ (fun c => ∑ y, A (sL R (σ (toF 0)) x) (sL C c y)*
        A (sL R (σ (toF 1)) 0) (sL C c y))).symm.trans
        (Finset.sum_congr rfl fun j _ => Finset.sum_congr rfl fun y _ =>
          congrArg (· * eR R C (σ (toF 1)) (τ j) y) (hsh j x y))
    have h5 : (∑ z, A (sL R (σ (toF 0)) x) (s5 C z)*A (sL R (σ (toF 1)) 0) (s5 C z))=0 :=
      Finset.sum_eq_zero fun z _ => by
        show B5 R C _ x z*B5 R C _ 0 z=0
        rw [hz5 z, mul_zero]
    have h3 : (∑ z, A (sL R (σ (toF 0)) x) (s3 C z)*A (sL R (σ (toF 1)) 0) (s3 C z))=
        B3 R C (σ (toF 0)) x c1 := by
      rw [Finset.sum_eq_single c1]
      · show B3 R C _ x c1*B3 R C _ 0 c1=_
        rw [hc1, if_pos rfl, mul_one]
      · intro z _ hz
        show B3 R C _ x z*B3 R C _ 0 z=0
        rw [hc1, if_neg hz, mul_zero]
      · intro h; exact absurd (Finset.mem_univ _) h
    have hgx := hg x
    rw [hL, h5, h3, hgx] at hov
    linarith
  -- each long block pair: an indicator of `{p, p+s}` if shared, zero otherwise
  have hPj : ∀ j : Fin 7, ∃ p s : ZMod 15,
      (Vc R C σ τ 0 j*Vc R C σ τ 1 j≠0 →
        s=(dsel (Vc R C σ τ) (Sc R C σ τ) j : ZMod 15) ∨
          s=-(dsel (Vc R C σ τ) (Sc R C σ τ) j : ZMod 15)) ∧
      ∀ x, (∑ y, eR R C (σ (toF 0)) (τ j) (y-o j*x)*eR R C (σ (toF 1)) (τ j) y)=
        if Vc R C σ τ 0 j*Vc R C σ τ 1 j≠0 then
          (if x=p then (1:ℤ) else 0)+(if x=p+s then 1 else 0) else 0 := by
    intro j
    have b0 := side_ebin R C hA (σ (toF 0)) (τ j)
    have b1 := side_ebin R C hA (σ (toF 1)) (τ j)
    have hc0 : (Vc R C σ τ 0 j : ℤ)=∑ y, eR R C (σ (toF 0)) (τ j) y := by
      rw [Vc_cast R C hA σ τ hσ hτ, toF_val]
    have hc1' : (Vc R C σ τ 1 j : ℤ)=∑ y, eR R C (σ (toF 1)) (τ j) y := by
      rw [Vc_cast R C hA σ τ hσ hτ, toF_val]
    have hgood := canon_good R C hA σ τ hσ hτ
    by_cases hs : Vc R C σ τ 0 j*Vc R C σ τ 1 j≠0
    · simp only [if_pos hs]
      rcases hdeg j hs with ⟨hv0,hv1⟩|⟨hv0,hv1⟩
      · have hreal := hgood.real 1 (by decide) j j.isLt
        rw [hv1] at hreal; simp only [Sc, toF_val] at hreal
        have hdeq : dsel (Vc R C σ τ) (Sc R C σ τ) j=distOf (sigZ (eR R C (σ (toF 1)) (τ j))) := by
          simp only [dsel, hv0, Sc, toF_val]; rfl
        rw [hdeq]
        obtain ⟨d1,d7,hac⟩ := ac_dist _ b1 hreal
        rw [hv0] at hc0; rw [hv1] at hc1'
        obtain ⟨p,s,hps,hval⟩ := pair_ov _ _ b0 b1 (ho j) _ d1 d7
          (Or.inl ⟨by exact_mod_cast hc0.symm, by exact_mod_cast hc1'.symm, hac⟩)
        exact ⟨p,s,fun _ => hps,hval⟩
      · have hreal := hgood.real 0 (by decide) j j.isLt
        rw [hv0] at hreal; simp only [Sc, toF_val] at hreal
        have hdeq : dsel (Vc R C σ τ) (Sc R C σ τ) j=distOf (sigZ (eR R C (σ (toF 0)) (τ j))) := by
          simp only [dsel, hv0, Sc, toF_val]; rfl
        rw [hdeq]
        obtain ⟨d1,d7,hac⟩ := ac_dist _ b0 hreal
        rw [hv0] at hc0; rw [hv1] at hc1'
        obtain ⟨p,s,hps,hval⟩ := pair_ov _ _ b0 b1 (ho j) _ d1 d7
          (Or.inr ⟨by exact_mod_cast hc0.symm, by exact_mod_cast hc1'.symm, hac⟩)
        exact ⟨p,s,fun _ => hps,hval⟩
    · refine ⟨0,0,fun h => absurd h hs,fun x => ?_⟩
      rw [if_neg hs]
      rcases Nat.mul_eq_zero.mp (not_not.mp hs) with h|h
      · rw [h] at hc0
        have hz := zero_supp _ b0 (by exact_mod_cast hc0.symm)
        exact Finset.sum_eq_zero fun y _ => by rw [hz, zero_mul]
      · rw [h] at hc1'
        have hz := zero_supp _ b1 (by exact_mod_cast hc1'.symm)
        exact Finset.sum_eq_zero fun y _ => by rw [hz, mul_zero]
  choose p s hsd hval using hPj
  have hpart := partition_mod r hr (fun j : Fin 7 => Vc R C σ τ 0 j*Vc R C σ τ 1 j≠0) p s
    (fun j : Fin 7 => dsel (Vc R C σ τ) (Sc R C σ τ) j) (fun j h => hdist j h) hsd
    (fun w => by
      have h1 := hx w
      rw [Finset.sum_congr rfl fun j _ => hval j w] at h1
      linarith)
  exact hsum hpart

end Final

end Symconf113

import Symconf113.CoverageShard113_110

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4123 : NodeCoverage113 [20,18,3] 3 72 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4124 : NodeCoverage113 [20,18] 18 75 :=
  node_fork113 (B := [18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4109
    (ChildrenCoverage113.cons _ _ compact113_node_4110
    (ChildrenCoverage113.cons _ _ compact113_node_4111
    (ChildrenCoverage113.cons _ _ compact113_node_4112
    (ChildrenCoverage113.cons _ _ compact113_node_4113
    (ChildrenCoverage113.cons _ _ compact113_node_4114
    (ChildrenCoverage113.cons _ _ compact113_node_4115
    (ChildrenCoverage113.cons _ _ compact113_node_4116
    (ChildrenCoverage113.cons _ _ compact113_node_4117
    (ChildrenCoverage113.cons _ _ compact113_node_4118
    (ChildrenCoverage113.cons _ _ compact113_node_4119
    (ChildrenCoverage113.cons _ _ compact113_node_4120
    (ChildrenCoverage113.cons _ _ compact113_node_4121
    (ChildrenCoverage113.cons _ _ compact113_node_4122
    (ChildrenCoverage113.cons _ _ compact113_node_4123
    ChildrenCoverage113.nil)))))))))))))))

theorem compact113_node_4125 : NodeCoverage113 [20,17,17] 17 59 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4126 : NodeCoverage113 [20,17,16] 16 60 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4127 : NodeCoverage113 [20,17,15] 15 61 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4128 : NodeCoverage113 [20,17,14] 14 62 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4129 : NodeCoverage113 [20,17,13] 13 63 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4130 : NodeCoverage113 [20,17,12] 12 64 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4131 : NodeCoverage113 [20,17,11] 11 65 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4132 : NodeCoverage113 [20,17,10] 10 66 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4133 : NodeCoverage113 [20,17,9] 9 67 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4134 : NodeCoverage113 [20,17,8] 8 68 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4135 : NodeCoverage113 [20,17,7] 7 69 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4136 : NodeCoverage113 [20,17,6] 6 70 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4137 : NodeCoverage113 [20,17,5] 5 71 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4138 : NodeCoverage113 [20,17,3] 3 73 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4139 : NodeCoverage113 [20,17] 17 76 :=
  node_fork113 (B := [17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4125
    (ChildrenCoverage113.cons _ _ compact113_node_4126
    (ChildrenCoverage113.cons _ _ compact113_node_4127
    (ChildrenCoverage113.cons _ _ compact113_node_4128
    (ChildrenCoverage113.cons _ _ compact113_node_4129
    (ChildrenCoverage113.cons _ _ compact113_node_4130
    (ChildrenCoverage113.cons _ _ compact113_node_4131
    (ChildrenCoverage113.cons _ _ compact113_node_4132
    (ChildrenCoverage113.cons _ _ compact113_node_4133
    (ChildrenCoverage113.cons _ _ compact113_node_4134
    (ChildrenCoverage113.cons _ _ compact113_node_4135
    (ChildrenCoverage113.cons _ _ compact113_node_4136
    (ChildrenCoverage113.cons _ _ compact113_node_4137
    (ChildrenCoverage113.cons _ _ compact113_node_4138
    ChildrenCoverage113.nil))))))))))))))

theorem compact113_node_4140 : NodeCoverage113 [20,16,16] 16 61 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4141 : NodeCoverage113 [20,16,15] 15 62 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4142 : NodeCoverage113 [20,16,14] 14 63 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4143 : NodeCoverage113 [20,16,13] 13 64 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4144 : NodeCoverage113 [20,16,12] 12 65 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4145 : NodeCoverage113 [20,16,11] 11 66 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4146 : NodeCoverage113 [20,16,10] 10 67 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4147 : NodeCoverage113 [20,16,9] 9 68 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4148 : NodeCoverage113 [20,16,8] 8 69 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4149 : NodeCoverage113 [20,16,7] 7 70 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4150 : NodeCoverage113 [20,16,6] 6 71 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4151 : NodeCoverage113 [20,16,5] 5 72 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4152 : NodeCoverage113 [20,16,3] 3 74 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4153 : NodeCoverage113 [20,16] 16 77 :=
  node_fork113 (B := [16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4140
    (ChildrenCoverage113.cons _ _ compact113_node_4141
    (ChildrenCoverage113.cons _ _ compact113_node_4142
    (ChildrenCoverage113.cons _ _ compact113_node_4143
    (ChildrenCoverage113.cons _ _ compact113_node_4144
    (ChildrenCoverage113.cons _ _ compact113_node_4145
    (ChildrenCoverage113.cons _ _ compact113_node_4146
    (ChildrenCoverage113.cons _ _ compact113_node_4147
    (ChildrenCoverage113.cons _ _ compact113_node_4148
    (ChildrenCoverage113.cons _ _ compact113_node_4149
    (ChildrenCoverage113.cons _ _ compact113_node_4150
    (ChildrenCoverage113.cons _ _ compact113_node_4151
    (ChildrenCoverage113.cons _ _ compact113_node_4152
    ChildrenCoverage113.nil)))))))))))))

theorem compact113_node_4154 : NodeCoverage113 [20,15,15] 15 63 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4155 : NodeCoverage113 [20,15,14] 14 64 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4156 : NodeCoverage113 [20,15,13] 13 65 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4157 : NodeCoverage113 [20,15,12] 12 66 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4158 : NodeCoverage113 [20,15,11] 11 67 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4159 : NodeCoverage113 [20,15,10] 10 68 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

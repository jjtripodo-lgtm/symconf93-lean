import Symconf113.ResidualLeaves113

/-! Kernel check: the signature stage refutes leaves 128 to 143. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem sigShard_128 : ((leaves.drop 128).take 16).all sigStage=true := by decide +kernel
end Symconf113

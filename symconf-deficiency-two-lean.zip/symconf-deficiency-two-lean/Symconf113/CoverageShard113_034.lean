import Symconf113.CoverageShard113_033

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1380 : NodeCoverage113 [39,15] 15 59 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1381 : NodeCoverage113 [39,14] 14 60 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1382 : NodeCoverage113 [39,13] 13 61 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1383 : NodeCoverage113 [39,12] 12 62 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1384 : NodeCoverage113 [39,11] 11 63 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1385 : NodeCoverage113 [39,10] 10 64 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1386 : NodeCoverage113 [39,9] 9 65 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1387 : NodeCoverage113 [39,8] 8 66 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1388 : NodeCoverage113 [39,7] 7 67 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1389 : NodeCoverage113 [39,6] 6 68 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1390 : NodeCoverage113 [39,5] 5 69 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1391 : NodeCoverage113 [39,3] 3 71 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1392 : NodeCoverage113 [39] 39 74 :=
  node_fork113 (B := [39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1356
    (ChildrenCoverage113.cons _ _ compact113_node_1357
    (ChildrenCoverage113.cons _ _ compact113_node_1358
    (ChildrenCoverage113.cons _ _ compact113_node_1359
    (ChildrenCoverage113.cons _ _ compact113_node_1360
    (ChildrenCoverage113.cons _ _ compact113_node_1361
    (ChildrenCoverage113.cons _ _ compact113_node_1362
    (ChildrenCoverage113.cons _ _ compact113_node_1363
    (ChildrenCoverage113.cons _ _ compact113_node_1364
    (ChildrenCoverage113.cons _ _ compact113_node_1365
    (ChildrenCoverage113.cons _ _ compact113_node_1366
    (ChildrenCoverage113.cons _ _ compact113_node_1367
    (ChildrenCoverage113.cons _ _ compact113_node_1368
    (ChildrenCoverage113.cons _ _ compact113_node_1369
    (ChildrenCoverage113.cons _ _ compact113_node_1370
    (ChildrenCoverage113.cons _ _ compact113_node_1371
    (ChildrenCoverage113.cons _ _ compact113_node_1372
    (ChildrenCoverage113.cons _ _ compact113_node_1373
    (ChildrenCoverage113.cons _ _ compact113_node_1374
    (ChildrenCoverage113.cons _ _ compact113_node_1375
    (ChildrenCoverage113.cons _ _ compact113_node_1376
    (ChildrenCoverage113.cons _ _ compact113_node_1377
    (ChildrenCoverage113.cons _ _ compact113_node_1378
    (ChildrenCoverage113.cons _ _ compact113_node_1379
    (ChildrenCoverage113.cons _ _ compact113_node_1380
    (ChildrenCoverage113.cons _ _ compact113_node_1381
    (ChildrenCoverage113.cons _ _ compact113_node_1382
    (ChildrenCoverage113.cons _ _ compact113_node_1383
    (ChildrenCoverage113.cons _ _ compact113_node_1384
    (ChildrenCoverage113.cons _ _ compact113_node_1385
    (ChildrenCoverage113.cons _ _ compact113_node_1386
    (ChildrenCoverage113.cons _ _ compact113_node_1387
    (ChildrenCoverage113.cons _ _ compact113_node_1388
    (ChildrenCoverage113.cons _ _ compact113_node_1389
    (ChildrenCoverage113.cons _ _ compact113_node_1390
    (ChildrenCoverage113.cons _ _ compact113_node_1391
    ChildrenCoverage113.nil))))))))))))))))))))))))))))))))))))

theorem compact113_node_1393 : NodeCoverage113 [38] 38 75 :=
  demand_node_prune113 38 compact113_demands_038 compact113_demands_038_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1394 : NodeCoverage113 [37,37,36] 36 3 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1395 : NodeCoverage113 [37,37,35] 35 4 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1396 : NodeCoverage113 [37,37,34] 34 5 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1397 : NodeCoverage113 [37,37,33] 33 6 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1398 : NodeCoverage113 [37,37,32] 32 7 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1399 : NodeCoverage113 [37,37,31] 31 8 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1400 : NodeCoverage113 [37,37,30] 30 9 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1401 : NodeCoverage113 [37,37,29] 29 10 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1402 : NodeCoverage113 [37,37,28] 28 11 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1403 : NodeCoverage113 [37,37,27] 27 12 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1404 : NodeCoverage113 [37,37,26] 26 13 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1405 : NodeCoverage113 [37,37,25] 25 14 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1406 : NodeCoverage113 [37,37,24] 24 15 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1407 : NodeCoverage113 [37,37,23] 23 16 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1408 : NodeCoverage113 [37,37,22] 22 17 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1409 : NodeCoverage113 [37,37,21] 21 18 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1410 : NodeCoverage113 [37,37,20] 20 19 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1411 : NodeCoverage113 [37,37,19] 19 20 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1412 : NodeCoverage113 [37,37,18] 18 21 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1413 : NodeCoverage113 [37,37,17] 17 22 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1414 : NodeCoverage113 [37,37,16] 16 23 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_118
import Symconf113.CoverageShard113_119
import Symconf113.CoverageShard113_120

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4701 : NodeCoverage113 [18,18,9,9,9,6] 6 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4702 : NodeCoverage113 [18,18,9,9,9,5] 5 45 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4703 : NodeCoverage113 [18,18,9,9,9,3] 3 47 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4704 : NodeCoverage113 [18,18,9,9,9] 9 50 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4698
    (ChildrenCoverage113.cons _ _ compact113_node_4699
    (ChildrenCoverage113.cons _ _ compact113_node_4700
    (ChildrenCoverage113.cons _ _ compact113_node_4701
    (ChildrenCoverage113.cons _ _ compact113_node_4702
    (ChildrenCoverage113.cons _ _ compact113_node_4703
    ChildrenCoverage113.nil))))))

theorem compact113_node_4705 : NodeCoverage113 [18,18,9,9,8] 8 51 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4706 : NodeCoverage113 [18,18,9,9,7] 7 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4707 : NodeCoverage113 [18,18,9,9,6] 6 53 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4708 : NodeCoverage113 [18,18,9,9,5] 5 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4709 : NodeCoverage113 [18,18,9,9,3] 3 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4710 : NodeCoverage113 [18,18,9,9] 9 59 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4704
    (ChildrenCoverage113.cons _ _ compact113_node_4705
    (ChildrenCoverage113.cons _ _ compact113_node_4706
    (ChildrenCoverage113.cons _ _ compact113_node_4707
    (ChildrenCoverage113.cons _ _ compact113_node_4708
    (ChildrenCoverage113.cons _ _ compact113_node_4709
    ChildrenCoverage113.nil))))))

theorem compact113_node_4711 : NodeCoverage113 [18,18,9,8] 8 60 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4712 : NodeCoverage113 [18,18,9,7] 7 61 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4713 : NodeCoverage113 [18,18,9,6] 6 62 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4714 : NodeCoverage113 [18,18,9,5] 5 63 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4715 : NodeCoverage113 [18,18,9,3] 3 65 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4716 : NodeCoverage113 [18,18,9] 9 68 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4710
    (ChildrenCoverage113.cons _ _ compact113_node_4711
    (ChildrenCoverage113.cons _ _ compact113_node_4712
    (ChildrenCoverage113.cons _ _ compact113_node_4713
    (ChildrenCoverage113.cons _ _ compact113_node_4714
    (ChildrenCoverage113.cons _ _ compact113_node_4715
    ChildrenCoverage113.nil))))))

theorem compact113_node_4717 : NodeCoverage113 [18,18,8] 8 69 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4718 : NodeCoverage113 [18,18,7] 7 70 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4719 : NodeCoverage113 [18,18,6] 6 71 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4720 : NodeCoverage113 [18,18,5] 5 72 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4721 : NodeCoverage113 [18,18,3] 3 74 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4722 : NodeCoverage113 [18,18] 18 77 :=
  node_fork113 (B := [18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4571
    (ChildrenCoverage113.cons _ _ compact113_node_4572
    (ChildrenCoverage113.cons _ _ compact113_node_4573
    (ChildrenCoverage113.cons _ _ compact113_node_4574
    (ChildrenCoverage113.cons _ _ compact113_node_4586
    (ChildrenCoverage113.cons _ _ compact113_node_4587
    (ChildrenCoverage113.cons _ _ compact113_node_4588
    (ChildrenCoverage113.cons _ _ compact113_node_4605
    (ChildrenCoverage113.cons _ _ compact113_node_4620
    (ChildrenCoverage113.cons _ _ compact113_node_4716
    (ChildrenCoverage113.cons _ _ compact113_node_4717
    (ChildrenCoverage113.cons _ _ compact113_node_4718
    (ChildrenCoverage113.cons _ _ compact113_node_4719
    (ChildrenCoverage113.cons _ _ compact113_node_4720
    (ChildrenCoverage113.cons _ _ compact113_node_4721
    ChildrenCoverage113.nil)))))))))))))))

theorem compact113_node_4723 : NodeCoverage113 [18,17,17] 17 61 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4724 : NodeCoverage113 [18,17,16] 16 62 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4725 : NodeCoverage113 [18,17,15] 15 63 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4726 : NodeCoverage113 [18,17,14] 14 64 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4727 : NodeCoverage113 [18,17,13] 13 65 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4728 : NodeCoverage113 [18,17,12] 12 66 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4729 : NodeCoverage113 [18,17,11] 11 67 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4730 : NodeCoverage113 [18,17,10] 10 68 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4731 : NodeCoverage113 [18,17,9] 9 69 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4732 : NodeCoverage113 [18,17,8] 8 70 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4733 : NodeCoverage113 [18,17,7] 7 71 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4734 : NodeCoverage113 [18,17,6] 6 72 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4735 : NodeCoverage113 [18,17,5] 5 73 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4736 : NodeCoverage113 [18,17,3] 3 75 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4737 : NodeCoverage113 [18,17] 17 78 :=
  node_fork113 (B := [17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4723
    (ChildrenCoverage113.cons _ _ compact113_node_4724
    (ChildrenCoverage113.cons _ _ compact113_node_4725
    (ChildrenCoverage113.cons _ _ compact113_node_4726
    (ChildrenCoverage113.cons _ _ compact113_node_4727
    (ChildrenCoverage113.cons _ _ compact113_node_4728
    (ChildrenCoverage113.cons _ _ compact113_node_4729
    (ChildrenCoverage113.cons _ _ compact113_node_4730
    (ChildrenCoverage113.cons _ _ compact113_node_4731
    (ChildrenCoverage113.cons _ _ compact113_node_4732
    (ChildrenCoverage113.cons _ _ compact113_node_4733
    (ChildrenCoverage113.cons _ _ compact113_node_4734
    (ChildrenCoverage113.cons _ _ compact113_node_4735
    (ChildrenCoverage113.cons _ _ compact113_node_4736
    ChildrenCoverage113.nil))))))))))))))

end Symconf113

import Symconf113.CoverageShard113_161

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_7191 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7190
    ChildrenCoverage113.nil)

theorem compact113_node_7192 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7191
    ChildrenCoverage113.nil)

theorem compact113_node_7193 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7192
    ChildrenCoverage113.nil)

theorem compact113_node_7194 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7193
    ChildrenCoverage113.nil)

theorem compact113_node_7195 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,3,3,3,3,3,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7194
    ChildrenCoverage113.nil)

theorem compact113_node_7196 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,3,3,3,3,3] 3 35 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7195
    ChildrenCoverage113.nil)

theorem compact113_node_7197 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,3,3,3,3] 3 38 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7196
    ChildrenCoverage113.nil)

theorem compact113_node_7198 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,3,3,3] 3 41 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7197
    ChildrenCoverage113.nil)

theorem compact113_node_7199 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,3,3] 3 44 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7198
    ChildrenCoverage113.nil)

theorem compact113_node_7200 : NodeCoverage113 [7,7,7,7,7,7,7,7,7,3] 3 47 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7199
    ChildrenCoverage113.nil)

theorem compact113_node_7201 : NodeCoverage113 [7,7,7,7,7,7,7,7,7] 7 50 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7166
    (ChildrenCoverage113.cons _ _ compact113_node_7167
    (ChildrenCoverage113.cons _ _ compact113_node_7185
    (ChildrenCoverage113.cons _ _ compact113_node_7200
    ChildrenCoverage113.nil))))

theorem compact113_node_7202 : NodeCoverage113 [7,7,7,7,7,7,7,7,6] 6 51 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7203 : NodeCoverage113 [7,7,7,7,7,7,7,7,5] 5 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7204 : NodeCoverage113 [7,7,7,7,7,7,7,7,3] 3 54 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7205 : NodeCoverage113 [7,7,7,7,7,7,7,7] 7 57 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7201
    (ChildrenCoverage113.cons _ _ compact113_node_7202
    (ChildrenCoverage113.cons _ _ compact113_node_7203
    (ChildrenCoverage113.cons _ _ compact113_node_7204
    ChildrenCoverage113.nil))))

theorem compact113_node_7206 : NodeCoverage113 [7,7,7,7,7,7,7,6] 6 58 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7207 : NodeCoverage113 [7,7,7,7,7,7,7,5] 5 59 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7208 : NodeCoverage113 [7,7,7,7,7,7,7,3] 3 61 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7209 : NodeCoverage113 [7,7,7,7,7,7,7] 7 64 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7205
    (ChildrenCoverage113.cons _ _ compact113_node_7206
    (ChildrenCoverage113.cons _ _ compact113_node_7207
    (ChildrenCoverage113.cons _ _ compact113_node_7208
    ChildrenCoverage113.nil))))

theorem compact113_node_7210 : NodeCoverage113 [7,7,7,7,7,7,6] 6 65 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7211 : NodeCoverage113 [7,7,7,7,7,7,5] 5 66 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7212 : NodeCoverage113 [7,7,7,7,7,7,3] 3 68 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7213 : NodeCoverage113 [7,7,7,7,7,7] 7 71 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7209
    (ChildrenCoverage113.cons _ _ compact113_node_7210
    (ChildrenCoverage113.cons _ _ compact113_node_7211
    (ChildrenCoverage113.cons _ _ compact113_node_7212
    ChildrenCoverage113.nil))))

theorem compact113_node_7214 : NodeCoverage113 [7,7,7,7,7,6] 6 72 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7215 : NodeCoverage113 [7,7,7,7,7,5] 5 73 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7216 : NodeCoverage113 [7,7,7,7,7,3] 3 75 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7217 : NodeCoverage113 [7,7,7,7,7] 7 78 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7213
    (ChildrenCoverage113.cons _ _ compact113_node_7214
    (ChildrenCoverage113.cons _ _ compact113_node_7215
    (ChildrenCoverage113.cons _ _ compact113_node_7216
    ChildrenCoverage113.nil))))

theorem compact113_node_7218 : NodeCoverage113 [7,7,7,7,6] 6 79 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7219 : NodeCoverage113 [7,7,7,7,5] 5 80 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7220 : NodeCoverage113 [7,7,7,7,3] 3 82 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7221 : NodeCoverage113 [7,7,7,7] 7 85 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7217
    (ChildrenCoverage113.cons _ _ compact113_node_7218
    (ChildrenCoverage113.cons _ _ compact113_node_7219
    (ChildrenCoverage113.cons _ _ compact113_node_7220
    ChildrenCoverage113.nil))))

theorem compact113_node_7222 : NodeCoverage113 [7,7,7,6] 6 86 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7223 : NodeCoverage113 [7,7,7,5] 5 87 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7224 : NodeCoverage113 [7,7,7,3] 3 89 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7225 : NodeCoverage113 [7,7,7] 7 92 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7221
    (ChildrenCoverage113.cons _ _ compact113_node_7222
    (ChildrenCoverage113.cons _ _ compact113_node_7223
    (ChildrenCoverage113.cons _ _ compact113_node_7224
    ChildrenCoverage113.nil))))

theorem compact113_node_7226 : NodeCoverage113 [7,7,6] 6 93 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7227 : NodeCoverage113 [7,7,5] 5 94 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7228 : NodeCoverage113 [7,7,3] 3 96 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7229 : NodeCoverage113 [7,7] 7 99 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7225
    (ChildrenCoverage113.cons _ _ compact113_node_7226
    (ChildrenCoverage113.cons _ _ compact113_node_7227
    (ChildrenCoverage113.cons _ _ compact113_node_7228
    ChildrenCoverage113.nil))))

theorem compact113_node_7230 : NodeCoverage113 [7,6] 6 100 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7231 : NodeCoverage113 [7,5] 5 101 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7232 : NodeCoverage113 [7,3] 3 103 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7233 : NodeCoverage113 [7] 7 106 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7229
    (ChildrenCoverage113.cons _ _ compact113_node_7230
    (ChildrenCoverage113.cons _ _ compact113_node_7231
    (ChildrenCoverage113.cons _ _ compact113_node_7232
    ChildrenCoverage113.nil))))

theorem compact113_node_7234 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7235 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7234
    ChildrenCoverage113.nil)

theorem compact113_node_7236 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7237 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7238 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7237
    ChildrenCoverage113.nil)

theorem compact113_node_7239 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7235
    (ChildrenCoverage113.cons _ _ compact113_node_7236
    (ChildrenCoverage113.cons _ _ compact113_node_7238
    ChildrenCoverage113.nil)))

theorem compact113_node_7240 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7241 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7242 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7241
    ChildrenCoverage113.nil)

theorem compact113_node_7243 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7242
    ChildrenCoverage113.nil)

theorem compact113_node_7244 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7243
    ChildrenCoverage113.nil)

theorem compact113_node_7245 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7239
    (ChildrenCoverage113.cons _ _ compact113_node_7240
    (ChildrenCoverage113.cons _ _ compact113_node_7244
    ChildrenCoverage113.nil)))

theorem compact113_node_7246 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7247 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7248 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7247
    ChildrenCoverage113.nil)

theorem compact113_node_7249 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7248
    ChildrenCoverage113.nil)

theorem compact113_node_7250 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7249
    ChildrenCoverage113.nil)

theorem compact113_node_7251 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7250
    ChildrenCoverage113.nil)

theorem compact113_node_7252 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7251
    ChildrenCoverage113.nil)

theorem compact113_node_7253 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6] 6 23 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7245
    (ChildrenCoverage113.cons _ _ compact113_node_7246
    (ChildrenCoverage113.cons _ _ compact113_node_7252
    ChildrenCoverage113.nil)))

theorem compact113_node_7254 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7255 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7256 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7255
    ChildrenCoverage113.nil)

theorem compact113_node_7257 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7256
    ChildrenCoverage113.nil)

theorem compact113_node_7258 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7257
    ChildrenCoverage113.nil)

theorem compact113_node_7259 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7258
    ChildrenCoverage113.nil)

theorem compact113_node_7260 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7259
    ChildrenCoverage113.nil)

theorem compact113_node_7261 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7260
    ChildrenCoverage113.nil)

theorem compact113_node_7262 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7261
    ChildrenCoverage113.nil)

theorem compact113_node_7263 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,6] 6 29 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7253
    (ChildrenCoverage113.cons _ _ compact113_node_7254
    (ChildrenCoverage113.cons _ _ compact113_node_7262
    ChildrenCoverage113.nil)))

theorem compact113_node_7264 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7265 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

end Symconf113

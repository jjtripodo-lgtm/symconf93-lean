import Symconf113.CoverageShard113_056
import Symconf113.CoverageShard113_059
import Symconf113.CoverageShard113_060
import Symconf113.CoverageShard113_062

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2403 : NodeCoverage113 [30,30,3] 3 50 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2404 : NodeCoverage113 [30,30] 30 53 :=
  node_fork113 (B := [30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2277
    (ChildrenCoverage113.cons _ _ compact113_node_2278
    (ChildrenCoverage113.cons _ _ compact113_node_2279
    (ChildrenCoverage113.cons _ _ compact113_node_2280
    (ChildrenCoverage113.cons _ _ compact113_node_2281
    (ChildrenCoverage113.cons _ _ compact113_node_2282
    (ChildrenCoverage113.cons _ _ compact113_node_2283
    (ChildrenCoverage113.cons _ _ compact113_node_2284
    (ChildrenCoverage113.cons _ _ compact113_node_2285
    (ChildrenCoverage113.cons _ _ compact113_node_2286
    (ChildrenCoverage113.cons _ _ compact113_node_2287
    (ChildrenCoverage113.cons _ _ compact113_node_2288
    (ChildrenCoverage113.cons _ _ compact113_node_2289
    (ChildrenCoverage113.cons _ _ compact113_node_2290
    (ChildrenCoverage113.cons _ _ compact113_node_2291
    (ChildrenCoverage113.cons _ _ compact113_node_2361
    (ChildrenCoverage113.cons _ _ compact113_node_2362
    (ChildrenCoverage113.cons _ _ compact113_node_2363
    (ChildrenCoverage113.cons _ _ compact113_node_2364
    (ChildrenCoverage113.cons _ _ compact113_node_2365
    (ChildrenCoverage113.cons _ _ compact113_node_2397
    (ChildrenCoverage113.cons _ _ compact113_node_2398
    (ChildrenCoverage113.cons _ _ compact113_node_2399
    (ChildrenCoverage113.cons _ _ compact113_node_2400
    (ChildrenCoverage113.cons _ _ compact113_node_2401
    (ChildrenCoverage113.cons _ _ compact113_node_2402
    (ChildrenCoverage113.cons _ _ compact113_node_2403
    ChildrenCoverage113.nil)))))))))))))))))))))))))))

theorem compact113_node_2405 : NodeCoverage113 [30,29] 29 54 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2406 : NodeCoverage113 [30,28] 28 55 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2407 : NodeCoverage113 [30,27] 27 56 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2408 : NodeCoverage113 [30,26] 26 57 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2409 : NodeCoverage113 [30,25] 25 58 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2410 : NodeCoverage113 [30,24] 24 59 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2411 : NodeCoverage113 [30,23] 23 60 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2412 : NodeCoverage113 [30,22] 22 61 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2413 : NodeCoverage113 [30,21] 21 62 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2414 : NodeCoverage113 [30,20] 20 63 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2415 : NodeCoverage113 [30,19] 19 64 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2416 : NodeCoverage113 [30,18] 18 65 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2417 : NodeCoverage113 [30,17] 17 66 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2418 : NodeCoverage113 [30,16] 16 67 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2419 : NodeCoverage113 [30,15,15,15,15,15] 15 8 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2420 : NodeCoverage113 [30,15,15,15,15,14] 14 9 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2421 : NodeCoverage113 [30,15,15,15,15,13] 13 10 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2422 : NodeCoverage113 [30,15,15,15,15,12] 12 11 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2423 : NodeCoverage113 [30,15,15,15,15,11] 11 12 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_053

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2196 : NodeCoverage113 [32,18] 18 63 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2197 : NodeCoverage113 [32,17] 17 64 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2198 : NodeCoverage113 [32,16,16,16] 16 33 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2199 : NodeCoverage113 [32,16,16,15] 15 34 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2200 : NodeCoverage113 [32,16,16,14] 14 35 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2201 : NodeCoverage113 [32,16,16,13] 13 36 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2202 : NodeCoverage113 [32,16,16,12] 12 37 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2203 : NodeCoverage113 [32,16,16,11] 11 38 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2204 : NodeCoverage113 [32,16,16,10] 10 39 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2205 : NodeCoverage113 [32,16,16,9] 9 40 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2206 : NodeCoverage113 [32,16,16,8] 8 41 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2207 : NodeCoverage113 [32,16,16,7] 7 42 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2208 : NodeCoverage113 [32,16,16,6] 6 43 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2209 : NodeCoverage113 [32,16,16,5] 5 44 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2210 : NodeCoverage113 [32,16,16,3] 3 46 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2211 : NodeCoverage113 [32,16,16] 16 49 :=
  node_fork113 (B := [16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2198
    (ChildrenCoverage113.cons _ _ compact113_node_2199
    (ChildrenCoverage113.cons _ _ compact113_node_2200
    (ChildrenCoverage113.cons _ _ compact113_node_2201
    (ChildrenCoverage113.cons _ _ compact113_node_2202
    (ChildrenCoverage113.cons _ _ compact113_node_2203
    (ChildrenCoverage113.cons _ _ compact113_node_2204
    (ChildrenCoverage113.cons _ _ compact113_node_2205
    (ChildrenCoverage113.cons _ _ compact113_node_2206
    (ChildrenCoverage113.cons _ _ compact113_node_2207
    (ChildrenCoverage113.cons _ _ compact113_node_2208
    (ChildrenCoverage113.cons _ _ compact113_node_2209
    (ChildrenCoverage113.cons _ _ compact113_node_2210
    ChildrenCoverage113.nil)))))))))))))

theorem compact113_node_2212 : NodeCoverage113 [32,16,15] 15 50 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2213 : NodeCoverage113 [32,16,14] 14 51 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2214 : NodeCoverage113 [32,16,13] 13 52 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2215 : NodeCoverage113 [32,16,12] 12 53 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2216 : NodeCoverage113 [32,16,11] 11 54 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2217 : NodeCoverage113 [32,16,10] 10 55 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2218 : NodeCoverage113 [32,16,9] 9 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2219 : NodeCoverage113 [32,16,8] 8 57 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2220 : NodeCoverage113 [32,16,7] 7 58 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2221 : NodeCoverage113 [32,16,6] 6 59 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2222 : NodeCoverage113 [32,16,5] 5 60 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2223 : NodeCoverage113 [32,16,3] 3 62 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2224 : NodeCoverage113 [32,16] 16 65 :=
  node_fork113 (B := [16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2211
    (ChildrenCoverage113.cons _ _ compact113_node_2212
    (ChildrenCoverage113.cons _ _ compact113_node_2213
    (ChildrenCoverage113.cons _ _ compact113_node_2214
    (ChildrenCoverage113.cons _ _ compact113_node_2215
    (ChildrenCoverage113.cons _ _ compact113_node_2216
    (ChildrenCoverage113.cons _ _ compact113_node_2217
    (ChildrenCoverage113.cons _ _ compact113_node_2218
    (ChildrenCoverage113.cons _ _ compact113_node_2219
    (ChildrenCoverage113.cons _ _ compact113_node_2220
    (ChildrenCoverage113.cons _ _ compact113_node_2221
    (ChildrenCoverage113.cons _ _ compact113_node_2222
    (ChildrenCoverage113.cons _ _ compact113_node_2223
    ChildrenCoverage113.nil)))))))))))))

theorem compact113_node_2225 : NodeCoverage113 [32,15] 15 66 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2226 : NodeCoverage113 [32,14] 14 67 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2227 : NodeCoverage113 [32,13] 13 68 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2228 : NodeCoverage113 [32,12] 12 69 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2229 : NodeCoverage113 [32,11] 11 70 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2230 : NodeCoverage113 [32,10] 10 71 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2231 : NodeCoverage113 [32,9,9] 9 63 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2232 : NodeCoverage113 [32,9,8] 8 64 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2233 : NodeCoverage113 [32,9,7] 7 65 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2234 : NodeCoverage113 [32,9,6] 6 66 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2235 : NodeCoverage113 [32,9,5] 5 67 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2236 : NodeCoverage113 [32,9,3] 3 69 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2237 : NodeCoverage113 [32,9] 9 72 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2231
    (ChildrenCoverage113.cons _ _ compact113_node_2232
    (ChildrenCoverage113.cons _ _ compact113_node_2233
    (ChildrenCoverage113.cons _ _ compact113_node_2234
    (ChildrenCoverage113.cons _ _ compact113_node_2235
    (ChildrenCoverage113.cons _ _ compact113_node_2236
    ChildrenCoverage113.nil))))))

theorem compact113_node_2238 : NodeCoverage113 [32,8] 8 73 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2239 : NodeCoverage113 [32,7] 7 74 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2240 : NodeCoverage113 [32,6] 6 75 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2241 : NodeCoverage113 [32,5] 5 76 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2242 : NodeCoverage113 [32,3] 3 78 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2243 : NodeCoverage113 [32] 32 81 :=
  node_fork113 (B := [32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2182
    (ChildrenCoverage113.cons _ _ compact113_node_2183
    (ChildrenCoverage113.cons _ _ compact113_node_2184
    (ChildrenCoverage113.cons _ _ compact113_node_2185
    (ChildrenCoverage113.cons _ _ compact113_node_2186
    (ChildrenCoverage113.cons _ _ compact113_node_2187
    (ChildrenCoverage113.cons _ _ compact113_node_2188
    (ChildrenCoverage113.cons _ _ compact113_node_2189
    (ChildrenCoverage113.cons _ _ compact113_node_2190
    (ChildrenCoverage113.cons _ _ compact113_node_2191
    (ChildrenCoverage113.cons _ _ compact113_node_2192
    (ChildrenCoverage113.cons _ _ compact113_node_2193
    (ChildrenCoverage113.cons _ _ compact113_node_2194
    (ChildrenCoverage113.cons _ _ compact113_node_2195
    (ChildrenCoverage113.cons _ _ compact113_node_2196
    (ChildrenCoverage113.cons _ _ compact113_node_2197
    (ChildrenCoverage113.cons _ _ compact113_node_2224
    (ChildrenCoverage113.cons _ _ compact113_node_2225
    (ChildrenCoverage113.cons _ _ compact113_node_2226
    (ChildrenCoverage113.cons _ _ compact113_node_2227
    (ChildrenCoverage113.cons _ _ compact113_node_2228
    (ChildrenCoverage113.cons _ _ compact113_node_2229
    (ChildrenCoverage113.cons _ _ compact113_node_2230
    (ChildrenCoverage113.cons _ _ compact113_node_2237
    (ChildrenCoverage113.cons _ _ compact113_node_2238
    (ChildrenCoverage113.cons _ _ compact113_node_2239
    (ChildrenCoverage113.cons _ _ compact113_node_2240
    (ChildrenCoverage113.cons _ _ compact113_node_2241
    (ChildrenCoverage113.cons _ _ compact113_node_2242
    ChildrenCoverage113.nil)))))))))))))))))))))))))))))

theorem compact113_node_2244 : NodeCoverage113 [31] 31 82 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2245 : NodeCoverage113 [30,30,30,23] 23 0 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2246 : NodeCoverage113 [30,30,30,20] 20 3 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2247 : NodeCoverage113 [30,30,30,19] 19 4 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2248 : NodeCoverage113 [30,30,30,18] 18 5 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

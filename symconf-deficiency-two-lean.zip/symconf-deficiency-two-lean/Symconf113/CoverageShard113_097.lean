import Symconf113.CoverageShard113_088
import Symconf113.CoverageShard113_089
import Symconf113.CoverageShard113_090
import Symconf113.CoverageShard113_091
import Symconf113.CoverageShard113_092
import Symconf113.CoverageShard113_096

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3403 : NodeCoverage113 [24,9,7] 7 73 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3404 : NodeCoverage113 [24,9,6] 6 74 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3405 : NodeCoverage113 [24,9,5] 5 75 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3406 : NodeCoverage113 [24,9,3] 3 77 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3407 : NodeCoverage113 [24,9] 9 80 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3401
    (ChildrenCoverage113.cons _ _ compact113_node_3402
    (ChildrenCoverage113.cons _ _ compact113_node_3403
    (ChildrenCoverage113.cons _ _ compact113_node_3404
    (ChildrenCoverage113.cons _ _ compact113_node_3405
    (ChildrenCoverage113.cons _ _ compact113_node_3406
    ChildrenCoverage113.nil))))))

theorem compact113_node_3408 : NodeCoverage113 [24,8] 8 81 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3409 : NodeCoverage113 [24,7] 7 82 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3410 : NodeCoverage113 [24,6] 6 83 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3411 : NodeCoverage113 [24,5] 5 84 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3412 : NodeCoverage113 [24,3] 3 86 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3413 : NodeCoverage113 [24] 24 89 :=
  node_fork113 (B := [24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3171
    (ChildrenCoverage113.cons _ _ compact113_node_3172
    (ChildrenCoverage113.cons _ _ compact113_node_3173
    (ChildrenCoverage113.cons _ _ compact113_node_3174
    (ChildrenCoverage113.cons _ _ compact113_node_3175
    (ChildrenCoverage113.cons _ _ compact113_node_3176
    (ChildrenCoverage113.cons _ _ compact113_node_3192
    (ChildrenCoverage113.cons _ _ compact113_node_3207
    (ChildrenCoverage113.cons _ _ compact113_node_3221
    (ChildrenCoverage113.cons _ _ compact113_node_3234
    (ChildrenCoverage113.cons _ _ compact113_node_3255
    (ChildrenCoverage113.cons _ _ compact113_node_3266
    (ChildrenCoverage113.cons _ _ compact113_node_3377
    (ChildrenCoverage113.cons _ _ compact113_node_3386
    (ChildrenCoverage113.cons _ _ compact113_node_3394
    (ChildrenCoverage113.cons _ _ compact113_node_3407
    (ChildrenCoverage113.cons _ _ compact113_node_3408
    (ChildrenCoverage113.cons _ _ compact113_node_3409
    (ChildrenCoverage113.cons _ _ compact113_node_3410
    (ChildrenCoverage113.cons _ _ compact113_node_3411
    (ChildrenCoverage113.cons _ _ compact113_node_3412
    ChildrenCoverage113.nil)))))))))))))))))))))

theorem compact113_node_3414 : NodeCoverage113 [23,23,23,23,21] 21 0 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3415 : NodeCoverage113 [23,23,23,23,18] 18 3 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3416 : NodeCoverage113 [23,23,23,23,17] 17 4 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3417 : NodeCoverage113 [23,23,23,23,16] 16 5 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3418 : NodeCoverage113 [23,23,23,23,15] 15 6 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3419 : NodeCoverage113 [23,23,23,23,14] 14 7 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3420 : NodeCoverage113 [23,23,23,23,13] 13 8 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

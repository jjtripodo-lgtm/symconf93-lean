import Symconf113.CoverageShard113_140
import Symconf113.CoverageShard113_141
import Symconf113.CoverageShard113_142
import Symconf113.CoverageShard113_143

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5929 : NodeCoverage113 [14,7,7,7,7,7,5] 5 59 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5930 : NodeCoverage113 [14,7,7,7,7,7,3] 3 61 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5931 : NodeCoverage113 [14,7,7,7,7,7] 7 64 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5927
    (ChildrenCoverage113.cons _ _ compact113_node_5928
    (ChildrenCoverage113.cons _ _ compact113_node_5929
    (ChildrenCoverage113.cons _ _ compact113_node_5930
    ChildrenCoverage113.nil))))

theorem compact113_node_5932 : NodeCoverage113 [14,7,7,7,7,6] 6 65 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5933 : NodeCoverage113 [14,7,7,7,7,5] 5 66 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5934 : NodeCoverage113 [14,7,7,7,7,3] 3 68 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5935 : NodeCoverage113 [14,7,7,7,7] 7 71 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5931
    (ChildrenCoverage113.cons _ _ compact113_node_5932
    (ChildrenCoverage113.cons _ _ compact113_node_5933
    (ChildrenCoverage113.cons _ _ compact113_node_5934
    ChildrenCoverage113.nil))))

theorem compact113_node_5936 : NodeCoverage113 [14,7,7,7,6] 6 72 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5937 : NodeCoverage113 [14,7,7,7,5] 5 73 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5938 : NodeCoverage113 [14,7,7,7,3] 3 75 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5939 : NodeCoverage113 [14,7,7,7] 7 78 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5935
    (ChildrenCoverage113.cons _ _ compact113_node_5936
    (ChildrenCoverage113.cons _ _ compact113_node_5937
    (ChildrenCoverage113.cons _ _ compact113_node_5938
    ChildrenCoverage113.nil))))

theorem compact113_node_5940 : NodeCoverage113 [14,7,7,6] 6 79 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5941 : NodeCoverage113 [14,7,7,5] 5 80 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5942 : NodeCoverage113 [14,7,7,3] 3 82 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5943 : NodeCoverage113 [14,7,7] 7 85 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5939
    (ChildrenCoverage113.cons _ _ compact113_node_5940
    (ChildrenCoverage113.cons _ _ compact113_node_5941
    (ChildrenCoverage113.cons _ _ compact113_node_5942
    ChildrenCoverage113.nil))))

theorem compact113_node_5944 : NodeCoverage113 [14,7,6] 6 86 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5945 : NodeCoverage113 [14,7,5] 5 87 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5946 : NodeCoverage113 [14,7,3] 3 89 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5947 : NodeCoverage113 [14,7] 7 92 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5943
    (ChildrenCoverage113.cons _ _ compact113_node_5944
    (ChildrenCoverage113.cons _ _ compact113_node_5945
    (ChildrenCoverage113.cons _ _ compact113_node_5946
    ChildrenCoverage113.nil))))

theorem compact113_node_5948 : NodeCoverage113 [14,6] 6 93 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5949 : NodeCoverage113 [14,5] 5 94 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5950 : NodeCoverage113 [14,3] 3 96 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5951 : NodeCoverage113 [14] 14 99 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5726
    (ChildrenCoverage113.cons _ _ compact113_node_5747
    (ChildrenCoverage113.cons _ _ compact113_node_5812
    (ChildrenCoverage113.cons _ _ compact113_node_5837
    (ChildrenCoverage113.cons _ _ compact113_node_5859
    (ChildrenCoverage113.cons _ _ compact113_node_5884
    (ChildrenCoverage113.cons _ _ compact113_node_5885
    (ChildrenCoverage113.cons _ _ compact113_node_5947
    (ChildrenCoverage113.cons _ _ compact113_node_5948
    (ChildrenCoverage113.cons _ _ compact113_node_5949
    (ChildrenCoverage113.cons _ _ compact113_node_5950
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_5952 : NodeCoverage113 [13,13,13,13,13,13,13,13,9] 9 0 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5953 : NodeCoverage113 [13,13,13,13,13,13,13,13,6] 6 3 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5954 : NodeCoverage113 [13,13,13,13,13,13,13,13,5] 5 4 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5955 : NodeCoverage113 [13,13,13,13,13,13,13,13,3] 3 6 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5956 : NodeCoverage113 [13,13,13,13,13,13,13,13] 13 9 :=
  node_fork113 (B := [9,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5952
    (ChildrenCoverage113.cons _ _ compact113_node_5953
    (ChildrenCoverage113.cons _ _ compact113_node_5954
    (ChildrenCoverage113.cons _ _ compact113_node_5955
    ChildrenCoverage113.nil))))

theorem compact113_node_5957 : NodeCoverage113 [13,13,13,13,13,13,13,12] 12 10 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5958 : NodeCoverage113 [13,13,13,13,13,13,13,11] 11 11 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5959 : NodeCoverage113 [13,13,13,13,13,13,13,10] 10 12 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5960 : NodeCoverage113 [13,13,13,13,13,13,13,9] 9 13 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5961 : NodeCoverage113 [13,13,13,13,13,13,13,8] 8 14 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5962 : NodeCoverage113 [13,13,13,13,13,13,13,7] 7 15 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5963 : NodeCoverage113 [13,13,13,13,13,13,13,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5964 : NodeCoverage113 [13,13,13,13,13,13,13,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5965 : NodeCoverage113 [13,13,13,13,13,13,13,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5966 : NodeCoverage113 [13,13,13,13,13,13,13] 13 22 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5956
    (ChildrenCoverage113.cons _ _ compact113_node_5957
    (ChildrenCoverage113.cons _ _ compact113_node_5958
    (ChildrenCoverage113.cons _ _ compact113_node_5959
    (ChildrenCoverage113.cons _ _ compact113_node_5960
    (ChildrenCoverage113.cons _ _ compact113_node_5961
    (ChildrenCoverage113.cons _ _ compact113_node_5962
    (ChildrenCoverage113.cons _ _ compact113_node_5963
    (ChildrenCoverage113.cons _ _ compact113_node_5964
    (ChildrenCoverage113.cons _ _ compact113_node_5965
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_5967 : NodeCoverage113 [13,13,13,13,13,13,12] 12 23 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5968 : NodeCoverage113 [13,13,13,13,13,13,11] 11 24 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5969 : NodeCoverage113 [13,13,13,13,13,13,10] 10 25 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5970 : NodeCoverage113 [13,13,13,13,13,13,9] 9 26 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5971 : NodeCoverage113 [13,13,13,13,13,13,8] 8 27 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5972 : NodeCoverage113 [13,13,13,13,13,13,7] 7 28 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5973 : NodeCoverage113 [13,13,13,13,13,13,6] 6 29 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5974 : NodeCoverage113 [13,13,13,13,13,13,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5975 : NodeCoverage113 [13,13,13,13,13,13,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_5976 : NodeCoverage113 [13,13,13,13,13,13,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5975
    ChildrenCoverage113.nil)

theorem compact113_node_5977 : NodeCoverage113 [13,13,13,13,13,13,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5976
    ChildrenCoverage113.nil)

theorem compact113_node_5978 : NodeCoverage113 [13,13,13,13,13,13,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5977
    ChildrenCoverage113.nil)

theorem compact113_node_5979 : NodeCoverage113 [13,13,13,13,13,13,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5978
    ChildrenCoverage113.nil)

theorem compact113_node_5980 : NodeCoverage113 [13,13,13,13,13,13,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5979
    ChildrenCoverage113.nil)

theorem compact113_node_5981 : NodeCoverage113 [13,13,13,13,13,13,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5980
    ChildrenCoverage113.nil)

theorem compact113_node_5982 : NodeCoverage113 [13,13,13,13,13,13,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5981
    ChildrenCoverage113.nil)

theorem compact113_node_5983 : NodeCoverage113 [13,13,13,13,13,13,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5982
    ChildrenCoverage113.nil)

theorem compact113_node_5984 : NodeCoverage113 [13,13,13,13,13,13,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5983
    ChildrenCoverage113.nil)

theorem compact113_node_5985 : NodeCoverage113 [13,13,13,13,13,13] 13 35 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5966
    (ChildrenCoverage113.cons _ _ compact113_node_5967
    (ChildrenCoverage113.cons _ _ compact113_node_5968
    (ChildrenCoverage113.cons _ _ compact113_node_5969
    (ChildrenCoverage113.cons _ _ compact113_node_5970
    (ChildrenCoverage113.cons _ _ compact113_node_5971
    (ChildrenCoverage113.cons _ _ compact113_node_5972
    (ChildrenCoverage113.cons _ _ compact113_node_5973
    (ChildrenCoverage113.cons _ _ compact113_node_5974
    (ChildrenCoverage113.cons _ _ compact113_node_5984
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_5986 : NodeCoverage113 [13,13,13,13,13,12] 12 36 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5987 : NodeCoverage113 [13,13,13,13,13,11] 11 37 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5988 : NodeCoverage113 [13,13,13,13,13,10] 10 38 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5989 : NodeCoverage113 [13,13,13,13,13,9] 9 39 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5990 : NodeCoverage113 [13,13,13,13,13,8] 8 40 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5991 : NodeCoverage113 [13,13,13,13,13,7] 7 41 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5992 : NodeCoverage113 [13,13,13,13,13,6] 6 42 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5993 : NodeCoverage113 [13,13,13,13,13,5] 5 43 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5994 : NodeCoverage113 [13,13,13,13,13,3] 3 45 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5995 : NodeCoverage113 [13,13,13,13,13] 13 48 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5985
    (ChildrenCoverage113.cons _ _ compact113_node_5986
    (ChildrenCoverage113.cons _ _ compact113_node_5987
    (ChildrenCoverage113.cons _ _ compact113_node_5988
    (ChildrenCoverage113.cons _ _ compact113_node_5989
    (ChildrenCoverage113.cons _ _ compact113_node_5990
    (ChildrenCoverage113.cons _ _ compact113_node_5991
    (ChildrenCoverage113.cons _ _ compact113_node_5992
    (ChildrenCoverage113.cons _ _ compact113_node_5993
    (ChildrenCoverage113.cons _ _ compact113_node_5994
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_5996 : NodeCoverage113 [13,13,13,13,12] 12 49 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5997 : NodeCoverage113 [13,13,13,13,11] 11 50 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5998 : NodeCoverage113 [13,13,13,13,10] 10 51 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5999 : NodeCoverage113 [13,13,13,13,9] 9 52 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6000 : NodeCoverage113 [13,13,13,13,8] 8 53 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_028
import Symconf113.CoverageShard113_029
import Symconf113.CoverageShard113_030
import Symconf113.CoverageShard113_031

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1322 : NodeCoverage113 [40,6] 6 67 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1323 : NodeCoverage113 [40,5] 5 68 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1324 : NodeCoverage113 [40,3] 3 70 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1325 : NodeCoverage113 [40] 40 73 :=
  node_fork113 (B := [40,39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1198
    (ChildrenCoverage113.cons _ _ compact113_node_1199
    (ChildrenCoverage113.cons _ _ compact113_node_1200
    (ChildrenCoverage113.cons _ _ compact113_node_1201
    (ChildrenCoverage113.cons _ _ compact113_node_1202
    (ChildrenCoverage113.cons _ _ compact113_node_1203
    (ChildrenCoverage113.cons _ _ compact113_node_1204
    (ChildrenCoverage113.cons _ _ compact113_node_1205
    (ChildrenCoverage113.cons _ _ compact113_node_1206
    (ChildrenCoverage113.cons _ _ compact113_node_1207
    (ChildrenCoverage113.cons _ _ compact113_node_1208
    (ChildrenCoverage113.cons _ _ compact113_node_1209
    (ChildrenCoverage113.cons _ _ compact113_node_1210
    (ChildrenCoverage113.cons _ _ compact113_node_1211
    (ChildrenCoverage113.cons _ _ compact113_node_1212
    (ChildrenCoverage113.cons _ _ compact113_node_1213
    (ChildrenCoverage113.cons _ _ compact113_node_1214
    (ChildrenCoverage113.cons _ _ compact113_node_1215
    (ChildrenCoverage113.cons _ _ compact113_node_1216
    (ChildrenCoverage113.cons _ _ compact113_node_1217
    (ChildrenCoverage113.cons _ _ compact113_node_1263
    (ChildrenCoverage113.cons _ _ compact113_node_1264
    (ChildrenCoverage113.cons _ _ compact113_node_1265
    (ChildrenCoverage113.cons _ _ compact113_node_1266
    (ChildrenCoverage113.cons _ _ compact113_node_1267
    (ChildrenCoverage113.cons _ _ compact113_node_1268
    (ChildrenCoverage113.cons _ _ compact113_node_1269
    (ChildrenCoverage113.cons _ _ compact113_node_1270
    (ChildrenCoverage113.cons _ _ compact113_node_1271
    (ChildrenCoverage113.cons _ _ compact113_node_1272
    (ChildrenCoverage113.cons _ _ compact113_node_1318
    (ChildrenCoverage113.cons _ _ compact113_node_1319
    (ChildrenCoverage113.cons _ _ compact113_node_1320
    (ChildrenCoverage113.cons _ _ compact113_node_1321
    (ChildrenCoverage113.cons _ _ compact113_node_1322
    (ChildrenCoverage113.cons _ _ compact113_node_1323
    (ChildrenCoverage113.cons _ _ compact113_node_1324
    ChildrenCoverage113.nil)))))))))))))))))))))))))))))))))))))

theorem compact113_node_1326 : NodeCoverage113 [39,39,35] 35 0 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1327 : NodeCoverage113 [39,39,32] 32 3 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1328 : NodeCoverage113 [39,39,31] 31 4 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1329 : NodeCoverage113 [39,39,30] 30 5 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1330 : NodeCoverage113 [39,39,29] 29 6 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1331 : NodeCoverage113 [39,39,28] 28 7 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1332 : NodeCoverage113 [39,39,27] 27 8 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1333 : NodeCoverage113 [39,39,26] 26 9 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1334 : NodeCoverage113 [39,39,25] 25 10 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1335 : NodeCoverage113 [39,39,24] 24 11 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1336 : NodeCoverage113 [39,39,23] 23 12 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1337 : NodeCoverage113 [39,39,22] 22 13 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1338 : NodeCoverage113 [39,39,21] 21 14 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1339 : NodeCoverage113 [39,39,20] 20 15 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1340 : NodeCoverage113 [39,39,19] 19 16 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1341 : NodeCoverage113 [39,39,18] 18 17 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1342 : NodeCoverage113 [39,39,17] 17 18 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1343 : NodeCoverage113 [39,39,16] 16 19 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1344 : NodeCoverage113 [39,39,15] 15 20 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1345 : NodeCoverage113 [39,39,14] 14 21 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1346 : NodeCoverage113 [39,39,13] 13 22 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_011
import Symconf113.CoverageShard113_012

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0574 : NodeCoverage113 [56,3] 3 54 :=
  demand_node_prune113 56 compact113_demands_056 compact113_demands_056_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0575 : NodeCoverage113 [56] 56 57 :=
  node_fork113 (B := [54,53,52,51,50,49,48,47,46,45,44,43,42,41,40,39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0493
    (ChildrenCoverage113.cons _ _ compact113_node_0494
    (ChildrenCoverage113.cons _ _ compact113_node_0495
    (ChildrenCoverage113.cons _ _ compact113_node_0496
    (ChildrenCoverage113.cons _ _ compact113_node_0497
    (ChildrenCoverage113.cons _ _ compact113_node_0498
    (ChildrenCoverage113.cons _ _ compact113_node_0499
    (ChildrenCoverage113.cons _ _ compact113_node_0500
    (ChildrenCoverage113.cons _ _ compact113_node_0501
    (ChildrenCoverage113.cons _ _ compact113_node_0502
    (ChildrenCoverage113.cons _ _ compact113_node_0503
    (ChildrenCoverage113.cons _ _ compact113_node_0504
    (ChildrenCoverage113.cons _ _ compact113_node_0505
    (ChildrenCoverage113.cons _ _ compact113_node_0506
    (ChildrenCoverage113.cons _ _ compact113_node_0507
    (ChildrenCoverage113.cons _ _ compact113_node_0508
    (ChildrenCoverage113.cons _ _ compact113_node_0509
    (ChildrenCoverage113.cons _ _ compact113_node_0510
    (ChildrenCoverage113.cons _ _ compact113_node_0511
    (ChildrenCoverage113.cons _ _ compact113_node_0512
    (ChildrenCoverage113.cons _ _ compact113_node_0513
    (ChildrenCoverage113.cons _ _ compact113_node_0514
    (ChildrenCoverage113.cons _ _ compact113_node_0515
    (ChildrenCoverage113.cons _ _ compact113_node_0516
    (ChildrenCoverage113.cons _ _ compact113_node_0517
    (ChildrenCoverage113.cons _ _ compact113_node_0518
    (ChildrenCoverage113.cons _ _ compact113_node_0519
    (ChildrenCoverage113.cons _ _ compact113_node_0520
    (ChildrenCoverage113.cons _ _ compact113_node_0521
    (ChildrenCoverage113.cons _ _ compact113_node_0522
    (ChildrenCoverage113.cons _ _ compact113_node_0523
    (ChildrenCoverage113.cons _ _ compact113_node_0524
    (ChildrenCoverage113.cons _ _ compact113_node_0525
    (ChildrenCoverage113.cons _ _ compact113_node_0526
    (ChildrenCoverage113.cons _ _ compact113_node_0527
    (ChildrenCoverage113.cons _ _ compact113_node_0528
    (ChildrenCoverage113.cons _ _ compact113_node_0529
    (ChildrenCoverage113.cons _ _ compact113_node_0530
    (ChildrenCoverage113.cons _ _ compact113_node_0531
    (ChildrenCoverage113.cons _ _ compact113_node_0532
    (ChildrenCoverage113.cons _ _ compact113_node_0564
    (ChildrenCoverage113.cons _ _ compact113_node_0565
    (ChildrenCoverage113.cons _ _ compact113_node_0566
    (ChildrenCoverage113.cons _ _ compact113_node_0567
    (ChildrenCoverage113.cons _ _ compact113_node_0568
    (ChildrenCoverage113.cons _ _ compact113_node_0569
    (ChildrenCoverage113.cons _ _ compact113_node_0570
    (ChildrenCoverage113.cons _ _ compact113_node_0571
    (ChildrenCoverage113.cons _ _ compact113_node_0572
    (ChildrenCoverage113.cons _ _ compact113_node_0573
    (ChildrenCoverage113.cons _ _ compact113_node_0574
    ChildrenCoverage113.nil)))))))))))))))))))))))))))))))))))))))))))))))))))

theorem compact113_node_0576 : NodeCoverage113 [55] 55 58 :=
  demand_node_prune113 55 compact113_demands_055 compact113_demands_055_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0577 : NodeCoverage113 [54] 54 59 :=
  demand_node_prune113 54 compact113_demands_054 compact113_demands_054_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0578 : NodeCoverage113 [53,53,7] 7 0 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0579 : NodeCoverage113 [53,53,3] 3 4 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0580 : NodeCoverage113 [53,53] 53 7 :=
  node_fork113 (B := [7,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0578
    (ChildrenCoverage113.cons _ _ compact113_node_0579
    ChildrenCoverage113.nil))

theorem compact113_node_0581 : NodeCoverage113 [53,52] 52 8 :=
  demand_node_prune113 52 compact113_demands_052 compact113_demands_052_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0582 : NodeCoverage113 [53,51] 51 9 :=
  demand_node_prune113 51 compact113_demands_051 compact113_demands_051_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0583 : NodeCoverage113 [53,50] 50 10 :=
  demand_node_prune113 50 compact113_demands_050 compact113_demands_050_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0584 : NodeCoverage113 [53,49] 49 11 :=
  demand_node_prune113 49 compact113_demands_049 compact113_demands_049_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0585 : NodeCoverage113 [53,48] 48 12 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0586 : NodeCoverage113 [53,47] 47 13 :=
  demand_node_prune113 47 compact113_demands_047 compact113_demands_047_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0587 : NodeCoverage113 [53,46] 46 14 :=
  demand_node_prune113 46 compact113_demands_046 compact113_demands_046_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0588 : NodeCoverage113 [53,45] 45 15 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0589 : NodeCoverage113 [53,44] 44 16 :=
  demand_node_prune113 44 compact113_demands_044 compact113_demands_044_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0590 : NodeCoverage113 [53,43] 43 17 :=
  demand_node_prune113 43 compact113_demands_043 compact113_demands_043_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0591 : NodeCoverage113 [53,42] 42 18 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0592 : NodeCoverage113 [53,41] 41 19 :=
  demand_node_prune113 41 compact113_demands_041 compact113_demands_041_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0593 : NodeCoverage113 [53,40] 40 20 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0594 : NodeCoverage113 [53,39] 39 21 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0595 : NodeCoverage113 [53,38] 38 22 :=
  demand_node_prune113 38 compact113_demands_038 compact113_demands_038_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0596 : NodeCoverage113 [53,37] 37 23 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0597 : NodeCoverage113 [53,36] 36 24 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0598 : NodeCoverage113 [53,35] 35 25 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0599 : NodeCoverage113 [53,34] 34 26 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0600 : NodeCoverage113 [53,33] 33 27 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0601 : NodeCoverage113 [53,32] 32 28 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0602 : NodeCoverage113 [53,31] 31 29 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0603 : NodeCoverage113 [53,30] 30 30 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0604 : NodeCoverage113 [53,29] 29 31 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0605 : NodeCoverage113 [53,28] 28 32 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0606 : NodeCoverage113 [53,27] 27 33 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0607 : NodeCoverage113 [53,26] 26 34 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0608 : NodeCoverage113 [53,25] 25 35 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0609 : NodeCoverage113 [53,24] 24 36 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0610 : NodeCoverage113 [53,23] 23 37 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0611 : NodeCoverage113 [53,22] 22 38 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

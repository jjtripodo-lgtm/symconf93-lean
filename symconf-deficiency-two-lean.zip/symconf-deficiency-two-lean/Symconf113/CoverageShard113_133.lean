import Symconf113.CoverageShard113_132

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5306 : NodeCoverage113 [15,15,15,15,15,5,3,3,3,3,3] 3 18 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5305
    ChildrenCoverage113.nil)

theorem compact113_node_5307 : NodeCoverage113 [15,15,15,15,15,5,3,3,3,3] 3 21 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5306
    ChildrenCoverage113.nil)

theorem compact113_node_5308 : NodeCoverage113 [15,15,15,15,15,5,3,3,3] 3 24 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5307
    ChildrenCoverage113.nil)

theorem compact113_node_5309 : NodeCoverage113 [15,15,15,15,15,5,3,3] 3 27 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5308
    ChildrenCoverage113.nil)

theorem compact113_node_5310 : NodeCoverage113 [15,15,15,15,15,5,3] 3 30 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5309
    ChildrenCoverage113.nil)

theorem compact113_node_5311 : NodeCoverage113 [15,15,15,15,15,5] 5 33 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5299
    (ChildrenCoverage113.cons _ _ compact113_node_5310
    ChildrenCoverage113.nil))

theorem compact113_node_5312 : NodeCoverage113 [15,15,15,15,15,3] 3 35 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5313 : NodeCoverage113 [15,15,15,15,15] 15 38 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5259
    (ChildrenCoverage113.cons _ _ compact113_node_5260
    (ChildrenCoverage113.cons _ _ compact113_node_5261
    (ChildrenCoverage113.cons _ _ compact113_node_5262
    (ChildrenCoverage113.cons _ _ compact113_node_5263
    (ChildrenCoverage113.cons _ _ compact113_node_5264
    (ChildrenCoverage113.cons _ _ compact113_node_5265
    (ChildrenCoverage113.cons _ _ compact113_node_5266
    (ChildrenCoverage113.cons _ _ compact113_node_5267
    (ChildrenCoverage113.cons _ _ compact113_node_5268
    (ChildrenCoverage113.cons _ _ compact113_node_5311
    (ChildrenCoverage113.cons _ _ compact113_node_5312
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_5314 : NodeCoverage113 [15,15,15,15,14] 14 39 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5315 : NodeCoverage113 [15,15,15,15,13] 13 40 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5316 : NodeCoverage113 [15,15,15,15,12] 12 41 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5317 : NodeCoverage113 [15,15,15,15,11] 11 42 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5318 : NodeCoverage113 [15,15,15,15,10] 10 43 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5319 : NodeCoverage113 [15,15,15,15,9] 9 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5320 : NodeCoverage113 [15,15,15,15,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5321 : NodeCoverage113 [15,15,15,15,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5322 : NodeCoverage113 [15,15,15,15,6] 6 47 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5323 : NodeCoverage113 [15,15,15,15,5] 5 48 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5324 : NodeCoverage113 [15,15,15,15,3] 3 50 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5325 : NodeCoverage113 [15,15,15,15] 15 53 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5313
    (ChildrenCoverage113.cons _ _ compact113_node_5314
    (ChildrenCoverage113.cons _ _ compact113_node_5315
    (ChildrenCoverage113.cons _ _ compact113_node_5316
    (ChildrenCoverage113.cons _ _ compact113_node_5317
    (ChildrenCoverage113.cons _ _ compact113_node_5318
    (ChildrenCoverage113.cons _ _ compact113_node_5319
    (ChildrenCoverage113.cons _ _ compact113_node_5320
    (ChildrenCoverage113.cons _ _ compact113_node_5321
    (ChildrenCoverage113.cons _ _ compact113_node_5322
    (ChildrenCoverage113.cons _ _ compact113_node_5323
    (ChildrenCoverage113.cons _ _ compact113_node_5324
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_5326 : NodeCoverage113 [15,15,15,14] 14 54 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5327 : NodeCoverage113 [15,15,15,13] 13 55 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5328 : NodeCoverage113 [15,15,15,12] 12 56 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5329 : NodeCoverage113 [15,15,15,11] 11 57 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5330 : NodeCoverage113 [15,15,15,10] 10 58 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5331 : NodeCoverage113 [15,15,15,9] 9 59 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5332 : NodeCoverage113 [15,15,15,8] 8 60 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5333 : NodeCoverage113 [15,15,15,7] 7 61 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5334 : NodeCoverage113 [15,15,15,6] 6 62 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5335 : NodeCoverage113 [15,15,15,5] 5 63 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5336 : NodeCoverage113 [15,15,15,3] 3 65 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5337 : NodeCoverage113 [15,15,15] 15 68 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5325
    (ChildrenCoverage113.cons _ _ compact113_node_5326
    (ChildrenCoverage113.cons _ _ compact113_node_5327
    (ChildrenCoverage113.cons _ _ compact113_node_5328
    (ChildrenCoverage113.cons _ _ compact113_node_5329
    (ChildrenCoverage113.cons _ _ compact113_node_5330
    (ChildrenCoverage113.cons _ _ compact113_node_5331
    (ChildrenCoverage113.cons _ _ compact113_node_5332
    (ChildrenCoverage113.cons _ _ compact113_node_5333
    (ChildrenCoverage113.cons _ _ compact113_node_5334
    (ChildrenCoverage113.cons _ _ compact113_node_5335
    (ChildrenCoverage113.cons _ _ compact113_node_5336
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_5338 : NodeCoverage113 [15,15,14] 14 69 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5339 : NodeCoverage113 [15,15,13] 13 70 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

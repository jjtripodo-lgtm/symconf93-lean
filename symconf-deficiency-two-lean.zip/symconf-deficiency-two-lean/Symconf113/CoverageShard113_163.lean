import Symconf113.CoverageShard113_162

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_7266 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7265
    ChildrenCoverage113.nil)

theorem compact113_node_7267 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7266
    ChildrenCoverage113.nil)

theorem compact113_node_7268 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7267
    ChildrenCoverage113.nil)

theorem compact113_node_7269 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7268
    ChildrenCoverage113.nil)

theorem compact113_node_7270 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7269
    ChildrenCoverage113.nil)

theorem compact113_node_7271 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7270
    ChildrenCoverage113.nil)

theorem compact113_node_7272 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7271
    ChildrenCoverage113.nil)

theorem compact113_node_7273 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7272
    ChildrenCoverage113.nil)

theorem compact113_node_7274 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7273
    ChildrenCoverage113.nil)

theorem compact113_node_7275 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,6] 6 35 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7263
    (ChildrenCoverage113.cons _ _ compact113_node_7264
    (ChildrenCoverage113.cons _ _ compact113_node_7274
    ChildrenCoverage113.nil)))

theorem compact113_node_7276 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7277 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7278 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7277
    ChildrenCoverage113.nil)

theorem compact113_node_7279 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7278
    ChildrenCoverage113.nil)

theorem compact113_node_7280 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7279
    ChildrenCoverage113.nil)

theorem compact113_node_7281 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7280
    ChildrenCoverage113.nil)

theorem compact113_node_7282 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7281
    ChildrenCoverage113.nil)

theorem compact113_node_7283 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7282
    ChildrenCoverage113.nil)

theorem compact113_node_7284 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7283
    ChildrenCoverage113.nil)

theorem compact113_node_7285 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7284
    ChildrenCoverage113.nil)

theorem compact113_node_7286 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,3,3,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7285
    ChildrenCoverage113.nil)

theorem compact113_node_7287 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,3,3] 3 35 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7286
    ChildrenCoverage113.nil)

theorem compact113_node_7288 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6,3] 3 38 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7287
    ChildrenCoverage113.nil)

theorem compact113_node_7289 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,6] 6 41 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7275
    (ChildrenCoverage113.cons _ _ compact113_node_7276
    (ChildrenCoverage113.cons _ _ compact113_node_7288
    ChildrenCoverage113.nil)))

theorem compact113_node_7290 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,5] 5 42 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7291 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7292 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7291
    ChildrenCoverage113.nil)

theorem compact113_node_7293 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7292
    ChildrenCoverage113.nil)

theorem compact113_node_7294 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7293
    ChildrenCoverage113.nil)

theorem compact113_node_7295 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7294
    ChildrenCoverage113.nil)

theorem compact113_node_7296 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7295
    ChildrenCoverage113.nil)

theorem compact113_node_7297 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7296
    ChildrenCoverage113.nil)

theorem compact113_node_7298 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7297
    ChildrenCoverage113.nil)

theorem compact113_node_7299 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7298
    ChildrenCoverage113.nil)

theorem compact113_node_7300 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7299
    ChildrenCoverage113.nil)

theorem compact113_node_7301 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,3,3,3,3] 3 35 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7300
    ChildrenCoverage113.nil)

theorem compact113_node_7302 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,3,3,3] 3 38 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7301
    ChildrenCoverage113.nil)

theorem compact113_node_7303 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,3,3] 3 41 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7302
    ChildrenCoverage113.nil)

theorem compact113_node_7304 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6,3] 3 44 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7303
    ChildrenCoverage113.nil)

theorem compact113_node_7305 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,6] 6 47 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7289
    (ChildrenCoverage113.cons _ _ compact113_node_7290
    (ChildrenCoverage113.cons _ _ compact113_node_7304
    ChildrenCoverage113.nil)))

theorem compact113_node_7306 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_7307 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7306
    ChildrenCoverage113.nil)

theorem compact113_node_7308 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,3] 3 5 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7309 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7307
    (ChildrenCoverage113.cons _ _ compact113_node_7308
    ChildrenCoverage113.nil))

theorem compact113_node_7310 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,3] 3 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7311 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7309
    (ChildrenCoverage113.cons _ _ compact113_node_7310
    ChildrenCoverage113.nil))

theorem compact113_node_7312 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,3] 3 15 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7313 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7311
    (ChildrenCoverage113.cons _ _ compact113_node_7312
    ChildrenCoverage113.nil))

theorem compact113_node_7314 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,3] 3 20 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7315 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5,5,5,5] 5 23 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7313
    (ChildrenCoverage113.cons _ _ compact113_node_7314
    ChildrenCoverage113.nil))

theorem compact113_node_7316 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5,5,5,3] 3 25 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7317 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5,5,5] 5 28 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7315
    (ChildrenCoverage113.cons _ _ compact113_node_7316
    ChildrenCoverage113.nil))

theorem compact113_node_7318 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5,5,3] 3 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7319 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5,5] 5 33 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7317
    (ChildrenCoverage113.cons _ _ compact113_node_7318
    ChildrenCoverage113.nil))

theorem compact113_node_7320 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5,3] 3 35 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7321 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,5] 5 38 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7319
    (ChildrenCoverage113.cons _ _ compact113_node_7320
    ChildrenCoverage113.nil))

theorem compact113_node_7322 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5,3] 3 40 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7323 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,5] 5 43 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7321
    (ChildrenCoverage113.cons _ _ compact113_node_7322
    ChildrenCoverage113.nil))

theorem compact113_node_7324 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5,3] 3 45 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7325 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,5] 5 48 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7323
    (ChildrenCoverage113.cons _ _ compact113_node_7324
    ChildrenCoverage113.nil))

theorem compact113_node_7326 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7327 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7326
    ChildrenCoverage113.nil)

theorem compact113_node_7328 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7327
    ChildrenCoverage113.nil)

theorem compact113_node_7329 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7328
    ChildrenCoverage113.nil)

theorem compact113_node_7330 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7329
    ChildrenCoverage113.nil)

theorem compact113_node_7331 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7330
    ChildrenCoverage113.nil)

theorem compact113_node_7332 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7331
    ChildrenCoverage113.nil)

theorem compact113_node_7333 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7332
    ChildrenCoverage113.nil)

theorem compact113_node_7334 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7333
    ChildrenCoverage113.nil)

theorem compact113_node_7335 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7334
    ChildrenCoverage113.nil)

theorem compact113_node_7336 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3] 3 35 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7335
    ChildrenCoverage113.nil)

theorem compact113_node_7337 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3,3,3,3,3] 3 38 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7336
    ChildrenCoverage113.nil)

theorem compact113_node_7338 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3,3,3,3] 3 41 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7337
    ChildrenCoverage113.nil)

theorem compact113_node_7339 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3,3,3] 3 44 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7338
    ChildrenCoverage113.nil)

theorem compact113_node_7340 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3,3] 3 47 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7339
    ChildrenCoverage113.nil)

end Symconf113

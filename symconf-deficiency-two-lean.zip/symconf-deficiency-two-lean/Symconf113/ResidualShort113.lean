import Symconf113.ResidualCoords113
import Symconf113.ResidualRealizeDefs113

/-! Facts about the blocks of the residual profile `3+5+15^7` that do not
depend on the census: row overlaps of a 113_11 incidence along the cycle
charts, and the shape of the short `15×5` and `15×3` blocks. -/
namespace Symconf113
open Matrix Symconf59
open scoped BigOperators

/-! ### Periodic functions on `ZMod 15` -/

theorem per_mod {m : ℕ} (h : ZMod 15 → ℤ) (hp : ∀ x, h (x+(m:ZMod 15))=h x) (x : ZMod 15) :
    h x=h ((x.val%m : ℕ) : ZMod 15) := by
  have key : ∀ q r : ℕ, h ((r+m*q : ℕ) : ZMod 15)=h (r : ZMod 15) := by
    intro q r
    induction q with
    | zero => simp
    | succ q ih =>
      rw [show r+m*(q+1)=(r+m*q)+m by ring, Nat.cast_add, hp, ih]
  have hx : x=((x.val%m+m*(x.val/m) : ℕ) : ZMod 15) := by
    rw [Nat.mod_add_div, ZMod.natCast_zmod_val]
  conv_lhs => rw [hx]
  exact key _ _

theorem card_fiber3 : ∀ r<3, (Finset.univ.filter fun u : ZMod 15 => u.val%3=r).card=5 := by decide
theorem card_fiber5 : ∀ r<5, (Finset.univ.filter fun u : ZMod 15 => u.val%5=r).card=3 := by decide

theorem sum_per {m : ℕ} (hm : m=3 ∨ m=5) (h : ZMod 15 → ℤ) (hp : ∀ x, h (x+(m:ZMod 15))=h x) :
    (∑ u, h u)=((15/m : ℕ) : ℤ)*∑ r ∈ Finset.range m, h (r : ZMod 15) := by
  have hmaps : ∀ u ∈ (Finset.univ : Finset (ZMod 15)), u.val%m ∈ Finset.range m := by
    intro u _
    exact Finset.mem_range.mpr (Nat.mod_lt _ (by rcases hm with rfl|rfl <;> norm_num))
  rw [← Finset.sum_fiberwise_of_maps_to hmaps, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro r hr
  have hr' := Finset.mem_range.mp hr
  have hc : ∀ u ∈ Finset.univ.filter (fun u : ZMod 15 => u.val%m=r), h u=h (r : ZMod 15) := by
    intro u hu
    rw [per_mod h hp u, (Finset.mem_filter.mp hu).2]
  rw [Finset.sum_congr rfl hc, Finset.sum_const, nsmul_eq_mul]
  congr 1
  rcases hm with rfl|rfl
  · rw [card_fiber3 r hr']
  · rw [card_fiber5 r hr']

theorem two_le_range {m : ℕ} (h : ℕ → ℤ) (hn : ∀ r, 0≤h r) {a b : ℕ} (ha : a<m) (hb : b<m)
    (hab : a≠b) : h a+h b≤∑ r ∈ Finset.range m, h r := by
  rw [← Finset.sum_pair hab]
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro x hx
    simp only [Finset.mem_insert, Finset.mem_singleton] at hx
    rcases hx with rfl|rfl <;> exact Finset.mem_range.mpr ‹_›
  · intro x _ _; exact hn x

theorem cls_shift3 : ∀ x δ : ZMod 15, (δ.val%3=0 ↔ (x+δ).val%3=x.val%3) := by decide
theorem cls_shift5 : ∀ x δ : ZMod 15, (δ.val%5=0 ↔ (x+δ).val%5=x.val%5) := by decide

theorem cls_shift {m : ℕ} (hm : m=3 ∨ m=5) (x δ : ZMod 15) :
    δ.val%m=0 ↔ (x+δ).val%m=x.val%m := by
  rcases hm with rfl|rfl
  · exact cls_shift3 x δ
  · exact cls_shift5 x δ

/-! ### Short blocks -/

theorem bin_sq {a : ℤ} (h : a=0 ∨ a=1) : a*a=a := by rcases h with rfl|rfl <;> norm_num

theorem bin_nonneg {a : ℤ} (h : a=0 ∨ a=1) : 0≤a := by rcases h with rfl|rfl <;> norm_num

/-- A binary intertwining `15×m` block (`m = 3` or `5`) of row degree at most
one: two rows meet a common column exactly when they differ by a multiple
of `m`. -/
theorem short_overlap {m : ℕ} [NeZero m] (hm : m=3 ∨ m=5) (f : ZMod 15 → ZMod m → ℤ)
    (hw : BlockWave f) (hb : ∀ x y, f x y=0 ∨ f x y=1) (hd : (∑ z, f 0 z)≤1)
    (x δ : ZMod 15) :
    (∑ z, f x z*f (x+δ) z)=if δ.val%m=0 then ∑ z, f 0 z else 0 := by
  have hper : ∀ u y, f (u+(m:ZMod 15)) y=f u y := by
    intro u y
    exact cyclic_block_binary_gcd_period f hw hb m (Nat.gcd_dvd_right 15 m) u y
  have hrow := cyclic_block_rows_constant f hw
  split_ifs with hδ
  · have he : ∀ z, f (x+δ) z=f x z := by
      intro z
      rw [per_mod (fun u => f u z) (fun u => hper u z) (x+δ),
        per_mod (fun u => f u z) (fun u => hper u z) x, (cls_shift hm x δ).mp hδ]
    simp only [he, bin_sq (hb _ _)]
    exact hrow x
  · apply Finset.sum_eq_zero
    intro z _
    have hcol := cyclic_block_cols_constant f hw z
    have htot := cyclic_block_totals f hw
    have hs := sum_per hm (fun u => f u z) (fun u => hper u z)
    have hS : (∑ r ∈ Finset.range m, f (r : ZMod 15) z)≤1 := by
      have hz : (∑ u, f u z)=∑ u, f u 0 := hcol
      rcases hm with rfl|rfl
      · simp only [Nat.cast_ofNat] at htot
        norm_num at hs
        omega
      · simp only [Nat.cast_ofNat] at htot
        norm_num at hs
        omega
    have hne : (x+δ).val%m≠x.val%m := fun h => hδ ((cls_shift hm x δ).mpr h)
    have hlt : ∀ u : ZMod 15, u.val%m<m := fun u => Nat.mod_lt _ (by rcases hm with rfl|rfl <;> norm_num)
    have h2 := two_le_range (fun r => f (r : ZMod 15) z) (fun r => bin_nonneg (hb _ _))
      (hlt (x+δ)) (hlt x) hne
    rw [← per_mod (fun u => f u z) (fun u => hper u z) (x+δ),
      ← per_mod (fun u => f u z) (fun u => hper u z) x] at h2
    rcases hb x z with h0|h0 <;> rcases hb (x+δ) z with h1|h1 <;> simp [h0,h1] at h2 ⊢ <;> omega

/-! ### Long blocks -/

theorem acZ_neg (e : ZMod 15 → ℤ) (d : ZMod 15) : acZ e (-d)=acZ e d := by
  unfold acZ
  rw [← Equiv.sum_comp (Equiv.addRight d)]
  apply Finset.sum_congr rfl
  intro v _
  simp only [Equiv.coe_addRight, add_neg_cancel_right]
  ring

theorem long_shape (f : ZMod 15 → ZMod 15 → ℤ) (hw : BlockWave f) (hb : ∀ x y, f x y=0 ∨ f x y=1) :
    (∀ i j, f i j=f 0 (j-i)) ∨ (∀ i j, f i j=f 0 (j+i)) :=
  binary_block_orientation (c := 8) (by decide) f hw hb

theorem long_colsum (f : ZMod 15 → ZMod 15 → ℤ) (hw : BlockWave f) (hb : ∀ x y, f x y=0 ∨ f x y=1)
    (y : ZMod 15) : (∑ x, f x y)=∑ u, f 0 u := by
  rcases long_shape f hw hb with hc|hc <;> simp_rw [hc _ y]
  · exact Equiv.sum_comp (Equiv.subLeft y) (f 0)
  · exact Equiv.sum_comp (Equiv.addLeft y) (f 0)

theorem long_rowov (f : ZMod 15 → ZMod 15 → ℤ) (hw : BlockWave f) (hb : ∀ x y, f x y=0 ∨ f x y=1)
    (x δ : ZMod 15) : (∑ y, f x y*f (x+δ) y)=acZ (f 0) δ := by
  unfold acZ
  rcases long_shape f hw hb with hc|hc
  · simp_rw [hc x, hc (x+δ)]
    rw [← Equiv.sum_comp (Equiv.addRight (x+δ))]
    apply Finset.sum_congr rfl
    intro u _
    simp only [Equiv.coe_addRight]
    rw [mul_comm]
    congr 2 <;> ring
  · simp_rw [hc x, hc (x+δ)]
    rw [← Equiv.sum_comp (Equiv.subRight x)]
    apply Finset.sum_congr rfl
    intro u _
    simp only [Equiv.subRight_apply]
    congr 2 <;> ring

theorem long_colov (f : ZMod 15 → ZMod 15 → ℤ) (hw : BlockWave f) (hb : ∀ x y, f x y=0 ∨ f x y=1)
    (y δ : ZMod 15) : (∑ x, f x y*f x (y+δ))=acZ (f 0) δ := by
  unfold acZ
  rcases long_shape f hw hb with hc|hc
  · simp_rw [hc _ y, hc _ (y+δ)]
    rw [← Equiv.sum_comp (Equiv.subLeft y)]
    apply Finset.sum_congr rfl
    intro u _
    simp only [Equiv.subLeft_apply]
    congr 2 <;> ring
  · simp_rw [hc _ y, hc _ (y+δ)]
    rw [← Equiv.sum_comp (Equiv.subRight y)]
    apply Finset.sum_congr rfl
    intro u _
    simp only [Equiv.subRight_apply]
    congr 2 <;> ring

end Symconf113

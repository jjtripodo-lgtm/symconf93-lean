import Symconf113.CoverageShard113_074
import Symconf113.CoverageShard113_075

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2675 : NodeCoverage113 [28,28,7,3] 3 47 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2676 : NodeCoverage113 [28,28,7] 7 50 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2672
    (ChildrenCoverage113.cons _ _ compact113_node_2673
    (ChildrenCoverage113.cons _ _ compact113_node_2674
    (ChildrenCoverage113.cons _ _ compact113_node_2675
    ChildrenCoverage113.nil))))

theorem compact113_node_2677 : NodeCoverage113 [28,28,6] 6 51 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2678 : NodeCoverage113 [28,28,5] 5 52 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2679 : NodeCoverage113 [28,28,3] 3 54 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2680 : NodeCoverage113 [28,28] 28 57 :=
  node_fork113 (B := [28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2579
    (ChildrenCoverage113.cons _ _ compact113_node_2580
    (ChildrenCoverage113.cons _ _ compact113_node_2581
    (ChildrenCoverage113.cons _ _ compact113_node_2582
    (ChildrenCoverage113.cons _ _ compact113_node_2583
    (ChildrenCoverage113.cons _ _ compact113_node_2584
    (ChildrenCoverage113.cons _ _ compact113_node_2585
    (ChildrenCoverage113.cons _ _ compact113_node_2586
    (ChildrenCoverage113.cons _ _ compact113_node_2587
    (ChildrenCoverage113.cons _ _ compact113_node_2588
    (ChildrenCoverage113.cons _ _ compact113_node_2589
    (ChildrenCoverage113.cons _ _ compact113_node_2590
    (ChildrenCoverage113.cons _ _ compact113_node_2591
    (ChildrenCoverage113.cons _ _ compact113_node_2592
    (ChildrenCoverage113.cons _ _ compact113_node_2643
    (ChildrenCoverage113.cons _ _ compact113_node_2644
    (ChildrenCoverage113.cons _ _ compact113_node_2645
    (ChildrenCoverage113.cons _ _ compact113_node_2646
    (ChildrenCoverage113.cons _ _ compact113_node_2647
    (ChildrenCoverage113.cons _ _ compact113_node_2648
    (ChildrenCoverage113.cons _ _ compact113_node_2649
    (ChildrenCoverage113.cons _ _ compact113_node_2676
    (ChildrenCoverage113.cons _ _ compact113_node_2677
    (ChildrenCoverage113.cons _ _ compact113_node_2678
    (ChildrenCoverage113.cons _ _ compact113_node_2679
    ChildrenCoverage113.nil)))))))))))))))))))))))))

theorem compact113_node_2681 : NodeCoverage113 [28,27] 27 58 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2682 : NodeCoverage113 [28,26] 26 59 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2683 : NodeCoverage113 [28,25] 25 60 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2684 : NodeCoverage113 [28,24] 24 61 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2685 : NodeCoverage113 [28,23] 23 62 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2686 : NodeCoverage113 [28,22] 22 63 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2687 : NodeCoverage113 [28,21] 21 64 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2688 : NodeCoverage113 [28,20] 20 65 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2689 : NodeCoverage113 [28,19] 19 66 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2690 : NodeCoverage113 [28,18] 18 67 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2691 : NodeCoverage113 [28,17] 17 68 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2692 : NodeCoverage113 [28,16] 16 69 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2693 : NodeCoverage113 [28,15] 15 70 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2694 : NodeCoverage113 [28,14,14,14,14,14] 14 15 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2695 : NodeCoverage113 [28,14,14,14,14,13] 13 16 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2696 : NodeCoverage113 [28,14,14,14,14,12] 12 17 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2697 : NodeCoverage113 [28,14,14,14,14,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2698 : NodeCoverage113 [28,14,14,14,14,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2699 : NodeCoverage113 [28,14,14,14,14,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2700 : NodeCoverage113 [28,14,14,14,14,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2701 : NodeCoverage113 [28,14,14,14,14,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2702 : NodeCoverage113 [28,14,14,14,14,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2703 : NodeCoverage113 [28,14,14,14,14,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2701
    (ChildrenCoverage113.cons _ _ compact113_node_2702
    ChildrenCoverage113.nil))

theorem compact113_node_2704 : NodeCoverage113 [28,14,14,14,14,7,7,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2705 : NodeCoverage113 [28,14,14,14,14,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2706 : NodeCoverage113 [28,14,14,14,14,7,7,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2707 : NodeCoverage113 [28,14,14,14,14,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2703
    (ChildrenCoverage113.cons _ _ compact113_node_2704
    (ChildrenCoverage113.cons _ _ compact113_node_2705
    (ChildrenCoverage113.cons _ _ compact113_node_2706
    ChildrenCoverage113.nil))))

theorem compact113_node_2708 : NodeCoverage113 [28,14,14,14,14,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2709 : NodeCoverage113 [28,14,14,14,14,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2710 : NodeCoverage113 [28,14,14,14,14,7,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2711 : NodeCoverage113 [28,14,14,14,14,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2707
    (ChildrenCoverage113.cons _ _ compact113_node_2708
    (ChildrenCoverage113.cons _ _ compact113_node_2709
    (ChildrenCoverage113.cons _ _ compact113_node_2710
    ChildrenCoverage113.nil))))

theorem compact113_node_2712 : NodeCoverage113 [28,14,14,14,14,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2713 : NodeCoverage113 [28,14,14,14,14,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2714 : NodeCoverage113 [28,14,14,14,14,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2715 : NodeCoverage113 [28,14,14,14,14] 14 29 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2694
    (ChildrenCoverage113.cons _ _ compact113_node_2695
    (ChildrenCoverage113.cons _ _ compact113_node_2696
    (ChildrenCoverage113.cons _ _ compact113_node_2697
    (ChildrenCoverage113.cons _ _ compact113_node_2698
    (ChildrenCoverage113.cons _ _ compact113_node_2699
    (ChildrenCoverage113.cons _ _ compact113_node_2700
    (ChildrenCoverage113.cons _ _ compact113_node_2711
    (ChildrenCoverage113.cons _ _ compact113_node_2712
    (ChildrenCoverage113.cons _ _ compact113_node_2713
    (ChildrenCoverage113.cons _ _ compact113_node_2714
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_2716 : NodeCoverage113 [28,14,14,14,13] 13 30 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2717 : NodeCoverage113 [28,14,14,14,12] 12 31 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2718 : NodeCoverage113 [28,14,14,14,11] 11 32 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2719 : NodeCoverage113 [28,14,14,14,10] 10 33 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2720 : NodeCoverage113 [28,14,14,14,9] 9 34 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2721 : NodeCoverage113 [28,14,14,14,8] 8 35 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2722 : NodeCoverage113 [28,14,14,14,7] 7 36 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2723 : NodeCoverage113 [28,14,14,14,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2724 : NodeCoverage113 [28,14,14,14,5] 5 38 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2725 : NodeCoverage113 [28,14,14,14,3] 3 40 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

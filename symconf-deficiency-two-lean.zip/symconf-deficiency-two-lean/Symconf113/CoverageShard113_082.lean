import Symconf113.CoverageShard113_081

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2949 : NodeCoverage113 [25,25,15] 15 48 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2950 : NodeCoverage113 [25,25,14] 14 49 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2951 : NodeCoverage113 [25,25,13] 13 50 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2952 : NodeCoverage113 [25,25,12] 12 51 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2953 : NodeCoverage113 [25,25,11] 11 52 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2954 : NodeCoverage113 [25,25,10] 10 53 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2955 : NodeCoverage113 [25,25,9] 9 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2956 : NodeCoverage113 [25,25,8] 8 55 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2957 : NodeCoverage113 [25,25,7] 7 56 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2958 : NodeCoverage113 [25,25,6] 6 57 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2959 : NodeCoverage113 [25,25,5] 5 58 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2960 : NodeCoverage113 [25,25,3] 3 60 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2961 : NodeCoverage113 [25,25] 25 63 :=
  node_fork113 (B := [25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2939
    (ChildrenCoverage113.cons _ _ compact113_node_2940
    (ChildrenCoverage113.cons _ _ compact113_node_2941
    (ChildrenCoverage113.cons _ _ compact113_node_2942
    (ChildrenCoverage113.cons _ _ compact113_node_2943
    (ChildrenCoverage113.cons _ _ compact113_node_2944
    (ChildrenCoverage113.cons _ _ compact113_node_2945
    (ChildrenCoverage113.cons _ _ compact113_node_2946
    (ChildrenCoverage113.cons _ _ compact113_node_2947
    (ChildrenCoverage113.cons _ _ compact113_node_2948
    (ChildrenCoverage113.cons _ _ compact113_node_2949
    (ChildrenCoverage113.cons _ _ compact113_node_2950
    (ChildrenCoverage113.cons _ _ compact113_node_2951
    (ChildrenCoverage113.cons _ _ compact113_node_2952
    (ChildrenCoverage113.cons _ _ compact113_node_2953
    (ChildrenCoverage113.cons _ _ compact113_node_2954
    (ChildrenCoverage113.cons _ _ compact113_node_2955
    (ChildrenCoverage113.cons _ _ compact113_node_2956
    (ChildrenCoverage113.cons _ _ compact113_node_2957
    (ChildrenCoverage113.cons _ _ compact113_node_2958
    (ChildrenCoverage113.cons _ _ compact113_node_2959
    (ChildrenCoverage113.cons _ _ compact113_node_2960
    ChildrenCoverage113.nil))))))))))))))))))))))

theorem compact113_node_2962 : NodeCoverage113 [25,24] 24 64 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2963 : NodeCoverage113 [25,23] 23 65 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2964 : NodeCoverage113 [25,22] 22 66 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2965 : NodeCoverage113 [25,21] 21 67 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2966 : NodeCoverage113 [25,20] 20 68 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2967 : NodeCoverage113 [25,19] 19 69 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2968 : NodeCoverage113 [25,18] 18 70 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2969 : NodeCoverage113 [25,17] 17 71 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2970 : NodeCoverage113 [25,16] 16 72 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2971 : NodeCoverage113 [25,15] 15 73 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2972 : NodeCoverage113 [25,14] 14 74 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2973 : NodeCoverage113 [25,13] 13 75 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2974 : NodeCoverage113 [25,12] 12 76 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2975 : NodeCoverage113 [25,11] 11 77 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2976 : NodeCoverage113 [25,10] 10 78 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2977 : NodeCoverage113 [25,9] 9 79 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2978 : NodeCoverage113 [25,8] 8 80 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2979 : NodeCoverage113 [25,7] 7 81 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2980 : NodeCoverage113 [25,6] 6 82 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2981 : NodeCoverage113 [25,5] 5 83 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2982 : NodeCoverage113 [25,3] 3 85 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2983 : NodeCoverage113 [25] 25 88 :=
  node_fork113 (B := [25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2961
    (ChildrenCoverage113.cons _ _ compact113_node_2962
    (ChildrenCoverage113.cons _ _ compact113_node_2963
    (ChildrenCoverage113.cons _ _ compact113_node_2964
    (ChildrenCoverage113.cons _ _ compact113_node_2965
    (ChildrenCoverage113.cons _ _ compact113_node_2966
    (ChildrenCoverage113.cons _ _ compact113_node_2967
    (ChildrenCoverage113.cons _ _ compact113_node_2968
    (ChildrenCoverage113.cons _ _ compact113_node_2969
    (ChildrenCoverage113.cons _ _ compact113_node_2970
    (ChildrenCoverage113.cons _ _ compact113_node_2971
    (ChildrenCoverage113.cons _ _ compact113_node_2972
    (ChildrenCoverage113.cons _ _ compact113_node_2973
    (ChildrenCoverage113.cons _ _ compact113_node_2974
    (ChildrenCoverage113.cons _ _ compact113_node_2975
    (ChildrenCoverage113.cons _ _ compact113_node_2976
    (ChildrenCoverage113.cons _ _ compact113_node_2977
    (ChildrenCoverage113.cons _ _ compact113_node_2978
    (ChildrenCoverage113.cons _ _ compact113_node_2979
    (ChildrenCoverage113.cons _ _ compact113_node_2980
    (ChildrenCoverage113.cons _ _ compact113_node_2981
    (ChildrenCoverage113.cons _ _ compact113_node_2982
    ChildrenCoverage113.nil))))))))))))))))))))))

theorem compact113_node_2984 : NodeCoverage113 [24,24,24,24,17] 17 0 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2985 : NodeCoverage113 [24,24,24,24,14] 14 3 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2986 : NodeCoverage113 [24,24,24,24,13] 13 4 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2987 : NodeCoverage113 [24,24,24,24,12,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2988 : NodeCoverage113 [24,24,24,24,12] 12 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2987
    ChildrenCoverage113.nil)

theorem compact113_node_2989 : NodeCoverage113 [24,24,24,24,11] 11 6 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2990 : NodeCoverage113 [24,24,24,24,10] 10 7 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2991 : NodeCoverage113 [24,24,24,24,9] 9 8 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2992 : NodeCoverage113 [24,24,24,24,8] 8 9 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2993 : NodeCoverage113 [24,24,24,24,7] 7 10 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2994 : NodeCoverage113 [24,24,24,24,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2995 : NodeCoverage113 [24,24,24,24,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2994
    ChildrenCoverage113.nil)

theorem compact113_node_2996 : NodeCoverage113 [24,24,24,24,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2997 : NodeCoverage113 [24,24,24,24,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_2998 : NodeCoverage113 [24,24,24,24,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2997
    ChildrenCoverage113.nil)

theorem compact113_node_2999 : NodeCoverage113 [24,24,24,24,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2995
    (ChildrenCoverage113.cons _ _ compact113_node_2996
    (ChildrenCoverage113.cons _ _ compact113_node_2998
    ChildrenCoverage113.nil)))

theorem compact113_node_3000 : NodeCoverage113 [24,24,24,24,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

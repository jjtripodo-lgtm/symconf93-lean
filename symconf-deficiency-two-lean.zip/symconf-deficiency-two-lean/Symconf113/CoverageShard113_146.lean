import Symconf113.CoverageShard113_145

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_6076 : NodeCoverage113 [12,12,12,12,12,12,12,6,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6075
    ChildrenCoverage113.nil)

theorem compact113_node_6077 : NodeCoverage113 [12,12,12,12,12,12,12,6,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6076
    ChildrenCoverage113.nil)

theorem compact113_node_6078 : NodeCoverage113 [12,12,12,12,12,12,12,6,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6077
    ChildrenCoverage113.nil)

theorem compact113_node_6079 : NodeCoverage113 [12,12,12,12,12,12,12,6] 6 23 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6071
    (ChildrenCoverage113.cons _ _ compact113_node_6072
    (ChildrenCoverage113.cons _ _ compact113_node_6078
    ChildrenCoverage113.nil)))

theorem compact113_node_6080 : NodeCoverage113 [12,12,12,12,12,12,12,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6081 : NodeCoverage113 [12,12,12,12,12,12,12,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6082 : NodeCoverage113 [12,12,12,12,12,12,12,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6081
    ChildrenCoverage113.nil)

theorem compact113_node_6083 : NodeCoverage113 [12,12,12,12,12,12,12,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6082
    ChildrenCoverage113.nil)

theorem compact113_node_6084 : NodeCoverage113 [12,12,12,12,12,12,12,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6083
    ChildrenCoverage113.nil)

theorem compact113_node_6085 : NodeCoverage113 [12,12,12,12,12,12,12,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6084
    ChildrenCoverage113.nil)

theorem compact113_node_6086 : NodeCoverage113 [12,12,12,12,12,12,12,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6085
    ChildrenCoverage113.nil)

theorem compact113_node_6087 : NodeCoverage113 [12,12,12,12,12,12,12,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6086
    ChildrenCoverage113.nil)

theorem compact113_node_6088 : NodeCoverage113 [12,12,12,12,12,12,12,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6087
    ChildrenCoverage113.nil)

theorem compact113_node_6089 : NodeCoverage113 [12,12,12,12,12,12,12] 12 29 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6054
    (ChildrenCoverage113.cons _ _ compact113_node_6055
    (ChildrenCoverage113.cons _ _ compact113_node_6056
    (ChildrenCoverage113.cons _ _ compact113_node_6057
    (ChildrenCoverage113.cons _ _ compact113_node_6058
    (ChildrenCoverage113.cons _ _ compact113_node_6059
    (ChildrenCoverage113.cons _ _ compact113_node_6079
    (ChildrenCoverage113.cons _ _ compact113_node_6080
    (ChildrenCoverage113.cons _ _ compact113_node_6088
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_6090 : NodeCoverage113 [12,12,12,12,12,12,11] 11 30 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6091 : NodeCoverage113 [12,12,12,12,12,12,10] 10 31 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6092 : NodeCoverage113 [12,12,12,12,12,12,9] 9 32 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6093 : NodeCoverage113 [12,12,12,12,12,12,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6094 : NodeCoverage113 [12,12,12,12,12,12,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6095 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6096 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6095
    ChildrenCoverage113.nil)

theorem compact113_node_6097 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6098 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6099 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6098
    ChildrenCoverage113.nil)

theorem compact113_node_6100 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6096
    (ChildrenCoverage113.cons _ _ compact113_node_6097
    (ChildrenCoverage113.cons _ _ compact113_node_6099
    ChildrenCoverage113.nil)))

theorem compact113_node_6101 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6102 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,6,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6103 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,6,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6102
    ChildrenCoverage113.nil)

theorem compact113_node_6104 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,6,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6103
    ChildrenCoverage113.nil)

theorem compact113_node_6105 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,6,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6104
    ChildrenCoverage113.nil)

theorem compact113_node_6106 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6100
    (ChildrenCoverage113.cons _ _ compact113_node_6101
    (ChildrenCoverage113.cons _ _ compact113_node_6105
    ChildrenCoverage113.nil)))

theorem compact113_node_6107 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6108 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6109 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6108
    ChildrenCoverage113.nil)

theorem compact113_node_6110 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6109
    ChildrenCoverage113.nil)

theorem compact113_node_6111 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6110
    ChildrenCoverage113.nil)

theorem compact113_node_6112 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6111
    ChildrenCoverage113.nil)

theorem compact113_node_6113 : NodeCoverage113 [12,12,12,12,12,12,6,6,6,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6112
    ChildrenCoverage113.nil)

theorem compact113_node_6114 : NodeCoverage113 [12,12,12,12,12,12,6,6,6] 6 23 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6106
    (ChildrenCoverage113.cons _ _ compact113_node_6107
    (ChildrenCoverage113.cons _ _ compact113_node_6113
    ChildrenCoverage113.nil)))

theorem compact113_node_6115 : NodeCoverage113 [12,12,12,12,12,12,6,6,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6116 : NodeCoverage113 [12,12,12,12,12,12,6,6,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6117 : NodeCoverage113 [12,12,12,12,12,12,6,6,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6116
    ChildrenCoverage113.nil)

theorem compact113_node_6118 : NodeCoverage113 [12,12,12,12,12,12,6,6,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6117
    ChildrenCoverage113.nil)

theorem compact113_node_6119 : NodeCoverage113 [12,12,12,12,12,12,6,6,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6118
    ChildrenCoverage113.nil)

theorem compact113_node_6120 : NodeCoverage113 [12,12,12,12,12,12,6,6,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6119
    ChildrenCoverage113.nil)

theorem compact113_node_6121 : NodeCoverage113 [12,12,12,12,12,12,6,6,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6120
    ChildrenCoverage113.nil)

theorem compact113_node_6122 : NodeCoverage113 [12,12,12,12,12,12,6,6,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6121
    ChildrenCoverage113.nil)

theorem compact113_node_6123 : NodeCoverage113 [12,12,12,12,12,12,6,6,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6122
    ChildrenCoverage113.nil)

theorem compact113_node_6124 : NodeCoverage113 [12,12,12,12,12,12,6,6] 6 29 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6114
    (ChildrenCoverage113.cons _ _ compact113_node_6115
    (ChildrenCoverage113.cons _ _ compact113_node_6123
    ChildrenCoverage113.nil)))

theorem compact113_node_6125 : NodeCoverage113 [12,12,12,12,12,12,6,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6126 : NodeCoverage113 [12,12,12,12,12,12,6,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6127 : NodeCoverage113 [12,12,12,12,12,12,6,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6126
    ChildrenCoverage113.nil)

theorem compact113_node_6128 : NodeCoverage113 [12,12,12,12,12,12,6,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6127
    ChildrenCoverage113.nil)

theorem compact113_node_6129 : NodeCoverage113 [12,12,12,12,12,12,6,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6128
    ChildrenCoverage113.nil)

theorem compact113_node_6130 : NodeCoverage113 [12,12,12,12,12,12,6,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6129
    ChildrenCoverage113.nil)

theorem compact113_node_6131 : NodeCoverage113 [12,12,12,12,12,12,6,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6130
    ChildrenCoverage113.nil)

theorem compact113_node_6132 : NodeCoverage113 [12,12,12,12,12,12,6,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6131
    ChildrenCoverage113.nil)

theorem compact113_node_6133 : NodeCoverage113 [12,12,12,12,12,12,6,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6132
    ChildrenCoverage113.nil)

theorem compact113_node_6134 : NodeCoverage113 [12,12,12,12,12,12,6,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6133
    ChildrenCoverage113.nil)

theorem compact113_node_6135 : NodeCoverage113 [12,12,12,12,12,12,6,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6134
    ChildrenCoverage113.nil)

theorem compact113_node_6136 : NodeCoverage113 [12,12,12,12,12,12,6] 6 35 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6124
    (ChildrenCoverage113.cons _ _ compact113_node_6125
    (ChildrenCoverage113.cons _ _ compact113_node_6135
    ChildrenCoverage113.nil)))

theorem compact113_node_6137 : NodeCoverage113 [12,12,12,12,12,12,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6138 : NodeCoverage113 [12,12,12,12,12,12,3] 3 38 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6139 : NodeCoverage113 [12,12,12,12,12,12] 12 41 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6089
    (ChildrenCoverage113.cons _ _ compact113_node_6090
    (ChildrenCoverage113.cons _ _ compact113_node_6091
    (ChildrenCoverage113.cons _ _ compact113_node_6092
    (ChildrenCoverage113.cons _ _ compact113_node_6093
    (ChildrenCoverage113.cons _ _ compact113_node_6094
    (ChildrenCoverage113.cons _ _ compact113_node_6136
    (ChildrenCoverage113.cons _ _ compact113_node_6137
    (ChildrenCoverage113.cons _ _ compact113_node_6138
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_6140 : NodeCoverage113 [12,12,12,12,12,11] 11 42 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6141 : NodeCoverage113 [12,12,12,12,12,10] 10 43 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6142 : NodeCoverage113 [12,12,12,12,12,9] 9 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6143 : NodeCoverage113 [12,12,12,12,12,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6144 : NodeCoverage113 [12,12,12,12,12,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6145 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6146 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6145
    ChildrenCoverage113.nil)

theorem compact113_node_6147 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6148 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6149 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6148
    ChildrenCoverage113.nil)

theorem compact113_node_6150 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6146
    (ChildrenCoverage113.cons _ _ compact113_node_6147
    (ChildrenCoverage113.cons _ _ compact113_node_6149
    ChildrenCoverage113.nil)))

end Symconf113

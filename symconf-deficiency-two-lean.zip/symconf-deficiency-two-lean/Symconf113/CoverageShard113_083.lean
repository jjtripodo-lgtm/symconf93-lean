import Symconf113.CoverageShard113_082

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3001 : NodeCoverage113 [24,24,24,24,3] 3 14 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3002 : NodeCoverage113 [24,24,24,24] 24 17 :=
  node_fork113 (B := [17,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2984
    (ChildrenCoverage113.cons _ _ compact113_node_2985
    (ChildrenCoverage113.cons _ _ compact113_node_2986
    (ChildrenCoverage113.cons _ _ compact113_node_2988
    (ChildrenCoverage113.cons _ _ compact113_node_2989
    (ChildrenCoverage113.cons _ _ compact113_node_2990
    (ChildrenCoverage113.cons _ _ compact113_node_2991
    (ChildrenCoverage113.cons _ _ compact113_node_2992
    (ChildrenCoverage113.cons _ _ compact113_node_2993
    (ChildrenCoverage113.cons _ _ compact113_node_2999
    (ChildrenCoverage113.cons _ _ compact113_node_3000
    (ChildrenCoverage113.cons _ _ compact113_node_3001
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_3003 : NodeCoverage113 [24,24,24,23] 23 18 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3004 : NodeCoverage113 [24,24,24,22] 22 19 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3005 : NodeCoverage113 [24,24,24,21] 21 20 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3006 : NodeCoverage113 [24,24,24,20] 20 21 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3007 : NodeCoverage113 [24,24,24,19] 19 22 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3008 : NodeCoverage113 [24,24,24,18] 18 23 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3009 : NodeCoverage113 [24,24,24,17] 17 24 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3010 : NodeCoverage113 [24,24,24,16] 16 25 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3011 : NodeCoverage113 [24,24,24,15] 15 26 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3012 : NodeCoverage113 [24,24,24,14] 14 27 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3013 : NodeCoverage113 [24,24,24,13] 13 28 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3014 : NodeCoverage113 [24,24,24,12,12,12,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3015 : NodeCoverage113 [24,24,24,12,12,12] 12 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3014
    ChildrenCoverage113.nil)

theorem compact113_node_3016 : NodeCoverage113 [24,24,24,12,12,11] 11 6 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3017 : NodeCoverage113 [24,24,24,12,12,10] 10 7 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3018 : NodeCoverage113 [24,24,24,12,12,9] 9 8 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3019 : NodeCoverage113 [24,24,24,12,12,8] 8 9 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3020 : NodeCoverage113 [24,24,24,12,12,7] 7 10 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3021 : NodeCoverage113 [24,24,24,12,12,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3022 : NodeCoverage113 [24,24,24,12,12,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3021
    ChildrenCoverage113.nil)

theorem compact113_node_3023 : NodeCoverage113 [24,24,24,12,12,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3024 : NodeCoverage113 [24,24,24,12,12,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_3025 : NodeCoverage113 [24,24,24,12,12,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3024
    ChildrenCoverage113.nil)

theorem compact113_node_3026 : NodeCoverage113 [24,24,24,12,12,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3022
    (ChildrenCoverage113.cons _ _ compact113_node_3023
    (ChildrenCoverage113.cons _ _ compact113_node_3025
    ChildrenCoverage113.nil)))

theorem compact113_node_3027 : NodeCoverage113 [24,24,24,12,12,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3028 : NodeCoverage113 [24,24,24,12,12,3] 3 14 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3029 : NodeCoverage113 [24,24,24,12,12] 12 17 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3015
    (ChildrenCoverage113.cons _ _ compact113_node_3016
    (ChildrenCoverage113.cons _ _ compact113_node_3017
    (ChildrenCoverage113.cons _ _ compact113_node_3018
    (ChildrenCoverage113.cons _ _ compact113_node_3019
    (ChildrenCoverage113.cons _ _ compact113_node_3020
    (ChildrenCoverage113.cons _ _ compact113_node_3026
    (ChildrenCoverage113.cons _ _ compact113_node_3027
    (ChildrenCoverage113.cons _ _ compact113_node_3028
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_3030 : NodeCoverage113 [24,24,24,12,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3031 : NodeCoverage113 [24,24,24,12,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3032 : NodeCoverage113 [24,24,24,12,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3033 : NodeCoverage113 [24,24,24,12,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3034 : NodeCoverage113 [24,24,24,12,7] 7 22 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3035 : NodeCoverage113 [24,24,24,12,6,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3036 : NodeCoverage113 [24,24,24,12,6,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3035
    ChildrenCoverage113.nil)

theorem compact113_node_3037 : NodeCoverage113 [24,24,24,12,6,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3038 : NodeCoverage113 [24,24,24,12,6,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_3039 : NodeCoverage113 [24,24,24,12,6,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3038
    ChildrenCoverage113.nil)

theorem compact113_node_3040 : NodeCoverage113 [24,24,24,12,6,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3036
    (ChildrenCoverage113.cons _ _ compact113_node_3037
    (ChildrenCoverage113.cons _ _ compact113_node_3039
    ChildrenCoverage113.nil)))

theorem compact113_node_3041 : NodeCoverage113 [24,24,24,12,6,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3042 : NodeCoverage113 [24,24,24,12,6,6,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_3043 : NodeCoverage113 [24,24,24,12,6,6,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3042
    ChildrenCoverage113.nil)

theorem compact113_node_3044 : NodeCoverage113 [24,24,24,12,6,6,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3043
    ChildrenCoverage113.nil)

theorem compact113_node_3045 : NodeCoverage113 [24,24,24,12,6,6,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3044
    ChildrenCoverage113.nil)

theorem compact113_node_3046 : NodeCoverage113 [24,24,24,12,6,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3040
    (ChildrenCoverage113.cons _ _ compact113_node_3041
    (ChildrenCoverage113.cons _ _ compact113_node_3045
    ChildrenCoverage113.nil)))

theorem compact113_node_3047 : NodeCoverage113 [24,24,24,12,6,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

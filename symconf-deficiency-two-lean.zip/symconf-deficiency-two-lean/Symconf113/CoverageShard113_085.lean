import Symconf113.CoverageShard113_083
import Symconf113.CoverageShard113_084

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3074 : NodeCoverage113 [24,24,24,6,3] 3 32 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3075 : NodeCoverage113 [24,24,24,6] 6 35 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3072
    (ChildrenCoverage113.cons _ _ compact113_node_3073
    (ChildrenCoverage113.cons _ _ compact113_node_3074
    ChildrenCoverage113.nil)))

theorem compact113_node_3076 : NodeCoverage113 [24,24,24,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3077 : NodeCoverage113 [24,24,24,3] 3 38 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3078 : NodeCoverage113 [24,24,24] 24 41 :=
  node_fork113 (B := [24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3002
    (ChildrenCoverage113.cons _ _ compact113_node_3003
    (ChildrenCoverage113.cons _ _ compact113_node_3004
    (ChildrenCoverage113.cons _ _ compact113_node_3005
    (ChildrenCoverage113.cons _ _ compact113_node_3006
    (ChildrenCoverage113.cons _ _ compact113_node_3007
    (ChildrenCoverage113.cons _ _ compact113_node_3008
    (ChildrenCoverage113.cons _ _ compact113_node_3009
    (ChildrenCoverage113.cons _ _ compact113_node_3010
    (ChildrenCoverage113.cons _ _ compact113_node_3011
    (ChildrenCoverage113.cons _ _ compact113_node_3012
    (ChildrenCoverage113.cons _ _ compact113_node_3013
    (ChildrenCoverage113.cons _ _ compact113_node_3052
    (ChildrenCoverage113.cons _ _ compact113_node_3053
    (ChildrenCoverage113.cons _ _ compact113_node_3054
    (ChildrenCoverage113.cons _ _ compact113_node_3055
    (ChildrenCoverage113.cons _ _ compact113_node_3056
    (ChildrenCoverage113.cons _ _ compact113_node_3057
    (ChildrenCoverage113.cons _ _ compact113_node_3075
    (ChildrenCoverage113.cons _ _ compact113_node_3076
    (ChildrenCoverage113.cons _ _ compact113_node_3077
    ChildrenCoverage113.nil)))))))))))))))))))))

theorem compact113_node_3079 : NodeCoverage113 [24,24,23] 23 42 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3080 : NodeCoverage113 [24,24,22] 22 43 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3081 : NodeCoverage113 [24,24,21] 21 44 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3082 : NodeCoverage113 [24,24,20] 20 45 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3083 : NodeCoverage113 [24,24,19] 19 46 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3084 : NodeCoverage113 [24,24,18] 18 47 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3085 : NodeCoverage113 [24,24,17] 17 48 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3086 : NodeCoverage113 [24,24,16] 16 49 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3087 : NodeCoverage113 [24,24,15] 15 50 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3088 : NodeCoverage113 [24,24,14] 14 51 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3089 : NodeCoverage113 [24,24,13] 13 52 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3090 : NodeCoverage113 [24,24,12,12,12,12,12] 12 5 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3091 : NodeCoverage113 [24,24,12,12,12,12,11] 11 6 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3092 : NodeCoverage113 [24,24,12,12,12,12,10] 10 7 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3093 : NodeCoverage113 [24,24,12,12,12,12,9] 9 8 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3094 : NodeCoverage113 [24,24,12,12,12,12,8] 8 9 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3095 : NodeCoverage113 [24,24,12,12,12,12,7] 7 10 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3096 : NodeCoverage113 [24,24,12,12,12,12,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3097 : NodeCoverage113 [24,24,12,12,12,12,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3096
    ChildrenCoverage113.nil)

theorem compact113_node_3098 : NodeCoverage113 [24,24,12,12,12,12,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3099 : NodeCoverage113 [24,24,12,12,12,12,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_3100 : NodeCoverage113 [24,24,12,12,12,12,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3099
    ChildrenCoverage113.nil)

theorem compact113_node_3101 : NodeCoverage113 [24,24,12,12,12,12,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3097
    (ChildrenCoverage113.cons _ _ compact113_node_3098
    (ChildrenCoverage113.cons _ _ compact113_node_3100
    ChildrenCoverage113.nil)))

theorem compact113_node_3102 : NodeCoverage113 [24,24,12,12,12,12,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

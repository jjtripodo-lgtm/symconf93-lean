import Symconf113.CoverageShard113_104
import Symconf113.CoverageShard113_105

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3878 : NodeCoverage113 [21,21,3] 3 68 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3879 : NodeCoverage113 [21,21] 21 71 :=
  node_fork113 (B := [21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3818
    (ChildrenCoverage113.cons _ _ compact113_node_3819
    (ChildrenCoverage113.cons _ _ compact113_node_3820
    (ChildrenCoverage113.cons _ _ compact113_node_3821
    (ChildrenCoverage113.cons _ _ compact113_node_3822
    (ChildrenCoverage113.cons _ _ compact113_node_3823
    (ChildrenCoverage113.cons _ _ compact113_node_3824
    (ChildrenCoverage113.cons _ _ compact113_node_3825
    (ChildrenCoverage113.cons _ _ compact113_node_3826
    (ChildrenCoverage113.cons _ _ compact113_node_3827
    (ChildrenCoverage113.cons _ _ compact113_node_3828
    (ChildrenCoverage113.cons _ _ compact113_node_3829
    (ChildrenCoverage113.cons _ _ compact113_node_3830
    (ChildrenCoverage113.cons _ _ compact113_node_3831
    (ChildrenCoverage113.cons _ _ compact113_node_3875
    (ChildrenCoverage113.cons _ _ compact113_node_3876
    (ChildrenCoverage113.cons _ _ compact113_node_3877
    (ChildrenCoverage113.cons _ _ compact113_node_3878
    ChildrenCoverage113.nil))))))))))))))))))

theorem compact113_node_3880 : NodeCoverage113 [21,20] 20 72 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3881 : NodeCoverage113 [21,19] 19 73 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3882 : NodeCoverage113 [21,18] 18 74 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3883 : NodeCoverage113 [21,17] 17 75 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3884 : NodeCoverage113 [21,16] 16 76 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3885 : NodeCoverage113 [21,15] 15 77 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3886 : NodeCoverage113 [21,14] 14 78 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3887 : NodeCoverage113 [21,13] 13 79 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3888 : NodeCoverage113 [21,12] 12 80 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3889 : NodeCoverage113 [21,11] 11 81 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3890 : NodeCoverage113 [21,10] 10 82 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3891 : NodeCoverage113 [21,9] 9 83 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3892 : NodeCoverage113 [21,8] 8 84 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3893 : NodeCoverage113 [21,7] 7 85 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3894 : NodeCoverage113 [21,6] 6 86 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3895 : NodeCoverage113 [21,5] 5 87 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3896 : NodeCoverage113 [21,3] 3 89 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3897 : NodeCoverage113 [21] 21 92 :=
  node_fork113 (B := [21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3879
    (ChildrenCoverage113.cons _ _ compact113_node_3880
    (ChildrenCoverage113.cons _ _ compact113_node_3881
    (ChildrenCoverage113.cons _ _ compact113_node_3882
    (ChildrenCoverage113.cons _ _ compact113_node_3883
    (ChildrenCoverage113.cons _ _ compact113_node_3884
    (ChildrenCoverage113.cons _ _ compact113_node_3885
    (ChildrenCoverage113.cons _ _ compact113_node_3886
    (ChildrenCoverage113.cons _ _ compact113_node_3887
    (ChildrenCoverage113.cons _ _ compact113_node_3888
    (ChildrenCoverage113.cons _ _ compact113_node_3889
    (ChildrenCoverage113.cons _ _ compact113_node_3890
    (ChildrenCoverage113.cons _ _ compact113_node_3891
    (ChildrenCoverage113.cons _ _ compact113_node_3892
    (ChildrenCoverage113.cons _ _ compact113_node_3893
    (ChildrenCoverage113.cons _ _ compact113_node_3894
    (ChildrenCoverage113.cons _ _ compact113_node_3895
    (ChildrenCoverage113.cons _ _ compact113_node_3896
    ChildrenCoverage113.nil))))))))))))))))))

theorem compact113_node_3898 : NodeCoverage113 [20,20,20,20,20,13] 13 0 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3899 : NodeCoverage113 [20,20,20,20,20,10] 10 3 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3900 : NodeCoverage113 [20,20,20,20,20,9] 9 4 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3901 : NodeCoverage113 [20,20,20,20,20,8] 8 5 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3902 : NodeCoverage113 [20,20,20,20,20,7] 7 6 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3903 : NodeCoverage113 [20,20,20,20,20,6] 6 7 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_141

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5804 : NodeCoverage113 [14,12,11] 11 76 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5805 : NodeCoverage113 [14,12,10] 10 77 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5806 : NodeCoverage113 [14,12,9] 9 78 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5807 : NodeCoverage113 [14,12,8] 8 79 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5808 : NodeCoverage113 [14,12,7] 7 80 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5809 : NodeCoverage113 [14,12,6] 6 81 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5810 : NodeCoverage113 [14,12,5] 5 82 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5811 : NodeCoverage113 [14,12,3] 3 84 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5812 : NodeCoverage113 [14,12] 12 87 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5803
    (ChildrenCoverage113.cons _ _ compact113_node_5804
    (ChildrenCoverage113.cons _ _ compact113_node_5805
    (ChildrenCoverage113.cons _ _ compact113_node_5806
    (ChildrenCoverage113.cons _ _ compact113_node_5807
    (ChildrenCoverage113.cons _ _ compact113_node_5808
    (ChildrenCoverage113.cons _ _ compact113_node_5809
    (ChildrenCoverage113.cons _ _ compact113_node_5810
    (ChildrenCoverage113.cons _ _ compact113_node_5811
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_5813 : NodeCoverage113 [14,11,11,11,11] 11 55 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5814 : NodeCoverage113 [14,11,11,11,10] 10 56 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5815 : NodeCoverage113 [14,11,11,11,9] 9 57 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5816 : NodeCoverage113 [14,11,11,11,8] 8 58 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5817 : NodeCoverage113 [14,11,11,11,7] 7 59 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5818 : NodeCoverage113 [14,11,11,11,6] 6 60 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5819 : NodeCoverage113 [14,11,11,11,5] 5 61 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5820 : NodeCoverage113 [14,11,11,11,3] 3 63 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5821 : NodeCoverage113 [14,11,11,11] 11 66 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5813
    (ChildrenCoverage113.cons _ _ compact113_node_5814
    (ChildrenCoverage113.cons _ _ compact113_node_5815
    (ChildrenCoverage113.cons _ _ compact113_node_5816
    (ChildrenCoverage113.cons _ _ compact113_node_5817
    (ChildrenCoverage113.cons _ _ compact113_node_5818
    (ChildrenCoverage113.cons _ _ compact113_node_5819
    (ChildrenCoverage113.cons _ _ compact113_node_5820
    ChildrenCoverage113.nil))))))))

theorem compact113_node_5822 : NodeCoverage113 [14,11,11,10] 10 67 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5823 : NodeCoverage113 [14,11,11,9] 9 68 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5824 : NodeCoverage113 [14,11,11,8] 8 69 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5825 : NodeCoverage113 [14,11,11,7] 7 70 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5826 : NodeCoverage113 [14,11,11,6] 6 71 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5827 : NodeCoverage113 [14,11,11,5] 5 72 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5828 : NodeCoverage113 [14,11,11,3] 3 74 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5829 : NodeCoverage113 [14,11,11] 11 77 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5821
    (ChildrenCoverage113.cons _ _ compact113_node_5822
    (ChildrenCoverage113.cons _ _ compact113_node_5823
    (ChildrenCoverage113.cons _ _ compact113_node_5824
    (ChildrenCoverage113.cons _ _ compact113_node_5825
    (ChildrenCoverage113.cons _ _ compact113_node_5826
    (ChildrenCoverage113.cons _ _ compact113_node_5827
    (ChildrenCoverage113.cons _ _ compact113_node_5828
    ChildrenCoverage113.nil))))))))

theorem compact113_node_5830 : NodeCoverage113 [14,11,10] 10 78 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5831 : NodeCoverage113 [14,11,9] 9 79 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5832 : NodeCoverage113 [14,11,8] 8 80 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5833 : NodeCoverage113 [14,11,7] 7 81 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5834 : NodeCoverage113 [14,11,6] 6 82 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5835 : NodeCoverage113 [14,11,5] 5 83 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5836 : NodeCoverage113 [14,11,3] 3 85 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5837 : NodeCoverage113 [14,11] 11 88 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5829
    (ChildrenCoverage113.cons _ _ compact113_node_5830
    (ChildrenCoverage113.cons _ _ compact113_node_5831
    (ChildrenCoverage113.cons _ _ compact113_node_5832
    (ChildrenCoverage113.cons _ _ compact113_node_5833
    (ChildrenCoverage113.cons _ _ compact113_node_5834
    (ChildrenCoverage113.cons _ _ compact113_node_5835
    (ChildrenCoverage113.cons _ _ compact113_node_5836
    ChildrenCoverage113.nil))))))))

theorem compact113_node_5838 : NodeCoverage113 [14,10,10,10,10] 10 59 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5839 : NodeCoverage113 [14,10,10,10,9] 9 60 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5840 : NodeCoverage113 [14,10,10,10,8] 8 61 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5841 : NodeCoverage113 [14,10,10,10,7] 7 62 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5842 : NodeCoverage113 [14,10,10,10,6] 6 63 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5843 : NodeCoverage113 [14,10,10,10,5] 5 64 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5844 : NodeCoverage113 [14,10,10,10,3] 3 66 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5845 : NodeCoverage113 [14,10,10,10] 10 69 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5838
    (ChildrenCoverage113.cons _ _ compact113_node_5839
    (ChildrenCoverage113.cons _ _ compact113_node_5840
    (ChildrenCoverage113.cons _ _ compact113_node_5841
    (ChildrenCoverage113.cons _ _ compact113_node_5842
    (ChildrenCoverage113.cons _ _ compact113_node_5843
    (ChildrenCoverage113.cons _ _ compact113_node_5844
    ChildrenCoverage113.nil)))))))

theorem compact113_node_5846 : NodeCoverage113 [14,10,10,9] 9 70 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5847 : NodeCoverage113 [14,10,10,8] 8 71 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5848 : NodeCoverage113 [14,10,10,7] 7 72 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5849 : NodeCoverage113 [14,10,10,6] 6 73 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5850 : NodeCoverage113 [14,10,10,5] 5 74 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5851 : NodeCoverage113 [14,10,10,3] 3 76 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5852 : NodeCoverage113 [14,10,10] 10 79 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5845
    (ChildrenCoverage113.cons _ _ compact113_node_5846
    (ChildrenCoverage113.cons _ _ compact113_node_5847
    (ChildrenCoverage113.cons _ _ compact113_node_5848
    (ChildrenCoverage113.cons _ _ compact113_node_5849
    (ChildrenCoverage113.cons _ _ compact113_node_5850
    (ChildrenCoverage113.cons _ _ compact113_node_5851
    ChildrenCoverage113.nil)))))))

theorem compact113_node_5853 : NodeCoverage113 [14,10,9] 9 80 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5854 : NodeCoverage113 [14,10,8] 8 81 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5855 : NodeCoverage113 [14,10,7] 7 82 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5856 : NodeCoverage113 [14,10,6] 6 83 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5857 : NodeCoverage113 [14,10,5] 5 84 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5858 : NodeCoverage113 [14,10,3] 3 86 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5859 : NodeCoverage113 [14,10] 10 89 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5852
    (ChildrenCoverage113.cons _ _ compact113_node_5853
    (ChildrenCoverage113.cons _ _ compact113_node_5854
    (ChildrenCoverage113.cons _ _ compact113_node_5855
    (ChildrenCoverage113.cons _ _ compact113_node_5856
    (ChildrenCoverage113.cons _ _ compact113_node_5857
    (ChildrenCoverage113.cons _ _ compact113_node_5858
    ChildrenCoverage113.nil)))))))

theorem compact113_node_5860 : NodeCoverage113 [14,9,9,9,9,9] 9 54 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5861 : NodeCoverage113 [14,9,9,9,9,8] 8 55 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5862 : NodeCoverage113 [14,9,9,9,9,7] 7 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_045
import Symconf113.CoverageShard113_046

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1917 : NodeCoverage113 [35,35,7,7,7,7,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1918 : NodeCoverage113 [35,35,7,7,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1914
    (ChildrenCoverage113.cons _ _ compact113_node_1915
    (ChildrenCoverage113.cons _ _ compact113_node_1916
    (ChildrenCoverage113.cons _ _ compact113_node_1917
    ChildrenCoverage113.nil))))

theorem compact113_node_1919 : NodeCoverage113 [35,35,7,7,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1920 : NodeCoverage113 [35,35,7,7,7,5] 5 17 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1921 : NodeCoverage113 [35,35,7,7,7,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1922 : NodeCoverage113 [35,35,7,7,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1918
    (ChildrenCoverage113.cons _ _ compact113_node_1919
    (ChildrenCoverage113.cons _ _ compact113_node_1920
    (ChildrenCoverage113.cons _ _ compact113_node_1921
    ChildrenCoverage113.nil))))

theorem compact113_node_1923 : NodeCoverage113 [35,35,7,7,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1924 : NodeCoverage113 [35,35,7,7,5] 5 24 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1925 : NodeCoverage113 [35,35,7,7,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1926 : NodeCoverage113 [35,35,7,7] 7 29 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1922
    (ChildrenCoverage113.cons _ _ compact113_node_1923
    (ChildrenCoverage113.cons _ _ compact113_node_1924
    (ChildrenCoverage113.cons _ _ compact113_node_1925
    ChildrenCoverage113.nil))))

theorem compact113_node_1927 : NodeCoverage113 [35,35,7,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1928 : NodeCoverage113 [35,35,7,5] 5 31 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1929 : NodeCoverage113 [35,35,7,3] 3 33 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1930 : NodeCoverage113 [35,35,7] 7 36 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1926
    (ChildrenCoverage113.cons _ _ compact113_node_1927
    (ChildrenCoverage113.cons _ _ compact113_node_1928
    (ChildrenCoverage113.cons _ _ compact113_node_1929
    ChildrenCoverage113.nil))))

theorem compact113_node_1931 : NodeCoverage113 [35,35,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1932 : NodeCoverage113 [35,35,5] 5 38 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1933 : NodeCoverage113 [35,35,3] 3 40 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1934 : NodeCoverage113 [35,35] 35 43 :=
  node_fork113 (B := [35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1884
    (ChildrenCoverage113.cons _ _ compact113_node_1885
    (ChildrenCoverage113.cons _ _ compact113_node_1886
    (ChildrenCoverage113.cons _ _ compact113_node_1887
    (ChildrenCoverage113.cons _ _ compact113_node_1888
    (ChildrenCoverage113.cons _ _ compact113_node_1889
    (ChildrenCoverage113.cons _ _ compact113_node_1890
    (ChildrenCoverage113.cons _ _ compact113_node_1891
    (ChildrenCoverage113.cons _ _ compact113_node_1892
    (ChildrenCoverage113.cons _ _ compact113_node_1893
    (ChildrenCoverage113.cons _ _ compact113_node_1894
    (ChildrenCoverage113.cons _ _ compact113_node_1895
    (ChildrenCoverage113.cons _ _ compact113_node_1896
    (ChildrenCoverage113.cons _ _ compact113_node_1897
    (ChildrenCoverage113.cons _ _ compact113_node_1898
    (ChildrenCoverage113.cons _ _ compact113_node_1899
    (ChildrenCoverage113.cons _ _ compact113_node_1900
    (ChildrenCoverage113.cons _ _ compact113_node_1901
    (ChildrenCoverage113.cons _ _ compact113_node_1902
    (ChildrenCoverage113.cons _ _ compact113_node_1903
    (ChildrenCoverage113.cons _ _ compact113_node_1904
    (ChildrenCoverage113.cons _ _ compact113_node_1905
    (ChildrenCoverage113.cons _ _ compact113_node_1906
    (ChildrenCoverage113.cons _ _ compact113_node_1907
    (ChildrenCoverage113.cons _ _ compact113_node_1908
    (ChildrenCoverage113.cons _ _ compact113_node_1909
    (ChildrenCoverage113.cons _ _ compact113_node_1910
    (ChildrenCoverage113.cons _ _ compact113_node_1911
    (ChildrenCoverage113.cons _ _ compact113_node_1930
    (ChildrenCoverage113.cons _ _ compact113_node_1931
    (ChildrenCoverage113.cons _ _ compact113_node_1932
    (ChildrenCoverage113.cons _ _ compact113_node_1933
    ChildrenCoverage113.nil))))))))))))))))))))))))))))))))

theorem compact113_node_1935 : NodeCoverage113 [35,34] 34 44 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1936 : NodeCoverage113 [35,33] 33 45 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1937 : NodeCoverage113 [35,32] 32 46 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1938 : NodeCoverage113 [35,31] 31 47 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1939 : NodeCoverage113 [35,30] 30 48 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1940 : NodeCoverage113 [35,29] 29 49 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1941 : NodeCoverage113 [35,28] 28 50 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1942 : NodeCoverage113 [35,27] 27 51 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1943 : NodeCoverage113 [35,26] 26 52 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1944 : NodeCoverage113 [35,25] 25 53 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1945 : NodeCoverage113 [35,24] 24 54 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1946 : NodeCoverage113 [35,23] 23 55 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1947 : NodeCoverage113 [35,22] 22 56 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1948 : NodeCoverage113 [35,21] 21 57 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1949 : NodeCoverage113 [35,20] 20 58 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1950 : NodeCoverage113 [35,19] 19 59 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1951 : NodeCoverage113 [35,18] 18 60 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1952 : NodeCoverage113 [35,17] 17 61 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1953 : NodeCoverage113 [35,16] 16 62 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_131

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5231 : NodeCoverage113 [15,15,15,15,15,15,12] 12 11 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5232 : NodeCoverage113 [15,15,15,15,15,15,11] 11 12 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5233 : NodeCoverage113 [15,15,15,15,15,15,10] 10 13 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5234 : NodeCoverage113 [15,15,15,15,15,15,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5235 : NodeCoverage113 [15,15,15,15,15,15,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5236 : NodeCoverage113 [15,15,15,15,15,15,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5237 : NodeCoverage113 [15,15,15,15,15,15,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5238 : NodeCoverage113 [15,15,15,15,15,15,5,5,5,5,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_5239 : NodeCoverage113 [15,15,15,15,15,15,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5238
    ChildrenCoverage113.nil)

theorem compact113_node_5240 : NodeCoverage113 [15,15,15,15,15,15,5,5,5,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_5241 : NodeCoverage113 [15,15,15,15,15,15,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5239
    (ChildrenCoverage113.cons _ _ compact113_node_5240
    ChildrenCoverage113.nil))

theorem compact113_node_5242 : NodeCoverage113 [15,15,15,15,15,15,5,5,3,3,3] 3 4 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_5243 : NodeCoverage113 [15,15,15,15,15,15,5,5,3,3] 3 7 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5242
    ChildrenCoverage113.nil)

theorem compact113_node_5244 : NodeCoverage113 [15,15,15,15,15,15,5,5,3] 3 10 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5243
    ChildrenCoverage113.nil)

theorem compact113_node_5245 : NodeCoverage113 [15,15,15,15,15,15,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5241
    (ChildrenCoverage113.cons _ _ compact113_node_5244
    ChildrenCoverage113.nil))

theorem compact113_node_5246 : NodeCoverage113 [15,15,15,15,15,15,5,3,3,3,3,3,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_5247 : NodeCoverage113 [15,15,15,15,15,15,5,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5246
    ChildrenCoverage113.nil)

theorem compact113_node_5248 : NodeCoverage113 [15,15,15,15,15,15,5,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5247
    ChildrenCoverage113.nil)

theorem compact113_node_5249 : NodeCoverage113 [15,15,15,15,15,15,5,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5248
    ChildrenCoverage113.nil)

theorem compact113_node_5250 : NodeCoverage113 [15,15,15,15,15,15,5,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5249
    ChildrenCoverage113.nil)

theorem compact113_node_5251 : NodeCoverage113 [15,15,15,15,15,15,5,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5250
    ChildrenCoverage113.nil)

theorem compact113_node_5252 : NodeCoverage113 [15,15,15,15,15,15,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5245
    (ChildrenCoverage113.cons _ _ compact113_node_5251
    ChildrenCoverage113.nil))

theorem compact113_node_5253 : NodeCoverage113 [15,15,15,15,15,15,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_5254 : NodeCoverage113 [15,15,15,15,15,15,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5253
    ChildrenCoverage113.nil)

theorem compact113_node_5255 : NodeCoverage113 [15,15,15,15,15,15,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5254
    ChildrenCoverage113.nil)

theorem compact113_node_5256 : NodeCoverage113 [15,15,15,15,15,15,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5255
    ChildrenCoverage113.nil)

theorem compact113_node_5257 : NodeCoverage113 [15,15,15,15,15,15,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5256
    ChildrenCoverage113.nil)

theorem compact113_node_5258 : NodeCoverage113 [15,15,15,15,15,15,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5257
    ChildrenCoverage113.nil)

theorem compact113_node_5259 : NodeCoverage113 [15,15,15,15,15,15] 15 23 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5228
    (ChildrenCoverage113.cons _ _ compact113_node_5229
    (ChildrenCoverage113.cons _ _ compact113_node_5230
    (ChildrenCoverage113.cons _ _ compact113_node_5231
    (ChildrenCoverage113.cons _ _ compact113_node_5232
    (ChildrenCoverage113.cons _ _ compact113_node_5233
    (ChildrenCoverage113.cons _ _ compact113_node_5234
    (ChildrenCoverage113.cons _ _ compact113_node_5235
    (ChildrenCoverage113.cons _ _ compact113_node_5236
    (ChildrenCoverage113.cons _ _ compact113_node_5237
    (ChildrenCoverage113.cons _ _ compact113_node_5252
    (ChildrenCoverage113.cons _ _ compact113_node_5258
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_5260 : NodeCoverage113 [15,15,15,15,15,14] 14 24 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5261 : NodeCoverage113 [15,15,15,15,15,13] 13 25 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5262 : NodeCoverage113 [15,15,15,15,15,12] 12 26 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5263 : NodeCoverage113 [15,15,15,15,15,11] 11 27 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5264 : NodeCoverage113 [15,15,15,15,15,10] 10 28 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5265 : NodeCoverage113 [15,15,15,15,15,9] 9 29 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5266 : NodeCoverage113 [15,15,15,15,15,8] 8 30 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5267 : NodeCoverage113 [15,15,15,15,15,7] 7 31 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5268 : NodeCoverage113 [15,15,15,15,15,6] 6 32 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5269 : NodeCoverage113 [15,15,15,15,15,5,5,5,5,5,5,5,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_5270 : NodeCoverage113 [15,15,15,15,15,5,5,5,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5269
    ChildrenCoverage113.nil)

theorem compact113_node_5271 : NodeCoverage113 [15,15,15,15,15,5,5,5,5,5,5,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_5272 : NodeCoverage113 [15,15,15,15,15,5,5,5,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5270
    (ChildrenCoverage113.cons _ _ compact113_node_5271
    ChildrenCoverage113.nil))

theorem compact113_node_5273 : NodeCoverage113 [15,15,15,15,15,5,5,5,5,5,3,3,3] 3 4 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_5274 : NodeCoverage113 [15,15,15,15,15,5,5,5,5,5,3,3] 3 7 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5273
    ChildrenCoverage113.nil)

theorem compact113_node_5275 : NodeCoverage113 [15,15,15,15,15,5,5,5,5,5,3] 3 10 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5274
    ChildrenCoverage113.nil)

theorem compact113_node_5276 : NodeCoverage113 [15,15,15,15,15,5,5,5,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5272
    (ChildrenCoverage113.cons _ _ compact113_node_5275
    ChildrenCoverage113.nil))

theorem compact113_node_5277 : NodeCoverage113 [15,15,15,15,15,5,5,5,5,3,3,3,3,3,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_5278 : NodeCoverage113 [15,15,15,15,15,5,5,5,5,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5277
    ChildrenCoverage113.nil)

theorem compact113_node_5279 : NodeCoverage113 [15,15,15,15,15,5,5,5,5,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5278
    ChildrenCoverage113.nil)

theorem compact113_node_5280 : NodeCoverage113 [15,15,15,15,15,5,5,5,5,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5279
    ChildrenCoverage113.nil)

theorem compact113_node_5281 : NodeCoverage113 [15,15,15,15,15,5,5,5,5,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5280
    ChildrenCoverage113.nil)

theorem compact113_node_5282 : NodeCoverage113 [15,15,15,15,15,5,5,5,5,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5281
    ChildrenCoverage113.nil)

theorem compact113_node_5283 : NodeCoverage113 [15,15,15,15,15,5,5,5,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5276
    (ChildrenCoverage113.cons _ _ compact113_node_5282
    ChildrenCoverage113.nil))

theorem compact113_node_5284 : NodeCoverage113 [15,15,15,15,15,5,5,5,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_5285 : NodeCoverage113 [15,15,15,15,15,5,5,5,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5284
    ChildrenCoverage113.nil)

theorem compact113_node_5286 : NodeCoverage113 [15,15,15,15,15,5,5,5,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5285
    ChildrenCoverage113.nil)

theorem compact113_node_5287 : NodeCoverage113 [15,15,15,15,15,5,5,5,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5286
    ChildrenCoverage113.nil)

theorem compact113_node_5288 : NodeCoverage113 [15,15,15,15,15,5,5,5,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5287
    ChildrenCoverage113.nil)

theorem compact113_node_5289 : NodeCoverage113 [15,15,15,15,15,5,5,5,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5288
    ChildrenCoverage113.nil)

theorem compact113_node_5290 : NodeCoverage113 [15,15,15,15,15,5,5,5] 5 23 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5283
    (ChildrenCoverage113.cons _ _ compact113_node_5289
    ChildrenCoverage113.nil))

theorem compact113_node_5291 : NodeCoverage113 [15,15,15,15,15,5,5,3,3,3,3,3,3,3,3] 3 4 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_5292 : NodeCoverage113 [15,15,15,15,15,5,5,3,3,3,3,3,3,3] 3 7 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5291
    ChildrenCoverage113.nil)

theorem compact113_node_5293 : NodeCoverage113 [15,15,15,15,15,5,5,3,3,3,3,3,3] 3 10 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5292
    ChildrenCoverage113.nil)

theorem compact113_node_5294 : NodeCoverage113 [15,15,15,15,15,5,5,3,3,3,3,3] 3 13 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5293
    ChildrenCoverage113.nil)

theorem compact113_node_5295 : NodeCoverage113 [15,15,15,15,15,5,5,3,3,3,3] 3 16 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5294
    ChildrenCoverage113.nil)

theorem compact113_node_5296 : NodeCoverage113 [15,15,15,15,15,5,5,3,3,3] 3 19 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5295
    ChildrenCoverage113.nil)

theorem compact113_node_5297 : NodeCoverage113 [15,15,15,15,15,5,5,3,3] 3 22 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5296
    ChildrenCoverage113.nil)

theorem compact113_node_5298 : NodeCoverage113 [15,15,15,15,15,5,5,3] 3 25 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5297
    ChildrenCoverage113.nil)

theorem compact113_node_5299 : NodeCoverage113 [15,15,15,15,15,5,5] 5 28 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5290
    (ChildrenCoverage113.cons _ _ compact113_node_5298
    ChildrenCoverage113.nil))

theorem compact113_node_5300 : NodeCoverage113 [15,15,15,15,15,5,3,3,3,3,3,3,3,3,3,3,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_5301 : NodeCoverage113 [15,15,15,15,15,5,3,3,3,3,3,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5300
    ChildrenCoverage113.nil)

theorem compact113_node_5302 : NodeCoverage113 [15,15,15,15,15,5,3,3,3,3,3,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5301
    ChildrenCoverage113.nil)

theorem compact113_node_5303 : NodeCoverage113 [15,15,15,15,15,5,3,3,3,3,3,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5302
    ChildrenCoverage113.nil)

theorem compact113_node_5304 : NodeCoverage113 [15,15,15,15,15,5,3,3,3,3,3,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5303
    ChildrenCoverage113.nil)

theorem compact113_node_5305 : NodeCoverage113 [15,15,15,15,15,5,3,3,3,3,3,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5304
    ChildrenCoverage113.nil)

end Symconf113

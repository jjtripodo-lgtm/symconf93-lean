import Symconf113.CoverageShard113_127

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5005 : NodeCoverage113 [17,17,17,17,9] 9 36 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5006 : NodeCoverage113 [17,17,17,17,8] 8 37 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5007 : NodeCoverage113 [17,17,17,17,7] 7 38 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5008 : NodeCoverage113 [17,17,17,17,6] 6 39 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5009 : NodeCoverage113 [17,17,17,17,5] 5 40 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5010 : NodeCoverage113 [17,17,17,17,3] 3 42 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5011 : NodeCoverage113 [17,17,17,17] 17 45 :=
  node_fork113 (B := [17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4997
    (ChildrenCoverage113.cons _ _ compact113_node_4998
    (ChildrenCoverage113.cons _ _ compact113_node_4999
    (ChildrenCoverage113.cons _ _ compact113_node_5000
    (ChildrenCoverage113.cons _ _ compact113_node_5001
    (ChildrenCoverage113.cons _ _ compact113_node_5002
    (ChildrenCoverage113.cons _ _ compact113_node_5003
    (ChildrenCoverage113.cons _ _ compact113_node_5004
    (ChildrenCoverage113.cons _ _ compact113_node_5005
    (ChildrenCoverage113.cons _ _ compact113_node_5006
    (ChildrenCoverage113.cons _ _ compact113_node_5007
    (ChildrenCoverage113.cons _ _ compact113_node_5008
    (ChildrenCoverage113.cons _ _ compact113_node_5009
    (ChildrenCoverage113.cons _ _ compact113_node_5010
    ChildrenCoverage113.nil))))))))))))))

theorem compact113_node_5012 : NodeCoverage113 [17,17,17,16] 16 46 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5013 : NodeCoverage113 [17,17,17,15] 15 47 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5014 : NodeCoverage113 [17,17,17,14] 14 48 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5015 : NodeCoverage113 [17,17,17,13] 13 49 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5016 : NodeCoverage113 [17,17,17,12] 12 50 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5017 : NodeCoverage113 [17,17,17,11] 11 51 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5018 : NodeCoverage113 [17,17,17,10] 10 52 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5019 : NodeCoverage113 [17,17,17,9] 9 53 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5020 : NodeCoverage113 [17,17,17,8] 8 54 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5021 : NodeCoverage113 [17,17,17,7] 7 55 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5022 : NodeCoverage113 [17,17,17,6] 6 56 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5023 : NodeCoverage113 [17,17,17,5] 5 57 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5024 : NodeCoverage113 [17,17,17,3] 3 59 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5025 : NodeCoverage113 [17,17,17] 17 62 :=
  node_fork113 (B := [17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5011
    (ChildrenCoverage113.cons _ _ compact113_node_5012
    (ChildrenCoverage113.cons _ _ compact113_node_5013
    (ChildrenCoverage113.cons _ _ compact113_node_5014
    (ChildrenCoverage113.cons _ _ compact113_node_5015
    (ChildrenCoverage113.cons _ _ compact113_node_5016
    (ChildrenCoverage113.cons _ _ compact113_node_5017
    (ChildrenCoverage113.cons _ _ compact113_node_5018
    (ChildrenCoverage113.cons _ _ compact113_node_5019
    (ChildrenCoverage113.cons _ _ compact113_node_5020
    (ChildrenCoverage113.cons _ _ compact113_node_5021
    (ChildrenCoverage113.cons _ _ compact113_node_5022
    (ChildrenCoverage113.cons _ _ compact113_node_5023
    (ChildrenCoverage113.cons _ _ compact113_node_5024
    ChildrenCoverage113.nil))))))))))))))

theorem compact113_node_5026 : NodeCoverage113 [17,17,16] 16 63 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5027 : NodeCoverage113 [17,17,15] 15 64 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5028 : NodeCoverage113 [17,17,14] 14 65 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5029 : NodeCoverage113 [17,17,13] 13 66 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5030 : NodeCoverage113 [17,17,12] 12 67 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5031 : NodeCoverage113 [17,17,11] 11 68 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5032 : NodeCoverage113 [17,17,10] 10 69 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5033 : NodeCoverage113 [17,17,9] 9 70 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5034 : NodeCoverage113 [17,17,8] 8 71 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5035 : NodeCoverage113 [17,17,7] 7 72 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5036 : NodeCoverage113 [17,17,6] 6 73 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5037 : NodeCoverage113 [17,17,5] 5 74 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5038 : NodeCoverage113 [17,17,3] 3 76 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5039 : NodeCoverage113 [17,17] 17 79 :=
  node_fork113 (B := [17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5025
    (ChildrenCoverage113.cons _ _ compact113_node_5026
    (ChildrenCoverage113.cons _ _ compact113_node_5027
    (ChildrenCoverage113.cons _ _ compact113_node_5028
    (ChildrenCoverage113.cons _ _ compact113_node_5029
    (ChildrenCoverage113.cons _ _ compact113_node_5030
    (ChildrenCoverage113.cons _ _ compact113_node_5031
    (ChildrenCoverage113.cons _ _ compact113_node_5032
    (ChildrenCoverage113.cons _ _ compact113_node_5033
    (ChildrenCoverage113.cons _ _ compact113_node_5034
    (ChildrenCoverage113.cons _ _ compact113_node_5035
    (ChildrenCoverage113.cons _ _ compact113_node_5036
    (ChildrenCoverage113.cons _ _ compact113_node_5037
    (ChildrenCoverage113.cons _ _ compact113_node_5038
    ChildrenCoverage113.nil))))))))))))))

theorem compact113_node_5040 : NodeCoverage113 [17,16] 16 80 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5041 : NodeCoverage113 [17,15] 15 81 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5042 : NodeCoverage113 [17,14] 14 82 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5043 : NodeCoverage113 [17,13] 13 83 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5044 : NodeCoverage113 [17,12] 12 84 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5045 : NodeCoverage113 [17,11] 11 85 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5046 : NodeCoverage113 [17,10] 10 86 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5047 : NodeCoverage113 [17,9] 9 87 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5048 : NodeCoverage113 [17,8] 8 88 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5049 : NodeCoverage113 [17,7] 7 89 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5050 : NodeCoverage113 [17,6] 6 90 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5051 : NodeCoverage113 [17,5] 5 91 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5052 : NodeCoverage113 [17,3] 3 93 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5053 : NodeCoverage113 [17] 17 96 :=
  node_fork113 (B := [17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5039
    (ChildrenCoverage113.cons _ _ compact113_node_5040
    (ChildrenCoverage113.cons _ _ compact113_node_5041
    (ChildrenCoverage113.cons _ _ compact113_node_5042
    (ChildrenCoverage113.cons _ _ compact113_node_5043
    (ChildrenCoverage113.cons _ _ compact113_node_5044
    (ChildrenCoverage113.cons _ _ compact113_node_5045
    (ChildrenCoverage113.cons _ _ compact113_node_5046
    (ChildrenCoverage113.cons _ _ compact113_node_5047
    (ChildrenCoverage113.cons _ _ compact113_node_5048
    (ChildrenCoverage113.cons _ _ compact113_node_5049
    (ChildrenCoverage113.cons _ _ compact113_node_5050
    (ChildrenCoverage113.cons _ _ compact113_node_5051
    (ChildrenCoverage113.cons _ _ compact113_node_5052
    ChildrenCoverage113.nil))))))))))))))

theorem compact113_node_5054 : NodeCoverage113 [16,16,16,16,16,16,14] 14 3 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5055 : NodeCoverage113 [16,16,16,16,16,16,13] 13 4 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5056 : NodeCoverage113 [16,16,16,16,16,16,12] 12 5 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5057 : NodeCoverage113 [16,16,16,16,16,16,11] 11 6 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5058 : NodeCoverage113 [16,16,16,16,16,16,10] 10 7 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5059 : NodeCoverage113 [16,16,16,16,16,16,9] 9 8 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5060 : NodeCoverage113 [16,16,16,16,16,16,8] 8 9 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5061 : NodeCoverage113 [16,16,16,16,16,16,7] 7 10 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5062 : NodeCoverage113 [16,16,16,16,16,16,6] 6 11 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5063 : NodeCoverage113 [16,16,16,16,16,16,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5064 : NodeCoverage113 [16,16,16,16,16,16,3] 3 14 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5065 : NodeCoverage113 [16,16,16,16,16,16] 16 17 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5054
    (ChildrenCoverage113.cons _ _ compact113_node_5055
    (ChildrenCoverage113.cons _ _ compact113_node_5056
    (ChildrenCoverage113.cons _ _ compact113_node_5057
    (ChildrenCoverage113.cons _ _ compact113_node_5058
    (ChildrenCoverage113.cons _ _ compact113_node_5059
    (ChildrenCoverage113.cons _ _ compact113_node_5060
    (ChildrenCoverage113.cons _ _ compact113_node_5061
    (ChildrenCoverage113.cons _ _ compact113_node_5062
    (ChildrenCoverage113.cons _ _ compact113_node_5063
    (ChildrenCoverage113.cons _ _ compact113_node_5064
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_5066 : NodeCoverage113 [16,16,16,16,16,15] 15 18 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5067 : NodeCoverage113 [16,16,16,16,16,14] 14 19 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5068 : NodeCoverage113 [16,16,16,16,16,13] 13 20 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5069 : NodeCoverage113 [16,16,16,16,16,12] 12 21 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

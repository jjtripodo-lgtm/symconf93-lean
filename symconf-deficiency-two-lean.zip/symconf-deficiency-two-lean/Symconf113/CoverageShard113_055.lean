import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2249 : NodeCoverage113 [30,30,30,17] 17 6 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2250 : NodeCoverage113 [30,30,30,16] 16 7 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2251 : NodeCoverage113 [30,30,30,15,8] 8 0 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2252 : NodeCoverage113 [30,30,30,15,5,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_2253 : NodeCoverage113 [30,30,30,15,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2252
    ChildrenCoverage113.nil)

theorem compact113_node_2254 : NodeCoverage113 [30,30,30,15,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_2255 : NodeCoverage113 [30,30,30,15] 15 8 :=
  node_fork113 (B := [8,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2251
    (ChildrenCoverage113.cons _ _ compact113_node_2253
    (ChildrenCoverage113.cons _ _ compact113_node_2254
    ChildrenCoverage113.nil)))

theorem compact113_node_2256 : NodeCoverage113 [30,30,30,14] 14 9 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2257 : NodeCoverage113 [30,30,30,13] 13 10 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2258 : NodeCoverage113 [30,30,30,12] 12 11 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2259 : NodeCoverage113 [30,30,30,11] 11 12 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2260 : NodeCoverage113 [30,30,30,10,10] 10 3 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2261 : NodeCoverage113 [30,30,30,10,9] 9 4 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2262 : NodeCoverage113 [30,30,30,10,8] 8 5 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2263 : NodeCoverage113 [30,30,30,10,7] 7 6 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2264 : NodeCoverage113 [30,30,30,10,6] 6 7 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2265 : NodeCoverage113 [30,30,30,10,5,5,3] 3 0 :=
  node_no_weak_demand113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2266 : NodeCoverage113 [30,30,30,10,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2265
    ChildrenCoverage113.nil)

theorem compact113_node_2267 : NodeCoverage113 [30,30,30,10,5,3] 3 5 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2268 : NodeCoverage113 [30,30,30,10,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2266
    (ChildrenCoverage113.cons _ _ compact113_node_2267
    ChildrenCoverage113.nil))

theorem compact113_node_2269 : NodeCoverage113 [30,30,30,10,3] 3 10 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2270 : NodeCoverage113 [30,30,30,10] 10 13 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2260
    (ChildrenCoverage113.cons _ _ compact113_node_2261
    (ChildrenCoverage113.cons _ _ compact113_node_2262
    (ChildrenCoverage113.cons _ _ compact113_node_2263
    (ChildrenCoverage113.cons _ _ compact113_node_2264
    (ChildrenCoverage113.cons _ _ compact113_node_2268
    (ChildrenCoverage113.cons _ _ compact113_node_2269
    ChildrenCoverage113.nil)))))))

theorem compact113_node_2271 : NodeCoverage113 [30,30,30,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2272 : NodeCoverage113 [30,30,30,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2273 : NodeCoverage113 [30,30,30,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2274 : NodeCoverage113 [30,30,30,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2275 : NodeCoverage113 [30,30,30,5] 5 18 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

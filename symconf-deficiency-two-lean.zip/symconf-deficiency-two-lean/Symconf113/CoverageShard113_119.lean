import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4574 : NodeCoverage113 [18,18,15] 15 62 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4575 : NodeCoverage113 [18,18,14,14] 14 49 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4576 : NodeCoverage113 [18,18,14,13] 13 50 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4577 : NodeCoverage113 [18,18,14,12] 12 51 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4578 : NodeCoverage113 [18,18,14,11] 11 52 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4579 : NodeCoverage113 [18,18,14,10] 10 53 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4580 : NodeCoverage113 [18,18,14,9] 9 54 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4581 : NodeCoverage113 [18,18,14,8] 8 55 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4582 : NodeCoverage113 [18,18,14,7] 7 56 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4583 : NodeCoverage113 [18,18,14,6] 6 57 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4584 : NodeCoverage113 [18,18,14,5] 5 58 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4585 : NodeCoverage113 [18,18,14,3] 3 60 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4586 : NodeCoverage113 [18,18,14] 14 63 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4575
    (ChildrenCoverage113.cons _ _ compact113_node_4576
    (ChildrenCoverage113.cons _ _ compact113_node_4577
    (ChildrenCoverage113.cons _ _ compact113_node_4578
    (ChildrenCoverage113.cons _ _ compact113_node_4579
    (ChildrenCoverage113.cons _ _ compact113_node_4580
    (ChildrenCoverage113.cons _ _ compact113_node_4581
    (ChildrenCoverage113.cons _ _ compact113_node_4582
    (ChildrenCoverage113.cons _ _ compact113_node_4583
    (ChildrenCoverage113.cons _ _ compact113_node_4584
    (ChildrenCoverage113.cons _ _ compact113_node_4585
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_4587 : NodeCoverage113 [18,18,13] 13 64 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4588 : NodeCoverage113 [18,18,12] 12 65 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4589 : NodeCoverage113 [18,18,11,11,11] 11 44 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4590 : NodeCoverage113 [18,18,11,11,10] 10 45 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4591 : NodeCoverage113 [18,18,11,11,9] 9 46 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4592 : NodeCoverage113 [18,18,11,11,8] 8 47 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4593 : NodeCoverage113 [18,18,11,11,7] 7 48 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4594 : NodeCoverage113 [18,18,11,11,6] 6 49 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4595 : NodeCoverage113 [18,18,11,11,5] 5 50 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4596 : NodeCoverage113 [18,18,11,11,3] 3 52 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4597 : NodeCoverage113 [18,18,11,11] 11 55 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4589
    (ChildrenCoverage113.cons _ _ compact113_node_4590
    (ChildrenCoverage113.cons _ _ compact113_node_4591
    (ChildrenCoverage113.cons _ _ compact113_node_4592
    (ChildrenCoverage113.cons _ _ compact113_node_4593
    (ChildrenCoverage113.cons _ _ compact113_node_4594
    (ChildrenCoverage113.cons _ _ compact113_node_4595
    (ChildrenCoverage113.cons _ _ compact113_node_4596
    ChildrenCoverage113.nil))))))))

theorem compact113_node_4598 : NodeCoverage113 [18,18,11,10] 10 56 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4599 : NodeCoverage113 [18,18,11,9] 9 57 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4600 : NodeCoverage113 [18,18,11,8] 8 58 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4601 : NodeCoverage113 [18,18,11,7] 7 59 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4602 : NodeCoverage113 [18,18,11,6] 6 60 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4603 : NodeCoverage113 [18,18,11,5] 5 61 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4604 : NodeCoverage113 [18,18,11,3] 3 63 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4605 : NodeCoverage113 [18,18,11] 11 66 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4597
    (ChildrenCoverage113.cons _ _ compact113_node_4598
    (ChildrenCoverage113.cons _ _ compact113_node_4599
    (ChildrenCoverage113.cons _ _ compact113_node_4600
    (ChildrenCoverage113.cons _ _ compact113_node_4601
    (ChildrenCoverage113.cons _ _ compact113_node_4602
    (ChildrenCoverage113.cons _ _ compact113_node_4603
    (ChildrenCoverage113.cons _ _ compact113_node_4604
    ChildrenCoverage113.nil))))))))

theorem compact113_node_4606 : NodeCoverage113 [18,18,10,10,10] 10 47 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4607 : NodeCoverage113 [18,18,10,10,9] 9 48 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4608 : NodeCoverage113 [18,18,10,10,8] 8 49 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4609 : NodeCoverage113 [18,18,10,10,7] 7 50 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4610 : NodeCoverage113 [18,18,10,10,6] 6 51 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4611 : NodeCoverage113 [18,18,10,10,5] 5 52 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4612 : NodeCoverage113 [18,18,10,10,3] 3 54 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4613 : NodeCoverage113 [18,18,10,10] 10 57 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4606
    (ChildrenCoverage113.cons _ _ compact113_node_4607
    (ChildrenCoverage113.cons _ _ compact113_node_4608
    (ChildrenCoverage113.cons _ _ compact113_node_4609
    (ChildrenCoverage113.cons _ _ compact113_node_4610
    (ChildrenCoverage113.cons _ _ compact113_node_4611
    (ChildrenCoverage113.cons _ _ compact113_node_4612
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4614 : NodeCoverage113 [18,18,10,9] 9 58 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4615 : NodeCoverage113 [18,18,10,8] 8 59 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4616 : NodeCoverage113 [18,18,10,7] 7 60 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4617 : NodeCoverage113 [18,18,10,6] 6 61 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4618 : NodeCoverage113 [18,18,10,5] 5 62 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4619 : NodeCoverage113 [18,18,10,3] 3 64 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4620 : NodeCoverage113 [18,18,10] 10 67 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4613
    (ChildrenCoverage113.cons _ _ compact113_node_4614
    (ChildrenCoverage113.cons _ _ compact113_node_4615
    (ChildrenCoverage113.cons _ _ compact113_node_4616
    (ChildrenCoverage113.cons _ _ compact113_node_4617
    (ChildrenCoverage113.cons _ _ compact113_node_4618
    (ChildrenCoverage113.cons _ _ compact113_node_4619
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4621 : NodeCoverage113 [18,18,9,9,9,9,9,9,9,9,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4622 : NodeCoverage113 [18,18,9,9,9,9,9,9,9,9] 9 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4621
    ChildrenCoverage113.nil)

theorem compact113_node_4623 : NodeCoverage113 [18,18,9,9,9,9,9,9,9,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4624 : NodeCoverage113 [18,18,9,9,9,9,9,9,9,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4625 : NodeCoverage113 [18,18,9,9,9,9,9,9,9,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_099

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3523 : NodeCoverage113 [22,22,22,18] 18 29 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3524 : NodeCoverage113 [22,22,22,17] 17 30 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3525 : NodeCoverage113 [22,22,22,16] 16 31 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3526 : NodeCoverage113 [22,22,22,15] 15 32 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3527 : NodeCoverage113 [22,22,22,14] 14 33 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3528 : NodeCoverage113 [22,22,22,13] 13 34 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3529 : NodeCoverage113 [22,22,22,12] 12 35 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3530 : NodeCoverage113 [22,22,22,11,11,11,11,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3531 : NodeCoverage113 [22,22,22,11,11,11,11] 11 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3530
    ChildrenCoverage113.nil)

theorem compact113_node_3532 : NodeCoverage113 [22,22,22,11,11,11,10] 10 4 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3533 : NodeCoverage113 [22,22,22,11,11,11,9] 9 5 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3534 : NodeCoverage113 [22,22,22,11,11,11,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3535 : NodeCoverage113 [22,22,22,11,11,11,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3536 : NodeCoverage113 [22,22,22,11,11,11,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3537 : NodeCoverage113 [22,22,22,11,11,11,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3538 : NodeCoverage113 [22,22,22,11,11,11,3] 3 11 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3539 : NodeCoverage113 [22,22,22,11,11,11] 11 14 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3531
    (ChildrenCoverage113.cons _ _ compact113_node_3532
    (ChildrenCoverage113.cons _ _ compact113_node_3533
    (ChildrenCoverage113.cons _ _ compact113_node_3534
    (ChildrenCoverage113.cons _ _ compact113_node_3535
    (ChildrenCoverage113.cons _ _ compact113_node_3536
    (ChildrenCoverage113.cons _ _ compact113_node_3537
    (ChildrenCoverage113.cons _ _ compact113_node_3538
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3540 : NodeCoverage113 [22,22,22,11,11,10] 10 15 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3541 : NodeCoverage113 [22,22,22,11,11,9] 9 16 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3542 : NodeCoverage113 [22,22,22,11,11,8] 8 17 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3543 : NodeCoverage113 [22,22,22,11,11,7] 7 18 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3544 : NodeCoverage113 [22,22,22,11,11,6] 6 19 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3545 : NodeCoverage113 [22,22,22,11,11,5] 5 20 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3546 : NodeCoverage113 [22,22,22,11,11,3] 3 22 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3547 : NodeCoverage113 [22,22,22,11,11] 11 25 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3539
    (ChildrenCoverage113.cons _ _ compact113_node_3540
    (ChildrenCoverage113.cons _ _ compact113_node_3541
    (ChildrenCoverage113.cons _ _ compact113_node_3542
    (ChildrenCoverage113.cons _ _ compact113_node_3543
    (ChildrenCoverage113.cons _ _ compact113_node_3544
    (ChildrenCoverage113.cons _ _ compact113_node_3545
    (ChildrenCoverage113.cons _ _ compact113_node_3546
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3548 : NodeCoverage113 [22,22,22,11,10] 10 26 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3549 : NodeCoverage113 [22,22,22,11,9] 9 27 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3550 : NodeCoverage113 [22,22,22,11,8] 8 28 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3551 : NodeCoverage113 [22,22,22,11,7] 7 29 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3552 : NodeCoverage113 [22,22,22,11,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3553 : NodeCoverage113 [22,22,22,11,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3554 : NodeCoverage113 [22,22,22,11,3] 3 33 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3555 : NodeCoverage113 [22,22,22,11] 11 36 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3547
    (ChildrenCoverage113.cons _ _ compact113_node_3548
    (ChildrenCoverage113.cons _ _ compact113_node_3549
    (ChildrenCoverage113.cons _ _ compact113_node_3550
    (ChildrenCoverage113.cons _ _ compact113_node_3551
    (ChildrenCoverage113.cons _ _ compact113_node_3552
    (ChildrenCoverage113.cons _ _ compact113_node_3553
    (ChildrenCoverage113.cons _ _ compact113_node_3554
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3556 : NodeCoverage113 [22,22,22,10] 10 37 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3557 : NodeCoverage113 [22,22,22,9] 9 38 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3558 : NodeCoverage113 [22,22,22,8] 8 39 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3559 : NodeCoverage113 [22,22,22,7] 7 40 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3560 : NodeCoverage113 [22,22,22,6] 6 41 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3561 : NodeCoverage113 [22,22,22,5] 5 42 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3562 : NodeCoverage113 [22,22,22,3] 3 44 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3563 : NodeCoverage113 [22,22,22] 22 47 :=
  node_fork113 (B := [22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3519
    (ChildrenCoverage113.cons _ _ compact113_node_3520
    (ChildrenCoverage113.cons _ _ compact113_node_3521
    (ChildrenCoverage113.cons _ _ compact113_node_3522
    (ChildrenCoverage113.cons _ _ compact113_node_3523
    (ChildrenCoverage113.cons _ _ compact113_node_3524
    (ChildrenCoverage113.cons _ _ compact113_node_3525
    (ChildrenCoverage113.cons _ _ compact113_node_3526
    (ChildrenCoverage113.cons _ _ compact113_node_3527
    (ChildrenCoverage113.cons _ _ compact113_node_3528
    (ChildrenCoverage113.cons _ _ compact113_node_3529
    (ChildrenCoverage113.cons _ _ compact113_node_3555
    (ChildrenCoverage113.cons _ _ compact113_node_3556
    (ChildrenCoverage113.cons _ _ compact113_node_3557
    (ChildrenCoverage113.cons _ _ compact113_node_3558
    (ChildrenCoverage113.cons _ _ compact113_node_3559
    (ChildrenCoverage113.cons _ _ compact113_node_3560
    (ChildrenCoverage113.cons _ _ compact113_node_3561
    (ChildrenCoverage113.cons _ _ compact113_node_3562
    ChildrenCoverage113.nil)))))))))))))))))))

theorem compact113_node_3564 : NodeCoverage113 [22,22,21] 21 48 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3565 : NodeCoverage113 [22,22,20] 20 49 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3566 : NodeCoverage113 [22,22,19] 19 50 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3567 : NodeCoverage113 [22,22,18] 18 51 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3568 : NodeCoverage113 [22,22,17] 17 52 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3569 : NodeCoverage113 [22,22,16] 16 53 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3570 : NodeCoverage113 [22,22,15] 15 54 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

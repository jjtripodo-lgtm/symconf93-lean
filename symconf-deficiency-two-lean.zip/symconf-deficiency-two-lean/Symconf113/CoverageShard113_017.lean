import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0732 : NodeCoverage113 [48,21] 21 44 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0733 : NodeCoverage113 [48,20] 20 45 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0734 : NodeCoverage113 [48,19] 19 46 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0735 : NodeCoverage113 [48,18] 18 47 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0736 : NodeCoverage113 [48,17] 17 48 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0737 : NodeCoverage113 [48,16,16,16] 16 17 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0738 : NodeCoverage113 [48,16,16,15] 15 18 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0739 : NodeCoverage113 [48,16,16,14] 14 19 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0740 : NodeCoverage113 [48,16,16,13] 13 20 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0741 : NodeCoverage113 [48,16,16,12,12,9] 9 0 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0742 : NodeCoverage113 [48,16,16,12,12,6] 6 3 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0743 : NodeCoverage113 [48,16,16,12,12,5] 5 4 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0744 : NodeCoverage113 [48,16,16,12,12,3] 3 6 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0745 : NodeCoverage113 [48,16,16,12,12] 12 9 :=
  node_fork113 (B := [9,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0741
    (ChildrenCoverage113.cons _ _ compact113_node_0742
    (ChildrenCoverage113.cons _ _ compact113_node_0743
    (ChildrenCoverage113.cons _ _ compact113_node_0744
    ChildrenCoverage113.nil))))

theorem compact113_node_0746 : NodeCoverage113 [48,16,16,12,11] 11 10 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0747 : NodeCoverage113 [48,16,16,12,10] 10 11 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0748 : NodeCoverage113 [48,16,16,12,9] 9 12 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0749 : NodeCoverage113 [48,16,16,12,8] 8 13 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0750 : NodeCoverage113 [48,16,16,12,7] 7 14 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0751 : NodeCoverage113 [48,16,16,12,6] 6 15 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0752 : NodeCoverage113 [48,16,16,12,5] 5 16 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0753 : NodeCoverage113 [48,16,16,12,3] 3 18 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0754 : NodeCoverage113 [48,16,16,12] 12 21 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0745
    (ChildrenCoverage113.cons _ _ compact113_node_0746
    (ChildrenCoverage113.cons _ _ compact113_node_0747
    (ChildrenCoverage113.cons _ _ compact113_node_0748
    (ChildrenCoverage113.cons _ _ compact113_node_0749
    (ChildrenCoverage113.cons _ _ compact113_node_0750
    (ChildrenCoverage113.cons _ _ compact113_node_0751
    (ChildrenCoverage113.cons _ _ compact113_node_0752
    (ChildrenCoverage113.cons _ _ compact113_node_0753
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_0755 : NodeCoverage113 [48,16,16,11] 11 22 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0756 : NodeCoverage113 [48,16,16,10] 10 23 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0757 : NodeCoverage113 [48,16,16,9] 9 24 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0758 : NodeCoverage113 [48,16,16,8] 8 25 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0759 : NodeCoverage113 [48,16,16,7] 7 26 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0760 : NodeCoverage113 [48,16,16,6] 6 27 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0761 : NodeCoverage113 [48,16,16,5] 5 28 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0762 : NodeCoverage113 [48,16,16,3] 3 30 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0763 : NodeCoverage113 [48,16,16] 16 33 :=
  node_fork113 (B := [16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0737
    (ChildrenCoverage113.cons _ _ compact113_node_0738
    (ChildrenCoverage113.cons _ _ compact113_node_0739
    (ChildrenCoverage113.cons _ _ compact113_node_0740
    (ChildrenCoverage113.cons _ _ compact113_node_0754
    (ChildrenCoverage113.cons _ _ compact113_node_0755
    (ChildrenCoverage113.cons _ _ compact113_node_0756
    (ChildrenCoverage113.cons _ _ compact113_node_0757
    (ChildrenCoverage113.cons _ _ compact113_node_0758
    (ChildrenCoverage113.cons _ _ compact113_node_0759
    (ChildrenCoverage113.cons _ _ compact113_node_0760
    (ChildrenCoverage113.cons _ _ compact113_node_0761
    (ChildrenCoverage113.cons _ _ compact113_node_0762
    ChildrenCoverage113.nil)))))))))))))

theorem compact113_node_0764 : NodeCoverage113 [48,16,15] 15 34 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0765 : NodeCoverage113 [48,16,14] 14 35 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0766 : NodeCoverage113 [48,16,13] 13 36 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0767 : NodeCoverage113 [48,16,12] 12 37 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0768 : NodeCoverage113 [48,16,11] 11 38 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0769 : NodeCoverage113 [48,16,10] 10 39 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0770 : NodeCoverage113 [48,16,9] 9 40 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0771 : NodeCoverage113 [48,16,8] 8 41 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0772 : NodeCoverage113 [48,16,7] 7 42 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0773 : NodeCoverage113 [48,16,6] 6 43 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0774 : NodeCoverage113 [48,16,5] 5 44 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0775 : NodeCoverage113 [48,16,3] 3 46 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0776 : NodeCoverage113 [48,16] 16 49 :=
  node_fork113 (B := [16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0763
    (ChildrenCoverage113.cons _ _ compact113_node_0764
    (ChildrenCoverage113.cons _ _ compact113_node_0765
    (ChildrenCoverage113.cons _ _ compact113_node_0766
    (ChildrenCoverage113.cons _ _ compact113_node_0767
    (ChildrenCoverage113.cons _ _ compact113_node_0768
    (ChildrenCoverage113.cons _ _ compact113_node_0769
    (ChildrenCoverage113.cons _ _ compact113_node_0770
    (ChildrenCoverage113.cons _ _ compact113_node_0771
    (ChildrenCoverage113.cons _ _ compact113_node_0772
    (ChildrenCoverage113.cons _ _ compact113_node_0773
    (ChildrenCoverage113.cons _ _ compact113_node_0774
    (ChildrenCoverage113.cons _ _ compact113_node_0775
    ChildrenCoverage113.nil)))))))))))))

end Symconf113

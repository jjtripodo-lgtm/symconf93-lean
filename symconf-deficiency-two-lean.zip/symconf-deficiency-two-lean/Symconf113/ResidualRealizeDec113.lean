import Symconf113.ResidualRealizeShard113_0
import Symconf113.ResidualRealizeShard113_1
import Symconf113.ResidualRealizeShard113_2
import Symconf113.ResidualRealizeShard113_3
import Symconf113.ResidualRealizeShard113_4
import Symconf113.ResidualRealizeShard113_5
import Symconf113.ResidualRealizeShard113_6
import Symconf113.ResidualRealizeShard113_7
import Symconf113.ResidualRealizeShard113_8
import Symconf113.ResidualRealizeShard113_9
import Symconf113.ResidualRealizeShard113_10
import Symconf113.ResidualRealizeShard113_11
import Symconf113.ResidualRealizeShard113_12
import Symconf113.ResidualRealizeShard113_13
import Symconf113.ResidualRealizeShard113_14
import Symconf113.ResidualRealizeShard113_15
import Symconf113.ResidualRealizeShard113_16
import Symconf113.ResidualRealizeShard113_17
import Symconf113.ResidualRealizeShard113_18
import Symconf113.ResidualRealizeShard113_19
import Symconf113.ResidualRealizeShard113_20
import Symconf113.ResidualRealizeShard113_21
import Symconf113.ResidualRealizeShard113_22
import Symconf113.ResidualRealizeShard113_23
import Symconf113.ResidualRealizeShard113_24
import Symconf113.ResidualRealizeShard113_25
import Symconf113.ResidualRealizeShard113_26
import Symconf113.ResidualRealizeShard113_27
import Symconf113.ResidualRealizeShard113_28
import Symconf113.ResidualRealizeShard113_29
import Symconf113.ResidualRealizeShard113_30
import Symconf113.ResidualRealizeShard113_31

/-! Kernel check over all `2^15` subsets of `ZMod 15`, assembled from 32
shards: with no adjacent pair and every nonzero autocorrelation at most
one, the signature is in `realList`. -/
namespace Symconf113

theorem realize_dec : ∀ l ∈ bools15,
    acL l 1=0 → ((List.range 14).all fun t => decide (acL l (t+1)≤1))=true →
      sigL l ∈ realList (cntL l) := by
  intro l hl h1 h2
  have hB : realB l=true := by
    unfold bools15 at hl
    rw [show (15 : ℕ)=10+1+1+1+1+1 from rfl, prodL_rep_succ, prodL_rep_succ, prodL_rep_succ,
      prodL_rep_succ, prodL_rep_succ] at hl
    simp only [List.mem_flatMap, List.mem_map, List.mem_cons, List.not_mem_nil, or_false] at hl
    obtain ⟨a,ha,l1,⟨b,hb,l2,⟨c,hc,l3,⟨d,hd,l4,⟨e,he,l5,hl5,rfl⟩,rfl⟩,rfl⟩,rfl⟩,rfl⟩ := hl
    change l5 ∈ bools10 at hl5
    rcases ha with rfl|rfl <;> rcases hb with rfl|rfl <;> rcases hc with rfl|rfl <;>
      rcases hd with rfl|rfl <;> rcases he with rfl|rfl
    · exact List.all_eq_true.mp realShard_0 _ hl5
    · exact List.all_eq_true.mp realShard_1 _ hl5
    · exact List.all_eq_true.mp realShard_2 _ hl5
    · exact List.all_eq_true.mp realShard_3 _ hl5
    · exact List.all_eq_true.mp realShard_4 _ hl5
    · exact List.all_eq_true.mp realShard_5 _ hl5
    · exact List.all_eq_true.mp realShard_6 _ hl5
    · exact List.all_eq_true.mp realShard_7 _ hl5
    · exact List.all_eq_true.mp realShard_8 _ hl5
    · exact List.all_eq_true.mp realShard_9 _ hl5
    · exact List.all_eq_true.mp realShard_10 _ hl5
    · exact List.all_eq_true.mp realShard_11 _ hl5
    · exact List.all_eq_true.mp realShard_12 _ hl5
    · exact List.all_eq_true.mp realShard_13 _ hl5
    · exact List.all_eq_true.mp realShard_14 _ hl5
    · exact List.all_eq_true.mp realShard_15 _ hl5
    · exact List.all_eq_true.mp realShard_16 _ hl5
    · exact List.all_eq_true.mp realShard_17 _ hl5
    · exact List.all_eq_true.mp realShard_18 _ hl5
    · exact List.all_eq_true.mp realShard_19 _ hl5
    · exact List.all_eq_true.mp realShard_20 _ hl5
    · exact List.all_eq_true.mp realShard_21 _ hl5
    · exact List.all_eq_true.mp realShard_22 _ hl5
    · exact List.all_eq_true.mp realShard_23 _ hl5
    · exact List.all_eq_true.mp realShard_24 _ hl5
    · exact List.all_eq_true.mp realShard_25 _ hl5
    · exact List.all_eq_true.mp realShard_26 _ hl5
    · exact List.all_eq_true.mp realShard_27 _ hl5
    · exact List.all_eq_true.mp realShard_28 _ hl5
    · exact List.all_eq_true.mp realShard_29 _ hl5
    · exact List.all_eq_true.mp realShard_30 _ hl5
    · exact List.all_eq_true.mp realShard_31 _ hl5
  unfold realB at hB
  simp only [h1, h2, beq_self_eq_true, Bool.not_true, Bool.false_or, decide_eq_true_eq] at hB
  exact hB

end Symconf113

import Symconf113.CoverageShard113_027

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1169 : NodeCoverage113 [40,40,24] 24 9 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1170 : NodeCoverage113 [40,40,23] 23 10 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1171 : NodeCoverage113 [40,40,22] 22 11 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1172 : NodeCoverage113 [40,40,21] 21 12 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1173 : NodeCoverage113 [40,40,20,13] 13 0 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1174 : NodeCoverage113 [40,40,20,10] 10 3 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1175 : NodeCoverage113 [40,40,20,9] 9 4 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1176 : NodeCoverage113 [40,40,20,8] 8 5 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1177 : NodeCoverage113 [40,40,20,7] 7 6 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1178 : NodeCoverage113 [40,40,20,6] 6 7 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1179 : NodeCoverage113 [40,40,20,5] 5 8 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1180 : NodeCoverage113 [40,40,20,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1181 : NodeCoverage113 [40,40,20] 20 13 :=
  node_fork113 (B := [13,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1173
    (ChildrenCoverage113.cons _ _ compact113_node_1174
    (ChildrenCoverage113.cons _ _ compact113_node_1175
    (ChildrenCoverage113.cons _ _ compact113_node_1176
    (ChildrenCoverage113.cons _ _ compact113_node_1177
    (ChildrenCoverage113.cons _ _ compact113_node_1178
    (ChildrenCoverage113.cons _ _ compact113_node_1179
    (ChildrenCoverage113.cons _ _ compact113_node_1180
    ChildrenCoverage113.nil))))))))

theorem compact113_node_1182 : NodeCoverage113 [40,40,19] 19 14 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1183 : NodeCoverage113 [40,40,18] 18 15 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1184 : NodeCoverage113 [40,40,17] 17 16 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1185 : NodeCoverage113 [40,40,16] 16 17 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1186 : NodeCoverage113 [40,40,15] 15 18 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1187 : NodeCoverage113 [40,40,14] 14 19 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1188 : NodeCoverage113 [40,40,13] 13 20 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1189 : NodeCoverage113 [40,40,12] 12 21 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1190 : NodeCoverage113 [40,40,11] 11 22 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1191 : NodeCoverage113 [40,40,10] 10 23 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1192 : NodeCoverage113 [40,40,9] 9 24 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1193 : NodeCoverage113 [40,40,8] 8 25 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1194 : NodeCoverage113 [40,40,7] 7 26 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1195 : NodeCoverage113 [40,40,6] 6 27 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1196 : NodeCoverage113 [40,40,5] 5 28 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1197 : NodeCoverage113 [40,40,3] 3 30 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1198 : NodeCoverage113 [40,40] 40 33 :=
  node_fork113 (B := [33,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1162
    (ChildrenCoverage113.cons _ _ compact113_node_1163
    (ChildrenCoverage113.cons _ _ compact113_node_1164
    (ChildrenCoverage113.cons _ _ compact113_node_1165
    (ChildrenCoverage113.cons _ _ compact113_node_1166
    (ChildrenCoverage113.cons _ _ compact113_node_1167
    (ChildrenCoverage113.cons _ _ compact113_node_1168
    (ChildrenCoverage113.cons _ _ compact113_node_1169
    (ChildrenCoverage113.cons _ _ compact113_node_1170
    (ChildrenCoverage113.cons _ _ compact113_node_1171
    (ChildrenCoverage113.cons _ _ compact113_node_1172
    (ChildrenCoverage113.cons _ _ compact113_node_1181
    (ChildrenCoverage113.cons _ _ compact113_node_1182
    (ChildrenCoverage113.cons _ _ compact113_node_1183
    (ChildrenCoverage113.cons _ _ compact113_node_1184
    (ChildrenCoverage113.cons _ _ compact113_node_1185
    (ChildrenCoverage113.cons _ _ compact113_node_1186
    (ChildrenCoverage113.cons _ _ compact113_node_1187
    (ChildrenCoverage113.cons _ _ compact113_node_1188
    (ChildrenCoverage113.cons _ _ compact113_node_1189
    (ChildrenCoverage113.cons _ _ compact113_node_1190
    (ChildrenCoverage113.cons _ _ compact113_node_1191
    (ChildrenCoverage113.cons _ _ compact113_node_1192
    (ChildrenCoverage113.cons _ _ compact113_node_1193
    (ChildrenCoverage113.cons _ _ compact113_node_1194
    (ChildrenCoverage113.cons _ _ compact113_node_1195
    (ChildrenCoverage113.cons _ _ compact113_node_1196
    (ChildrenCoverage113.cons _ _ compact113_node_1197
    ChildrenCoverage113.nil))))))))))))))))))))))))))))

theorem compact113_node_1199 : NodeCoverage113 [40,39] 39 34 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1200 : NodeCoverage113 [40,38] 38 35 :=
  demand_node_prune113 38 compact113_demands_038 compact113_demands_038_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1201 : NodeCoverage113 [40,37] 37 36 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1202 : NodeCoverage113 [40,36] 36 37 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1203 : NodeCoverage113 [40,35] 35 38 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1204 : NodeCoverage113 [40,34] 34 39 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1205 : NodeCoverage113 [40,33] 33 40 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1206 : NodeCoverage113 [40,32] 32 41 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1207 : NodeCoverage113 [40,31] 31 42 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

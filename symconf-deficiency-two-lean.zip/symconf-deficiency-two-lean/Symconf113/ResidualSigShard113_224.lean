import Symconf113.ResidualLeaves113

/-! Kernel check: the signature stage refutes leaves 224 to 239. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem sigShard_224 : ((leaves.drop 224).take 16).all sigStage=true := by decide +kernel
end Symconf113

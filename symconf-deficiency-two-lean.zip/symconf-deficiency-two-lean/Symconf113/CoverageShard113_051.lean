import Symconf113.CoverageShard113_049
import Symconf113.CoverageShard113_050

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2073 : NodeCoverage113 [33,11,11,11,11,11,6] 6 19 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2074 : NodeCoverage113 [33,11,11,11,11,11,5] 5 20 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2075 : NodeCoverage113 [33,11,11,11,11,11,3] 3 22 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2076 : NodeCoverage113 [33,11,11,11,11,11] 11 25 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2068
    (ChildrenCoverage113.cons _ _ compact113_node_2069
    (ChildrenCoverage113.cons _ _ compact113_node_2070
    (ChildrenCoverage113.cons _ _ compact113_node_2071
    (ChildrenCoverage113.cons _ _ compact113_node_2072
    (ChildrenCoverage113.cons _ _ compact113_node_2073
    (ChildrenCoverage113.cons _ _ compact113_node_2074
    (ChildrenCoverage113.cons _ _ compact113_node_2075
    ChildrenCoverage113.nil))))))))

theorem compact113_node_2077 : NodeCoverage113 [33,11,11,11,11,10] 10 26 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2078 : NodeCoverage113 [33,11,11,11,11,9] 9 27 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2079 : NodeCoverage113 [33,11,11,11,11,8] 8 28 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2080 : NodeCoverage113 [33,11,11,11,11,7] 7 29 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2081 : NodeCoverage113 [33,11,11,11,11,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2082 : NodeCoverage113 [33,11,11,11,11,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2083 : NodeCoverage113 [33,11,11,11,11,3] 3 33 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2084 : NodeCoverage113 [33,11,11,11,11] 11 36 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2076
    (ChildrenCoverage113.cons _ _ compact113_node_2077
    (ChildrenCoverage113.cons _ _ compact113_node_2078
    (ChildrenCoverage113.cons _ _ compact113_node_2079
    (ChildrenCoverage113.cons _ _ compact113_node_2080
    (ChildrenCoverage113.cons _ _ compact113_node_2081
    (ChildrenCoverage113.cons _ _ compact113_node_2082
    (ChildrenCoverage113.cons _ _ compact113_node_2083
    ChildrenCoverage113.nil))))))))

theorem compact113_node_2085 : NodeCoverage113 [33,11,11,11,10] 10 37 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2086 : NodeCoverage113 [33,11,11,11,9] 9 38 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2087 : NodeCoverage113 [33,11,11,11,8] 8 39 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2088 : NodeCoverage113 [33,11,11,11,7] 7 40 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2089 : NodeCoverage113 [33,11,11,11,6] 6 41 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2090 : NodeCoverage113 [33,11,11,11,5] 5 42 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2091 : NodeCoverage113 [33,11,11,11,3] 3 44 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2092 : NodeCoverage113 [33,11,11,11] 11 47 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2084
    (ChildrenCoverage113.cons _ _ compact113_node_2085
    (ChildrenCoverage113.cons _ _ compact113_node_2086
    (ChildrenCoverage113.cons _ _ compact113_node_2087
    (ChildrenCoverage113.cons _ _ compact113_node_2088
    (ChildrenCoverage113.cons _ _ compact113_node_2089
    (ChildrenCoverage113.cons _ _ compact113_node_2090
    (ChildrenCoverage113.cons _ _ compact113_node_2091
    ChildrenCoverage113.nil))))))))

theorem compact113_node_2093 : NodeCoverage113 [33,11,11,10] 10 48 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2094 : NodeCoverage113 [33,11,11,9] 9 49 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2095 : NodeCoverage113 [33,11,11,8] 8 50 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2096 : NodeCoverage113 [33,11,11,7] 7 51 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2097 : NodeCoverage113 [33,11,11,6] 6 52 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2098 : NodeCoverage113 [33,11,11,5] 5 53 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2099 : NodeCoverage113 [33,11,11,3] 3 55 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2100 : NodeCoverage113 [33,11,11] 11 58 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2092
    (ChildrenCoverage113.cons _ _ compact113_node_2093
    (ChildrenCoverage113.cons _ _ compact113_node_2094
    (ChildrenCoverage113.cons _ _ compact113_node_2095
    (ChildrenCoverage113.cons _ _ compact113_node_2096
    (ChildrenCoverage113.cons _ _ compact113_node_2097
    (ChildrenCoverage113.cons _ _ compact113_node_2098
    (ChildrenCoverage113.cons _ _ compact113_node_2099
    ChildrenCoverage113.nil))))))))

theorem compact113_node_2101 : NodeCoverage113 [33,11,10] 10 59 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2102 : NodeCoverage113 [33,11,9] 9 60 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2103 : NodeCoverage113 [33,11,8] 8 61 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2104 : NodeCoverage113 [33,11,7] 7 62 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2105 : NodeCoverage113 [33,11,6] 6 63 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2106 : NodeCoverage113 [33,11,5] 5 64 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2107 : NodeCoverage113 [33,11,3] 3 66 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2108 : NodeCoverage113 [33,11] 11 69 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2100
    (ChildrenCoverage113.cons _ _ compact113_node_2101
    (ChildrenCoverage113.cons _ _ compact113_node_2102
    (ChildrenCoverage113.cons _ _ compact113_node_2103
    (ChildrenCoverage113.cons _ _ compact113_node_2104
    (ChildrenCoverage113.cons _ _ compact113_node_2105
    (ChildrenCoverage113.cons _ _ compact113_node_2106
    (ChildrenCoverage113.cons _ _ compact113_node_2107
    ChildrenCoverage113.nil))))))))

theorem compact113_node_2109 : NodeCoverage113 [33,10] 10 70 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2110 : NodeCoverage113 [33,9] 9 71 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2111 : NodeCoverage113 [33,8] 8 72 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2112 : NodeCoverage113 [33,7] 7 73 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2113 : NodeCoverage113 [33,6] 6 74 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2114 : NodeCoverage113 [33,5] 5 75 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2115 : NodeCoverage113 [33,3] 3 77 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2116 : NodeCoverage113 [33] 33 80 :=
  node_fork113 (B := [33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2037
    (ChildrenCoverage113.cons _ _ compact113_node_2038
    (ChildrenCoverage113.cons _ _ compact113_node_2039
    (ChildrenCoverage113.cons _ _ compact113_node_2040
    (ChildrenCoverage113.cons _ _ compact113_node_2041
    (ChildrenCoverage113.cons _ _ compact113_node_2042
    (ChildrenCoverage113.cons _ _ compact113_node_2043
    (ChildrenCoverage113.cons _ _ compact113_node_2044
    (ChildrenCoverage113.cons _ _ compact113_node_2045
    (ChildrenCoverage113.cons _ _ compact113_node_2046
    (ChildrenCoverage113.cons _ _ compact113_node_2047
    (ChildrenCoverage113.cons _ _ compact113_node_2048
    (ChildrenCoverage113.cons _ _ compact113_node_2049
    (ChildrenCoverage113.cons _ _ compact113_node_2050
    (ChildrenCoverage113.cons _ _ compact113_node_2051
    (ChildrenCoverage113.cons _ _ compact113_node_2052
    (ChildrenCoverage113.cons _ _ compact113_node_2053
    (ChildrenCoverage113.cons _ _ compact113_node_2054
    (ChildrenCoverage113.cons _ _ compact113_node_2055
    (ChildrenCoverage113.cons _ _ compact113_node_2056
    (ChildrenCoverage113.cons _ _ compact113_node_2057
    (ChildrenCoverage113.cons _ _ compact113_node_2058
    (ChildrenCoverage113.cons _ _ compact113_node_2108
    (ChildrenCoverage113.cons _ _ compact113_node_2109
    (ChildrenCoverage113.cons _ _ compact113_node_2110
    (ChildrenCoverage113.cons _ _ compact113_node_2111
    (ChildrenCoverage113.cons _ _ compact113_node_2112
    (ChildrenCoverage113.cons _ _ compact113_node_2113
    (ChildrenCoverage113.cons _ _ compact113_node_2114
    (ChildrenCoverage113.cons _ _ compact113_node_2115
    ChildrenCoverage113.nil))))))))))))))))))))))))))))))

theorem compact113_node_2117 : NodeCoverage113 [32,32,32,17] 17 0 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2118 : NodeCoverage113 [32,32,32,14] 14 3 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2119 : NodeCoverage113 [32,32,32,13] 13 4 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2120 : NodeCoverage113 [32,32,32,12] 12 5 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2121 : NodeCoverage113 [32,32,32,11] 11 6 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2122 : NodeCoverage113 [32,32,32,10] 10 7 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2123 : NodeCoverage113 [32,32,32,9] 9 8 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2124 : NodeCoverage113 [32,32,32,8] 8 9 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2125 : NodeCoverage113 [32,32,32,7] 7 10 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2126 : NodeCoverage113 [32,32,32,6] 6 11 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2127 : NodeCoverage113 [32,32,32,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2128 : NodeCoverage113 [32,32,32,3] 3 14 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2129 : NodeCoverage113 [32,32,32] 32 17 :=
  node_fork113 (B := [17,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2117
    (ChildrenCoverage113.cons _ _ compact113_node_2118
    (ChildrenCoverage113.cons _ _ compact113_node_2119
    (ChildrenCoverage113.cons _ _ compact113_node_2120
    (ChildrenCoverage113.cons _ _ compact113_node_2121
    (ChildrenCoverage113.cons _ _ compact113_node_2122
    (ChildrenCoverage113.cons _ _ compact113_node_2123
    (ChildrenCoverage113.cons _ _ compact113_node_2124
    (ChildrenCoverage113.cons _ _ compact113_node_2125
    (ChildrenCoverage113.cons _ _ compact113_node_2126
    (ChildrenCoverage113.cons _ _ compact113_node_2127
    (ChildrenCoverage113.cons _ _ compact113_node_2128
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_2130 : NodeCoverage113 [32,32,31] 31 18 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2365 : NodeCoverage113 [30,30,11] 11 42 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2366 : NodeCoverage113 [30,30,10,10,10,10,10] 10 3 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2367 : NodeCoverage113 [30,30,10,10,10,10,9] 9 4 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2368 : NodeCoverage113 [30,30,10,10,10,10,8] 8 5 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2369 : NodeCoverage113 [30,30,10,10,10,10,7] 7 6 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2370 : NodeCoverage113 [30,30,10,10,10,10,6] 6 7 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2371 : NodeCoverage113 [30,30,10,10,10,10,5,5,3] 3 0 :=
  node_no_weak_demand113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2372 : NodeCoverage113 [30,30,10,10,10,10,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2371
    ChildrenCoverage113.nil)

theorem compact113_node_2373 : NodeCoverage113 [30,30,10,10,10,10,5,3] 3 5 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2374 : NodeCoverage113 [30,30,10,10,10,10,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2372
    (ChildrenCoverage113.cons _ _ compact113_node_2373
    ChildrenCoverage113.nil))

theorem compact113_node_2375 : NodeCoverage113 [30,30,10,10,10,10,3] 3 10 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2376 : NodeCoverage113 [30,30,10,10,10,10] 10 13 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2366
    (ChildrenCoverage113.cons _ _ compact113_node_2367
    (ChildrenCoverage113.cons _ _ compact113_node_2368
    (ChildrenCoverage113.cons _ _ compact113_node_2369
    (ChildrenCoverage113.cons _ _ compact113_node_2370
    (ChildrenCoverage113.cons _ _ compact113_node_2374
    (ChildrenCoverage113.cons _ _ compact113_node_2375
    ChildrenCoverage113.nil)))))))

theorem compact113_node_2377 : NodeCoverage113 [30,30,10,10,10,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2378 : NodeCoverage113 [30,30,10,10,10,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2379 : NodeCoverage113 [30,30,10,10,10,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2380 : NodeCoverage113 [30,30,10,10,10,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2381 : NodeCoverage113 [30,30,10,10,10,5] 5 18 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2382 : NodeCoverage113 [30,30,10,10,10,3] 3 20 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2383 : NodeCoverage113 [30,30,10,10,10] 10 23 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2376
    (ChildrenCoverage113.cons _ _ compact113_node_2377
    (ChildrenCoverage113.cons _ _ compact113_node_2378
    (ChildrenCoverage113.cons _ _ compact113_node_2379
    (ChildrenCoverage113.cons _ _ compact113_node_2380
    (ChildrenCoverage113.cons _ _ compact113_node_2381
    (ChildrenCoverage113.cons _ _ compact113_node_2382
    ChildrenCoverage113.nil)))))))

theorem compact113_node_2384 : NodeCoverage113 [30,30,10,10,9] 9 24 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2385 : NodeCoverage113 [30,30,10,10,8] 8 25 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2386 : NodeCoverage113 [30,30,10,10,7] 7 26 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

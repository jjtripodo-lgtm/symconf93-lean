import Symconf113.CoverageShard113_065

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2464 : NodeCoverage113 [30,15,6] 6 62 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2465 : NodeCoverage113 [30,15,5] 5 63 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2466 : NodeCoverage113 [30,15,3] 3 65 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2467 : NodeCoverage113 [30,15] 15 68 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2455
    (ChildrenCoverage113.cons _ _ compact113_node_2456
    (ChildrenCoverage113.cons _ _ compact113_node_2457
    (ChildrenCoverage113.cons _ _ compact113_node_2458
    (ChildrenCoverage113.cons _ _ compact113_node_2459
    (ChildrenCoverage113.cons _ _ compact113_node_2460
    (ChildrenCoverage113.cons _ _ compact113_node_2461
    (ChildrenCoverage113.cons _ _ compact113_node_2462
    (ChildrenCoverage113.cons _ _ compact113_node_2463
    (ChildrenCoverage113.cons _ _ compact113_node_2464
    (ChildrenCoverage113.cons _ _ compact113_node_2465
    (ChildrenCoverage113.cons _ _ compact113_node_2466
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_2468 : NodeCoverage113 [30,14] 14 69 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2469 : NodeCoverage113 [30,13] 13 70 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2470 : NodeCoverage113 [30,12,12] 12 59 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2471 : NodeCoverage113 [30,12,11] 11 60 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2472 : NodeCoverage113 [30,12,10] 10 61 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_000
import Symconf113.CoverageShard113_001
import Symconf113.CoverageShard113_002
import Symconf113.CoverageShard113_003
import Symconf113.CoverageShard113_004
import Symconf113.CoverageShard113_006
import Symconf113.CoverageShard113_007
import Symconf113.CoverageShard113_011
import Symconf113.CoverageShard113_013
import Symconf113.CoverageShard113_014
import Symconf113.CoverageShard113_016
import Symconf113.CoverageShard113_019
import Symconf113.CoverageShard113_022
import Symconf113.CoverageShard113_024
import Symconf113.CoverageShard113_027
import Symconf113.CoverageShard113_032
import Symconf113.CoverageShard113_034
import Symconf113.CoverageShard113_036
import Symconf113.CoverageShard113_045
import Symconf113.CoverageShard113_048
import Symconf113.CoverageShard113_051
import Symconf113.CoverageShard113_054
import Symconf113.CoverageShard113_073
import Symconf113.CoverageShard113_077
import Symconf113.CoverageShard113_080
import Symconf113.CoverageShard113_082
import Symconf113.CoverageShard113_097
import Symconf113.CoverageShard113_099
import Symconf113.CoverageShard113_103
import Symconf113.CoverageShard113_106
import Symconf113.CoverageShard113_114
import Symconf113.CoverageShard113_116
import Symconf113.CoverageShard113_127
import Symconf113.CoverageShard113_128
import Symconf113.CoverageShard113_131
import Symconf113.CoverageShard113_135
import Symconf113.CoverageShard113_144
import Symconf113.CoverageShard113_145
import Symconf113.CoverageShard113_153
import Symconf113.CoverageShard113_154
import Symconf113.CoverageShard113_159
import Symconf113.CoverageShard113_161
import Symconf113.CoverageShard113_162
import Symconf113.CoverageShard113_165
import Symconf113.CoverageShard113_166

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_7566 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 24 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7565
    ChildrenCoverage113.nil)

theorem compact113_node_7567 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3,3] 3 27 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7566
    ChildrenCoverage113.nil)

theorem compact113_node_7568 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3] 3 30 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7567
    ChildrenCoverage113.nil)

theorem compact113_node_7569 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3] 3 33 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7568
    ChildrenCoverage113.nil)

theorem compact113_node_7570 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3] 3 36 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7569
    ChildrenCoverage113.nil)

theorem compact113_node_7571 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3] 3 39 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7570
    ChildrenCoverage113.nil)

theorem compact113_node_7572 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3] 3 42 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7571
    ChildrenCoverage113.nil)

theorem compact113_node_7573 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3] 3 45 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7572
    ChildrenCoverage113.nil)

theorem compact113_node_7574 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3,3] 3 48 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7573
    ChildrenCoverage113.nil)

theorem compact113_node_7575 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3,3] 3 51 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7574
    ChildrenCoverage113.nil)

theorem compact113_node_7576 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3,3] 3 54 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7575
    ChildrenCoverage113.nil)

theorem compact113_node_7577 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3,3] 3 57 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7576
    ChildrenCoverage113.nil)

theorem compact113_node_7578 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,3] 3 60 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7577
    ChildrenCoverage113.nil)

theorem compact113_node_7579 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5] 5 63 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7557
    (ChildrenCoverage113.cons _ _ compact113_node_7578
    ChildrenCoverage113.nil))

theorem compact113_node_7580 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,3] 3 65 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7581 : NodeCoverage113 [5,5,5,5,5,5,5,5,5] 5 68 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7579
    (ChildrenCoverage113.cons _ _ compact113_node_7580
    ChildrenCoverage113.nil))

theorem compact113_node_7582 : NodeCoverage113 [5,5,5,5,5,5,5,5,3] 3 70 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7583 : NodeCoverage113 [5,5,5,5,5,5,5,5] 5 73 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7581
    (ChildrenCoverage113.cons _ _ compact113_node_7582
    ChildrenCoverage113.nil))

theorem compact113_node_7584 : NodeCoverage113 [5,5,5,5,5,5,5,3] 3 75 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7585 : NodeCoverage113 [5,5,5,5,5,5,5] 5 78 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7583
    (ChildrenCoverage113.cons _ _ compact113_node_7584
    ChildrenCoverage113.nil))

theorem compact113_node_7586 : NodeCoverage113 [5,5,5,5,5,5,3] 3 80 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7587 : NodeCoverage113 [5,5,5,5,5,5] 5 83 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7585
    (ChildrenCoverage113.cons _ _ compact113_node_7586
    ChildrenCoverage113.nil))

theorem compact113_node_7588 : NodeCoverage113 [5,5,5,5,5,3] 3 85 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7589 : NodeCoverage113 [5,5,5,5,5] 5 88 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7587
    (ChildrenCoverage113.cons _ _ compact113_node_7588
    ChildrenCoverage113.nil))

theorem compact113_node_7590 : NodeCoverage113 [5,5,5,5,3] 3 90 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7591 : NodeCoverage113 [5,5,5,5] 5 93 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7589
    (ChildrenCoverage113.cons _ _ compact113_node_7590
    ChildrenCoverage113.nil))

theorem compact113_node_7592 : NodeCoverage113 [5,5,5,3] 3 95 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7593 : NodeCoverage113 [5,5,5] 5 98 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7591
    (ChildrenCoverage113.cons _ _ compact113_node_7592
    ChildrenCoverage113.nil))

theorem compact113_node_7594 : NodeCoverage113 [5,5,3] 3 100 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7595 : NodeCoverage113 [5,5] 5 103 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7593
    (ChildrenCoverage113.cons _ _ compact113_node_7594
    ChildrenCoverage113.nil))

theorem compact113_node_7596 : NodeCoverage113 [5,3] 3 105 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7597 : NodeCoverage113 [5] 5 108 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7595
    (ChildrenCoverage113.cons _ _ compact113_node_7596
    ChildrenCoverage113.nil))

theorem compact113_node_7598 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7599 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7598
    ChildrenCoverage113.nil)

theorem compact113_node_7600 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7599
    ChildrenCoverage113.nil)

theorem compact113_node_7601 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7600
    ChildrenCoverage113.nil)

theorem compact113_node_7602 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7601
    ChildrenCoverage113.nil)

theorem compact113_node_7603 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7602
    ChildrenCoverage113.nil)

theorem compact113_node_7604 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7603
    ChildrenCoverage113.nil)

theorem compact113_node_7605 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7604
    ChildrenCoverage113.nil)

theorem compact113_node_7606 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7605
    ChildrenCoverage113.nil)

theorem compact113_node_7607 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7606
    ChildrenCoverage113.nil)

theorem compact113_node_7608 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 35 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7607
    ChildrenCoverage113.nil)

theorem compact113_node_7609 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 38 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7608
    ChildrenCoverage113.nil)

theorem compact113_node_7610 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 41 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7609
    ChildrenCoverage113.nil)

theorem compact113_node_7611 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 44 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7610
    ChildrenCoverage113.nil)

theorem compact113_node_7612 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 47 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7611
    ChildrenCoverage113.nil)

theorem compact113_node_7613 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 50 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7612
    ChildrenCoverage113.nil)

theorem compact113_node_7614 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 53 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7613
    ChildrenCoverage113.nil)

theorem compact113_node_7615 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 56 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7614
    ChildrenCoverage113.nil)

theorem compact113_node_7616 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 59 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7615
    ChildrenCoverage113.nil)

theorem compact113_node_7617 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 62 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7616
    ChildrenCoverage113.nil)

theorem compact113_node_7618 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 65 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7617
    ChildrenCoverage113.nil)

theorem compact113_node_7619 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 68 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7618
    ChildrenCoverage113.nil)

theorem compact113_node_7620 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 71 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7619
    ChildrenCoverage113.nil)

theorem compact113_node_7621 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3,3] 3 74 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7620
    ChildrenCoverage113.nil)

theorem compact113_node_7622 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3,3] 3 77 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7621
    ChildrenCoverage113.nil)

theorem compact113_node_7623 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3,3] 3 80 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7622
    ChildrenCoverage113.nil)

theorem compact113_node_7624 : NodeCoverage113 [3,3,3,3,3,3,3,3,3,3] 3 83 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7623
    ChildrenCoverage113.nil)

theorem compact113_node_7625 : NodeCoverage113 [3,3,3,3,3,3,3,3,3] 3 86 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7624
    ChildrenCoverage113.nil)

theorem compact113_node_7626 : NodeCoverage113 [3,3,3,3,3,3,3,3] 3 89 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7625
    ChildrenCoverage113.nil)

theorem compact113_node_7627 : NodeCoverage113 [3,3,3,3,3,3,3] 3 92 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7626
    ChildrenCoverage113.nil)

theorem compact113_node_7628 : NodeCoverage113 [3,3,3,3,3,3] 3 95 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7627
    ChildrenCoverage113.nil)

theorem compact113_node_7629 : NodeCoverage113 [3,3,3,3,3] 3 98 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7628
    ChildrenCoverage113.nil)

theorem compact113_node_7630 : NodeCoverage113 [3,3,3,3] 3 101 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7629
    ChildrenCoverage113.nil)

theorem compact113_node_7631 : NodeCoverage113 [3,3,3] 3 104 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7630
    ChildrenCoverage113.nil)

theorem compact113_node_7632 : NodeCoverage113 [3,3] 3 107 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7631
    ChildrenCoverage113.nil)

theorem compact113_node_7633 : NodeCoverage113 [3] 3 110 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7632
    ChildrenCoverage113.nil)

theorem compact113_node_7634 : NodeCoverage113 [] 113 113 :=
  node_fork113 (B := [113,110,109,108,107,106,105,104,103,102,101,100,99,98,97,96,95,94,93,92,91,90,89,88,87,86,85,84,83,82,81,80,79,78,77,76,75,74,73,72,71,70,69,68,67,66,65,64,63,62,61,60,59,58,57,56,55,54,53,52,51,50,49,48,47,46,45,44,43,42,41,40,39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0000
    (ChildrenCoverage113.cons _ _ compact113_node_0001
    (ChildrenCoverage113.cons _ _ compact113_node_0002
    (ChildrenCoverage113.cons _ _ compact113_node_0003
    (ChildrenCoverage113.cons _ _ compact113_node_0004
    (ChildrenCoverage113.cons _ _ compact113_node_0005
    (ChildrenCoverage113.cons _ _ compact113_node_0006
    (ChildrenCoverage113.cons _ _ compact113_node_0007
    (ChildrenCoverage113.cons _ _ compact113_node_0008
    (ChildrenCoverage113.cons _ _ compact113_node_0009
    (ChildrenCoverage113.cons _ _ compact113_node_0010
    (ChildrenCoverage113.cons _ _ compact113_node_0011
    (ChildrenCoverage113.cons _ _ compact113_node_0012
    (ChildrenCoverage113.cons _ _ compact113_node_0013
    (ChildrenCoverage113.cons _ _ compact113_node_0014
    (ChildrenCoverage113.cons _ _ compact113_node_0015
    (ChildrenCoverage113.cons _ _ compact113_node_0016
    (ChildrenCoverage113.cons _ _ compact113_node_0017
    (ChildrenCoverage113.cons _ _ compact113_node_0018
    (ChildrenCoverage113.cons _ _ compact113_node_0019
    (ChildrenCoverage113.cons _ _ compact113_node_0020
    (ChildrenCoverage113.cons _ _ compact113_node_0021
    (ChildrenCoverage113.cons _ _ compact113_node_0022
    (ChildrenCoverage113.cons _ _ compact113_node_0023
    (ChildrenCoverage113.cons _ _ compact113_node_0024
    (ChildrenCoverage113.cons _ _ compact113_node_0025
    (ChildrenCoverage113.cons _ _ compact113_node_0026
    (ChildrenCoverage113.cons _ _ compact113_node_0027
    (ChildrenCoverage113.cons _ _ compact113_node_0028
    (ChildrenCoverage113.cons _ _ compact113_node_0029
    (ChildrenCoverage113.cons _ _ compact113_node_0030
    (ChildrenCoverage113.cons _ _ compact113_node_0059
    (ChildrenCoverage113.cons _ _ compact113_node_0060
    (ChildrenCoverage113.cons _ _ compact113_node_0061
    (ChildrenCoverage113.cons _ _ compact113_node_0093
    (ChildrenCoverage113.cons _ _ compact113_node_0094
    (ChildrenCoverage113.cons _ _ compact113_node_0095
    (ChildrenCoverage113.cons _ _ compact113_node_0096
    (ChildrenCoverage113.cons _ _ compact113_node_0097
    (ChildrenCoverage113.cons _ _ compact113_node_0155
    (ChildrenCoverage113.cons _ _ compact113_node_0156
    (ChildrenCoverage113.cons _ _ compact113_node_0217
    (ChildrenCoverage113.cons _ _ compact113_node_0218
    (ChildrenCoverage113.cons _ _ compact113_node_0219
    (ChildrenCoverage113.cons _ _ compact113_node_0220
    (ChildrenCoverage113.cons _ _ compact113_node_0221
    (ChildrenCoverage113.cons _ _ compact113_node_0222
    (ChildrenCoverage113.cons _ _ compact113_node_0280
    (ChildrenCoverage113.cons _ _ compact113_node_0351
    (ChildrenCoverage113.cons _ _ compact113_node_0352
    (ChildrenCoverage113.cons _ _ compact113_node_0353
    (ChildrenCoverage113.cons _ _ compact113_node_0489
    (ChildrenCoverage113.cons _ _ compact113_node_0490
    (ChildrenCoverage113.cons _ _ compact113_node_0491
    (ChildrenCoverage113.cons _ _ compact113_node_0492
    (ChildrenCoverage113.cons _ _ compact113_node_0575
    (ChildrenCoverage113.cons _ _ compact113_node_0576
    (ChildrenCoverage113.cons _ _ compact113_node_0577
    (ChildrenCoverage113.cons _ _ compact113_node_0630
    (ChildrenCoverage113.cons _ _ compact113_node_0631
    (ChildrenCoverage113.cons _ _ compact113_node_0632
    (ChildrenCoverage113.cons _ _ compact113_node_0633
    (ChildrenCoverage113.cons _ _ compact113_node_0692
    (ChildrenCoverage113.cons _ _ compact113_node_0826
    (ChildrenCoverage113.cons _ _ compact113_node_0827
    (ChildrenCoverage113.cons _ _ compact113_node_0828
    (ChildrenCoverage113.cons _ _ compact113_node_0966
    (ChildrenCoverage113.cons _ _ compact113_node_1028
    (ChildrenCoverage113.cons _ _ compact113_node_1029
    (ChildrenCoverage113.cons _ _ compact113_node_1160
    (ChildrenCoverage113.cons _ _ compact113_node_1161
    (ChildrenCoverage113.cons _ _ compact113_node_1325
    (ChildrenCoverage113.cons _ _ compact113_node_1392
    (ChildrenCoverage113.cons _ _ compact113_node_1393
    (ChildrenCoverage113.cons _ _ compact113_node_1461
    (ChildrenCoverage113.cons _ _ compact113_node_1880
    (ChildrenCoverage113.cons _ _ compact113_node_1966
    (ChildrenCoverage113.cons _ _ compact113_node_1967
    (ChildrenCoverage113.cons _ _ compact113_node_2116
    (ChildrenCoverage113.cons _ _ compact113_node_2243
    (ChildrenCoverage113.cons _ _ compact113_node_2244
    (ChildrenCoverage113.cons _ _ compact113_node_2545
    (ChildrenCoverage113.cons _ _ compact113_node_2546
    (ChildrenCoverage113.cons _ _ compact113_node_2785
    (ChildrenCoverage113.cons _ _ compact113_node_2907
    (ChildrenCoverage113.cons _ _ compact113_node_2908
    (ChildrenCoverage113.cons _ _ compact113_node_2983
    (ChildrenCoverage113.cons _ _ compact113_node_3413
    (ChildrenCoverage113.cons _ _ compact113_node_3490
    (ChildrenCoverage113.cons _ _ compact113_node_3737
    (ChildrenCoverage113.cons _ _ compact113_node_3897
    (ChildrenCoverage113.cons _ _ compact113_node_4290
    (ChildrenCoverage113.cons _ _ compact113_node_4368
    (ChildrenCoverage113.cons _ _ compact113_node_4976
    (ChildrenCoverage113.cons _ _ compact113_node_5053
    (ChildrenCoverage113.cons _ _ compact113_node_5223
    (ChildrenCoverage113.cons _ _ compact113_node_5361
    (ChildrenCoverage113.cons _ _ compact113_node_5951
    (ChildrenCoverage113.cons _ _ compact113_node_6035
    (ChildrenCoverage113.cons _ _ compact113_node_6594
    (ChildrenCoverage113.cons _ _ compact113_node_6679
    (ChildrenCoverage113.cons _ _ compact113_node_7025
    (ChildrenCoverage113.cons _ _ compact113_node_7119
    (ChildrenCoverage113.cons _ _ compact113_node_7120
    (ChildrenCoverage113.cons _ _ compact113_node_7233
    (ChildrenCoverage113.cons _ _ compact113_node_7454
    (ChildrenCoverage113.cons _ _ compact113_node_7597
    (ChildrenCoverage113.cons _ _ compact113_node_7633
    ChildrenCoverage113.nil))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))

end Symconf113

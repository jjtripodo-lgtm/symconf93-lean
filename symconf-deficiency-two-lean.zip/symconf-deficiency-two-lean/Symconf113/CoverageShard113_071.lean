import Symconf113.CoverageShard113_070

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2529 : NodeCoverage113 [30,10,10,5] 5 58 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2530 : NodeCoverage113 [30,10,10,3] 3 60 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2531 : NodeCoverage113 [30,10,10] 10 63 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2524
    (ChildrenCoverage113.cons _ _ compact113_node_2525
    (ChildrenCoverage113.cons _ _ compact113_node_2526
    (ChildrenCoverage113.cons _ _ compact113_node_2527
    (ChildrenCoverage113.cons _ _ compact113_node_2528
    (ChildrenCoverage113.cons _ _ compact113_node_2529
    (ChildrenCoverage113.cons _ _ compact113_node_2530
    ChildrenCoverage113.nil)))))))

theorem compact113_node_2532 : NodeCoverage113 [30,10,9] 9 64 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2533 : NodeCoverage113 [30,10,8] 8 65 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2534 : NodeCoverage113 [30,10,7] 7 66 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2535 : NodeCoverage113 [30,10,6] 6 67 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_144

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_6001 : NodeCoverage113 [13,13,13,13,7] 7 54 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6002 : NodeCoverage113 [13,13,13,13,6] 6 55 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6003 : NodeCoverage113 [13,13,13,13,5] 5 56 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6004 : NodeCoverage113 [13,13,13,13,3] 3 58 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6005 : NodeCoverage113 [13,13,13,13] 13 61 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5995
    (ChildrenCoverage113.cons _ _ compact113_node_5996
    (ChildrenCoverage113.cons _ _ compact113_node_5997
    (ChildrenCoverage113.cons _ _ compact113_node_5998
    (ChildrenCoverage113.cons _ _ compact113_node_5999
    (ChildrenCoverage113.cons _ _ compact113_node_6000
    (ChildrenCoverage113.cons _ _ compact113_node_6001
    (ChildrenCoverage113.cons _ _ compact113_node_6002
    (ChildrenCoverage113.cons _ _ compact113_node_6003
    (ChildrenCoverage113.cons _ _ compact113_node_6004
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_6006 : NodeCoverage113 [13,13,13,12] 12 62 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6007 : NodeCoverage113 [13,13,13,11] 11 63 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6008 : NodeCoverage113 [13,13,13,10] 10 64 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6009 : NodeCoverage113 [13,13,13,9] 9 65 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6010 : NodeCoverage113 [13,13,13,8] 8 66 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6011 : NodeCoverage113 [13,13,13,7] 7 67 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6012 : NodeCoverage113 [13,13,13,6] 6 68 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6013 : NodeCoverage113 [13,13,13,5] 5 69 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6014 : NodeCoverage113 [13,13,13,3] 3 71 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6015 : NodeCoverage113 [13,13,13] 13 74 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6005
    (ChildrenCoverage113.cons _ _ compact113_node_6006
    (ChildrenCoverage113.cons _ _ compact113_node_6007
    (ChildrenCoverage113.cons _ _ compact113_node_6008
    (ChildrenCoverage113.cons _ _ compact113_node_6009
    (ChildrenCoverage113.cons _ _ compact113_node_6010
    (ChildrenCoverage113.cons _ _ compact113_node_6011
    (ChildrenCoverage113.cons _ _ compact113_node_6012
    (ChildrenCoverage113.cons _ _ compact113_node_6013
    (ChildrenCoverage113.cons _ _ compact113_node_6014
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_6016 : NodeCoverage113 [13,13,12] 12 75 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6017 : NodeCoverage113 [13,13,11] 11 76 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6018 : NodeCoverage113 [13,13,10] 10 77 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6019 : NodeCoverage113 [13,13,9] 9 78 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6020 : NodeCoverage113 [13,13,8] 8 79 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6021 : NodeCoverage113 [13,13,7] 7 80 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6022 : NodeCoverage113 [13,13,6] 6 81 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6023 : NodeCoverage113 [13,13,5] 5 82 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6024 : NodeCoverage113 [13,13,3] 3 84 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6025 : NodeCoverage113 [13,13] 13 87 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6015
    (ChildrenCoverage113.cons _ _ compact113_node_6016
    (ChildrenCoverage113.cons _ _ compact113_node_6017
    (ChildrenCoverage113.cons _ _ compact113_node_6018
    (ChildrenCoverage113.cons _ _ compact113_node_6019
    (ChildrenCoverage113.cons _ _ compact113_node_6020
    (ChildrenCoverage113.cons _ _ compact113_node_6021
    (ChildrenCoverage113.cons _ _ compact113_node_6022
    (ChildrenCoverage113.cons _ _ compact113_node_6023
    (ChildrenCoverage113.cons _ _ compact113_node_6024
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_6026 : NodeCoverage113 [13,12] 12 88 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6027 : NodeCoverage113 [13,11] 11 89 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6028 : NodeCoverage113 [13,10] 10 90 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6029 : NodeCoverage113 [13,9] 9 91 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6030 : NodeCoverage113 [13,8] 8 92 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6031 : NodeCoverage113 [13,7] 7 93 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6032 : NodeCoverage113 [13,6] 6 94 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6033 : NodeCoverage113 [13,5] 5 95 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6034 : NodeCoverage113 [13,3] 3 97 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6035 : NodeCoverage113 [13] 13 100 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6025
    (ChildrenCoverage113.cons _ _ compact113_node_6026
    (ChildrenCoverage113.cons _ _ compact113_node_6027
    (ChildrenCoverage113.cons _ _ compact113_node_6028
    (ChildrenCoverage113.cons _ _ compact113_node_6029
    (ChildrenCoverage113.cons _ _ compact113_node_6030
    (ChildrenCoverage113.cons _ _ compact113_node_6031
    (ChildrenCoverage113.cons _ _ compact113_node_6032
    (ChildrenCoverage113.cons _ _ compact113_node_6033
    (ChildrenCoverage113.cons _ _ compact113_node_6034
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_6036 : NodeCoverage113 [12,12,12,12,12,12,12,12,12,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6037 : NodeCoverage113 [12,12,12,12,12,12,12,12,12] 12 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6036
    ChildrenCoverage113.nil)

theorem compact113_node_6038 : NodeCoverage113 [12,12,12,12,12,12,12,12,11] 11 6 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6039 : NodeCoverage113 [12,12,12,12,12,12,12,12,10] 10 7 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6040 : NodeCoverage113 [12,12,12,12,12,12,12,12,9] 9 8 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6041 : NodeCoverage113 [12,12,12,12,12,12,12,12,8] 8 9 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6042 : NodeCoverage113 [12,12,12,12,12,12,12,12,7] 7 10 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6043 : NodeCoverage113 [12,12,12,12,12,12,12,12,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6044 : NodeCoverage113 [12,12,12,12,12,12,12,12,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6043
    ChildrenCoverage113.nil)

theorem compact113_node_6045 : NodeCoverage113 [12,12,12,12,12,12,12,12,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6046 : NodeCoverage113 [12,12,12,12,12,12,12,12,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6047 : NodeCoverage113 [12,12,12,12,12,12,12,12,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6046
    ChildrenCoverage113.nil)

theorem compact113_node_6048 : NodeCoverage113 [12,12,12,12,12,12,12,12,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6044
    (ChildrenCoverage113.cons _ _ compact113_node_6045
    (ChildrenCoverage113.cons _ _ compact113_node_6047
    ChildrenCoverage113.nil)))

theorem compact113_node_6049 : NodeCoverage113 [12,12,12,12,12,12,12,12,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6050 : NodeCoverage113 [12,12,12,12,12,12,12,12,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6051 : NodeCoverage113 [12,12,12,12,12,12,12,12,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6050
    ChildrenCoverage113.nil)

theorem compact113_node_6052 : NodeCoverage113 [12,12,12,12,12,12,12,12,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6051
    ChildrenCoverage113.nil)

theorem compact113_node_6053 : NodeCoverage113 [12,12,12,12,12,12,12,12,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6052
    ChildrenCoverage113.nil)

theorem compact113_node_6054 : NodeCoverage113 [12,12,12,12,12,12,12,12] 12 17 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6037
    (ChildrenCoverage113.cons _ _ compact113_node_6038
    (ChildrenCoverage113.cons _ _ compact113_node_6039
    (ChildrenCoverage113.cons _ _ compact113_node_6040
    (ChildrenCoverage113.cons _ _ compact113_node_6041
    (ChildrenCoverage113.cons _ _ compact113_node_6042
    (ChildrenCoverage113.cons _ _ compact113_node_6048
    (ChildrenCoverage113.cons _ _ compact113_node_6049
    (ChildrenCoverage113.cons _ _ compact113_node_6053
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_6055 : NodeCoverage113 [12,12,12,12,12,12,12,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6056 : NodeCoverage113 [12,12,12,12,12,12,12,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6057 : NodeCoverage113 [12,12,12,12,12,12,12,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6058 : NodeCoverage113 [12,12,12,12,12,12,12,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6059 : NodeCoverage113 [12,12,12,12,12,12,12,7] 7 22 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6060 : NodeCoverage113 [12,12,12,12,12,12,12,6,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6061 : NodeCoverage113 [12,12,12,12,12,12,12,6,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6060
    ChildrenCoverage113.nil)

theorem compact113_node_6062 : NodeCoverage113 [12,12,12,12,12,12,12,6,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6063 : NodeCoverage113 [12,12,12,12,12,12,12,6,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6064 : NodeCoverage113 [12,12,12,12,12,12,12,6,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6063
    ChildrenCoverage113.nil)

theorem compact113_node_6065 : NodeCoverage113 [12,12,12,12,12,12,12,6,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6061
    (ChildrenCoverage113.cons _ _ compact113_node_6062
    (ChildrenCoverage113.cons _ _ compact113_node_6064
    ChildrenCoverage113.nil)))

theorem compact113_node_6066 : NodeCoverage113 [12,12,12,12,12,12,12,6,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6067 : NodeCoverage113 [12,12,12,12,12,12,12,6,6,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6068 : NodeCoverage113 [12,12,12,12,12,12,12,6,6,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6067
    ChildrenCoverage113.nil)

theorem compact113_node_6069 : NodeCoverage113 [12,12,12,12,12,12,12,6,6,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6068
    ChildrenCoverage113.nil)

theorem compact113_node_6070 : NodeCoverage113 [12,12,12,12,12,12,12,6,6,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6069
    ChildrenCoverage113.nil)

theorem compact113_node_6071 : NodeCoverage113 [12,12,12,12,12,12,12,6,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6065
    (ChildrenCoverage113.cons _ _ compact113_node_6066
    (ChildrenCoverage113.cons _ _ compact113_node_6070
    ChildrenCoverage113.nil)))

theorem compact113_node_6072 : NodeCoverage113 [12,12,12,12,12,12,12,6,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6073 : NodeCoverage113 [12,12,12,12,12,12,12,6,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6074 : NodeCoverage113 [12,12,12,12,12,12,12,6,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6073
    ChildrenCoverage113.nil)

theorem compact113_node_6075 : NodeCoverage113 [12,12,12,12,12,12,12,6,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6074
    ChildrenCoverage113.nil)

end Symconf113

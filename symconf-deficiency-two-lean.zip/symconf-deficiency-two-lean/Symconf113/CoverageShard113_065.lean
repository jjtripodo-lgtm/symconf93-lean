import Symconf113.CoverageShard113_064

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2441 : NodeCoverage113 [30,15,15,15,5] 5 33 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2442 : NodeCoverage113 [30,15,15,15,3] 3 35 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2443 : NodeCoverage113 [30,15,15,15] 15 38 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2431
    (ChildrenCoverage113.cons _ _ compact113_node_2432
    (ChildrenCoverage113.cons _ _ compact113_node_2433
    (ChildrenCoverage113.cons _ _ compact113_node_2434
    (ChildrenCoverage113.cons _ _ compact113_node_2435
    (ChildrenCoverage113.cons _ _ compact113_node_2436
    (ChildrenCoverage113.cons _ _ compact113_node_2437
    (ChildrenCoverage113.cons _ _ compact113_node_2438
    (ChildrenCoverage113.cons _ _ compact113_node_2439
    (ChildrenCoverage113.cons _ _ compact113_node_2440
    (ChildrenCoverage113.cons _ _ compact113_node_2441
    (ChildrenCoverage113.cons _ _ compact113_node_2442
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_2444 : NodeCoverage113 [30,15,15,14] 14 39 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2445 : NodeCoverage113 [30,15,15,13] 13 40 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2446 : NodeCoverage113 [30,15,15,12] 12 41 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2447 : NodeCoverage113 [30,15,15,11] 11 42 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2448 : NodeCoverage113 [30,15,15,10] 10 43 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2449 : NodeCoverage113 [30,15,15,9] 9 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2450 : NodeCoverage113 [30,15,15,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2451 : NodeCoverage113 [30,15,15,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2452 : NodeCoverage113 [30,15,15,6] 6 47 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2453 : NodeCoverage113 [30,15,15,5] 5 48 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2454 : NodeCoverage113 [30,15,15,3] 3 50 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2455 : NodeCoverage113 [30,15,15] 15 53 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2443
    (ChildrenCoverage113.cons _ _ compact113_node_2444
    (ChildrenCoverage113.cons _ _ compact113_node_2445
    (ChildrenCoverage113.cons _ _ compact113_node_2446
    (ChildrenCoverage113.cons _ _ compact113_node_2447
    (ChildrenCoverage113.cons _ _ compact113_node_2448
    (ChildrenCoverage113.cons _ _ compact113_node_2449
    (ChildrenCoverage113.cons _ _ compact113_node_2450
    (ChildrenCoverage113.cons _ _ compact113_node_2451
    (ChildrenCoverage113.cons _ _ compact113_node_2452
    (ChildrenCoverage113.cons _ _ compact113_node_2453
    (ChildrenCoverage113.cons _ _ compact113_node_2454
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_2456 : NodeCoverage113 [30,15,14] 14 54 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2457 : NodeCoverage113 [30,15,13] 13 55 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2458 : NodeCoverage113 [30,15,12] 12 56 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2459 : NodeCoverage113 [30,15,11] 11 57 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2460 : NodeCoverage113 [30,15,10] 10 58 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2461 : NodeCoverage113 [30,15,9] 9 59 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2462 : NodeCoverage113 [30,15,8] 8 60 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2463 : NodeCoverage113 [30,15,7] 7 61 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

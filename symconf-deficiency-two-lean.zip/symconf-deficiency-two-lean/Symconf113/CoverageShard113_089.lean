import Symconf113.CoverageShard113_088

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3183 : NodeCoverage113 [24,18,12] 12 59 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3184 : NodeCoverage113 [24,18,11] 11 60 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3185 : NodeCoverage113 [24,18,10] 10 61 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3186 : NodeCoverage113 [24,18,9] 9 62 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3187 : NodeCoverage113 [24,18,8] 8 63 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3188 : NodeCoverage113 [24,18,7] 7 64 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3189 : NodeCoverage113 [24,18,6] 6 65 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3190 : NodeCoverage113 [24,18,5] 5 66 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3191 : NodeCoverage113 [24,18,3] 3 68 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3192 : NodeCoverage113 [24,18] 18 71 :=
  node_fork113 (B := [18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3177
    (ChildrenCoverage113.cons _ _ compact113_node_3178
    (ChildrenCoverage113.cons _ _ compact113_node_3179
    (ChildrenCoverage113.cons _ _ compact113_node_3180
    (ChildrenCoverage113.cons _ _ compact113_node_3181
    (ChildrenCoverage113.cons _ _ compact113_node_3182
    (ChildrenCoverage113.cons _ _ compact113_node_3183
    (ChildrenCoverage113.cons _ _ compact113_node_3184
    (ChildrenCoverage113.cons _ _ compact113_node_3185
    (ChildrenCoverage113.cons _ _ compact113_node_3186
    (ChildrenCoverage113.cons _ _ compact113_node_3187
    (ChildrenCoverage113.cons _ _ compact113_node_3188
    (ChildrenCoverage113.cons _ _ compact113_node_3189
    (ChildrenCoverage113.cons _ _ compact113_node_3190
    (ChildrenCoverage113.cons _ _ compact113_node_3191
    ChildrenCoverage113.nil)))))))))))))))

theorem compact113_node_3193 : NodeCoverage113 [24,17,17] 17 55 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3194 : NodeCoverage113 [24,17,16] 16 56 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3195 : NodeCoverage113 [24,17,15] 15 57 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3196 : NodeCoverage113 [24,17,14] 14 58 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3197 : NodeCoverage113 [24,17,13] 13 59 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3198 : NodeCoverage113 [24,17,12] 12 60 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3199 : NodeCoverage113 [24,17,11] 11 61 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3200 : NodeCoverage113 [24,17,10] 10 62 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3201 : NodeCoverage113 [24,17,9] 9 63 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3202 : NodeCoverage113 [24,17,8] 8 64 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3203 : NodeCoverage113 [24,17,7] 7 65 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3204 : NodeCoverage113 [24,17,6] 6 66 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3205 : NodeCoverage113 [24,17,5] 5 67 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3206 : NodeCoverage113 [24,17,3] 3 69 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3207 : NodeCoverage113 [24,17] 17 72 :=
  node_fork113 (B := [17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3193
    (ChildrenCoverage113.cons _ _ compact113_node_3194
    (ChildrenCoverage113.cons _ _ compact113_node_3195
    (ChildrenCoverage113.cons _ _ compact113_node_3196
    (ChildrenCoverage113.cons _ _ compact113_node_3197
    (ChildrenCoverage113.cons _ _ compact113_node_3198
    (ChildrenCoverage113.cons _ _ compact113_node_3199
    (ChildrenCoverage113.cons _ _ compact113_node_3200
    (ChildrenCoverage113.cons _ _ compact113_node_3201
    (ChildrenCoverage113.cons _ _ compact113_node_3202
    (ChildrenCoverage113.cons _ _ compact113_node_3203
    (ChildrenCoverage113.cons _ _ compact113_node_3204
    (ChildrenCoverage113.cons _ _ compact113_node_3205
    (ChildrenCoverage113.cons _ _ compact113_node_3206
    ChildrenCoverage113.nil))))))))))))))

end Symconf113

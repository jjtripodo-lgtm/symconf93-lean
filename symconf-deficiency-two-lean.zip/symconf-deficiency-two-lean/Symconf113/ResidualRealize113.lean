import Symconf113.ResidualRealizeDec113
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Tactic.Ring

/-! Realizable signatures. A 0/1 function on `ZMod 15` whose nonzero
autocorrelations are all at most one has its signature (autocorrelations at
distances `1..7`) in `realList` of its size. The finite part is a kernel
check over all `2^15` subsets. -/
namespace Symconf113
open scoped BigOperators

theorem sum15 (F : ZMod 15 → ℤ) : (∑ u, F u)=((List.range 15).map fun k : ℕ => F (k : ZMod 15)).sum := by
  have h : (∑ u : ZMod 15, F u)=∑ u : Fin 15, F ((u : ℕ) : ZMod 15) :=
    Finset.sum_congr rfl (fun u _ => congrArg F (Fin.cast_val_eq_self (n := 15) (u : Fin 15)).symm)
  rw [h, Fin.sum_univ_eq_sum_range (fun k : ℕ => F (k : ZMod 15)) 15]
  simp [List.range_succ, Finset.sum_range_succ]; ring

def lstZ (e : ZMod 15 → ℤ) : List Bool := (List.range 15).map fun k : ℕ => decide (e (k : ZMod 15)=1)

theorem bl_lstZ (e : ZMod 15 → ℤ) (hb : ∀ u, e u=0 ∨ e u=1) (k : ℕ) :
    (bl (lstZ e) k : ℤ)=e (k : ZMod 15) := by
  have hk : k%15<15 := Nat.mod_lt _ (by omega)
  have hc : ((k%15 : ℕ) : ZMod 15)=(k : ZMod 15) := by
    rw [ZMod.natCast_mod]
  unfold bl lstZ
  rw [List.getD_eq_getElem?_getD, List.getElem?_map, List.getElem?_range hk]
  simp only [Option.map_some, Option.getD_some, hc]
  rcases hb (k : ZMod 15) with h|h <;> simp [h]

theorem lstZ_mem (e : ZMod 15 → ℤ) : lstZ e ∈ bools15 := by
  apply mem_prodL
  have : List.replicate 15 [false,true]=(List.range 15).map (fun _ => [false,true]) := by simp
  rw [this]
  unfold lstZ
  rw [List.forall₂_map_left_iff, List.forall₂_map_right_iff, List.forall₂_same]
  intro k _
  cases decide (e (k : ZMod 15)=1) <;> simp

theorem acL_lstZ (e : ZMod 15 → ℤ) (hb : ∀ u, e u=0 ∨ e u=1) (d : ℕ) :
    (acL (lstZ e) d : ℤ)=acZ e (d : ZMod 15) := by
  unfold acL acZ
  rw [sum15, Nat.cast_list_sum, List.map_map]
  congr 1
  apply List.map_congr_left
  intro k _
  simp only [Function.comp, Nat.cast_mul, bl_lstZ e hb, Nat.cast_add]

theorem cntL_lstZ (e : ZMod 15 → ℤ) (hb : ∀ u, e u=0 ∨ e u=1) :
    (cntL (lstZ e) : ℤ)=∑ u, e u := by
  unfold cntL
  rw [sum15, Nat.cast_list_sum, List.map_map]
  congr 1
  apply List.map_congr_left
  intro k _
  exact bl_lstZ e hb k

theorem realizable (e : ZMod 15 → ℤ) (hb : ∀ u, e u=0 ∨ e u=1)
    (h1 : acZ e 1=0) (hac : ∀ d : ZMod 15, d≠0 → acZ e d≤1) : sigZ e ∈ realList (degZ e) := by
  have hone : acL (lstZ e) 1=0 := by
    have := acL_lstZ e hb 1
    rw [Nat.cast_one, h1] at this
    exact_mod_cast this
  have hcond : ((List.range 14).all fun t => decide (acL (lstZ e) (t+1)≤1))=true := by
    rw [List.all_eq_true]
    intro t ht
    have ht' := List.mem_range.mp ht
    have hne : ((t+1 : ℕ) : ZMod 15)≠0 := by
      intro h
      rw [ZMod.natCast_eq_zero_iff] at h
      omega
    have := hac _ hne
    rw [← acL_lstZ e hb] at this
    simp only [decide_eq_true_eq]
    exact_mod_cast this
  have h := realize_dec _ (lstZ_mem e) hone hcond
  have hs : sigL (lstZ e)=sigZ e := by
    unfold sigL sigZ
    apply ofF_ext
    intro t _
    rw [← acL_lstZ e hb, Int.toNat_natCast]
  have h2 : cntL (lstZ e)=degZ e := by
    unfold degZ
    rw [← cntL_lstZ e hb, Int.toNat_natCast]
  rwa [hs, h2] at h

end Symconf113

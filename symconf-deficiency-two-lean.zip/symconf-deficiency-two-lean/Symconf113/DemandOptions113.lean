import Symconf113.CoverageBasics113
import Mathlib.Data.List.Count
import Mathlib.Data.List.Sort

/-! Exact positive-row options and the full demand extraction. A skipped
column has u=0. Every kept column has its own physical multiplicity. -/
namespace Symconf113
open scoped List

structure PositiveOption113 where
  b : Nat
  u : Nat
  v : Nat
  deriving DecidableEq

def PositiveOption113.cost (x : PositiveOption113) : Nat := x.u*x.v

def optionAllowed113 (a : Nat) (o : PositiveOption113) : Prop :=
  3≤o.b ∧ o.b≤113 ∧ o.b≠4 ∧ 1≤o.u ∧ o.u≤11 ∧
    1≤o.v ∧ o.v≤11 ∧ a*o.u=o.b*o.v ∧ (a∣o.b ∨ o.u≤1)

instance (a : Nat) (o : PositiveOption113) : Decidable (optionAllowed113 a o) :=
  inferInstanceAs (Decidable (_∧_))

def optionOrder113 (x y : PositiveOption113) : Bool := decide (y.v≤x.v)

def positiveBlock113 (a v : Nat) : List PositiveOption113 :=
  (List.range' 1 11).reverse.map (fun u => ⟨a*u/v,u,v⟩)

def rawOptions113 (a : Nat) : List PositiveOption113 :=
  (List.range' 1 11).reverse.flatMap (positiveBlock113 a)

def rowOptions113 (a : Nat) : List PositiveOption113 :=
  (rawOptions113 a).filter (fun o => decide (optionAllowed113 a o))

theorem rowOptions113_iff {a : Nat} {o : PositiveOption113} :
    o∈rowOptions113 a ↔ optionAllowed113 a o := by
  rw [rowOptions113,rawOptions113,List.mem_filter]
  constructor
  · intro hh
    exact decide_eq_true_eq.mp hh.2
  · intro hh
    refine ⟨List.mem_flatMap.mpr ⟨o.v,?_ ,?_⟩,decide_eq_true_eq.mpr hh⟩
    · rw [List.mem_reverse,List.mem_range'_1]
      exact ⟨hh.2.2.2.2.2.1,by have := hh.2.2.2.2.2.2.1; omega⟩
    · unfold positiveBlock113
      apply List.mem_map.mpr
      refine ⟨o.u,?_ ,?_⟩
      · rw [List.mem_reverse,List.mem_range'_1]
        exact ⟨hh.2.2.2.1,by have := hh.2.2.2.2.1; omega⟩
      · have hv : 0<o.v := hh.2.2.2.2.2.1
        have hV : a*o.u/o.v=o.b := by rw [hh.2.2.2.2.2.2.2.1,Nat.mul_div_cancel _ hv]
        cases o
        simp only [hV]

private theorem positiveBlock113_value {a v : Nat} {o : PositiveOption113}
    (h : o∈positiveBlock113 a v) : o.v=v := by
  obtain ⟨u,_,rfl⟩ := List.mem_map.mp h
  rfl

private theorem optionsFlat_sorted113 (a : Nat) (V : List Nat) (h : V.Pairwise (·≥·)) :
    (V.flatMap (positiveBlock113 a)).Pairwise (fun x y=>y.v≤x.v) := by
  induction V with
  | nil => simp
  | cons v V ih =>
    rw [List.flatMap_cons,List.pairwise_append]
    refine ⟨List.pairwise_iff_getElem.mpr ?_,ih (List.pairwise_cons.mp h).2,?_⟩
    · intro i j hi hj _
      rw [positiveBlock113_value (List.getElem_mem hj),positiveBlock113_value (List.getElem_mem hi)]
    · intro x hx y hy
      obtain ⟨b,hB,hY⟩ := List.mem_flatMap.mp hy
      rw [positiveBlock113_value hx,positiveBlock113_value hY]
      exact (List.pairwise_cons.mp h).1 b hB

theorem rowOptions113_sorted (a : Nat) :
    (rowOptions113 a).Pairwise (fun x y => y.v≤x.v) := by
  have h : (List.range' 1 11).reverse.Pairwise (·≥·) := by
    rw [List.pairwise_reverse]
    exact (List.sortedLT_range' 1 11 (by decide : (1:Nat)≠0)).pairwise.imp (fun h=>le_of_lt h)
  exact (optionsFlat_sorted113 a _ h).sublist (List.filter_sublist ..)

/-- Read every genuinely positive block of a realizable normalized row.
Its physical sizes form a bona fide sublist of the original columns. -/
theorem loose_positive_options113 {a : Nat} (ha : 0<a) {P : List Nat} {s q : Nat}
    (h : LooseRow113 a P s q)
    (hP : ∀ b∈P,3≤b ∧ b≤113 ∧ b≠4) :
    ∃ L : List PositiveOption113, (∀ o∈L,o∈rowOptions113 a) ∧
      (L.map PositiveOption113.u).sum=s ∧ (L.map PositiveOption113.cost).sum=q ∧
      L.map PositiveOption113.b <+ P := by
  induction h with
  | nil => exact ⟨[],by simp⟩
  | cons b P u v s q hb hu hv he hper _ ih =>
    obtain ⟨L,hL,hs,hq,hsub⟩ := ih (fun c hc=>hP c (List.mem_cons_of_mem _ hc))
    by_cases hu0 : u=0
    · exact ⟨L,hL,by simpa only [hu0,zero_add] using hs,
        by simpa only [hu0,zero_mul,zero_add] using hq,hsub.cons _⟩
    · let o : PositiveOption113 := ⟨b,u,v⟩
      have hv0 : 1≤v := by
        by_contra hn
        have h0 : v=0 := by omega
        exact (Nat.ne_of_gt (Nat.mul_pos ha (Nat.pos_of_ne_zero hu0))) (by simpa [h0] using he)
      have hO : o∈rowOptions113 a := rowOptions113_iff.mpr
        ⟨(hP b (by simp)).1,(hP b (by simp)).2.1,(hP b (by simp)).2.2,
          Nat.pos_of_ne_zero hu0,hu,hv0,hv,he,hper⟩
      refine ⟨o::L,?_ ,?_ ,?_ ,hsub.cons_cons _⟩
      · intro x hx
        rcases List.mem_cons.mp hx with rfl|hm
        · exact hO
        · exact hL x hm
      · simp [o,hs]
      · simp [o,PositiveOption113.cost,hq]

end Symconf113

#print axioms Symconf113.rowOptions113_iff
#print axioms Symconf113.loose_positive_options113

import Symconf113.ResidualLeaves113

/-! Kernel check: the signature stage refutes leaves 64 to 79. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem sigShard_64 : ((leaves.drop 64).take 16).all sigStage=true := by decide +kernel
end Symconf113

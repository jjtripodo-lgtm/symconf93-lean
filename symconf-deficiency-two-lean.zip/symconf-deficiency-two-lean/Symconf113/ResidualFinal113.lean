import Symconf113.ResidualLeafCensus113
import Symconf113.ResidualComplete113_0
import Symconf113.ResidualComplete113_1
import Symconf113.ResidualComplete113_2
import Symconf113.ResidualComplete113_3
import Symconf113.ResidualComplete113_4
import Symconf113.ResidualComplete113_5
import Symconf113.ResidualComplete113_6
import Symconf113.ResidualFinalAB113
import Symconf113.OneProfile113

/-! The residual profile `3+5+15^7` is impossible, proved in Lean with no
hypotheses. Together with the unconditional reduction to the profiles
`[113]` and `3+5+15^7`, and the named Buratti–Stinson hypothesis
`NoModularGolombRuler113` for `[113]`, no 113-by-113 incidence of a
symmetric configuration `113_11` exists.

Steps: sort the long row and column cycles into type order (`canon_exists`),
read off the census conditions (`canon_good`), run the kernel census
(`canon_census_leaves`), which forces the type-A/type-B row pair to meet
`abOK`, and refute `abOK` by the partition argument (`abOK_false`). -/
namespace Symconf113
open Matrix Symconf59

/-- Every row vector passing the row tests is in the candidate list for its
type index (the seven kernel checks `complete_i`). -/
theorem census_complete : ∀ i<7, ∀ v ∈ vecs, rowOK i v=true → (i,v) ∈ degLists.getD i [] := by
  intro i hi v hv hok
  interval_cases i
  · show (0,v) ∈ candA.map ((0,·)); exact List.mem_map.mpr ⟨v,complete_0 v hv hok,rfl⟩
  · show (1,v) ∈ candB.map ((1,·)); exact List.mem_map.mpr ⟨v,complete_1 v hv hok,rfl⟩
  · show (2,v) ∈ candC.map ((2,·)); exact List.mem_map.mpr ⟨v,complete_2 v hv hok,rfl⟩
  · show (3,v) ∈ candC.map ((3,·)); exact List.mem_map.mpr ⟨v,complete_3 v hv hok,rfl⟩
  · show (4,v) ∈ candE.map ((4,·)); exact List.mem_map.mpr ⟨v,complete_4 v hv hok,rfl⟩
  · show (5,v) ∈ candE.map ((5,·)); exact List.mem_map.mpr ⟨v,complete_5 v hv hok,rfl⟩
  · show (6,v) ∈ candE.map ((6,·)); exact List.mem_map.mpr ⟨v,complete_6 v hv hok,rfl⟩

/-- Unconditional: no 113_11 incidence has leave profile `3+5+15^7`. -/
theorem no_residual_incidence113 {A : Int113} (hA : Incidence113 A)
    (R : OrderedCycles (rowLeave A) Residual113) (C : OrderedCycles (colLeave A) Residual113) :
    False := by
  obtain ⟨σ,τ,hσ,hτ⟩ := canon_exists R C hA
  exact abOK_false R C hA σ τ hσ hτ
    (canon_census_leaves (canon_good R C hA σ τ hσ hτ) census_complete)

/-- With the named Buratti–Stinson hypothesis `NoModularGolombRuler113`:
no 113-by-113 incidence of a symmetric configuration `113_11` exists. -/
theorem no_unrestricted_incidence113 (ruler : NoModularGolombRuler113) :
    ¬ ∃ A : Int113, Incidence113 A := by
  rintro ⟨A,hA⟩
  obtain ⟨R,C,-⟩ := incidence113_residual_profile ruler hA
  exact no_residual_incidence113 hA R C

end Symconf113

#print axioms Symconf113.no_residual_incidence113
#print axioms Symconf113.no_unrestricted_incidence113

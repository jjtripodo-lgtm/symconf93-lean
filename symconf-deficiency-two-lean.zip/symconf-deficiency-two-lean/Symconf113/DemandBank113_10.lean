import Symconf113.LeafDemand113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

def compact113_demands_084 : List (List Nat) := [
  [84,12,21]
]
theorem compact113_demands_084_exact : rowDemand113 84=compact113_demands_084 := by decide +kernel

def compact113_demands_085 : List (List Nat) := [

]
theorem compact113_demands_085_exact : rowDemand113 85=compact113_demands_085 := by decide +kernel

def compact113_demands_086 : List (List Nat) := [

]
theorem compact113_demands_086_exact : rowDemand113 86=compact113_demands_086 := by decide +kernel

def compact113_demands_087 : List (List Nat) := [

]
theorem compact113_demands_087_exact : rowDemand113 87=compact113_demands_087 := by decide +kernel

def compact113_demands_088 : List (List Nat) := [
  [8,88,22],
  [8,8,8,8,11,11,11,11,11,11,22],
  [8,8,8,8,8,11,11,11,11,11,88],
  [8,8,8,8,8,8,11,11,11,22,44],
  [8,8,8,8,8,8,8,11,11,44,88],
  [8,8,8,8,8,8,8,8,22,44,44],
  [8,8,8,8,8,8,8,8,22,88]
]
theorem compact113_demands_088_exact : rowDemand113 88=compact113_demands_088 := by decide +kernel

def compact113_demands_089 : List (List Nat) := [

]
theorem compact113_demands_089_exact : rowDemand113 89=compact113_demands_089 := by decide +kernel

def compact113_demands_090 : List (List Nat) := [
  [9,9,10,10,10,10,10,10,10,10,15],
  [9,9,9,10,10,10,10,10,10,10,18],
  [9,9,9,9,9,10,10,10,10,15,15],
  [9,9,9,9,9,10,10,10,10,10,30],
  [9,9,9,9,9,9,10,10,10,15,18],
  [9,9,9,9,9,9,10,10,10,10,45],
  [9,9,9,9,9,9,9,10,10,18,18],
  [9,9,9,9,9,9,9,10,10,10,90],
  [9,9,9,9,9,9,9,9,15,15,15],
  [9,9,9,9,9,9,9,9,10,15,30],
  [9,9,9,9,9,9,9,9,9,18,30],
  [9,9,9,9,9,9,9,9,9,15,45]
]
theorem compact113_demands_090_exact : rowDemand113 90=compact113_demands_090 := by decide +kernel

def compact113_demands_091 : List (List Nat) := [

]
theorem compact113_demands_091_exact : rowDemand113 91=compact113_demands_091 := by decide +kernel

end Symconf113

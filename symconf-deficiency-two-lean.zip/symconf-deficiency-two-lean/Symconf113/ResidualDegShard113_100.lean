import Symconf113.ResidualDegDefs113

/-! Kernel check: the degree search below type-`A` rows 100 and 101. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem degShard_100 : ((degTopList.drop 100).take 2).all degTop=true := by decide +kernel
end Symconf113

import Symconf113.CoverageShard113_077

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2790 : NodeCoverage113 [27,27,27,24] 24 8 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2791 : NodeCoverage113 [27,27,27,23] 23 9 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2792 : NodeCoverage113 [27,27,27,22] 22 10 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2793 : NodeCoverage113 [27,27,27,21] 21 11 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2794 : NodeCoverage113 [27,27,27,20] 20 12 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2795 : NodeCoverage113 [27,27,27,19] 19 13 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2796 : NodeCoverage113 [27,27,27,18] 18 14 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2797 : NodeCoverage113 [27,27,27,17] 17 15 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2798 : NodeCoverage113 [27,27,27,16] 16 16 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2799 : NodeCoverage113 [27,27,27,15] 15 17 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2800 : NodeCoverage113 [27,27,27,14] 14 18 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2801 : NodeCoverage113 [27,27,27,13] 13 19 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2802 : NodeCoverage113 [27,27,27,12] 12 20 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2803 : NodeCoverage113 [27,27,27,11] 11 21 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2804 : NodeCoverage113 [27,27,27,10] 10 22 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2805 : NodeCoverage113 [27,27,27,9,9,9,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2806 : NodeCoverage113 [27,27,27,9,9,9] 9 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2805
    ChildrenCoverage113.nil)

theorem compact113_node_2807 : NodeCoverage113 [27,27,27,9,9,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2808 : NodeCoverage113 [27,27,27,9,9,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2809 : NodeCoverage113 [27,27,27,9,9,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2810 : NodeCoverage113 [27,27,27,9,9,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2811 : NodeCoverage113 [27,27,27,9,9,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_2812 : NodeCoverage113 [27,27,27,9,9,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2811
    ChildrenCoverage113.nil)

theorem compact113_node_2813 : NodeCoverage113 [27,27,27,9,9,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2812
    ChildrenCoverage113.nil)

theorem compact113_node_2814 : NodeCoverage113 [27,27,27,9,9] 9 14 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2806
    (ChildrenCoverage113.cons _ _ compact113_node_2807
    (ChildrenCoverage113.cons _ _ compact113_node_2808
    (ChildrenCoverage113.cons _ _ compact113_node_2809
    (ChildrenCoverage113.cons _ _ compact113_node_2810
    (ChildrenCoverage113.cons _ _ compact113_node_2813
    ChildrenCoverage113.nil))))))

theorem compact113_node_2815 : NodeCoverage113 [27,27,27,9,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2816 : NodeCoverage113 [27,27,27,9,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2817 : NodeCoverage113 [27,27,27,9,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2818 : NodeCoverage113 [27,27,27,9,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2819 : NodeCoverage113 [27,27,27,9,3] 3 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2820 : NodeCoverage113 [27,27,27,9] 9 23 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2814
    (ChildrenCoverage113.cons _ _ compact113_node_2815
    (ChildrenCoverage113.cons _ _ compact113_node_2816
    (ChildrenCoverage113.cons _ _ compact113_node_2817
    (ChildrenCoverage113.cons _ _ compact113_node_2818
    (ChildrenCoverage113.cons _ _ compact113_node_2819
    ChildrenCoverage113.nil))))))

theorem compact113_node_2821 : NodeCoverage113 [27,27,27,8] 8 24 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2822 : NodeCoverage113 [27,27,27,7] 7 25 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2823 : NodeCoverage113 [27,27,27,6] 6 26 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2824 : NodeCoverage113 [27,27,27,5] 5 27 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2825 : NodeCoverage113 [27,27,27,3] 3 29 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2826 : NodeCoverage113 [27,27,27] 27 32 :=
  node_fork113 (B := [27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2787
    (ChildrenCoverage113.cons _ _ compact113_node_2788
    (ChildrenCoverage113.cons _ _ compact113_node_2789
    (ChildrenCoverage113.cons _ _ compact113_node_2790
    (ChildrenCoverage113.cons _ _ compact113_node_2791
    (ChildrenCoverage113.cons _ _ compact113_node_2792
    (ChildrenCoverage113.cons _ _ compact113_node_2793
    (ChildrenCoverage113.cons _ _ compact113_node_2794
    (ChildrenCoverage113.cons _ _ compact113_node_2795
    (ChildrenCoverage113.cons _ _ compact113_node_2796
    (ChildrenCoverage113.cons _ _ compact113_node_2797
    (ChildrenCoverage113.cons _ _ compact113_node_2798
    (ChildrenCoverage113.cons _ _ compact113_node_2799
    (ChildrenCoverage113.cons _ _ compact113_node_2800
    (ChildrenCoverage113.cons _ _ compact113_node_2801
    (ChildrenCoverage113.cons _ _ compact113_node_2802
    (ChildrenCoverage113.cons _ _ compact113_node_2803
    (ChildrenCoverage113.cons _ _ compact113_node_2804
    (ChildrenCoverage113.cons _ _ compact113_node_2820
    (ChildrenCoverage113.cons _ _ compact113_node_2821
    (ChildrenCoverage113.cons _ _ compact113_node_2822
    (ChildrenCoverage113.cons _ _ compact113_node_2823
    (ChildrenCoverage113.cons _ _ compact113_node_2824
    (ChildrenCoverage113.cons _ _ compact113_node_2825
    ChildrenCoverage113.nil))))))))))))))))))))))))

theorem compact113_node_2827 : NodeCoverage113 [27,27,26] 26 33 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2828 : NodeCoverage113 [27,27,25] 25 34 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2829 : NodeCoverage113 [27,27,24] 24 35 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2830 : NodeCoverage113 [27,27,23] 23 36 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2831 : NodeCoverage113 [27,27,22] 22 37 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2832 : NodeCoverage113 [27,27,21] 21 38 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

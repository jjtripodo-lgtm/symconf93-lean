import Symconf113.CoverageShard113_136

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5480 : NodeCoverage113 [14,14,14,14,5] 5 52 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5481 : NodeCoverage113 [14,14,14,14,3] 3 54 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5482 : NodeCoverage113 [14,14,14,14] 14 57 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5434
    (ChildrenCoverage113.cons _ _ compact113_node_5435
    (ChildrenCoverage113.cons _ _ compact113_node_5436
    (ChildrenCoverage113.cons _ _ compact113_node_5437
    (ChildrenCoverage113.cons _ _ compact113_node_5438
    (ChildrenCoverage113.cons _ _ compact113_node_5439
    (ChildrenCoverage113.cons _ _ compact113_node_5440
    (ChildrenCoverage113.cons _ _ compact113_node_5478
    (ChildrenCoverage113.cons _ _ compact113_node_5479
    (ChildrenCoverage113.cons _ _ compact113_node_5480
    (ChildrenCoverage113.cons _ _ compact113_node_5481
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_5483 : NodeCoverage113 [14,14,14,13] 13 58 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5484 : NodeCoverage113 [14,14,14,12] 12 59 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5485 : NodeCoverage113 [14,14,14,11] 11 60 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5486 : NodeCoverage113 [14,14,14,10] 10 61 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5487 : NodeCoverage113 [14,14,14,9] 9 62 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5488 : NodeCoverage113 [14,14,14,8] 8 63 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5489 : NodeCoverage113 [14,14,14,7,7,7,7,7,7,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5490 : NodeCoverage113 [14,14,14,7,7,7,7,7,7,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5491 : NodeCoverage113 [14,14,14,7,7,7,7,7,7,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5489
    (ChildrenCoverage113.cons _ _ compact113_node_5490
    ChildrenCoverage113.nil))

theorem compact113_node_5492 : NodeCoverage113 [14,14,14,7,7,7,7,7,7,7,7,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5493 : NodeCoverage113 [14,14,14,7,7,7,7,7,7,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5494 : NodeCoverage113 [14,14,14,7,7,7,7,7,7,7,7,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5495 : NodeCoverage113 [14,14,14,7,7,7,7,7,7,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5491
    (ChildrenCoverage113.cons _ _ compact113_node_5492
    (ChildrenCoverage113.cons _ _ compact113_node_5493
    (ChildrenCoverage113.cons _ _ compact113_node_5494
    ChildrenCoverage113.nil))))

theorem compact113_node_5496 : NodeCoverage113 [14,14,14,7,7,7,7,7,7,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5497 : NodeCoverage113 [14,14,14,7,7,7,7,7,7,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5498 : NodeCoverage113 [14,14,14,7,7,7,7,7,7,7,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5499 : NodeCoverage113 [14,14,14,7,7,7,7,7,7,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5495
    (ChildrenCoverage113.cons _ _ compact113_node_5496
    (ChildrenCoverage113.cons _ _ compact113_node_5497
    (ChildrenCoverage113.cons _ _ compact113_node_5498
    ChildrenCoverage113.nil))))

theorem compact113_node_5500 : NodeCoverage113 [14,14,14,7,7,7,7,7,7,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5501 : NodeCoverage113 [14,14,14,7,7,7,7,7,7,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5502 : NodeCoverage113 [14,14,14,7,7,7,7,7,7,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5503 : NodeCoverage113 [14,14,14,7,7,7,7,7,7] 7 29 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5499
    (ChildrenCoverage113.cons _ _ compact113_node_5500
    (ChildrenCoverage113.cons _ _ compact113_node_5501
    (ChildrenCoverage113.cons _ _ compact113_node_5502
    ChildrenCoverage113.nil))))

theorem compact113_node_5504 : NodeCoverage113 [14,14,14,7,7,7,7,7,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5505 : NodeCoverage113 [14,14,14,7,7,7,7,7,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5506 : NodeCoverage113 [14,14,14,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3,3] 3 0 :=
  node_no_weak_demand113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5507 : NodeCoverage113 [14,14,14,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5506
    ChildrenCoverage113.nil)

theorem compact113_node_5508 : NodeCoverage113 [14,14,14,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5507
    ChildrenCoverage113.nil)

theorem compact113_node_5509 : NodeCoverage113 [14,14,14,7,7,7,7,7,3,3,3,3,3,3,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5508
    ChildrenCoverage113.nil)

theorem compact113_node_5510 : NodeCoverage113 [14,14,14,7,7,7,7,7,3,3,3,3,3,3,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5509
    ChildrenCoverage113.nil)

theorem compact113_node_5511 : NodeCoverage113 [14,14,14,7,7,7,7,7,3,3,3,3,3,3,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5510
    ChildrenCoverage113.nil)

theorem compact113_node_5512 : NodeCoverage113 [14,14,14,7,7,7,7,7,3,3,3,3,3,3] 3 18 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5511
    ChildrenCoverage113.nil)

theorem compact113_node_5513 : NodeCoverage113 [14,14,14,7,7,7,7,7,3,3,3,3,3] 3 21 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5512
    ChildrenCoverage113.nil)

theorem compact113_node_5514 : NodeCoverage113 [14,14,14,7,7,7,7,7,3,3,3,3] 3 24 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5513
    ChildrenCoverage113.nil)

theorem compact113_node_5515 : NodeCoverage113 [14,14,14,7,7,7,7,7,3,3,3] 3 27 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5514
    ChildrenCoverage113.nil)

theorem compact113_node_5516 : NodeCoverage113 [14,14,14,7,7,7,7,7,3,3] 3 30 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5515
    ChildrenCoverage113.nil)

theorem compact113_node_5517 : NodeCoverage113 [14,14,14,7,7,7,7,7,3] 3 33 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5516
    ChildrenCoverage113.nil)

theorem compact113_node_5518 : NodeCoverage113 [14,14,14,7,7,7,7,7] 7 36 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5503
    (ChildrenCoverage113.cons _ _ compact113_node_5504
    (ChildrenCoverage113.cons _ _ compact113_node_5505
    (ChildrenCoverage113.cons _ _ compact113_node_5517
    ChildrenCoverage113.nil))))

theorem compact113_node_5519 : NodeCoverage113 [14,14,14,7,7,7,7,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5520 : NodeCoverage113 [14,14,14,7,7,7,7,5] 5 38 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5521 : NodeCoverage113 [14,14,14,7,7,7,7,3] 3 40 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5522 : NodeCoverage113 [14,14,14,7,7,7,7] 7 43 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5518
    (ChildrenCoverage113.cons _ _ compact113_node_5519
    (ChildrenCoverage113.cons _ _ compact113_node_5520
    (ChildrenCoverage113.cons _ _ compact113_node_5521
    ChildrenCoverage113.nil))))

theorem compact113_node_5523 : NodeCoverage113 [14,14,14,7,7,7,6] 6 44 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5524 : NodeCoverage113 [14,14,14,7,7,7,5] 5 45 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5525 : NodeCoverage113 [14,14,14,7,7,7,3] 3 47 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5526 : NodeCoverage113 [14,14,14,7,7,7] 7 50 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5522
    (ChildrenCoverage113.cons _ _ compact113_node_5523
    (ChildrenCoverage113.cons _ _ compact113_node_5524
    (ChildrenCoverage113.cons _ _ compact113_node_5525
    ChildrenCoverage113.nil))))

theorem compact113_node_5527 : NodeCoverage113 [14,14,14,7,7,6] 6 51 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5528 : NodeCoverage113 [14,14,14,7,7,5] 5 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5529 : NodeCoverage113 [14,14,14,7,7,3] 3 54 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5530 : NodeCoverage113 [14,14,14,7,7] 7 57 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5526
    (ChildrenCoverage113.cons _ _ compact113_node_5527
    (ChildrenCoverage113.cons _ _ compact113_node_5528
    (ChildrenCoverage113.cons _ _ compact113_node_5529
    ChildrenCoverage113.nil))))

theorem compact113_node_5531 : NodeCoverage113 [14,14,14,7,6] 6 58 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5532 : NodeCoverage113 [14,14,14,7,5] 5 59 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5533 : NodeCoverage113 [14,14,14,7,3] 3 61 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5534 : NodeCoverage113 [14,14,14,7] 7 64 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5530
    (ChildrenCoverage113.cons _ _ compact113_node_5531
    (ChildrenCoverage113.cons _ _ compact113_node_5532
    (ChildrenCoverage113.cons _ _ compact113_node_5533
    ChildrenCoverage113.nil))))

theorem compact113_node_5535 : NodeCoverage113 [14,14,14,6] 6 65 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5536 : NodeCoverage113 [14,14,14,5] 5 66 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5537 : NodeCoverage113 [14,14,14,3] 3 68 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5538 : NodeCoverage113 [14,14,14] 14 71 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5482
    (ChildrenCoverage113.cons _ _ compact113_node_5483
    (ChildrenCoverage113.cons _ _ compact113_node_5484
    (ChildrenCoverage113.cons _ _ compact113_node_5485
    (ChildrenCoverage113.cons _ _ compact113_node_5486
    (ChildrenCoverage113.cons _ _ compact113_node_5487
    (ChildrenCoverage113.cons _ _ compact113_node_5488
    (ChildrenCoverage113.cons _ _ compact113_node_5534
    (ChildrenCoverage113.cons _ _ compact113_node_5535
    (ChildrenCoverage113.cons _ _ compact113_node_5536
    (ChildrenCoverage113.cons _ _ compact113_node_5537
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_5539 : NodeCoverage113 [14,14,13,13,13] 13 46 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5540 : NodeCoverage113 [14,14,13,13,12] 12 47 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5541 : NodeCoverage113 [14,14,13,13,11] 11 48 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5542 : NodeCoverage113 [14,14,13,13,10] 10 49 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5543 : NodeCoverage113 [14,14,13,13,9] 9 50 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5544 : NodeCoverage113 [14,14,13,13,8] 8 51 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5545 : NodeCoverage113 [14,14,13,13,7] 7 52 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5546 : NodeCoverage113 [14,14,13,13,6] 6 53 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5547 : NodeCoverage113 [14,14,13,13,5] 5 54 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5548 : NodeCoverage113 [14,14,13,13,3] 3 56 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5549 : NodeCoverage113 [14,14,13,13] 13 59 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5539
    (ChildrenCoverage113.cons _ _ compact113_node_5540
    (ChildrenCoverage113.cons _ _ compact113_node_5541
    (ChildrenCoverage113.cons _ _ compact113_node_5542
    (ChildrenCoverage113.cons _ _ compact113_node_5543
    (ChildrenCoverage113.cons _ _ compact113_node_5544
    (ChildrenCoverage113.cons _ _ compact113_node_5545
    (ChildrenCoverage113.cons _ _ compact113_node_5546
    (ChildrenCoverage113.cons _ _ compact113_node_5547
    (ChildrenCoverage113.cons _ _ compact113_node_5548
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_5550 : NodeCoverage113 [14,14,13,12] 12 60 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5551 : NodeCoverage113 [14,14,13,11] 11 61 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5552 : NodeCoverage113 [14,14,13,10] 10 62 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5553 : NodeCoverage113 [14,14,13,9] 9 63 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5554 : NodeCoverage113 [14,14,13,8] 8 64 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

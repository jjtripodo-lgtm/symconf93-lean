import Symconf113.CoverageShard113_063
import Symconf113.CoverageShard113_066
import Symconf113.CoverageShard113_067
import Symconf113.CoverageShard113_072

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2543 : NodeCoverage113 [30,5] 5 78 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2544 : NodeCoverage113 [30,3] 3 80 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2545 : NodeCoverage113 [30] 30 83 :=
  node_fork113 (B := [30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2404
    (ChildrenCoverage113.cons _ _ compact113_node_2405
    (ChildrenCoverage113.cons _ _ compact113_node_2406
    (ChildrenCoverage113.cons _ _ compact113_node_2407
    (ChildrenCoverage113.cons _ _ compact113_node_2408
    (ChildrenCoverage113.cons _ _ compact113_node_2409
    (ChildrenCoverage113.cons _ _ compact113_node_2410
    (ChildrenCoverage113.cons _ _ compact113_node_2411
    (ChildrenCoverage113.cons _ _ compact113_node_2412
    (ChildrenCoverage113.cons _ _ compact113_node_2413
    (ChildrenCoverage113.cons _ _ compact113_node_2414
    (ChildrenCoverage113.cons _ _ compact113_node_2415
    (ChildrenCoverage113.cons _ _ compact113_node_2416
    (ChildrenCoverage113.cons _ _ compact113_node_2417
    (ChildrenCoverage113.cons _ _ compact113_node_2418
    (ChildrenCoverage113.cons _ _ compact113_node_2467
    (ChildrenCoverage113.cons _ _ compact113_node_2468
    (ChildrenCoverage113.cons _ _ compact113_node_2469
    (ChildrenCoverage113.cons _ _ compact113_node_2479
    (ChildrenCoverage113.cons _ _ compact113_node_2488
    (ChildrenCoverage113.cons _ _ compact113_node_2538
    (ChildrenCoverage113.cons _ _ compact113_node_2539
    (ChildrenCoverage113.cons _ _ compact113_node_2540
    (ChildrenCoverage113.cons _ _ compact113_node_2541
    (ChildrenCoverage113.cons _ _ compact113_node_2542
    (ChildrenCoverage113.cons _ _ compact113_node_2543
    (ChildrenCoverage113.cons _ _ compact113_node_2544
    ChildrenCoverage113.nil)))))))))))))))))))))))))))

theorem compact113_node_2546 : NodeCoverage113 [29] 29 84 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2547 : NodeCoverage113 [28,28,28,26] 26 3 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2548 : NodeCoverage113 [28,28,28,25] 25 4 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2549 : NodeCoverage113 [28,28,28,24] 24 5 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2550 : NodeCoverage113 [28,28,28,23] 23 6 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2551 : NodeCoverage113 [28,28,28,22] 22 7 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2552 : NodeCoverage113 [28,28,28,21] 21 8 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2553 : NodeCoverage113 [28,28,28,20] 20 9 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2554 : NodeCoverage113 [28,28,28,19] 19 10 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2555 : NodeCoverage113 [28,28,28,18] 18 11 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2556 : NodeCoverage113 [28,28,28,17] 17 12 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2557 : NodeCoverage113 [28,28,28,16] 16 13 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2558 : NodeCoverage113 [28,28,28,15] 15 14 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2559 : NodeCoverage113 [28,28,28,14,12] 12 3 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2560 : NodeCoverage113 [28,28,28,14,11] 11 4 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

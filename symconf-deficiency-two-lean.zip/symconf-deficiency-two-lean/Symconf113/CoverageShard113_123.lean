import Symconf113.CoverageShard113_122

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4763 : NodeCoverage113 [18,15,3] 3 77 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4764 : NodeCoverage113 [18,15] 15 80 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4752
    (ChildrenCoverage113.cons _ _ compact113_node_4753
    (ChildrenCoverage113.cons _ _ compact113_node_4754
    (ChildrenCoverage113.cons _ _ compact113_node_4755
    (ChildrenCoverage113.cons _ _ compact113_node_4756
    (ChildrenCoverage113.cons _ _ compact113_node_4757
    (ChildrenCoverage113.cons _ _ compact113_node_4758
    (ChildrenCoverage113.cons _ _ compact113_node_4759
    (ChildrenCoverage113.cons _ _ compact113_node_4760
    (ChildrenCoverage113.cons _ _ compact113_node_4761
    (ChildrenCoverage113.cons _ _ compact113_node_4762
    (ChildrenCoverage113.cons _ _ compact113_node_4763
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_4765 : NodeCoverage113 [18,14,14] 14 67 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4766 : NodeCoverage113 [18,14,13] 13 68 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4767 : NodeCoverage113 [18,14,12,12] 12 57 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4768 : NodeCoverage113 [18,14,12,11] 11 58 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4769 : NodeCoverage113 [18,14,12,10] 10 59 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4770 : NodeCoverage113 [18,14,12,9] 9 60 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4771 : NodeCoverage113 [18,14,12,8] 8 61 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4772 : NodeCoverage113 [18,14,12,7] 7 62 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4773 : NodeCoverage113 [18,14,12,6] 6 63 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4774 : NodeCoverage113 [18,14,12,5] 5 64 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4775 : NodeCoverage113 [18,14,12,3] 3 66 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4776 : NodeCoverage113 [18,14,12] 12 69 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4767
    (ChildrenCoverage113.cons _ _ compact113_node_4768
    (ChildrenCoverage113.cons _ _ compact113_node_4769
    (ChildrenCoverage113.cons _ _ compact113_node_4770
    (ChildrenCoverage113.cons _ _ compact113_node_4771
    (ChildrenCoverage113.cons _ _ compact113_node_4772
    (ChildrenCoverage113.cons _ _ compact113_node_4773
    (ChildrenCoverage113.cons _ _ compact113_node_4774
    (ChildrenCoverage113.cons _ _ compact113_node_4775
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_4777 : NodeCoverage113 [18,14,11,11] 11 59 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4778 : NodeCoverage113 [18,14,11,10] 10 60 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4779 : NodeCoverage113 [18,14,11,9] 9 61 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4780 : NodeCoverage113 [18,14,11,8] 8 62 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4781 : NodeCoverage113 [18,14,11,7] 7 63 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4782 : NodeCoverage113 [18,14,11,6] 6 64 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4783 : NodeCoverage113 [18,14,11,5] 5 65 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4784 : NodeCoverage113 [18,14,11,3] 3 67 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4785 : NodeCoverage113 [18,14,11] 11 70 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4777
    (ChildrenCoverage113.cons _ _ compact113_node_4778
    (ChildrenCoverage113.cons _ _ compact113_node_4779
    (ChildrenCoverage113.cons _ _ compact113_node_4780
    (ChildrenCoverage113.cons _ _ compact113_node_4781
    (ChildrenCoverage113.cons _ _ compact113_node_4782
    (ChildrenCoverage113.cons _ _ compact113_node_4783
    (ChildrenCoverage113.cons _ _ compact113_node_4784
    ChildrenCoverage113.nil))))))))

theorem compact113_node_4786 : NodeCoverage113 [18,14,10,10] 10 61 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4787 : NodeCoverage113 [18,14,10,9] 9 62 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4788 : NodeCoverage113 [18,14,10,8] 8 63 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4789 : NodeCoverage113 [18,14,10,7] 7 64 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4790 : NodeCoverage113 [18,14,10,6] 6 65 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4791 : NodeCoverage113 [18,14,10,5] 5 66 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4792 : NodeCoverage113 [18,14,10,3] 3 68 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4793 : NodeCoverage113 [18,14,10] 10 71 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4786
    (ChildrenCoverage113.cons _ _ compact113_node_4787
    (ChildrenCoverage113.cons _ _ compact113_node_4788
    (ChildrenCoverage113.cons _ _ compact113_node_4789
    (ChildrenCoverage113.cons _ _ compact113_node_4790
    (ChildrenCoverage113.cons _ _ compact113_node_4791
    (ChildrenCoverage113.cons _ _ compact113_node_4792
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4794 : NodeCoverage113 [18,14,9,9,9] 9 54 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4795 : NodeCoverage113 [18,14,9,9,8] 8 55 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4796 : NodeCoverage113 [18,14,9,9,7] 7 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4797 : NodeCoverage113 [18,14,9,9,6] 6 57 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4798 : NodeCoverage113 [18,14,9,9,5] 5 58 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4799 : NodeCoverage113 [18,14,9,9,3] 3 60 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4800 : NodeCoverage113 [18,14,9,9] 9 63 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4794
    (ChildrenCoverage113.cons _ _ compact113_node_4795
    (ChildrenCoverage113.cons _ _ compact113_node_4796
    (ChildrenCoverage113.cons _ _ compact113_node_4797
    (ChildrenCoverage113.cons _ _ compact113_node_4798
    (ChildrenCoverage113.cons _ _ compact113_node_4799
    ChildrenCoverage113.nil))))))

theorem compact113_node_4801 : NodeCoverage113 [18,14,9,8] 8 64 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4802 : NodeCoverage113 [18,14,9,7] 7 65 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4803 : NodeCoverage113 [18,14,9,6] 6 66 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4804 : NodeCoverage113 [18,14,9,5] 5 67 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

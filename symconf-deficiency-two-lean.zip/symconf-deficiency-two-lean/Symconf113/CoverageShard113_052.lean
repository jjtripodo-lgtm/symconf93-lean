import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2131 : NodeCoverage113 [32,32,30] 30 19 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2132 : NodeCoverage113 [32,32,29] 29 20 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2133 : NodeCoverage113 [32,32,28] 28 21 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2134 : NodeCoverage113 [32,32,27] 27 22 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2135 : NodeCoverage113 [32,32,26] 26 23 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2136 : NodeCoverage113 [32,32,25] 25 24 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2137 : NodeCoverage113 [32,32,24] 24 25 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2138 : NodeCoverage113 [32,32,23] 23 26 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2139 : NodeCoverage113 [32,32,22] 22 27 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2140 : NodeCoverage113 [32,32,21] 21 28 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2141 : NodeCoverage113 [32,32,20] 20 29 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2142 : NodeCoverage113 [32,32,19] 19 30 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2143 : NodeCoverage113 [32,32,18] 18 31 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2144 : NodeCoverage113 [32,32,17] 17 32 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2145 : NodeCoverage113 [32,32,16,16,14] 14 3 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2146 : NodeCoverage113 [32,32,16,16,13] 13 4 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2147 : NodeCoverage113 [32,32,16,16,12] 12 5 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2148 : NodeCoverage113 [32,32,16,16,11] 11 6 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2149 : NodeCoverage113 [32,32,16,16,10] 10 7 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2150 : NodeCoverage113 [32,32,16,16,9] 9 8 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2151 : NodeCoverage113 [32,32,16,16,8] 8 9 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2152 : NodeCoverage113 [32,32,16,16,7] 7 10 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2153 : NodeCoverage113 [32,32,16,16,6] 6 11 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2154 : NodeCoverage113 [32,32,16,16,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2155 : NodeCoverage113 [32,32,16,16,3] 3 14 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2156 : NodeCoverage113 [32,32,16,16] 16 17 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2145
    (ChildrenCoverage113.cons _ _ compact113_node_2146
    (ChildrenCoverage113.cons _ _ compact113_node_2147
    (ChildrenCoverage113.cons _ _ compact113_node_2148
    (ChildrenCoverage113.cons _ _ compact113_node_2149
    (ChildrenCoverage113.cons _ _ compact113_node_2150
    (ChildrenCoverage113.cons _ _ compact113_node_2151
    (ChildrenCoverage113.cons _ _ compact113_node_2152
    (ChildrenCoverage113.cons _ _ compact113_node_2153
    (ChildrenCoverage113.cons _ _ compact113_node_2154
    (ChildrenCoverage113.cons _ _ compact113_node_2155
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_2157 : NodeCoverage113 [32,32,16,15] 15 18 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2158 : NodeCoverage113 [32,32,16,14] 14 19 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2159 : NodeCoverage113 [32,32,16,13] 13 20 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2160 : NodeCoverage113 [32,32,16,12] 12 21 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2161 : NodeCoverage113 [32,32,16,11] 11 22 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

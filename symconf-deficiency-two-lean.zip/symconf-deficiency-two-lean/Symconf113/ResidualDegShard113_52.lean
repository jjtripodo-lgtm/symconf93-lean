import Symconf113.ResidualDegDefs113

/-! Kernel check: the degree search below type-`A` rows 52 and 53. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem degShard_52 : ((degTopList.drop 52).take 2).all degTop=true := by decide +kernel
end Symconf113

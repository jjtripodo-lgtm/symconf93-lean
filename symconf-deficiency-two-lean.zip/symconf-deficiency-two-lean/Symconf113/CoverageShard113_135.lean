import Symconf113.CoverageShard113_134

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5357 : NodeCoverage113 [15,7] 7 91 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5358 : NodeCoverage113 [15,6] 6 92 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5359 : NodeCoverage113 [15,5] 5 93 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5360 : NodeCoverage113 [15,3] 3 95 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5361 : NodeCoverage113 [15] 15 98 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5349
    (ChildrenCoverage113.cons _ _ compact113_node_5350
    (ChildrenCoverage113.cons _ _ compact113_node_5351
    (ChildrenCoverage113.cons _ _ compact113_node_5352
    (ChildrenCoverage113.cons _ _ compact113_node_5353
    (ChildrenCoverage113.cons _ _ compact113_node_5354
    (ChildrenCoverage113.cons _ _ compact113_node_5355
    (ChildrenCoverage113.cons _ _ compact113_node_5356
    (ChildrenCoverage113.cons _ _ compact113_node_5357
    (ChildrenCoverage113.cons _ _ compact113_node_5358
    (ChildrenCoverage113.cons _ _ compact113_node_5359
    (ChildrenCoverage113.cons _ _ compact113_node_5360
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_5362 : NodeCoverage113 [14,14,14,14,14,14,14,12] 12 3 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5363 : NodeCoverage113 [14,14,14,14,14,14,14,11] 11 4 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5364 : NodeCoverage113 [14,14,14,14,14,14,14,10] 10 5 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5365 : NodeCoverage113 [14,14,14,14,14,14,14,9] 9 6 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5366 : NodeCoverage113 [14,14,14,14,14,14,14,8] 8 7 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5367 : NodeCoverage113 [14,14,14,14,14,14,14,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5368 : NodeCoverage113 [14,14,14,14,14,14,14,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5369 : NodeCoverage113 [14,14,14,14,14,14,14,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5367
    (ChildrenCoverage113.cons _ _ compact113_node_5368
    ChildrenCoverage113.nil))

theorem compact113_node_5370 : NodeCoverage113 [14,14,14,14,14,14,14,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5371 : NodeCoverage113 [14,14,14,14,14,14,14,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5372 : NodeCoverage113 [14,14,14,14,14,14,14,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5373 : NodeCoverage113 [14,14,14,14,14,14,14] 14 15 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5362
    (ChildrenCoverage113.cons _ _ compact113_node_5363
    (ChildrenCoverage113.cons _ _ compact113_node_5364
    (ChildrenCoverage113.cons _ _ compact113_node_5365
    (ChildrenCoverage113.cons _ _ compact113_node_5366
    (ChildrenCoverage113.cons _ _ compact113_node_5369
    (ChildrenCoverage113.cons _ _ compact113_node_5370
    (ChildrenCoverage113.cons _ _ compact113_node_5371
    (ChildrenCoverage113.cons _ _ compact113_node_5372
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_5374 : NodeCoverage113 [14,14,14,14,14,14,13] 13 16 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5375 : NodeCoverage113 [14,14,14,14,14,14,12] 12 17 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5376 : NodeCoverage113 [14,14,14,14,14,14,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5377 : NodeCoverage113 [14,14,14,14,14,14,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5378 : NodeCoverage113 [14,14,14,14,14,14,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5379 : NodeCoverage113 [14,14,14,14,14,14,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5380 : NodeCoverage113 [14,14,14,14,14,14,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5381 : NodeCoverage113 [14,14,14,14,14,14,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5382 : NodeCoverage113 [14,14,14,14,14,14,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5380
    (ChildrenCoverage113.cons _ _ compact113_node_5381
    ChildrenCoverage113.nil))

theorem compact113_node_5383 : NodeCoverage113 [14,14,14,14,14,14,7,7,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5384 : NodeCoverage113 [14,14,14,14,14,14,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5385 : NodeCoverage113 [14,14,14,14,14,14,7,7,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5386 : NodeCoverage113 [14,14,14,14,14,14,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5382
    (ChildrenCoverage113.cons _ _ compact113_node_5383
    (ChildrenCoverage113.cons _ _ compact113_node_5384
    (ChildrenCoverage113.cons _ _ compact113_node_5385
    ChildrenCoverage113.nil))))

theorem compact113_node_5387 : NodeCoverage113 [14,14,14,14,14,14,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5388 : NodeCoverage113 [14,14,14,14,14,14,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5389 : NodeCoverage113 [14,14,14,14,14,14,7,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5390 : NodeCoverage113 [14,14,14,14,14,14,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5386
    (ChildrenCoverage113.cons _ _ compact113_node_5387
    (ChildrenCoverage113.cons _ _ compact113_node_5388
    (ChildrenCoverage113.cons _ _ compact113_node_5389
    ChildrenCoverage113.nil))))

theorem compact113_node_5391 : NodeCoverage113 [14,14,14,14,14,14,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5392 : NodeCoverage113 [14,14,14,14,14,14,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5393 : NodeCoverage113 [14,14,14,14,14,14,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5394 : NodeCoverage113 [14,14,14,14,14,14] 14 29 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5373
    (ChildrenCoverage113.cons _ _ compact113_node_5374
    (ChildrenCoverage113.cons _ _ compact113_node_5375
    (ChildrenCoverage113.cons _ _ compact113_node_5376
    (ChildrenCoverage113.cons _ _ compact113_node_5377
    (ChildrenCoverage113.cons _ _ compact113_node_5378
    (ChildrenCoverage113.cons _ _ compact113_node_5379
    (ChildrenCoverage113.cons _ _ compact113_node_5390
    (ChildrenCoverage113.cons _ _ compact113_node_5391
    (ChildrenCoverage113.cons _ _ compact113_node_5392
    (ChildrenCoverage113.cons _ _ compact113_node_5393
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_5395 : NodeCoverage113 [14,14,14,14,14,13] 13 30 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5396 : NodeCoverage113 [14,14,14,14,14,12] 12 31 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5397 : NodeCoverage113 [14,14,14,14,14,11] 11 32 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5398 : NodeCoverage113 [14,14,14,14,14,10] 10 33 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5399 : NodeCoverage113 [14,14,14,14,14,9] 9 34 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5400 : NodeCoverage113 [14,14,14,14,14,8] 8 35 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5401 : NodeCoverage113 [14,14,14,14,14,7,7,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5402 : NodeCoverage113 [14,14,14,14,14,7,7,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5403 : NodeCoverage113 [14,14,14,14,14,7,7,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5401
    (ChildrenCoverage113.cons _ _ compact113_node_5402
    ChildrenCoverage113.nil))

theorem compact113_node_5404 : NodeCoverage113 [14,14,14,14,14,7,7,7,7,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

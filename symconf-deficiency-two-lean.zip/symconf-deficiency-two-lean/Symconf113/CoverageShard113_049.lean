import Symconf113.CoverageShard113_048

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1990 : NodeCoverage113 [33,33,23] 23 24 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1991 : NodeCoverage113 [33,33,22] 22 25 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1992 : NodeCoverage113 [33,33,21] 21 26 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1993 : NodeCoverage113 [33,33,20] 20 27 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1994 : NodeCoverage113 [33,33,19] 19 28 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1995 : NodeCoverage113 [33,33,18] 18 29 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1996 : NodeCoverage113 [33,33,17] 17 30 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1997 : NodeCoverage113 [33,33,16] 16 31 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1998 : NodeCoverage113 [33,33,15] 15 32 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1999 : NodeCoverage113 [33,33,14] 14 33 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2000 : NodeCoverage113 [33,33,13] 13 34 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2001 : NodeCoverage113 [33,33,12] 12 35 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2002 : NodeCoverage113 [33,33,11,11,11,11,3] 3 0 :=
  node_no_weak_demand113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2003 : NodeCoverage113 [33,33,11,11,11,11] 11 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2002
    ChildrenCoverage113.nil)

theorem compact113_node_2004 : NodeCoverage113 [33,33,11,11,11,10] 10 4 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2005 : NodeCoverage113 [33,33,11,11,11,9] 9 5 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2006 : NodeCoverage113 [33,33,11,11,11,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2007 : NodeCoverage113 [33,33,11,11,11,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2008 : NodeCoverage113 [33,33,11,11,11,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2009 : NodeCoverage113 [33,33,11,11,11,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2010 : NodeCoverage113 [33,33,11,11,11,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_2011 : NodeCoverage113 [33,33,11,11,11,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2010
    ChildrenCoverage113.nil)

theorem compact113_node_2012 : NodeCoverage113 [33,33,11,11,11,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2011
    ChildrenCoverage113.nil)

theorem compact113_node_2013 : NodeCoverage113 [33,33,11,11,11] 11 14 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2003
    (ChildrenCoverage113.cons _ _ compact113_node_2004
    (ChildrenCoverage113.cons _ _ compact113_node_2005
    (ChildrenCoverage113.cons _ _ compact113_node_2006
    (ChildrenCoverage113.cons _ _ compact113_node_2007
    (ChildrenCoverage113.cons _ _ compact113_node_2008
    (ChildrenCoverage113.cons _ _ compact113_node_2009
    (ChildrenCoverage113.cons _ _ compact113_node_2012
    ChildrenCoverage113.nil))))))))

theorem compact113_node_2014 : NodeCoverage113 [33,33,11,11,10] 10 15 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2015 : NodeCoverage113 [33,33,11,11,9] 9 16 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2016 : NodeCoverage113 [33,33,11,11,8] 8 17 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2017 : NodeCoverage113 [33,33,11,11,7] 7 18 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2018 : NodeCoverage113 [33,33,11,11,6] 6 19 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2019 : NodeCoverage113 [33,33,11,11,5] 5 20 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2020 : NodeCoverage113 [33,33,11,11,3] 3 22 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2021 : NodeCoverage113 [33,33,11,11] 11 25 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2013
    (ChildrenCoverage113.cons _ _ compact113_node_2014
    (ChildrenCoverage113.cons _ _ compact113_node_2015
    (ChildrenCoverage113.cons _ _ compact113_node_2016
    (ChildrenCoverage113.cons _ _ compact113_node_2017
    (ChildrenCoverage113.cons _ _ compact113_node_2018
    (ChildrenCoverage113.cons _ _ compact113_node_2019
    (ChildrenCoverage113.cons _ _ compact113_node_2020
    ChildrenCoverage113.nil))))))))

theorem compact113_node_2022 : NodeCoverage113 [33,33,11,10] 10 26 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2023 : NodeCoverage113 [33,33,11,9] 9 27 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2024 : NodeCoverage113 [33,33,11,8] 8 28 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2025 : NodeCoverage113 [33,33,11,7] 7 29 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2026 : NodeCoverage113 [33,33,11,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2027 : NodeCoverage113 [33,33,11,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2028 : NodeCoverage113 [33,33,11,3] 3 33 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2029 : NodeCoverage113 [33,33,11] 11 36 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2021
    (ChildrenCoverage113.cons _ _ compact113_node_2022
    (ChildrenCoverage113.cons _ _ compact113_node_2023
    (ChildrenCoverage113.cons _ _ compact113_node_2024
    (ChildrenCoverage113.cons _ _ compact113_node_2025
    (ChildrenCoverage113.cons _ _ compact113_node_2026
    (ChildrenCoverage113.cons _ _ compact113_node_2027
    (ChildrenCoverage113.cons _ _ compact113_node_2028
    ChildrenCoverage113.nil))))))))

theorem compact113_node_2030 : NodeCoverage113 [33,33,10] 10 37 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2031 : NodeCoverage113 [33,33,9] 9 38 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2032 : NodeCoverage113 [33,33,8] 8 39 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2033 : NodeCoverage113 [33,33,7] 7 40 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2034 : NodeCoverage113 [33,33,6] 6 41 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2035 : NodeCoverage113 [33,33,5] 5 42 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2036 : NodeCoverage113 [33,33,3] 3 44 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2037 : NodeCoverage113 [33,33] 33 47 :=
  node_fork113 (B := [33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1980
    (ChildrenCoverage113.cons _ _ compact113_node_1981
    (ChildrenCoverage113.cons _ _ compact113_node_1982
    (ChildrenCoverage113.cons _ _ compact113_node_1983
    (ChildrenCoverage113.cons _ _ compact113_node_1984
    (ChildrenCoverage113.cons _ _ compact113_node_1985
    (ChildrenCoverage113.cons _ _ compact113_node_1986
    (ChildrenCoverage113.cons _ _ compact113_node_1987
    (ChildrenCoverage113.cons _ _ compact113_node_1988
    (ChildrenCoverage113.cons _ _ compact113_node_1989
    (ChildrenCoverage113.cons _ _ compact113_node_1990
    (ChildrenCoverage113.cons _ _ compact113_node_1991
    (ChildrenCoverage113.cons _ _ compact113_node_1992
    (ChildrenCoverage113.cons _ _ compact113_node_1993
    (ChildrenCoverage113.cons _ _ compact113_node_1994
    (ChildrenCoverage113.cons _ _ compact113_node_1995
    (ChildrenCoverage113.cons _ _ compact113_node_1996
    (ChildrenCoverage113.cons _ _ compact113_node_1997
    (ChildrenCoverage113.cons _ _ compact113_node_1998
    (ChildrenCoverage113.cons _ _ compact113_node_1999
    (ChildrenCoverage113.cons _ _ compact113_node_2000
    (ChildrenCoverage113.cons _ _ compact113_node_2001
    (ChildrenCoverage113.cons _ _ compact113_node_2029
    (ChildrenCoverage113.cons _ _ compact113_node_2030
    (ChildrenCoverage113.cons _ _ compact113_node_2031
    (ChildrenCoverage113.cons _ _ compact113_node_2032
    (ChildrenCoverage113.cons _ _ compact113_node_2033
    (ChildrenCoverage113.cons _ _ compact113_node_2034
    (ChildrenCoverage113.cons _ _ compact113_node_2035
    (ChildrenCoverage113.cons _ _ compact113_node_2036
    ChildrenCoverage113.nil))))))))))))))))))))))))))))))

theorem compact113_node_2038 : NodeCoverage113 [33,32] 32 48 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2039 : NodeCoverage113 [33,31] 31 49 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

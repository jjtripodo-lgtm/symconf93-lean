import Symconf113.CoverageShard113_142

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5863 : NodeCoverage113 [14,9,9,9,9,6] 6 57 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5864 : NodeCoverage113 [14,9,9,9,9,5] 5 58 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5865 : NodeCoverage113 [14,9,9,9,9,3] 3 60 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5866 : NodeCoverage113 [14,9,9,9,9] 9 63 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5860
    (ChildrenCoverage113.cons _ _ compact113_node_5861
    (ChildrenCoverage113.cons _ _ compact113_node_5862
    (ChildrenCoverage113.cons _ _ compact113_node_5863
    (ChildrenCoverage113.cons _ _ compact113_node_5864
    (ChildrenCoverage113.cons _ _ compact113_node_5865
    ChildrenCoverage113.nil))))))

theorem compact113_node_5867 : NodeCoverage113 [14,9,9,9,8] 8 64 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5868 : NodeCoverage113 [14,9,9,9,7] 7 65 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5869 : NodeCoverage113 [14,9,9,9,6] 6 66 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5870 : NodeCoverage113 [14,9,9,9,5] 5 67 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5871 : NodeCoverage113 [14,9,9,9,3] 3 69 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5872 : NodeCoverage113 [14,9,9,9] 9 72 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5866
    (ChildrenCoverage113.cons _ _ compact113_node_5867
    (ChildrenCoverage113.cons _ _ compact113_node_5868
    (ChildrenCoverage113.cons _ _ compact113_node_5869
    (ChildrenCoverage113.cons _ _ compact113_node_5870
    (ChildrenCoverage113.cons _ _ compact113_node_5871
    ChildrenCoverage113.nil))))))

theorem compact113_node_5873 : NodeCoverage113 [14,9,9,8] 8 73 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5874 : NodeCoverage113 [14,9,9,7] 7 74 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5875 : NodeCoverage113 [14,9,9,6] 6 75 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5876 : NodeCoverage113 [14,9,9,5] 5 76 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5877 : NodeCoverage113 [14,9,9,3] 3 78 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5878 : NodeCoverage113 [14,9,9] 9 81 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5872
    (ChildrenCoverage113.cons _ _ compact113_node_5873
    (ChildrenCoverage113.cons _ _ compact113_node_5874
    (ChildrenCoverage113.cons _ _ compact113_node_5875
    (ChildrenCoverage113.cons _ _ compact113_node_5876
    (ChildrenCoverage113.cons _ _ compact113_node_5877
    ChildrenCoverage113.nil))))))

theorem compact113_node_5879 : NodeCoverage113 [14,9,8] 8 82 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5880 : NodeCoverage113 [14,9,7] 7 83 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5881 : NodeCoverage113 [14,9,6] 6 84 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5882 : NodeCoverage113 [14,9,5] 5 85 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5883 : NodeCoverage113 [14,9,3] 3 87 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5884 : NodeCoverage113 [14,9] 9 90 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5878
    (ChildrenCoverage113.cons _ _ compact113_node_5879
    (ChildrenCoverage113.cons _ _ compact113_node_5880
    (ChildrenCoverage113.cons _ _ compact113_node_5881
    (ChildrenCoverage113.cons _ _ compact113_node_5882
    (ChildrenCoverage113.cons _ _ compact113_node_5883
    ChildrenCoverage113.nil))))))

theorem compact113_node_5885 : NodeCoverage113 [14,8] 8 91 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5886 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,7,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5887 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,7,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5888 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,7,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5886
    (ChildrenCoverage113.cons _ _ compact113_node_5887
    ChildrenCoverage113.nil))

theorem compact113_node_5889 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,7,7,7,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5890 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,7,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5891 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,7,7,7,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5892 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,7,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5888
    (ChildrenCoverage113.cons _ _ compact113_node_5889
    (ChildrenCoverage113.cons _ _ compact113_node_5890
    (ChildrenCoverage113.cons _ _ compact113_node_5891
    ChildrenCoverage113.nil))))

theorem compact113_node_5893 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,7,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5894 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,7,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5895 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,7,7,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5896 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,7,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5892
    (ChildrenCoverage113.cons _ _ compact113_node_5893
    (ChildrenCoverage113.cons _ _ compact113_node_5894
    (ChildrenCoverage113.cons _ _ compact113_node_5895
    ChildrenCoverage113.nil))))

theorem compact113_node_5897 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,7,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5898 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,7,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5899 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,7,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5900 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,7] 7 29 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5896
    (ChildrenCoverage113.cons _ _ compact113_node_5897
    (ChildrenCoverage113.cons _ _ compact113_node_5898
    (ChildrenCoverage113.cons _ _ compact113_node_5899
    ChildrenCoverage113.nil))))

theorem compact113_node_5901 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5902 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5903 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3,3] 3 0 :=
  node_no_weak_demand113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5904 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5903
    ChildrenCoverage113.nil)

theorem compact113_node_5905 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5904
    ChildrenCoverage113.nil)

theorem compact113_node_5906 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5905
    ChildrenCoverage113.nil)

theorem compact113_node_5907 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5906
    ChildrenCoverage113.nil)

theorem compact113_node_5908 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5907
    ChildrenCoverage113.nil)

theorem compact113_node_5909 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,3,3,3,3,3,3] 3 18 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5908
    ChildrenCoverage113.nil)

theorem compact113_node_5910 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,3,3,3,3,3] 3 21 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5909
    ChildrenCoverage113.nil)

theorem compact113_node_5911 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,3,3,3,3] 3 24 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5910
    ChildrenCoverage113.nil)

theorem compact113_node_5912 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,3,3,3] 3 27 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5911
    ChildrenCoverage113.nil)

theorem compact113_node_5913 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,3,3] 3 30 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5912
    ChildrenCoverage113.nil)

theorem compact113_node_5914 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7,3] 3 33 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5913
    ChildrenCoverage113.nil)

theorem compact113_node_5915 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,7] 7 36 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5900
    (ChildrenCoverage113.cons _ _ compact113_node_5901
    (ChildrenCoverage113.cons _ _ compact113_node_5902
    (ChildrenCoverage113.cons _ _ compact113_node_5914
    ChildrenCoverage113.nil))))

theorem compact113_node_5916 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5917 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,5] 5 38 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5918 : NodeCoverage113 [14,7,7,7,7,7,7,7,7,3] 3 40 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5919 : NodeCoverage113 [14,7,7,7,7,7,7,7,7] 7 43 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5915
    (ChildrenCoverage113.cons _ _ compact113_node_5916
    (ChildrenCoverage113.cons _ _ compact113_node_5917
    (ChildrenCoverage113.cons _ _ compact113_node_5918
    ChildrenCoverage113.nil))))

theorem compact113_node_5920 : NodeCoverage113 [14,7,7,7,7,7,7,7,6] 6 44 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5921 : NodeCoverage113 [14,7,7,7,7,7,7,7,5] 5 45 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5922 : NodeCoverage113 [14,7,7,7,7,7,7,7,3] 3 47 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5923 : NodeCoverage113 [14,7,7,7,7,7,7,7] 7 50 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5919
    (ChildrenCoverage113.cons _ _ compact113_node_5920
    (ChildrenCoverage113.cons _ _ compact113_node_5921
    (ChildrenCoverage113.cons _ _ compact113_node_5922
    ChildrenCoverage113.nil))))

theorem compact113_node_5924 : NodeCoverage113 [14,7,7,7,7,7,7,6] 6 51 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5925 : NodeCoverage113 [14,7,7,7,7,7,7,5] 5 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5926 : NodeCoverage113 [14,7,7,7,7,7,7,3] 3 54 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5927 : NodeCoverage113 [14,7,7,7,7,7,7] 7 57 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5923
    (ChildrenCoverage113.cons _ _ compact113_node_5924
    (ChildrenCoverage113.cons _ _ compact113_node_5925
    (ChildrenCoverage113.cons _ _ compact113_node_5926
    ChildrenCoverage113.nil))))

theorem compact113_node_5928 : NodeCoverage113 [14,7,7,7,7,7,6] 6 58 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

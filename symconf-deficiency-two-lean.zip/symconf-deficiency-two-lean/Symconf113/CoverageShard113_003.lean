import Symconf113.CoverageShard113_002

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0133 : NodeCoverage113 [72,12,9,3] 3 17 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0134 : NodeCoverage113 [72,12,9] 9 20 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0128
    (ChildrenCoverage113.cons _ _ compact113_node_0129
    (ChildrenCoverage113.cons _ _ compact113_node_0130
    (ChildrenCoverage113.cons _ _ compact113_node_0131
    (ChildrenCoverage113.cons _ _ compact113_node_0132
    (ChildrenCoverage113.cons _ _ compact113_node_0133
    ChildrenCoverage113.nil))))))

theorem compact113_node_0135 : NodeCoverage113 [72,12,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0136 : NodeCoverage113 [72,12,7] 7 22 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0137 : NodeCoverage113 [72,12,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0138 : NodeCoverage113 [72,12,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0139 : NodeCoverage113 [72,12,3] 3 26 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0140 : NodeCoverage113 [72,12] 12 29 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0125
    (ChildrenCoverage113.cons _ _ compact113_node_0126
    (ChildrenCoverage113.cons _ _ compact113_node_0127
    (ChildrenCoverage113.cons _ _ compact113_node_0134
    (ChildrenCoverage113.cons _ _ compact113_node_0135
    (ChildrenCoverage113.cons _ _ compact113_node_0136
    (ChildrenCoverage113.cons _ _ compact113_node_0137
    (ChildrenCoverage113.cons _ _ compact113_node_0138
    (ChildrenCoverage113.cons _ _ compact113_node_0139
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_0141 : NodeCoverage113 [72,11] 11 30 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0142 : NodeCoverage113 [72,10] 10 31 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0143 : NodeCoverage113 [72,9,9] 9 23 :=
  demand_node_prune113 72 compact113_demands_072 compact113_demands_072_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0144 : NodeCoverage113 [72,9,8] 8 24 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0145 : NodeCoverage113 [72,9,7] 7 25 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0146 : NodeCoverage113 [72,9,6] 6 26 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0147 : NodeCoverage113 [72,9,5] 5 27 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0148 : NodeCoverage113 [72,9,3] 3 29 :=
  demand_node_prune113 72 compact113_demands_072 compact113_demands_072_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0149 : NodeCoverage113 [72,9] 9 32 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0143
    (ChildrenCoverage113.cons _ _ compact113_node_0144
    (ChildrenCoverage113.cons _ _ compact113_node_0145
    (ChildrenCoverage113.cons _ _ compact113_node_0146
    (ChildrenCoverage113.cons _ _ compact113_node_0147
    (ChildrenCoverage113.cons _ _ compact113_node_0148
    ChildrenCoverage113.nil))))))

theorem compact113_node_0150 : NodeCoverage113 [72,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0151 : NodeCoverage113 [72,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0152 : NodeCoverage113 [72,6] 6 35 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0153 : NodeCoverage113 [72,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0154 : NodeCoverage113 [72,3] 3 38 :=
  demand_node_prune113 72 compact113_demands_072 compact113_demands_072_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0155 : NodeCoverage113 [72] 72 41 :=
  node_fork113 (B := [41,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0098
    (ChildrenCoverage113.cons _ _ compact113_node_0099
    (ChildrenCoverage113.cons _ _ compact113_node_0100
    (ChildrenCoverage113.cons _ _ compact113_node_0101
    (ChildrenCoverage113.cons _ _ compact113_node_0102
    (ChildrenCoverage113.cons _ _ compact113_node_0103
    (ChildrenCoverage113.cons _ _ compact113_node_0104
    (ChildrenCoverage113.cons _ _ compact113_node_0105
    (ChildrenCoverage113.cons _ _ compact113_node_0106
    (ChildrenCoverage113.cons _ _ compact113_node_0107
    (ChildrenCoverage113.cons _ _ compact113_node_0108
    (ChildrenCoverage113.cons _ _ compact113_node_0109
    (ChildrenCoverage113.cons _ _ compact113_node_0110
    (ChildrenCoverage113.cons _ _ compact113_node_0111
    (ChildrenCoverage113.cons _ _ compact113_node_0112
    (ChildrenCoverage113.cons _ _ compact113_node_0113
    (ChildrenCoverage113.cons _ _ compact113_node_0114
    (ChildrenCoverage113.cons _ _ compact113_node_0115
    (ChildrenCoverage113.cons _ _ compact113_node_0116
    (ChildrenCoverage113.cons _ _ compact113_node_0117
    (ChildrenCoverage113.cons _ _ compact113_node_0118
    (ChildrenCoverage113.cons _ _ compact113_node_0119
    (ChildrenCoverage113.cons _ _ compact113_node_0120
    (ChildrenCoverage113.cons _ _ compact113_node_0121
    (ChildrenCoverage113.cons _ _ compact113_node_0122
    (ChildrenCoverage113.cons _ _ compact113_node_0123
    (ChildrenCoverage113.cons _ _ compact113_node_0124
    (ChildrenCoverage113.cons _ _ compact113_node_0140
    (ChildrenCoverage113.cons _ _ compact113_node_0141
    (ChildrenCoverage113.cons _ _ compact113_node_0142
    (ChildrenCoverage113.cons _ _ compact113_node_0149
    (ChildrenCoverage113.cons _ _ compact113_node_0150
    (ChildrenCoverage113.cons _ _ compact113_node_0151
    (ChildrenCoverage113.cons _ _ compact113_node_0152
    (ChildrenCoverage113.cons _ _ compact113_node_0153
    (ChildrenCoverage113.cons _ _ compact113_node_0154
    ChildrenCoverage113.nil))))))))))))))))))))))))))))))))))))

theorem compact113_node_0156 : NodeCoverage113 [71] 71 42 :=
  demand_node_prune113 71 compact113_demands_071 compact113_demands_071_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0157 : NodeCoverage113 [70,43] 43 0 :=
  demand_node_prune113 43 compact113_demands_043 compact113_demands_043_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0158 : NodeCoverage113 [70,40] 40 3 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0159 : NodeCoverage113 [70,39] 39 4 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0160 : NodeCoverage113 [70,38] 38 5 :=
  demand_node_prune113 38 compact113_demands_038 compact113_demands_038_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0161 : NodeCoverage113 [70,37] 37 6 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0162 : NodeCoverage113 [70,36] 36 7 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0163 : NodeCoverage113 [70,35] 35 8 :=
  demand_node_prune113 70 compact113_demands_070 compact113_demands_070_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0164 : NodeCoverage113 [70,34] 34 9 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0165 : NodeCoverage113 [70,33] 33 10 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0166 : NodeCoverage113 [70,32] 32 11 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0167 : NodeCoverage113 [70,31] 31 12 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0168 : NodeCoverage113 [70,30] 30 13 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0169 : NodeCoverage113 [70,29] 29 14 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0170 : NodeCoverage113 [70,28] 28 15 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0171 : NodeCoverage113 [70,27] 27 16 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0172 : NodeCoverage113 [70,26] 26 17 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0173 : NodeCoverage113 [70,25] 25 18 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0174 : NodeCoverage113 [70,24] 24 19 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

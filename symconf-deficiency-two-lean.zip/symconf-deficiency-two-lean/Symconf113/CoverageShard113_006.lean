import Symconf113.CoverageShard113_004
import Symconf113.CoverageShard113_005

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0260 : NodeCoverage113 [64,16,10] 10 23 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0261 : NodeCoverage113 [64,16,9] 9 24 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0262 : NodeCoverage113 [64,16,8] 8 25 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0263 : NodeCoverage113 [64,16,7] 7 26 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0264 : NodeCoverage113 [64,16,6] 6 27 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0265 : NodeCoverage113 [64,16,5] 5 28 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0266 : NodeCoverage113 [64,16,3] 3 30 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0267 : NodeCoverage113 [64,16] 16 33 :=
  node_fork113 (B := [16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0254
    (ChildrenCoverage113.cons _ _ compact113_node_0255
    (ChildrenCoverage113.cons _ _ compact113_node_0256
    (ChildrenCoverage113.cons _ _ compact113_node_0257
    (ChildrenCoverage113.cons _ _ compact113_node_0258
    (ChildrenCoverage113.cons _ _ compact113_node_0259
    (ChildrenCoverage113.cons _ _ compact113_node_0260
    (ChildrenCoverage113.cons _ _ compact113_node_0261
    (ChildrenCoverage113.cons _ _ compact113_node_0262
    (ChildrenCoverage113.cons _ _ compact113_node_0263
    (ChildrenCoverage113.cons _ _ compact113_node_0264
    (ChildrenCoverage113.cons _ _ compact113_node_0265
    (ChildrenCoverage113.cons _ _ compact113_node_0266
    ChildrenCoverage113.nil)))))))))))))

theorem compact113_node_0268 : NodeCoverage113 [64,15] 15 34 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0269 : NodeCoverage113 [64,14] 14 35 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0270 : NodeCoverage113 [64,13] 13 36 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0271 : NodeCoverage113 [64,12] 12 37 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0272 : NodeCoverage113 [64,11] 11 38 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0273 : NodeCoverage113 [64,10] 10 39 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0274 : NodeCoverage113 [64,9] 9 40 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0275 : NodeCoverage113 [64,8] 8 41 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0276 : NodeCoverage113 [64,7] 7 42 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0277 : NodeCoverage113 [64,6] 6 43 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0278 : NodeCoverage113 [64,5] 5 44 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0279 : NodeCoverage113 [64,3] 3 46 :=
  demand_node_prune113 64 compact113_demands_064 compact113_demands_064_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0280 : NodeCoverage113 [64] 64 49 :=
  node_fork113 (B := [49,46,45,44,43,42,41,40,39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0223
    (ChildrenCoverage113.cons _ _ compact113_node_0224
    (ChildrenCoverage113.cons _ _ compact113_node_0225
    (ChildrenCoverage113.cons _ _ compact113_node_0226
    (ChildrenCoverage113.cons _ _ compact113_node_0227
    (ChildrenCoverage113.cons _ _ compact113_node_0228
    (ChildrenCoverage113.cons _ _ compact113_node_0229
    (ChildrenCoverage113.cons _ _ compact113_node_0230
    (ChildrenCoverage113.cons _ _ compact113_node_0231
    (ChildrenCoverage113.cons _ _ compact113_node_0232
    (ChildrenCoverage113.cons _ _ compact113_node_0233
    (ChildrenCoverage113.cons _ _ compact113_node_0234
    (ChildrenCoverage113.cons _ _ compact113_node_0235
    (ChildrenCoverage113.cons _ _ compact113_node_0236
    (ChildrenCoverage113.cons _ _ compact113_node_0237
    (ChildrenCoverage113.cons _ _ compact113_node_0238
    (ChildrenCoverage113.cons _ _ compact113_node_0239
    (ChildrenCoverage113.cons _ _ compact113_node_0240
    (ChildrenCoverage113.cons _ _ compact113_node_0241
    (ChildrenCoverage113.cons _ _ compact113_node_0242
    (ChildrenCoverage113.cons _ _ compact113_node_0243
    (ChildrenCoverage113.cons _ _ compact113_node_0244
    (ChildrenCoverage113.cons _ _ compact113_node_0245
    (ChildrenCoverage113.cons _ _ compact113_node_0246
    (ChildrenCoverage113.cons _ _ compact113_node_0247
    (ChildrenCoverage113.cons _ _ compact113_node_0248
    (ChildrenCoverage113.cons _ _ compact113_node_0249
    (ChildrenCoverage113.cons _ _ compact113_node_0250
    (ChildrenCoverage113.cons _ _ compact113_node_0251
    (ChildrenCoverage113.cons _ _ compact113_node_0252
    (ChildrenCoverage113.cons _ _ compact113_node_0253
    (ChildrenCoverage113.cons _ _ compact113_node_0267
    (ChildrenCoverage113.cons _ _ compact113_node_0268
    (ChildrenCoverage113.cons _ _ compact113_node_0269
    (ChildrenCoverage113.cons _ _ compact113_node_0270
    (ChildrenCoverage113.cons _ _ compact113_node_0271
    (ChildrenCoverage113.cons _ _ compact113_node_0272
    (ChildrenCoverage113.cons _ _ compact113_node_0273
    (ChildrenCoverage113.cons _ _ compact113_node_0274
    (ChildrenCoverage113.cons _ _ compact113_node_0275
    (ChildrenCoverage113.cons _ _ compact113_node_0276
    (ChildrenCoverage113.cons _ _ compact113_node_0277
    (ChildrenCoverage113.cons _ _ compact113_node_0278
    (ChildrenCoverage113.cons _ _ compact113_node_0279
    ChildrenCoverage113.nil))))))))))))))))))))))))))))))))))))))))))))

theorem compact113_node_0281 : NodeCoverage113 [63,50] 50 0 :=
  demand_node_prune113 50 compact113_demands_050 compact113_demands_050_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0282 : NodeCoverage113 [63,47] 47 3 :=
  demand_node_prune113 47 compact113_demands_047 compact113_demands_047_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0283 : NodeCoverage113 [63,46] 46 4 :=
  demand_node_prune113 46 compact113_demands_046 compact113_demands_046_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0284 : NodeCoverage113 [63,45] 45 5 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0285 : NodeCoverage113 [63,44] 44 6 :=
  demand_node_prune113 44 compact113_demands_044 compact113_demands_044_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0286 : NodeCoverage113 [63,43] 43 7 :=
  demand_node_prune113 43 compact113_demands_043 compact113_demands_043_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0287 : NodeCoverage113 [63,42] 42 8 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0288 : NodeCoverage113 [63,41] 41 9 :=
  demand_node_prune113 41 compact113_demands_041 compact113_demands_041_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0289 : NodeCoverage113 [63,40] 40 10 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0290 : NodeCoverage113 [63,39] 39 11 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0291 : NodeCoverage113 [63,38] 38 12 :=
  demand_node_prune113 38 compact113_demands_038 compact113_demands_038_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0292 : NodeCoverage113 [63,37] 37 13 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0293 : NodeCoverage113 [63,36] 36 14 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0294 : NodeCoverage113 [63,35] 35 15 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0295 : NodeCoverage113 [63,34] 34 16 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0296 : NodeCoverage113 [63,33] 33 17 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0297 : NodeCoverage113 [63,32] 32 18 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0298 : NodeCoverage113 [63,31] 31 19 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0299 : NodeCoverage113 [63,30] 30 20 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0300 : NodeCoverage113 [63,29] 29 21 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0301 : NodeCoverage113 [63,28] 28 22 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0302 : NodeCoverage113 [63,27] 27 23 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0303 : NodeCoverage113 [63,26] 26 24 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

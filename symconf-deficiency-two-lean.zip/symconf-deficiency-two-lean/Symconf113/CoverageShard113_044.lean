import Symconf113.CoverageShard113_043

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1789 : NodeCoverage113 [36,12,12,3] 3 50 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1790 : NodeCoverage113 [36,12,12] 12 53 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1763
    (ChildrenCoverage113.cons _ _ compact113_node_1764
    (ChildrenCoverage113.cons _ _ compact113_node_1765
    (ChildrenCoverage113.cons _ _ compact113_node_1784
    (ChildrenCoverage113.cons _ _ compact113_node_1785
    (ChildrenCoverage113.cons _ _ compact113_node_1786
    (ChildrenCoverage113.cons _ _ compact113_node_1787
    (ChildrenCoverage113.cons _ _ compact113_node_1788
    (ChildrenCoverage113.cons _ _ compact113_node_1789
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_1791 : NodeCoverage113 [36,12,11] 11 54 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1792 : NodeCoverage113 [36,12,10] 10 55 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1793 : NodeCoverage113 [36,12,9,9,9] 9 38 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1794 : NodeCoverage113 [36,12,9,9,8] 8 39 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1795 : NodeCoverage113 [36,12,9,9,7] 7 40 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1796 : NodeCoverage113 [36,12,9,9,6] 6 41 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1797 : NodeCoverage113 [36,12,9,9,5] 5 42 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1798 : NodeCoverage113 [36,12,9,9,3] 3 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1799 : NodeCoverage113 [36,12,9,9] 9 47 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1793
    (ChildrenCoverage113.cons _ _ compact113_node_1794
    (ChildrenCoverage113.cons _ _ compact113_node_1795
    (ChildrenCoverage113.cons _ _ compact113_node_1796
    (ChildrenCoverage113.cons _ _ compact113_node_1797
    (ChildrenCoverage113.cons _ _ compact113_node_1798
    ChildrenCoverage113.nil))))))

theorem compact113_node_1800 : NodeCoverage113 [36,12,9,8] 8 48 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1801 : NodeCoverage113 [36,12,9,7] 7 49 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1802 : NodeCoverage113 [36,12,9,6] 6 50 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1803 : NodeCoverage113 [36,12,9,5] 5 51 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1804 : NodeCoverage113 [36,12,9,3] 3 53 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1805 : NodeCoverage113 [36,12,9] 9 56 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1799
    (ChildrenCoverage113.cons _ _ compact113_node_1800
    (ChildrenCoverage113.cons _ _ compact113_node_1801
    (ChildrenCoverage113.cons _ _ compact113_node_1802
    (ChildrenCoverage113.cons _ _ compact113_node_1803
    (ChildrenCoverage113.cons _ _ compact113_node_1804
    ChildrenCoverage113.nil))))))

theorem compact113_node_1806 : NodeCoverage113 [36,12,8] 8 57 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1807 : NodeCoverage113 [36,12,7] 7 58 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1808 : NodeCoverage113 [36,12,6] 6 59 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1809 : NodeCoverage113 [36,12,5] 5 60 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1810 : NodeCoverage113 [36,12,3] 3 62 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1811 : NodeCoverage113 [36,12] 12 65 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1790
    (ChildrenCoverage113.cons _ _ compact113_node_1791
    (ChildrenCoverage113.cons _ _ compact113_node_1792
    (ChildrenCoverage113.cons _ _ compact113_node_1805
    (ChildrenCoverage113.cons _ _ compact113_node_1806
    (ChildrenCoverage113.cons _ _ compact113_node_1807
    (ChildrenCoverage113.cons _ _ compact113_node_1808
    (ChildrenCoverage113.cons _ _ compact113_node_1809
    (ChildrenCoverage113.cons _ _ compact113_node_1810
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_1812 : NodeCoverage113 [36,11,11] 11 55 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1813 : NodeCoverage113 [36,11,10] 10 56 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1814 : NodeCoverage113 [36,11,9] 9 57 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1815 : NodeCoverage113 [36,11,8] 8 58 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1816 : NodeCoverage113 [36,11,7] 7 59 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1817 : NodeCoverage113 [36,11,6] 6 60 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1818 : NodeCoverage113 [36,11,5] 5 61 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1819 : NodeCoverage113 [36,11,3] 3 63 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1820 : NodeCoverage113 [36,11] 11 66 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1812
    (ChildrenCoverage113.cons _ _ compact113_node_1813
    (ChildrenCoverage113.cons _ _ compact113_node_1814
    (ChildrenCoverage113.cons _ _ compact113_node_1815
    (ChildrenCoverage113.cons _ _ compact113_node_1816
    (ChildrenCoverage113.cons _ _ compact113_node_1817
    (ChildrenCoverage113.cons _ _ compact113_node_1818
    (ChildrenCoverage113.cons _ _ compact113_node_1819
    ChildrenCoverage113.nil))))))))

theorem compact113_node_1821 : NodeCoverage113 [36,10,10] 10 57 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1822 : NodeCoverage113 [36,10,9] 9 58 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1823 : NodeCoverage113 [36,10,8] 8 59 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1824 : NodeCoverage113 [36,10,7] 7 60 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1825 : NodeCoverage113 [36,10,6] 6 61 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1826 : NodeCoverage113 [36,10,5] 5 62 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1827 : NodeCoverage113 [36,10,3] 3 64 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1828 : NodeCoverage113 [36,10] 10 67 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1821
    (ChildrenCoverage113.cons _ _ compact113_node_1822
    (ChildrenCoverage113.cons _ _ compact113_node_1823
    (ChildrenCoverage113.cons _ _ compact113_node_1824
    (ChildrenCoverage113.cons _ _ compact113_node_1825
    (ChildrenCoverage113.cons _ _ compact113_node_1826
    (ChildrenCoverage113.cons _ _ compact113_node_1827
    ChildrenCoverage113.nil)))))))

theorem compact113_node_1829 : NodeCoverage113 [36,9,9,9,9,9,9,9,9,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1830 : NodeCoverage113 [36,9,9,9,9,9,9,9,9] 9 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1829
    ChildrenCoverage113.nil)

theorem compact113_node_1831 : NodeCoverage113 [36,9,9,9,9,9,9,9,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1832 : NodeCoverage113 [36,9,9,9,9,9,9,9,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1833 : NodeCoverage113 [36,9,9,9,9,9,9,9,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1834 : NodeCoverage113 [36,9,9,9,9,9,9,9,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1835 : NodeCoverage113 [36,9,9,9,9,9,9,9,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_1836 : NodeCoverage113 [36,9,9,9,9,9,9,9,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1835
    ChildrenCoverage113.nil)

theorem compact113_node_1837 : NodeCoverage113 [36,9,9,9,9,9,9,9,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1836
    ChildrenCoverage113.nil)

theorem compact113_node_1838 : NodeCoverage113 [36,9,9,9,9,9,9,9] 9 14 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1830
    (ChildrenCoverage113.cons _ _ compact113_node_1831
    (ChildrenCoverage113.cons _ _ compact113_node_1832
    (ChildrenCoverage113.cons _ _ compact113_node_1833
    (ChildrenCoverage113.cons _ _ compact113_node_1834
    (ChildrenCoverage113.cons _ _ compact113_node_1837
    ChildrenCoverage113.nil))))))

theorem compact113_node_1839 : NodeCoverage113 [36,9,9,9,9,9,9,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1840 : NodeCoverage113 [36,9,9,9,9,9,9,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1841 : NodeCoverage113 [36,9,9,9,9,9,9,6] 6 17 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1842 : NodeCoverage113 [36,9,9,9,9,9,9,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

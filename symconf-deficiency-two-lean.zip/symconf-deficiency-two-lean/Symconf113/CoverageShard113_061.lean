import Symconf113.CoverageShard113_060

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2387 : NodeCoverage113 [30,30,10,10,6] 6 27 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2388 : NodeCoverage113 [30,30,10,10,5] 5 28 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2389 : NodeCoverage113 [30,30,10,10,3] 3 30 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2390 : NodeCoverage113 [30,30,10,10] 10 33 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2383
    (ChildrenCoverage113.cons _ _ compact113_node_2384
    (ChildrenCoverage113.cons _ _ compact113_node_2385
    (ChildrenCoverage113.cons _ _ compact113_node_2386
    (ChildrenCoverage113.cons _ _ compact113_node_2387
    (ChildrenCoverage113.cons _ _ compact113_node_2388
    (ChildrenCoverage113.cons _ _ compact113_node_2389
    ChildrenCoverage113.nil)))))))

theorem compact113_node_2391 : NodeCoverage113 [30,30,10,9] 9 34 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2392 : NodeCoverage113 [30,30,10,8] 8 35 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2393 : NodeCoverage113 [30,30,10,7] 7 36 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2394 : NodeCoverage113 [30,30,10,6] 6 37 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

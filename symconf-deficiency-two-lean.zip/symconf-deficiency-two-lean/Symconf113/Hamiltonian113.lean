import Symconf113.OddOrientation
import Symconf113.OriginalCoordinates

/-! The Hamiltonian profile `[113]`. When both leave graphs are single
113-cycles, the incidence in cycle coordinates is a 0/1 block intertwining
the cycle adjacency, hence circulant or reverse-circulant. Either way its
first row is the indicator of an 11-subset of `ZMod 113` whose nonzero
differences are all distinct: a (113,11) modular Golomb ruler.

That no such ruler exists is Buratti and Stinson, *New results on modular
Golomb rulers, optical orthogonal codes and related structures*, Ars Math.
Contemp. 20 (2021), Theorems 1.6 and 2.3(9). It is stated here as the named
hypothesis `NoModularGolombRuler113` and is not proved in Lean. -/
namespace Symconf113
open Matrix Symconf59
open scoped BigOperators

/-- No 11-subset of `ZMod 113` has all nonzero differences distinct, stated
through the subset's indicator `g`. Named hypothesis (Buratti–Stinson 2021). -/
def NoModularGolombRuler113 : Prop :=
  ¬∃ g : ZMod 113 → ℤ, (∀ z, g z=0 ∨ g z=1) ∧ (∑ z,g z)=11 ∧
    ∀ d : ZMod 113, d≠0 → (∑ z, g z*g (z+d))≤1

private theorem sum_blocks113 (F : Site → ℤ) (e : BlocksOf [113] ≃ Site) :
    (∑ y : ZMod 113, F (e ⟨0,(ZMod.finEquiv 113).symm y⟩))=∑ q,F q := by
  calc (∑ y : ZMod 113, F (e ⟨0,(ZMod.finEquiv 113).symm y⟩))
      = ∑ y : Fin 113, F (e ⟨0,y⟩) :=
        Equiv.sum_comp (ZMod.finEquiv 113).symm.toEquiv (fun y => F (e ⟨0,y⟩))
    _ = ∑ b : BlocksOf [113], F (e b) := by
        rw [Fintype.sum_sigma]
        exact (Fin.sum_univ_one (fun i : Fin 1 => ∑ y : Fin ([113].get i), F (e ⟨i,y⟩))).symm
    _ = ∑ q,F q := Equiv.sum_comp e F

/-- A Hamiltonian counterexample yields a (113,11) modular Golomb ruler. -/
theorem hamiltonian_ruler {A : Int113} (hA : Incidence113 A)
    (R : OrderedCycles (rowLeave A) [113]) (C : OrderedCycles (colLeave A) [113]) :
    ∃ g : ZMod 113 → ℤ, (∀ z, g z=0 ∨ g z=1) ∧ (∑ z,g z)=11 ∧
      ∀ d : ZMod 113, d≠0 → (∑ z, g z*g (z+d))≤1 := by
  haveI : NeZero ([113].get ⟨0,by decide⟩) := ⟨by decide⟩
  let i0 : Fin [113].length := ⟨0,by decide⟩
  let f : ZMod 113 → ZMod 113 → ℤ := zblock R C i0 i0
  have hw : BlockWave f := zblock_wave R C i0 i0 hA
  have hb : ∀ x y, f x y=0 ∨ f x y=1 := fun x y => hA.binary _ _
  let row (x : ZMod 113) : Site := R.sites ⟨i0,(ZMod.finEquiv 113).symm x⟩
  have hf (x y : ZMod 113) : f x y=A (row x) (C.sites ⟨i0,(ZMod.finEquiv 113).symm y⟩) := rfl
  have hsum (x : ZMod 113) : (∑ y,f x y)=11 := by
    exact (sum_blocks113 (fun q => A (row x) q) C.sites).trans (hA.rows _)
  have hov (d : ZMod 113) (hd : d≠0) : (∑ y,f 0 y*f d y)≤1 := by
    have hne : row 0≠row d := by
      intro h
      have := (Sigma.mk.inj_iff.mp (R.sites.injective h)).2
      exact hd ((ZMod.finEquiv 113).symm.injective (eq_of_heq this)).symm
    exact le_of_eq_of_le (sum_blocks113 (fun q => A (row 0) q*A (row d) q) C.sites)
      (hA.overlap _ _ hne)
  have hc : (2:ZMod 113)*57=1 := by decide
  refine ⟨f 0,fun z => hb 0 z,hsum 0,fun d hd => ?_⟩
  rcases binary_block_orientation hc f hw hb with hcirc | hrev
  · have h := hov (-d) (neg_ne_zero.mpr hd)
    simpa only [hcirc (-d), sub_neg_eq_add] using h
  · have h := hov d hd
    simpa only [hrev d] using h

theorem no_hamiltonian_incidence113 (ruler : NoModularGolombRuler113) {A : Int113}
    (hA : Incidence113 A) (R : OrderedCycles (rowLeave A) [113])
    (C : OrderedCycles (colLeave A) [113]) : False :=
  ruler (hamiltonian_ruler hA R C)

end Symconf113

#print axioms Symconf113.no_hamiltonian_incidence113

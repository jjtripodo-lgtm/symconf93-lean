import Symconf113.CoverageShard113_159

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_7056 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7055
    ChildrenCoverage113.nil)

theorem compact113_node_7057 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7056
    ChildrenCoverage113.nil)

theorem compact113_node_7058 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7057
    ChildrenCoverage113.nil)

theorem compact113_node_7059 : NodeCoverage113 [9,9,9,9,9,9,9,9,9,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7058
    ChildrenCoverage113.nil)

theorem compact113_node_7060 : NodeCoverage113 [9,9,9,9,9,9,9,9,9] 9 32 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7046
    (ChildrenCoverage113.cons _ _ compact113_node_7047
    (ChildrenCoverage113.cons _ _ compact113_node_7048
    (ChildrenCoverage113.cons _ _ compact113_node_7049
    (ChildrenCoverage113.cons _ _ compact113_node_7050
    (ChildrenCoverage113.cons _ _ compact113_node_7059
    ChildrenCoverage113.nil))))))

theorem compact113_node_7061 : NodeCoverage113 [9,9,9,9,9,9,9,9,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7062 : NodeCoverage113 [9,9,9,9,9,9,9,9,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7063 : NodeCoverage113 [9,9,9,9,9,9,9,9,6] 6 35 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7064 : NodeCoverage113 [9,9,9,9,9,9,9,9,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7065 : NodeCoverage113 [9,9,9,9,9,9,9,9,3,3,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7066 : NodeCoverage113 [9,9,9,9,9,9,9,9,3,3,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7065
    ChildrenCoverage113.nil)

theorem compact113_node_7067 : NodeCoverage113 [9,9,9,9,9,9,9,9,3,3,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7066
    ChildrenCoverage113.nil)

theorem compact113_node_7068 : NodeCoverage113 [9,9,9,9,9,9,9,9,3,3,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7067
    ChildrenCoverage113.nil)

theorem compact113_node_7069 : NodeCoverage113 [9,9,9,9,9,9,9,9,3,3,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7068
    ChildrenCoverage113.nil)

theorem compact113_node_7070 : NodeCoverage113 [9,9,9,9,9,9,9,9,3,3,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7069
    ChildrenCoverage113.nil)

theorem compact113_node_7071 : NodeCoverage113 [9,9,9,9,9,9,9,9,3,3,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7070
    ChildrenCoverage113.nil)

theorem compact113_node_7072 : NodeCoverage113 [9,9,9,9,9,9,9,9,3,3,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7071
    ChildrenCoverage113.nil)

theorem compact113_node_7073 : NodeCoverage113 [9,9,9,9,9,9,9,9,3,3,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7072
    ChildrenCoverage113.nil)

theorem compact113_node_7074 : NodeCoverage113 [9,9,9,9,9,9,9,9,3,3,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7073
    ChildrenCoverage113.nil)

theorem compact113_node_7075 : NodeCoverage113 [9,9,9,9,9,9,9,9,3,3] 3 35 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7074
    ChildrenCoverage113.nil)

theorem compact113_node_7076 : NodeCoverage113 [9,9,9,9,9,9,9,9,3] 3 38 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7075
    ChildrenCoverage113.nil)

theorem compact113_node_7077 : NodeCoverage113 [9,9,9,9,9,9,9,9] 9 41 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7060
    (ChildrenCoverage113.cons _ _ compact113_node_7061
    (ChildrenCoverage113.cons _ _ compact113_node_7062
    (ChildrenCoverage113.cons _ _ compact113_node_7063
    (ChildrenCoverage113.cons _ _ compact113_node_7064
    (ChildrenCoverage113.cons _ _ compact113_node_7076
    ChildrenCoverage113.nil))))))

theorem compact113_node_7078 : NodeCoverage113 [9,9,9,9,9,9,9,8] 8 42 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7079 : NodeCoverage113 [9,9,9,9,9,9,9,7] 7 43 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7080 : NodeCoverage113 [9,9,9,9,9,9,9,6] 6 44 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7081 : NodeCoverage113 [9,9,9,9,9,9,9,5] 5 45 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7082 : NodeCoverage113 [9,9,9,9,9,9,9,3] 3 47 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7083 : NodeCoverage113 [9,9,9,9,9,9,9] 9 50 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7077
    (ChildrenCoverage113.cons _ _ compact113_node_7078
    (ChildrenCoverage113.cons _ _ compact113_node_7079
    (ChildrenCoverage113.cons _ _ compact113_node_7080
    (ChildrenCoverage113.cons _ _ compact113_node_7081
    (ChildrenCoverage113.cons _ _ compact113_node_7082
    ChildrenCoverage113.nil))))))

theorem compact113_node_7084 : NodeCoverage113 [9,9,9,9,9,9,8] 8 51 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7085 : NodeCoverage113 [9,9,9,9,9,9,7] 7 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7086 : NodeCoverage113 [9,9,9,9,9,9,6] 6 53 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7087 : NodeCoverage113 [9,9,9,9,9,9,5] 5 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7088 : NodeCoverage113 [9,9,9,9,9,9,3] 3 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7089 : NodeCoverage113 [9,9,9,9,9,9] 9 59 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7083
    (ChildrenCoverage113.cons _ _ compact113_node_7084
    (ChildrenCoverage113.cons _ _ compact113_node_7085
    (ChildrenCoverage113.cons _ _ compact113_node_7086
    (ChildrenCoverage113.cons _ _ compact113_node_7087
    (ChildrenCoverage113.cons _ _ compact113_node_7088
    ChildrenCoverage113.nil))))))

theorem compact113_node_7090 : NodeCoverage113 [9,9,9,9,9,8] 8 60 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7091 : NodeCoverage113 [9,9,9,9,9,7] 7 61 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7092 : NodeCoverage113 [9,9,9,9,9,6] 6 62 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7093 : NodeCoverage113 [9,9,9,9,9,5] 5 63 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7094 : NodeCoverage113 [9,9,9,9,9,3] 3 65 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7095 : NodeCoverage113 [9,9,9,9,9] 9 68 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7089
    (ChildrenCoverage113.cons _ _ compact113_node_7090
    (ChildrenCoverage113.cons _ _ compact113_node_7091
    (ChildrenCoverage113.cons _ _ compact113_node_7092
    (ChildrenCoverage113.cons _ _ compact113_node_7093
    (ChildrenCoverage113.cons _ _ compact113_node_7094
    ChildrenCoverage113.nil))))))

theorem compact113_node_7096 : NodeCoverage113 [9,9,9,9,8] 8 69 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7097 : NodeCoverage113 [9,9,9,9,7] 7 70 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7098 : NodeCoverage113 [9,9,9,9,6] 6 71 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7099 : NodeCoverage113 [9,9,9,9,5] 5 72 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7100 : NodeCoverage113 [9,9,9,9,3] 3 74 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7101 : NodeCoverage113 [9,9,9,9] 9 77 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7095
    (ChildrenCoverage113.cons _ _ compact113_node_7096
    (ChildrenCoverage113.cons _ _ compact113_node_7097
    (ChildrenCoverage113.cons _ _ compact113_node_7098
    (ChildrenCoverage113.cons _ _ compact113_node_7099
    (ChildrenCoverage113.cons _ _ compact113_node_7100
    ChildrenCoverage113.nil))))))

theorem compact113_node_7102 : NodeCoverage113 [9,9,9,8] 8 78 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7103 : NodeCoverage113 [9,9,9,7] 7 79 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7104 : NodeCoverage113 [9,9,9,6] 6 80 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7105 : NodeCoverage113 [9,9,9,5] 5 81 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7106 : NodeCoverage113 [9,9,9,3] 3 83 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7107 : NodeCoverage113 [9,9,9] 9 86 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7101
    (ChildrenCoverage113.cons _ _ compact113_node_7102
    (ChildrenCoverage113.cons _ _ compact113_node_7103
    (ChildrenCoverage113.cons _ _ compact113_node_7104
    (ChildrenCoverage113.cons _ _ compact113_node_7105
    (ChildrenCoverage113.cons _ _ compact113_node_7106
    ChildrenCoverage113.nil))))))

theorem compact113_node_7108 : NodeCoverage113 [9,9,8] 8 87 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7109 : NodeCoverage113 [9,9,7] 7 88 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7110 : NodeCoverage113 [9,9,6] 6 89 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7111 : NodeCoverage113 [9,9,5] 5 90 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7112 : NodeCoverage113 [9,9,3] 3 92 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7113 : NodeCoverage113 [9,9] 9 95 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7107
    (ChildrenCoverage113.cons _ _ compact113_node_7108
    (ChildrenCoverage113.cons _ _ compact113_node_7109
    (ChildrenCoverage113.cons _ _ compact113_node_7110
    (ChildrenCoverage113.cons _ _ compact113_node_7111
    (ChildrenCoverage113.cons _ _ compact113_node_7112
    ChildrenCoverage113.nil))))))

theorem compact113_node_7114 : NodeCoverage113 [9,8] 8 96 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7115 : NodeCoverage113 [9,7] 7 97 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

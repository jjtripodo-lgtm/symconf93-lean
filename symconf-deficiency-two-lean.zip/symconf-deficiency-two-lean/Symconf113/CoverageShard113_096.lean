import Symconf113.CoverageShard113_094
import Symconf113.CoverageShard113_095

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3374 : NodeCoverage113 [24,12,6] 6 71 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3375 : NodeCoverage113 [24,12,5] 5 72 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3376 : NodeCoverage113 [24,12,3] 3 74 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3377 : NodeCoverage113 [24,12] 12 77 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3334
    (ChildrenCoverage113.cons _ _ compact113_node_3343
    (ChildrenCoverage113.cons _ _ compact113_node_3358
    (ChildrenCoverage113.cons _ _ compact113_node_3371
    (ChildrenCoverage113.cons _ _ compact113_node_3372
    (ChildrenCoverage113.cons _ _ compact113_node_3373
    (ChildrenCoverage113.cons _ _ compact113_node_3374
    (ChildrenCoverage113.cons _ _ compact113_node_3375
    (ChildrenCoverage113.cons _ _ compact113_node_3376
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_3378 : NodeCoverage113 [24,11,11] 11 67 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3379 : NodeCoverage113 [24,11,10] 10 68 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3380 : NodeCoverage113 [24,11,9] 9 69 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3381 : NodeCoverage113 [24,11,8] 8 70 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3382 : NodeCoverage113 [24,11,7] 7 71 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3383 : NodeCoverage113 [24,11,6] 6 72 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3384 : NodeCoverage113 [24,11,5] 5 73 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3385 : NodeCoverage113 [24,11,3] 3 75 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3386 : NodeCoverage113 [24,11] 11 78 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3378
    (ChildrenCoverage113.cons _ _ compact113_node_3379
    (ChildrenCoverage113.cons _ _ compact113_node_3380
    (ChildrenCoverage113.cons _ _ compact113_node_3381
    (ChildrenCoverage113.cons _ _ compact113_node_3382
    (ChildrenCoverage113.cons _ _ compact113_node_3383
    (ChildrenCoverage113.cons _ _ compact113_node_3384
    (ChildrenCoverage113.cons _ _ compact113_node_3385
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3387 : NodeCoverage113 [24,10,10] 10 69 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3388 : NodeCoverage113 [24,10,9] 9 70 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3389 : NodeCoverage113 [24,10,8] 8 71 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3390 : NodeCoverage113 [24,10,7] 7 72 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3391 : NodeCoverage113 [24,10,6] 6 73 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3392 : NodeCoverage113 [24,10,5] 5 74 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3393 : NodeCoverage113 [24,10,3] 3 76 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3394 : NodeCoverage113 [24,10] 10 79 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3387
    (ChildrenCoverage113.cons _ _ compact113_node_3388
    (ChildrenCoverage113.cons _ _ compact113_node_3389
    (ChildrenCoverage113.cons _ _ compact113_node_3390
    (ChildrenCoverage113.cons _ _ compact113_node_3391
    (ChildrenCoverage113.cons _ _ compact113_node_3392
    (ChildrenCoverage113.cons _ _ compact113_node_3393
    ChildrenCoverage113.nil)))))))

theorem compact113_node_3395 : NodeCoverage113 [24,9,9,9] 9 62 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3396 : NodeCoverage113 [24,9,9,8] 8 63 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3397 : NodeCoverage113 [24,9,9,7] 7 64 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3398 : NodeCoverage113 [24,9,9,6] 6 65 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3399 : NodeCoverage113 [24,9,9,5] 5 66 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3400 : NodeCoverage113 [24,9,9,3] 3 68 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3401 : NodeCoverage113 [24,9,9] 9 71 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3395
    (ChildrenCoverage113.cons _ _ compact113_node_3396
    (ChildrenCoverage113.cons _ _ compact113_node_3397
    (ChildrenCoverage113.cons _ _ compact113_node_3398
    (ChildrenCoverage113.cons _ _ compact113_node_3399
    (ChildrenCoverage113.cons _ _ compact113_node_3400
    ChildrenCoverage113.nil))))))

theorem compact113_node_3402 : NodeCoverage113 [24,9,8] 8 72 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.ResidualDegDefs113

/-! Kernel check: the degree search below type-`A` rows 78 and 79. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem degShard_78 : ((degTopList.drop 78).take 2).all degTop=true := by decide +kernel
end Symconf113

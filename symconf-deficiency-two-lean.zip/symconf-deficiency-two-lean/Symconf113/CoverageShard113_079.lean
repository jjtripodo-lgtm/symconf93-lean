import Symconf113.CoverageShard113_078

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2833 : NodeCoverage113 [27,27,20] 20 39 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2834 : NodeCoverage113 [27,27,19] 19 40 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2835 : NodeCoverage113 [27,27,18] 18 41 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2836 : NodeCoverage113 [27,27,17] 17 42 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2837 : NodeCoverage113 [27,27,16] 16 43 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2838 : NodeCoverage113 [27,27,15] 15 44 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2839 : NodeCoverage113 [27,27,14] 14 45 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2840 : NodeCoverage113 [27,27,13] 13 46 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2841 : NodeCoverage113 [27,27,12] 12 47 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2842 : NodeCoverage113 [27,27,11] 11 48 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2843 : NodeCoverage113 [27,27,10] 10 49 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2844 : NodeCoverage113 [27,27,9,9,9,9,9,9,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2845 : NodeCoverage113 [27,27,9,9,9,9,9,9] 9 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2844
    ChildrenCoverage113.nil)

theorem compact113_node_2846 : NodeCoverage113 [27,27,9,9,9,9,9,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2847 : NodeCoverage113 [27,27,9,9,9,9,9,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2848 : NodeCoverage113 [27,27,9,9,9,9,9,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2849 : NodeCoverage113 [27,27,9,9,9,9,9,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2850 : NodeCoverage113 [27,27,9,9,9,9,9,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_2851 : NodeCoverage113 [27,27,9,9,9,9,9,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2850
    ChildrenCoverage113.nil)

theorem compact113_node_2852 : NodeCoverage113 [27,27,9,9,9,9,9,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2851
    ChildrenCoverage113.nil)

theorem compact113_node_2853 : NodeCoverage113 [27,27,9,9,9,9,9] 9 14 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2845
    (ChildrenCoverage113.cons _ _ compact113_node_2846
    (ChildrenCoverage113.cons _ _ compact113_node_2847
    (ChildrenCoverage113.cons _ _ compact113_node_2848
    (ChildrenCoverage113.cons _ _ compact113_node_2849
    (ChildrenCoverage113.cons _ _ compact113_node_2852
    ChildrenCoverage113.nil))))))

theorem compact113_node_2854 : NodeCoverage113 [27,27,9,9,9,9,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2855 : NodeCoverage113 [27,27,9,9,9,9,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2856 : NodeCoverage113 [27,27,9,9,9,9,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2857 : NodeCoverage113 [27,27,9,9,9,9,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2858 : NodeCoverage113 [27,27,9,9,9,9,3] 3 20 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2859 : NodeCoverage113 [27,27,9,9,9,9] 9 23 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2853
    (ChildrenCoverage113.cons _ _ compact113_node_2854
    (ChildrenCoverage113.cons _ _ compact113_node_2855
    (ChildrenCoverage113.cons _ _ compact113_node_2856
    (ChildrenCoverage113.cons _ _ compact113_node_2857
    (ChildrenCoverage113.cons _ _ compact113_node_2858
    ChildrenCoverage113.nil))))))

theorem compact113_node_2860 : NodeCoverage113 [27,27,9,9,9,8] 8 24 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2861 : NodeCoverage113 [27,27,9,9,9,7] 7 25 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2862 : NodeCoverage113 [27,27,9,9,9,6] 6 26 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2863 : NodeCoverage113 [27,27,9,9,9,5] 5 27 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2864 : NodeCoverage113 [27,27,9,9,9,3] 3 29 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2865 : NodeCoverage113 [27,27,9,9,9] 9 32 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2859
    (ChildrenCoverage113.cons _ _ compact113_node_2860
    (ChildrenCoverage113.cons _ _ compact113_node_2861
    (ChildrenCoverage113.cons _ _ compact113_node_2862
    (ChildrenCoverage113.cons _ _ compact113_node_2863
    (ChildrenCoverage113.cons _ _ compact113_node_2864
    ChildrenCoverage113.nil))))))

theorem compact113_node_2866 : NodeCoverage113 [27,27,9,9,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2867 : NodeCoverage113 [27,27,9,9,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2868 : NodeCoverage113 [27,27,9,9,6] 6 35 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2869 : NodeCoverage113 [27,27,9,9,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2870 : NodeCoverage113 [27,27,9,9,3] 3 38 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2871 : NodeCoverage113 [27,27,9,9] 9 41 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2865
    (ChildrenCoverage113.cons _ _ compact113_node_2866
    (ChildrenCoverage113.cons _ _ compact113_node_2867
    (ChildrenCoverage113.cons _ _ compact113_node_2868
    (ChildrenCoverage113.cons _ _ compact113_node_2869
    (ChildrenCoverage113.cons _ _ compact113_node_2870
    ChildrenCoverage113.nil))))))

theorem compact113_node_2872 : NodeCoverage113 [27,27,9,8] 8 42 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2873 : NodeCoverage113 [27,27,9,7] 7 43 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2874 : NodeCoverage113 [27,27,9,6] 6 44 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2875 : NodeCoverage113 [27,27,9,5] 5 45 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2876 : NodeCoverage113 [27,27,9,3] 3 47 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2877 : NodeCoverage113 [27,27,9] 9 50 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2871
    (ChildrenCoverage113.cons _ _ compact113_node_2872
    (ChildrenCoverage113.cons _ _ compact113_node_2873
    (ChildrenCoverage113.cons _ _ compact113_node_2874
    (ChildrenCoverage113.cons _ _ compact113_node_2875
    (ChildrenCoverage113.cons _ _ compact113_node_2876
    ChildrenCoverage113.nil))))))

theorem compact113_node_2878 : NodeCoverage113 [27,27,8] 8 51 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2879 : NodeCoverage113 [27,27,7] 7 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2880 : NodeCoverage113 [27,27,6] 6 53 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2881 : NodeCoverage113 [27,27,5] 5 54 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2882 : NodeCoverage113 [27,27,3] 3 56 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2883 : NodeCoverage113 [27,27] 27 59 :=
  node_fork113 (B := [27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2826
    (ChildrenCoverage113.cons _ _ compact113_node_2827
    (ChildrenCoverage113.cons _ _ compact113_node_2828
    (ChildrenCoverage113.cons _ _ compact113_node_2829
    (ChildrenCoverage113.cons _ _ compact113_node_2830
    (ChildrenCoverage113.cons _ _ compact113_node_2831
    (ChildrenCoverage113.cons _ _ compact113_node_2832
    (ChildrenCoverage113.cons _ _ compact113_node_2833
    (ChildrenCoverage113.cons _ _ compact113_node_2834
    (ChildrenCoverage113.cons _ _ compact113_node_2835
    (ChildrenCoverage113.cons _ _ compact113_node_2836
    (ChildrenCoverage113.cons _ _ compact113_node_2837
    (ChildrenCoverage113.cons _ _ compact113_node_2838
    (ChildrenCoverage113.cons _ _ compact113_node_2839
    (ChildrenCoverage113.cons _ _ compact113_node_2840
    (ChildrenCoverage113.cons _ _ compact113_node_2841
    (ChildrenCoverage113.cons _ _ compact113_node_2842
    (ChildrenCoverage113.cons _ _ compact113_node_2843
    (ChildrenCoverage113.cons _ _ compact113_node_2877
    (ChildrenCoverage113.cons _ _ compact113_node_2878
    (ChildrenCoverage113.cons _ _ compact113_node_2879
    (ChildrenCoverage113.cons _ _ compact113_node_2880
    (ChildrenCoverage113.cons _ _ compact113_node_2881
    (ChildrenCoverage113.cons _ _ compact113_node_2882
    ChildrenCoverage113.nil))))))))))))))))))))))))

theorem compact113_node_2884 : NodeCoverage113 [27,26] 26 60 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2885 : NodeCoverage113 [27,25] 25 61 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.LeafDemand113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

def compact113_demands_076 : List (List Nat) := [
  [76,38,76]
]
theorem compact113_demands_076_exact : rowDemand113 76=compact113_demands_076 := by decide +kernel

def compact113_demands_077 : List (List Nat) := [
  [77,11,11,11],
  [77,77],
  [7,7,11,11,11,11,11,11,11,11,11],
  [7,7,77,11,11],
  [7,7,7,7,7,11,11,77],
  [7,7,7,7,7,11,11,11,77],
  [7,7,7,7,7,11,11,11,11,77,77],
  [7,7,7,7,7,7,11,11,77,77],
  [7,7,7,7,7,7,7,77,77]
]
theorem compact113_demands_077_exact : rowDemand113 77=compact113_demands_077 := by decide +kernel

def compact113_demands_078 : List (List Nat) := [
  [78,26,39]
]
theorem compact113_demands_078_exact : rowDemand113 78=compact113_demands_078 := by decide +kernel

def compact113_demands_079 : List (List Nat) := [

]
theorem compact113_demands_079_exact : rowDemand113 79=compact113_demands_079 := by decide +kernel

def compact113_demands_080 : List (List Nat) := [
  [10,10,10,10,10,10,10,10,10,10,10],
  [80,10,10,10],
  [80,16,40],
  [8,8,10,10,10,10,10,10,10,10,20],
  [8,8,80,20],
  [8,8,8,10,10,10,10,10,10,16,16],
  [8,8,8,10,10,10,10,10,10,10,40],
  [8,8,8,8,10,10,10,10,10,20,20],
  [8,8,8,8,8,10,10,10,16,16,20],
  [8,8,8,8,8,10,10,10,10,20,40],
  [8,8,8,8,8,10,10,10,10,16,80],
  [8,8,8,8,8,8,10,16,16,16,16],
  [8,8,8,8,8,8,10,10,20,20,20],
  [8,8,8,8,8,8,10,10,16,16,40],
  [8,8,8,8,8,8,10,10,10,40,40],
  [8,8,8,8,8,8,10,10,10,80],
  [8,8,8,8,8,8,8,16,16,20,20],
  [8,8,8,8,8,8,8,10,20,20,40],
  [8,8,8,8,8,8,8,10,16,20,80],
  [8,8,8,8,8,8,8,10,10,80,80],
  [8,8,8,8,8,8,8,8,20,40,40],
  [8,8,8,8,8,8,8,8,20,80],
  [8,8,8,8,8,8,8,8,16,40,80]
]
theorem compact113_demands_080_exact : rowDemand113 80=compact113_demands_080 := by decide +kernel

def compact113_demands_081 : List (List Nat) := [

]
theorem compact113_demands_081_exact : rowDemand113 81=compact113_demands_081 := by decide +kernel

def compact113_demands_082 : List (List Nat) := [

]
theorem compact113_demands_082_exact : rowDemand113 82=compact113_demands_082 := by decide +kernel

def compact113_demands_083 : List (List Nat) := [

]
theorem compact113_demands_083_exact : rowDemand113 83=compact113_demands_083 := by decide +kernel

end Symconf113

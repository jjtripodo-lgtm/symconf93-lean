import Symconf113.RulerCoverDefs113

namespace Symconf113.Ruler113

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem coverShard113_56 : (List.range' 40 1).any (opt2At 3 (go 7) [2,0] m0)=false := by
  decide +kernel

end Symconf113.Ruler113

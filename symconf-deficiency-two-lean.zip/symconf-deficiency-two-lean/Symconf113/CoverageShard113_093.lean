import Symconf113.CoverageShard113_092

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3289 : NodeCoverage113 [24,12,12,12,12,12,3] 3 26 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3290 : NodeCoverage113 [24,12,12,12,12,12] 12 29 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3281
    (ChildrenCoverage113.cons _ _ compact113_node_3282
    (ChildrenCoverage113.cons _ _ compact113_node_3283
    (ChildrenCoverage113.cons _ _ compact113_node_3284
    (ChildrenCoverage113.cons _ _ compact113_node_3285
    (ChildrenCoverage113.cons _ _ compact113_node_3286
    (ChildrenCoverage113.cons _ _ compact113_node_3287
    (ChildrenCoverage113.cons _ _ compact113_node_3288
    (ChildrenCoverage113.cons _ _ compact113_node_3289
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_3291 : NodeCoverage113 [24,12,12,12,12,11] 11 30 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3292 : NodeCoverage113 [24,12,12,12,12,10] 10 31 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3293 : NodeCoverage113 [24,12,12,12,12,9] 9 32 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3294 : NodeCoverage113 [24,12,12,12,12,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3295 : NodeCoverage113 [24,12,12,12,12,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3296 : NodeCoverage113 [24,12,12,12,12,6,6,6,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3297 : NodeCoverage113 [24,12,12,12,12,6,6,6,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3296
    ChildrenCoverage113.nil)

theorem compact113_node_3298 : NodeCoverage113 [24,12,12,12,12,6,6,6,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3299 : NodeCoverage113 [24,12,12,12,12,6,6,6,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_3300 : NodeCoverage113 [24,12,12,12,12,6,6,6,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3299
    ChildrenCoverage113.nil)

theorem compact113_node_3301 : NodeCoverage113 [24,12,12,12,12,6,6,6,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3297
    (ChildrenCoverage113.cons _ _ compact113_node_3298
    (ChildrenCoverage113.cons _ _ compact113_node_3300
    ChildrenCoverage113.nil)))

theorem compact113_node_3302 : NodeCoverage113 [24,12,12,12,12,6,6,6,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3303 : NodeCoverage113 [24,12,12,12,12,6,6,6,6,3] 3 14 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3304 : NodeCoverage113 [24,12,12,12,12,6,6,6,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3301
    (ChildrenCoverage113.cons _ _ compact113_node_3302
    (ChildrenCoverage113.cons _ _ compact113_node_3303
    ChildrenCoverage113.nil)))

theorem compact113_node_3305 : NodeCoverage113 [24,12,12,12,12,6,6,6,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3306 : NodeCoverage113 [24,12,12,12,12,6,6,6,3] 3 20 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3307 : NodeCoverage113 [24,12,12,12,12,6,6,6] 6 23 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3304
    (ChildrenCoverage113.cons _ _ compact113_node_3305
    (ChildrenCoverage113.cons _ _ compact113_node_3306
    ChildrenCoverage113.nil)))

theorem compact113_node_3308 : NodeCoverage113 [24,12,12,12,12,6,6,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3309 : NodeCoverage113 [24,12,12,12,12,6,6,3] 3 26 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3310 : NodeCoverage113 [24,12,12,12,12,6,6] 6 29 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3307
    (ChildrenCoverage113.cons _ _ compact113_node_3308
    (ChildrenCoverage113.cons _ _ compact113_node_3309
    ChildrenCoverage113.nil)))

theorem compact113_node_3311 : NodeCoverage113 [24,12,12,12,12,6,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3312 : NodeCoverage113 [24,12,12,12,12,6,3] 3 32 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3313 : NodeCoverage113 [24,12,12,12,12,6] 6 35 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3310
    (ChildrenCoverage113.cons _ _ compact113_node_3311
    (ChildrenCoverage113.cons _ _ compact113_node_3312
    ChildrenCoverage113.nil)))

theorem compact113_node_3314 : NodeCoverage113 [24,12,12,12,12,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3315 : NodeCoverage113 [24,12,12,12,12,3] 3 38 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3316 : NodeCoverage113 [24,12,12,12,12] 12 41 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3290
    (ChildrenCoverage113.cons _ _ compact113_node_3291
    (ChildrenCoverage113.cons _ _ compact113_node_3292
    (ChildrenCoverage113.cons _ _ compact113_node_3293
    (ChildrenCoverage113.cons _ _ compact113_node_3294
    (ChildrenCoverage113.cons _ _ compact113_node_3295
    (ChildrenCoverage113.cons _ _ compact113_node_3313
    (ChildrenCoverage113.cons _ _ compact113_node_3314
    (ChildrenCoverage113.cons _ _ compact113_node_3315
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_3317 : NodeCoverage113 [24,12,12,12,11] 11 42 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3318 : NodeCoverage113 [24,12,12,12,10] 10 43 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

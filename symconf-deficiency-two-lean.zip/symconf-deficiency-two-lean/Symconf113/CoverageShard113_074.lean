import Symconf113.CoverageShard113_073

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2561 : NodeCoverage113 [28,28,28,14,10] 10 5 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2562 : NodeCoverage113 [28,28,28,14,9] 9 6 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2563 : NodeCoverage113 [28,28,28,14,8] 8 7 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2564 : NodeCoverage113 [28,28,28,14,7] 7 8 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2565 : NodeCoverage113 [28,28,28,14,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2566 : NodeCoverage113 [28,28,28,14,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2567 : NodeCoverage113 [28,28,28,14,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2568 : NodeCoverage113 [28,28,28,14] 14 15 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2559
    (ChildrenCoverage113.cons _ _ compact113_node_2560
    (ChildrenCoverage113.cons _ _ compact113_node_2561
    (ChildrenCoverage113.cons _ _ compact113_node_2562
    (ChildrenCoverage113.cons _ _ compact113_node_2563
    (ChildrenCoverage113.cons _ _ compact113_node_2564
    (ChildrenCoverage113.cons _ _ compact113_node_2565
    (ChildrenCoverage113.cons _ _ compact113_node_2566
    (ChildrenCoverage113.cons _ _ compact113_node_2567
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_2569 : NodeCoverage113 [28,28,28,13] 13 16 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2570 : NodeCoverage113 [28,28,28,12] 12 17 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2571 : NodeCoverage113 [28,28,28,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2572 : NodeCoverage113 [28,28,28,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2573 : NodeCoverage113 [28,28,28,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2574 : NodeCoverage113 [28,28,28,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2575 : NodeCoverage113 [28,28,28,7] 7 22 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2576 : NodeCoverage113 [28,28,28,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2577 : NodeCoverage113 [28,28,28,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2578 : NodeCoverage113 [28,28,28,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2579 : NodeCoverage113 [28,28,28] 28 29 :=
  node_fork113 (B := [26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2547
    (ChildrenCoverage113.cons _ _ compact113_node_2548
    (ChildrenCoverage113.cons _ _ compact113_node_2549
    (ChildrenCoverage113.cons _ _ compact113_node_2550
    (ChildrenCoverage113.cons _ _ compact113_node_2551
    (ChildrenCoverage113.cons _ _ compact113_node_2552
    (ChildrenCoverage113.cons _ _ compact113_node_2553
    (ChildrenCoverage113.cons _ _ compact113_node_2554
    (ChildrenCoverage113.cons _ _ compact113_node_2555
    (ChildrenCoverage113.cons _ _ compact113_node_2556
    (ChildrenCoverage113.cons _ _ compact113_node_2557
    (ChildrenCoverage113.cons _ _ compact113_node_2558
    (ChildrenCoverage113.cons _ _ compact113_node_2568
    (ChildrenCoverage113.cons _ _ compact113_node_2569
    (ChildrenCoverage113.cons _ _ compact113_node_2570
    (ChildrenCoverage113.cons _ _ compact113_node_2571
    (ChildrenCoverage113.cons _ _ compact113_node_2572
    (ChildrenCoverage113.cons _ _ compact113_node_2573
    (ChildrenCoverage113.cons _ _ compact113_node_2574
    (ChildrenCoverage113.cons _ _ compact113_node_2575
    (ChildrenCoverage113.cons _ _ compact113_node_2576
    (ChildrenCoverage113.cons _ _ compact113_node_2577
    (ChildrenCoverage113.cons _ _ compact113_node_2578
    ChildrenCoverage113.nil)))))))))))))))))))))))

theorem compact113_node_2580 : NodeCoverage113 [28,28,27] 27 30 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2581 : NodeCoverage113 [28,28,26] 26 31 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2582 : NodeCoverage113 [28,28,25] 25 32 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2583 : NodeCoverage113 [28,28,24] 24 33 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2584 : NodeCoverage113 [28,28,23] 23 34 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2585 : NodeCoverage113 [28,28,22] 22 35 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2586 : NodeCoverage113 [28,28,21] 21 36 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2587 : NodeCoverage113 [28,28,20] 20 37 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2588 : NodeCoverage113 [28,28,19] 19 38 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2589 : NodeCoverage113 [28,28,18] 18 39 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2590 : NodeCoverage113 [28,28,17] 17 40 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2591 : NodeCoverage113 [28,28,16] 16 41 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2592 : NodeCoverage113 [28,28,15] 15 42 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2593 : NodeCoverage113 [28,28,14,14,14] 14 15 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2594 : NodeCoverage113 [28,28,14,14,13] 13 16 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2595 : NodeCoverage113 [28,28,14,14,12] 12 17 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2596 : NodeCoverage113 [28,28,14,14,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2597 : NodeCoverage113 [28,28,14,14,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2598 : NodeCoverage113 [28,28,14,14,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2599 : NodeCoverage113 [28,28,14,14,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2600 : NodeCoverage113 [28,28,14,14,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2601 : NodeCoverage113 [28,28,14,14,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2602 : NodeCoverage113 [28,28,14,14,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2600
    (ChildrenCoverage113.cons _ _ compact113_node_2601
    ChildrenCoverage113.nil))

theorem compact113_node_2603 : NodeCoverage113 [28,28,14,14,7,7,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2604 : NodeCoverage113 [28,28,14,14,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

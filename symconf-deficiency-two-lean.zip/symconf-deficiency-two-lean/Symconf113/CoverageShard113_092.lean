import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3256 : NodeCoverage113 [24,13,13] 13 63 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3257 : NodeCoverage113 [24,13,12] 12 64 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3258 : NodeCoverage113 [24,13,11] 11 65 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3259 : NodeCoverage113 [24,13,10] 10 66 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3260 : NodeCoverage113 [24,13,9] 9 67 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3261 : NodeCoverage113 [24,13,8] 8 68 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3262 : NodeCoverage113 [24,13,7] 7 69 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3263 : NodeCoverage113 [24,13,6] 6 70 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3264 : NodeCoverage113 [24,13,5] 5 71 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3265 : NodeCoverage113 [24,13,3] 3 73 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3266 : NodeCoverage113 [24,13] 13 76 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3256
    (ChildrenCoverage113.cons _ _ compact113_node_3257
    (ChildrenCoverage113.cons _ _ compact113_node_3258
    (ChildrenCoverage113.cons _ _ compact113_node_3259
    (ChildrenCoverage113.cons _ _ compact113_node_3260
    (ChildrenCoverage113.cons _ _ compact113_node_3261
    (ChildrenCoverage113.cons _ _ compact113_node_3262
    (ChildrenCoverage113.cons _ _ compact113_node_3263
    (ChildrenCoverage113.cons _ _ compact113_node_3264
    (ChildrenCoverage113.cons _ _ compact113_node_3265
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_3267 : NodeCoverage113 [24,12,12,12,12,12,12,12] 12 5 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3268 : NodeCoverage113 [24,12,12,12,12,12,12,11] 11 6 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3269 : NodeCoverage113 [24,12,12,12,12,12,12,10] 10 7 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3270 : NodeCoverage113 [24,12,12,12,12,12,12,9] 9 8 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3271 : NodeCoverage113 [24,12,12,12,12,12,12,8] 8 9 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3272 : NodeCoverage113 [24,12,12,12,12,12,12,7] 7 10 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3273 : NodeCoverage113 [24,12,12,12,12,12,12,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3274 : NodeCoverage113 [24,12,12,12,12,12,12,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3273
    ChildrenCoverage113.nil)

theorem compact113_node_3275 : NodeCoverage113 [24,12,12,12,12,12,12,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3276 : NodeCoverage113 [24,12,12,12,12,12,12,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_3277 : NodeCoverage113 [24,12,12,12,12,12,12,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3276
    ChildrenCoverage113.nil)

theorem compact113_node_3278 : NodeCoverage113 [24,12,12,12,12,12,12,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3274
    (ChildrenCoverage113.cons _ _ compact113_node_3275
    (ChildrenCoverage113.cons _ _ compact113_node_3277
    ChildrenCoverage113.nil)))

theorem compact113_node_3279 : NodeCoverage113 [24,12,12,12,12,12,12,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3280 : NodeCoverage113 [24,12,12,12,12,12,12,3] 3 14 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3281 : NodeCoverage113 [24,12,12,12,12,12,12] 12 17 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3267
    (ChildrenCoverage113.cons _ _ compact113_node_3268
    (ChildrenCoverage113.cons _ _ compact113_node_3269
    (ChildrenCoverage113.cons _ _ compact113_node_3270
    (ChildrenCoverage113.cons _ _ compact113_node_3271
    (ChildrenCoverage113.cons _ _ compact113_node_3272
    (ChildrenCoverage113.cons _ _ compact113_node_3278
    (ChildrenCoverage113.cons _ _ compact113_node_3279
    (ChildrenCoverage113.cons _ _ compact113_node_3280
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_3282 : NodeCoverage113 [24,12,12,12,12,12,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3283 : NodeCoverage113 [24,12,12,12,12,12,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3284 : NodeCoverage113 [24,12,12,12,12,12,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3285 : NodeCoverage113 [24,12,12,12,12,12,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3286 : NodeCoverage113 [24,12,12,12,12,12,7] 7 22 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3287 : NodeCoverage113 [24,12,12,12,12,12,6] 6 23 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3288 : NodeCoverage113 [24,12,12,12,12,12,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.PairEnum113
import Symconf113.ProfileDefinitions

/-! From the profile facts of two distinct rows to a finite check.

The columns met by row `i` or row `j` are read as a list of `PairOpt`s.
That list pays the exact row totals and the cross moment, so the complete
enumerator finds a permutation of it. Every candidate the enumerator returns
is then tested for the exact cross moment and both period bounds; the ones
that pass must carry an allowed pair of row signatures. With no allowed
signatures the two rows cannot coexist. -/
namespace Symconf113
open scoped BigOperators

/-! ### Options -/

def mkOpt (a1 a2 b u1 u2 : ℕ) : PairOpt := ⟨b,u1,a1*u1/b,u2,a2*u2/b⟩

def optAdmissible (a1 a2 : ℕ) (o : PairOpt) : Bool :=
  decide (0<o.b ∧ o.b*o.v1=a1*o.u1 ∧ o.b*o.v2=a2*o.u2 ∧ o.v1≤11 ∧ o.v2≤11 ∧
    (o.u1≤1 ∨ a1∣o.b) ∧ (o.u2≤1 ∨ a2∣o.b) ∧ (0<o.u1 ∨ 0<o.u2))

def rawOpts (a1 a2 : ℕ) (bs : List ℕ) : List PairOpt :=
  (bs.flatMap fun b => (List.range 12).flatMap fun u1 => (List.range 12).map fun u2 =>
    mkOpt a1 a2 b u1 u2).filter (optAdmissible a1 a2)

def pairOpts (a1 a2 : ℕ) (bs : List ℕ) : List PairOpt :=
  ((rawOpts a1 a2 bs).filter (fun o => decide (0<o.u1))).insertionSort
      (fun o p => p.v1≤o.v1) ++
  ((rawOpts a1 a2 bs).filter (fun o => decide (o.u1=0))).insertionSort
      (fun o p => p.v2≤o.v2)

theorem mem_pairOpts {a1 a2 : ℕ} {bs : List ℕ} {o : PairOpt} (hb : o.b∈bs) (hb0 : 0<o.b)
    (h1 : o.b*o.v1=a1*o.u1) (h2 : o.b*o.v2=a2*o.u2) (hu1 : o.u1≤11) (hu2 : o.u2≤11)
    (hv1 : o.v1≤11) (hv2 : o.v2≤11) (hp1 : o.u1≤1 ∨ a1∣o.b) (hp2 : o.u2≤1 ∨ a2∣o.b)
    (hne : 0<o.u1 ∨ 0<o.u2) : o∈pairOpts a1 a2 bs := by
  have hmk : mkOpt a1 a2 o.b o.u1 o.u2=o := by
    obtain ⟨b,u1,v1,u2,v2⟩ := o
    simp only at *
    simp only [mkOpt, PairOpt.mk.injEq, true_and]
    exact ⟨Nat.div_eq_of_eq_mul_left hb0 (by rw [←h1]; ring),
      Nat.div_eq_of_eq_mul_left hb0 (by rw [←h2]; ring)⟩
  have hraw : o∈rawOpts a1 a2 bs := by
    unfold rawOpts
    rw [List.mem_filter]
    refine ⟨?_, ?_⟩
    · simp only [List.mem_flatMap, List.mem_range, List.mem_map]
      exact ⟨o.b,hb,o.u1,by omega,o.u2,by omega,hmk⟩
    · simp only [optAdmissible, decide_eq_true_eq]
      exact ⟨hb0,h1,h2,hv1,hv2,hp1,hp2,hne⟩
  unfold pairOpts
  rw [List.mem_append, (List.perm_insertionSort _ _).mem_iff, (List.perm_insertionSort _ _).mem_iff,
    List.mem_filter, List.mem_filter]
  by_cases h : 0<o.u1
  · exact Or.inl ⟨hraw, by simpa using h⟩
  · exact Or.inr ⟨hraw, by simp; omega⟩

/-! ### Signatures and the per-candidate test -/

/-- Order-free record of a list of encoded columns. -/
def sigOf (l : List ℕ) : List ℕ := l.insertionSort (·≤·)

theorem sigOf_perm {l l' : List ℕ} (h : l.Perm l') : sigOf l=sigOf l' :=
  List.Perm.eq_of_sortedLE List.sortedLE_insertionSort List.sortedLE_insertionSort
    ((List.perm_insertionSort _ l).trans (h.trans (List.perm_insertionSort _ l').symm))

def sig1 (D : List PairOpt) : List ℕ :=
  sigOf ((D.filter (fun o => decide (0<o.u1))).map fun o => o.b*100+o.u1)

def sig2 (D : List PairOpt) : List ℕ :=
  sigOf ((D.filter (fun o => decide (0<o.u2))).map fun o => o.b*100+o.u2)

def periodOK1 (a : ℕ) (D : List PairOpt) : Bool :=
  (List.range a).all fun d =>
    decide (d=0) || decide ((D.map fun o => if Nat.gcd a o.b ∣ d then o.u1 else 0).sum≤1)

def periodOK2 (a : ℕ) (D : List PairOpt) : Bool :=
  (List.range a).all fun d =>
    decide (d=0) || decide ((D.map fun o => if Nat.gcd a o.b ∣ d then o.u2 else 0).sum≤1)

def pairGood (a1 a2 : ℕ) (D : List PairOpt) : Bool :=
  decide ((D.map PairOpt.x).sum=a1*a2) && periodOK1 a1 D && periodOK2 a2 D

def countIn (P : List ℕ) (y : ℕ) : ℕ := (P.filter (fun z => decide (z=y))).length

/-- The whole finite certificate for an ordered pair of row lengths. -/
def pairSigCheck (a1 a2 : ℕ) (P : List ℕ) (S : List (List ℕ × List ℕ)) : Bool :=
  let O := pairOpts a1 a2 P.dedup
  decide (O.Pairwise PairOrder) && O.all (fun o => decide o.OK) &&
  (pairEnum O 11 (a1+8) 11 (a2+8) (a1*a2) (countIn P)).all
    (fun D => !pairGood a1 a2 D || decide ((sig1 D, sig2 D)∈S))

/-! ### Reading a row of the profile facts -/

theorem sum_map_filter_of_zero {α : Type*} (l : List α) (p : α → Bool) (f : α → ℕ)
    (h : ∀ z∈l, p z=false → f z=0) : ((l.filter p).map f).sum=(l.map f).sum := by
  induction l with
  | nil => simp
  | cons a l ih =>
    have ih' := ih (fun z hz => h z (List.mem_cons_of_mem _ hz))
    by_cases hp : p a
    · simp [hp, ih']
    · have : f a=0 := h a (by simp) (by simpa using hp)
      simp [hp, ih', this]

/-- The signature of row `i`: its nonzero columns, encoded as
`length*100+degree`, sorted. -/
def rowSig {P : List ℕ} (F : OriginalProfileFacts P) (i : Fin P.length) : List ℕ :=
  sigOf (((List.finRange P.length).filter (fun c => decide (0<(F.row i).u c))).map
    fun c => P.get c*100+(F.row i).u c)

section rows
variable {P : List ℕ} (F : OriginalProfileFacts P)
include F

theorem len_pos (c : Fin P.length) : 0<P.get c := by
  have := F.positive (P.get c) (List.get_mem P c)
  omega

theorem row_u_sum (i : Fin P.length) : (∑ c,(F.row i).u c)=11 := by
  have ha := len_pos F i
  have h : (∑ c,P.get i*(F.row i).u c)=11*P.get i := by
    rw [←(F.row i).momentOne]
    exact Finset.sum_congr rfl (fun c _ => (F.row i).block c)
  rw [←Finset.mul_sum] at h
  exact Nat.eq_of_mul_eq_mul_left ha (by rw [h]; ring)

theorem row_uv_sum (i : Fin P.length) :
    (∑ c,(F.row i).u c*(F.row i).v c)=P.get i+8 := by
  have ha := len_pos F i
  have h : (∑ c,P.get i*((F.row i).u c*(F.row i).v c))=P.get i*(P.get i+8) := by
    rw [←(F.row i).momentTwo]
    refine Finset.sum_congr rfl (fun c _ => ?_)
    rw [←mul_assoc, (F.row i).block c]
  rw [←Finset.mul_sum] at h
  exact Nat.eq_of_mul_eq_mul_left ha h

theorem row_u_le (i c : Fin P.length) : (F.row i).u c≤11 := by
  rw [←row_u_sum F i]
  exact Finset.single_le_sum (fun _ _ => Nat.zero_le _) (Finset.mem_univ c)

theorem row_v_zero (i c : Fin P.length) (h : (F.row i).u c=0) : (F.row i).v c=0 := by
  have hb := (F.row i).block c
  have := len_pos F c
  rw [h, mul_zero] at hb
  rcases Nat.mul_eq_zero.mp hb.symm with h' | h'
  · omega
  · exact h'

theorem row_v_pos (i c : Fin P.length) (h : 0<(F.row i).u c) : 0<(F.row i).v c := by
  have hb := (F.row i).block c
  have := len_pos F i
  rcases Nat.eq_zero_or_pos ((F.row i).v c) with h' | h'
  · rw [h', mul_zero] at hb
    rcases Nat.mul_eq_zero.mp hb with h'' | h'' <;> omega
  · exact h'

theorem row_period_one (i c : Fin P.length) :
    (F.row i).u c≤1 ∨ P.get i∣P.get c := by
  by_cases hd : P.get i∣P.get c
  · exact Or.inr hd
  · left
    have ha := len_pos F i
    have hg : Nat.gcd (P.get i) (P.get c)<P.get i := by
      rcases Nat.lt_or_ge (Nat.gcd (P.get i) (P.get c)) (P.get i) with h | h
      · exact h
      · exfalso; apply hd
        have hle := Nat.le_of_dvd ha (Nat.gcd_dvd_left (P.get i) (P.get c))
        have : Nat.gcd (P.get i) (P.get c)=P.get i := le_antisymm hle h
        rw [←this]; exact Nat.gcd_dvd_right _ _
    have hgp : 0<Nat.gcd (P.get i) (P.get c) := Nat.gcd_pos_of_pos_left _ ha
    have hb := F.period i (Nat.gcd (P.get i) (P.get c)) hgp hg
    refine le_trans ?_ hb
    have := Finset.single_le_sum (f := fun j =>
        if Nat.gcd (P.get i) (P.get j) ∣ Nat.gcd (P.get i) (P.get c) then (F.row i).u j else 0)
      (fun _ _ => Nat.zero_le _) (Finset.mem_univ c)
    simpa using this

end rows

/-! ### The pair theorem -/

theorem pair_sig {P : List ℕ} (F : OriginalProfileFacts P) (i j : Fin P.length) (hij : i≠j)
    (S : List (List ℕ × List ℕ)) (h : pairSigCheck (P.get i) (P.get j) P S=true) :
    (rowSig F i, rowSig F j)∈S := by
  set cols := (List.finRange P.length).filter (fun c => decide (0<(F.row i).u c ∨ 0<(F.row j).u c)) with hcols
  let g : Fin P.length → PairOpt := fun c => ⟨P.get c, (F.row i).u c, (F.row i).v c, (F.row j).u c, (F.row j).v c⟩
  set L := cols.map g with hL
  set O := pairOpts (P.get i) (P.get j) P.dedup with hO
  simp only [pairSigCheck, Bool.and_eq_true, decide_eq_true_eq, List.all_eq_true] at h
  obtain ⟨⟨hsort,hok⟩,hall⟩ := h
  -- zero outside the selected columns
  have hz {f : Fin P.length → ℕ} (hf : ∀ c, (F.row i).u c=0 → (F.row j).u c=0 → f c=0) :
      ((cols.map f).sum)=∑ c,f c := by
    rw [hcols, sum_map_filter_of_zero, Fin.sum_univ_def]
    intro c _ hc
    simp only [decide_eq_false_iff_not, not_or, not_lt, Nat.le_zero] at hc
    exact hf c hc.1 hc.2
  have hcolsub : cols.Sublist (List.finRange P.length) := List.filter_sublist
  -- membership of every column in the option list
  have hmem : ∀ o∈L, o∈O := by
    intro o ho
    rw [hL, List.mem_map] at ho
    obtain ⟨c,hc,rfl⟩ := ho
    have hc' := (List.mem_filter.mp hc).2
    simp only [decide_eq_true_eq] at hc'
    exact mem_pairOpts (List.mem_dedup.mpr (List.get_mem P c)) (len_pos F c)
      ((F.row i).block c).symm ((F.row j).block c).symm (row_u_le F i c) (row_u_le F j c)
      (F.cap i c) (F.cap j c) (row_period_one F i c) (row_period_one F j c) hc'
  have hs1 : (L.map PairOpt.u1).sum=11 := by
    rw [hL, List.map_map]
    exact (hz (f := (F.row i).u) (fun c h _ => h)).trans (row_u_sum F i)
  have hq1 : (L.map PairOpt.c1).sum=(P.get i)+8 := by
    rw [hL, List.map_map]
    exact (hz (f := fun c => (F.row i).u c*(F.row i).v c) (fun c h _ => by simp [h])).trans (row_uv_sum F i)
  have hs2 : (L.map PairOpt.u2).sum=11 := by
    rw [hL, List.map_map]
    exact (hz (f := (F.row j).u) (fun c _ h => h)).trans (row_u_sum F j)
  have hq2 : (L.map PairOpt.c2).sum=(P.get j)+8 := by
    rw [hL, List.map_map]
    exact (hz (f := fun c => (F.row j).u c*(F.row j).v c) (fun c _ h => by simp [h])).trans (row_uv_sum F j)
  have hx : (L.map PairOpt.x).sum=(P.get i)*(P.get j) := by
    rw [hL, List.map_map]
    refine (hz (f := fun c => P.get c*(F.row i).v c*(F.row j).v c) (fun c h _ => by
      simp [row_v_zero F i c h])).trans ?_
    exact F.cross i j hij
  have hcnt : ∀ y, (L.filter (fun o => o.b=y)).length≤countIn P y := by
    intro y
    rw [hL, List.filter_map, List.length_map, countIn]
    have hsub := (hcolsub.filter (fun c => decide (P.get c=y))).length_le
    refine le_trans (le_of_eq ?_) (le_trans hsub (le_of_eq ?_))
    · rfl
    · conv_rhs => rw [←List.map_get_finRange P]
      rw [List.filter_map, List.length_map]
      rfl
  obtain ⟨D,hD,hDP⟩ := pairEnum_complete O L 11 ((P.get i)+8) 11 ((P.get j)+8) ((P.get i)*(P.get j)) (countIn P)
    hsort hok hmem hs1 hq1 hs2 hq2 (le_of_eq hx) hcnt
  have hcheck := hall D hD
  have hpsum (f : PairOpt → ℕ) : (D.map f).sum=(L.map f).sum := (hDP.map f).sum_eq
  have hgood : pairGood (P.get i) (P.get j) D=true := by
    simp only [pairGood, Bool.and_eq_true, decide_eq_true_eq, periodOK1, periodOK2,
      List.all_eq_true, List.mem_range, Bool.or_eq_true]
    refine ⟨⟨by rw [hpsum, hx], ?_⟩, ?_⟩
    · intro d hd
      by_cases hd0 : d=0
      · exact Or.inl hd0
      · right
        rw [hpsum, hL, List.map_map]
        refine le_trans (le_of_eq (hz (f := fun c => if Nat.gcd (P.get i) (P.get c) ∣ d then (F.row i).u c else 0)
          (fun c h _ => by simp [h]))) ?_
        exact F.period i d (Nat.pos_of_ne_zero hd0) hd
    · intro d hd
      by_cases hd0 : d=0
      · exact Or.inl hd0
      · right
        rw [hpsum, hL, List.map_map]
        refine le_trans (le_of_eq (hz (f := fun c => if Nat.gcd (P.get j) (P.get c) ∣ d then (F.row j).u c else 0)
          (fun c _ h => by simp [h]))) ?_
        exact F.period j d (Nat.pos_of_ne_zero hd0) hd
  rw [hgood] at hcheck
  simp only [Bool.not_true, Bool.false_or, decide_eq_true_eq] at hcheck
  have e1 : sig1 D=rowSig F i := by
    unfold sig1 rowSig
    rw [sigOf_perm ((hDP.filter _).map _), hL, hcols, List.filter_map, List.filter_filter,
      List.map_map]
    congr 2
    apply List.filter_congr
    intro c _
    simp only [Function.comp, g]
    by_cases hc : 0<(F.row i).u c <;> simp [hc]
  have e2 : sig2 D=rowSig F j := by
    unfold sig2 rowSig
    rw [sigOf_perm ((hDP.filter _).map _), hL, hcols, List.filter_map, List.filter_filter,
      List.map_map]
    congr 2
    apply List.filter_congr
    intro c _
    simp only [Function.comp, g]
    by_cases hc : 0<(F.row j).u c <;> simp [hc]
  rw [←e1, ←e2]
  exact hcheck

/-- No allowed signatures: the two rows cannot coexist. -/
theorem pair_exclusion {P : List ℕ} (F : OriginalProfileFacts P) (i j : Fin P.length)
    (hij : i≠j) (h : pairSigCheck (P.get i) (P.get j) P []=true) : False := by
  have := pair_sig F i j hij [] h
  simp at this

/-- Allowed pairs of signatures that no three rows can realise pairwise. -/
def noTriangle (S : List (List ℕ × List ℕ)) : Bool :=
  S.all fun p => S.all fun q => !(decide (p.1=q.1)) || !(decide ((p.2,q.2)∈S))

theorem triple_exclusion {P : List ℕ} (F : OriginalProfileFacts P) (i j k : Fin P.length)
    (hij : i≠j) (hik : i≠k) (hjk : j≠k) (S : List (List ℕ × List ℕ))
    (h1 : pairSigCheck (P.get i) (P.get j) P S=true)
    (h2 : pairSigCheck (P.get i) (P.get k) P S=true)
    (h3 : pairSigCheck (P.get j) (P.get k) P S=true) (hS : noTriangle S=true) : False := by
  have e1 := pair_sig F i j hij S h1
  have e2 := pair_sig F i k hik S h2
  have e3 := pair_sig F j k hjk S h3
  simp only [noTriangle, List.all_eq_true, Bool.or_eq_true, Bool.not_eq_true',
    decide_eq_false_iff_not] at hS
  rcases hS _ e1 _ e2 with h | h
  · exact h rfl
  · exact h e3

end Symconf113

#print axioms Symconf113.pair_sig
#print axioms Symconf113.triple_exclusion

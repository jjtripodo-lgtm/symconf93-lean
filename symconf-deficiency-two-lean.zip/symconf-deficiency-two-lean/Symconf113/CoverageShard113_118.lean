import Symconf113.CoverageShard113_117

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4518 : NodeCoverage113 [18,18,18,9,9,9,6,6,6,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4517
    ChildrenCoverage113.nil)

theorem compact113_node_4519 : NodeCoverage113 [18,18,18,9,9,9,6,6,6,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4518
    ChildrenCoverage113.nil)

theorem compact113_node_4520 : NodeCoverage113 [18,18,18,9,9,9,6,6,6] 6 14 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4515
    (ChildrenCoverage113.cons _ _ compact113_node_4516
    (ChildrenCoverage113.cons _ _ compact113_node_4519
    ChildrenCoverage113.nil)))

theorem compact113_node_4521 : NodeCoverage113 [18,18,18,9,9,9,6,6,5] 5 15 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4522 : NodeCoverage113 [18,18,18,9,9,9,6,6,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4523 : NodeCoverage113 [18,18,18,9,9,9,6,6,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4522
    ChildrenCoverage113.nil)

theorem compact113_node_4524 : NodeCoverage113 [18,18,18,9,9,9,6,6,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4523
    ChildrenCoverage113.nil)

theorem compact113_node_4525 : NodeCoverage113 [18,18,18,9,9,9,6,6,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4524
    ChildrenCoverage113.nil)

theorem compact113_node_4526 : NodeCoverage113 [18,18,18,9,9,9,6,6,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4525
    ChildrenCoverage113.nil)

theorem compact113_node_4527 : NodeCoverage113 [18,18,18,9,9,9,6,6] 6 20 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4520
    (ChildrenCoverage113.cons _ _ compact113_node_4521
    (ChildrenCoverage113.cons _ _ compact113_node_4526
    ChildrenCoverage113.nil)))

theorem compact113_node_4528 : NodeCoverage113 [18,18,18,9,9,9,6,5] 5 21 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4529 : NodeCoverage113 [18,18,18,9,9,9,6,3] 3 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4530 : NodeCoverage113 [18,18,18,9,9,9,6] 6 26 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4527
    (ChildrenCoverage113.cons _ _ compact113_node_4528
    (ChildrenCoverage113.cons _ _ compact113_node_4529
    ChildrenCoverage113.nil)))

theorem compact113_node_4531 : NodeCoverage113 [18,18,18,9,9,9,5] 5 27 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4532 : NodeCoverage113 [18,18,18,9,9,9,3] 3 29 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4533 : NodeCoverage113 [18,18,18,9,9,9] 9 32 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4510
    (ChildrenCoverage113.cons _ _ compact113_node_4511
    (ChildrenCoverage113.cons _ _ compact113_node_4512
    (ChildrenCoverage113.cons _ _ compact113_node_4530
    (ChildrenCoverage113.cons _ _ compact113_node_4531
    (ChildrenCoverage113.cons _ _ compact113_node_4532
    ChildrenCoverage113.nil))))))

theorem compact113_node_4534 : NodeCoverage113 [18,18,18,9,9,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4535 : NodeCoverage113 [18,18,18,9,9,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4536 : NodeCoverage113 [18,18,18,9,9,6,6,6,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4537 : NodeCoverage113 [18,18,18,9,9,6,6,6,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4536
    ChildrenCoverage113.nil)

theorem compact113_node_4538 : NodeCoverage113 [18,18,18,9,9,6,6,6,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4539 : NodeCoverage113 [18,18,18,9,9,6,6,6,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4540 : NodeCoverage113 [18,18,18,9,9,6,6,6,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4539
    ChildrenCoverage113.nil)

theorem compact113_node_4541 : NodeCoverage113 [18,18,18,9,9,6,6,6,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4537
    (ChildrenCoverage113.cons _ _ compact113_node_4538
    (ChildrenCoverage113.cons _ _ compact113_node_4540
    ChildrenCoverage113.nil)))

theorem compact113_node_4542 : NodeCoverage113 [18,18,18,9,9,6,6,6,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4543 : NodeCoverage113 [18,18,18,9,9,6,6,6,6,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4544 : NodeCoverage113 [18,18,18,9,9,6,6,6,6,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4543
    ChildrenCoverage113.nil)

theorem compact113_node_4545 : NodeCoverage113 [18,18,18,9,9,6,6,6,6,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4544
    ChildrenCoverage113.nil)

theorem compact113_node_4546 : NodeCoverage113 [18,18,18,9,9,6,6,6,6,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4545
    ChildrenCoverage113.nil)

theorem compact113_node_4547 : NodeCoverage113 [18,18,18,9,9,6,6,6,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4541
    (ChildrenCoverage113.cons _ _ compact113_node_4542
    (ChildrenCoverage113.cons _ _ compact113_node_4546
    ChildrenCoverage113.nil)))

theorem compact113_node_4548 : NodeCoverage113 [18,18,18,9,9,6,6,6,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4549 : NodeCoverage113 [18,18,18,9,9,6,6,6,3] 3 20 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4550 : NodeCoverage113 [18,18,18,9,9,6,6,6] 6 23 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4547
    (ChildrenCoverage113.cons _ _ compact113_node_4548
    (ChildrenCoverage113.cons _ _ compact113_node_4549
    ChildrenCoverage113.nil)))

theorem compact113_node_4551 : NodeCoverage113 [18,18,18,9,9,6,6,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4552 : NodeCoverage113 [18,18,18,9,9,6,6,3] 3 26 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4553 : NodeCoverage113 [18,18,18,9,9,6,6] 6 29 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4550
    (ChildrenCoverage113.cons _ _ compact113_node_4551
    (ChildrenCoverage113.cons _ _ compact113_node_4552
    ChildrenCoverage113.nil)))

theorem compact113_node_4554 : NodeCoverage113 [18,18,18,9,9,6,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4555 : NodeCoverage113 [18,18,18,9,9,6,3] 3 32 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4556 : NodeCoverage113 [18,18,18,9,9,6] 6 35 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4553
    (ChildrenCoverage113.cons _ _ compact113_node_4554
    (ChildrenCoverage113.cons _ _ compact113_node_4555
    ChildrenCoverage113.nil)))

theorem compact113_node_4557 : NodeCoverage113 [18,18,18,9,9,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4558 : NodeCoverage113 [18,18,18,9,9,3] 3 38 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4559 : NodeCoverage113 [18,18,18,9,9] 9 41 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4533
    (ChildrenCoverage113.cons _ _ compact113_node_4534
    (ChildrenCoverage113.cons _ _ compact113_node_4535
    (ChildrenCoverage113.cons _ _ compact113_node_4556
    (ChildrenCoverage113.cons _ _ compact113_node_4557
    (ChildrenCoverage113.cons _ _ compact113_node_4558
    ChildrenCoverage113.nil))))))

theorem compact113_node_4560 : NodeCoverage113 [18,18,18,9,8] 8 42 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4561 : NodeCoverage113 [18,18,18,9,7] 7 43 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4562 : NodeCoverage113 [18,18,18,9,6] 6 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4563 : NodeCoverage113 [18,18,18,9,5] 5 45 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4564 : NodeCoverage113 [18,18,18,9,3] 3 47 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4565 : NodeCoverage113 [18,18,18,9] 9 50 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4559
    (ChildrenCoverage113.cons _ _ compact113_node_4560
    (ChildrenCoverage113.cons _ _ compact113_node_4561
    (ChildrenCoverage113.cons _ _ compact113_node_4562
    (ChildrenCoverage113.cons _ _ compact113_node_4563
    (ChildrenCoverage113.cons _ _ compact113_node_4564
    ChildrenCoverage113.nil))))))

theorem compact113_node_4566 : NodeCoverage113 [18,18,18,8] 8 51 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4567 : NodeCoverage113 [18,18,18,7] 7 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4568 : NodeCoverage113 [18,18,18,6] 6 53 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4569 : NodeCoverage113 [18,18,18,5] 5 54 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4570 : NodeCoverage113 [18,18,18,3] 3 56 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4571 : NodeCoverage113 [18,18,18] 18 59 :=
  node_fork113 (B := [18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4473
    (ChildrenCoverage113.cons _ _ compact113_node_4474
    (ChildrenCoverage113.cons _ _ compact113_node_4475
    (ChildrenCoverage113.cons _ _ compact113_node_4476
    (ChildrenCoverage113.cons _ _ compact113_node_4477
    (ChildrenCoverage113.cons _ _ compact113_node_4478
    (ChildrenCoverage113.cons _ _ compact113_node_4479
    (ChildrenCoverage113.cons _ _ compact113_node_4480
    (ChildrenCoverage113.cons _ _ compact113_node_4481
    (ChildrenCoverage113.cons _ _ compact113_node_4565
    (ChildrenCoverage113.cons _ _ compact113_node_4566
    (ChildrenCoverage113.cons _ _ compact113_node_4567
    (ChildrenCoverage113.cons _ _ compact113_node_4568
    (ChildrenCoverage113.cons _ _ compact113_node_4569
    (ChildrenCoverage113.cons _ _ compact113_node_4570
    ChildrenCoverage113.nil)))))))))))))))

theorem compact113_node_4572 : NodeCoverage113 [18,18,17] 17 60 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4573 : NodeCoverage113 [18,18,16] 16 61 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_008

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0400 : NodeCoverage113 [60,15,15,5] 5 18 :=
  demand_node_prune113 60 compact113_demands_060 compact113_demands_060_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0401 : NodeCoverage113 [60,15,15,3] 3 20 :=
  demand_node_prune113 60 compact113_demands_060 compact113_demands_060_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0402 : NodeCoverage113 [60,15,15] 15 23 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0390
    (ChildrenCoverage113.cons _ _ compact113_node_0391
    (ChildrenCoverage113.cons _ _ compact113_node_0392
    (ChildrenCoverage113.cons _ _ compact113_node_0393
    (ChildrenCoverage113.cons _ _ compact113_node_0394
    (ChildrenCoverage113.cons _ _ compact113_node_0395
    (ChildrenCoverage113.cons _ _ compact113_node_0396
    (ChildrenCoverage113.cons _ _ compact113_node_0397
    (ChildrenCoverage113.cons _ _ compact113_node_0398
    (ChildrenCoverage113.cons _ _ compact113_node_0399
    (ChildrenCoverage113.cons _ _ compact113_node_0400
    (ChildrenCoverage113.cons _ _ compact113_node_0401
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_0403 : NodeCoverage113 [60,15,14] 14 24 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0404 : NodeCoverage113 [60,15,13] 13 25 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0405 : NodeCoverage113 [60,15,12,12,11] 11 3 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0406 : NodeCoverage113 [60,15,12,12,10] 10 4 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0407 : NodeCoverage113 [60,15,12,12,9] 9 5 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0408 : NodeCoverage113 [60,15,12,12,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0409 : NodeCoverage113 [60,15,12,12,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0410 : NodeCoverage113 [60,15,12,12,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0411 : NodeCoverage113 [60,15,12,12,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0412 : NodeCoverage113 [60,15,12,12,3] 3 11 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0413 : NodeCoverage113 [60,15,12,12] 12 14 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0405
    (ChildrenCoverage113.cons _ _ compact113_node_0406
    (ChildrenCoverage113.cons _ _ compact113_node_0407
    (ChildrenCoverage113.cons _ _ compact113_node_0408
    (ChildrenCoverage113.cons _ _ compact113_node_0409
    (ChildrenCoverage113.cons _ _ compact113_node_0410
    (ChildrenCoverage113.cons _ _ compact113_node_0411
    (ChildrenCoverage113.cons _ _ compact113_node_0412
    ChildrenCoverage113.nil))))))))

theorem compact113_node_0414 : NodeCoverage113 [60,15,12,11] 11 15 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0415 : NodeCoverage113 [60,15,12,10] 10 16 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0416 : NodeCoverage113 [60,15,12,9] 9 17 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0417 : NodeCoverage113 [60,15,12,8] 8 18 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0418 : NodeCoverage113 [60,15,12,7] 7 19 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0419 : NodeCoverage113 [60,15,12,6] 6 20 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0420 : NodeCoverage113 [60,15,12,5] 5 21 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0421 : NodeCoverage113 [60,15,12,3] 3 23 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0422 : NodeCoverage113 [60,15,12] 12 26 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0413
    (ChildrenCoverage113.cons _ _ compact113_node_0414
    (ChildrenCoverage113.cons _ _ compact113_node_0415
    (ChildrenCoverage113.cons _ _ compact113_node_0416
    (ChildrenCoverage113.cons _ _ compact113_node_0417
    (ChildrenCoverage113.cons _ _ compact113_node_0418
    (ChildrenCoverage113.cons _ _ compact113_node_0419
    (ChildrenCoverage113.cons _ _ compact113_node_0420
    (ChildrenCoverage113.cons _ _ compact113_node_0421
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_0423 : NodeCoverage113 [60,15,11] 11 27 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0424 : NodeCoverage113 [60,15,10,10,10,8] 8 0 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0425 : NodeCoverage113 [60,15,10,10,10,5] 5 3 :=
  demand_node_prune113 60 compact113_demands_060 compact113_demands_060_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0426 : NodeCoverage113 [60,15,10,10,10,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0427 : NodeCoverage113 [60,15,10,10,10] 10 8 :=
  node_fork113 (B := [8,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0424
    (ChildrenCoverage113.cons _ _ compact113_node_0425
    (ChildrenCoverage113.cons _ _ compact113_node_0426
    ChildrenCoverage113.nil)))

theorem compact113_node_0428 : NodeCoverage113 [60,15,10,10,9] 9 9 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0429 : NodeCoverage113 [60,15,10,10,8] 8 10 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0430 : NodeCoverage113 [60,15,10,10,7] 7 11 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0431 : NodeCoverage113 [60,15,10,10,6] 6 12 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0432 : NodeCoverage113 [60,15,10,10,5] 5 13 :=
  demand_node_prune113 60 compact113_demands_060 compact113_demands_060_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0433 : NodeCoverage113 [60,15,10,10,3] 3 15 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0434 : NodeCoverage113 [60,15,10,10] 10 18 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0427
    (ChildrenCoverage113.cons _ _ compact113_node_0428
    (ChildrenCoverage113.cons _ _ compact113_node_0429
    (ChildrenCoverage113.cons _ _ compact113_node_0430
    (ChildrenCoverage113.cons _ _ compact113_node_0431
    (ChildrenCoverage113.cons _ _ compact113_node_0432
    (ChildrenCoverage113.cons _ _ compact113_node_0433
    ChildrenCoverage113.nil)))))))

theorem compact113_node_0435 : NodeCoverage113 [60,15,10,9] 9 19 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0436 : NodeCoverage113 [60,15,10,8] 8 20 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0437 : NodeCoverage113 [60,15,10,7] 7 21 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0438 : NodeCoverage113 [60,15,10,6] 6 22 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0439 : NodeCoverage113 [60,15,10,5] 5 23 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0440 : NodeCoverage113 [60,15,10,3] 3 25 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0441 : NodeCoverage113 [60,15,10] 10 28 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0434
    (ChildrenCoverage113.cons _ _ compact113_node_0435
    (ChildrenCoverage113.cons _ _ compact113_node_0436
    (ChildrenCoverage113.cons _ _ compact113_node_0437
    (ChildrenCoverage113.cons _ _ compact113_node_0438
    (ChildrenCoverage113.cons _ _ compact113_node_0439
    (ChildrenCoverage113.cons _ _ compact113_node_0440
    ChildrenCoverage113.nil)))))))

theorem compact113_node_0442 : NodeCoverage113 [60,15,9] 9 29 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0443 : NodeCoverage113 [60,15,8] 8 30 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0444 : NodeCoverage113 [60,15,7] 7 31 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0445 : NodeCoverage113 [60,15,6] 6 32 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

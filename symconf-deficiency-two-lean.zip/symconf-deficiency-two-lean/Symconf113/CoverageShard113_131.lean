import Symconf113.CoverageShard113_129
import Symconf113.CoverageShard113_130

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5162 : NodeCoverage113 [16,16,11,11,9] 9 50 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5163 : NodeCoverage113 [16,16,11,11,8] 8 51 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5164 : NodeCoverage113 [16,16,11,11,7] 7 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5165 : NodeCoverage113 [16,16,11,11,6] 6 53 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5166 : NodeCoverage113 [16,16,11,11,5] 5 54 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5167 : NodeCoverage113 [16,16,11,11,3] 3 56 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5168 : NodeCoverage113 [16,16,11,11] 11 59 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5160
    (ChildrenCoverage113.cons _ _ compact113_node_5161
    (ChildrenCoverage113.cons _ _ compact113_node_5162
    (ChildrenCoverage113.cons _ _ compact113_node_5163
    (ChildrenCoverage113.cons _ _ compact113_node_5164
    (ChildrenCoverage113.cons _ _ compact113_node_5165
    (ChildrenCoverage113.cons _ _ compact113_node_5166
    (ChildrenCoverage113.cons _ _ compact113_node_5167
    ChildrenCoverage113.nil))))))))

theorem compact113_node_5169 : NodeCoverage113 [16,16,11,10] 10 60 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5170 : NodeCoverage113 [16,16,11,9] 9 61 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5171 : NodeCoverage113 [16,16,11,8] 8 62 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5172 : NodeCoverage113 [16,16,11,7] 7 63 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5173 : NodeCoverage113 [16,16,11,6] 6 64 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5174 : NodeCoverage113 [16,16,11,5] 5 65 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5175 : NodeCoverage113 [16,16,11,3] 3 67 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5176 : NodeCoverage113 [16,16,11] 11 70 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5168
    (ChildrenCoverage113.cons _ _ compact113_node_5169
    (ChildrenCoverage113.cons _ _ compact113_node_5170
    (ChildrenCoverage113.cons _ _ compact113_node_5171
    (ChildrenCoverage113.cons _ _ compact113_node_5172
    (ChildrenCoverage113.cons _ _ compact113_node_5173
    (ChildrenCoverage113.cons _ _ compact113_node_5174
    (ChildrenCoverage113.cons _ _ compact113_node_5175
    ChildrenCoverage113.nil))))))))

theorem compact113_node_5177 : NodeCoverage113 [16,16,10,10,10] 10 51 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5178 : NodeCoverage113 [16,16,10,10,9] 9 52 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5179 : NodeCoverage113 [16,16,10,10,8] 8 53 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5180 : NodeCoverage113 [16,16,10,10,7] 7 54 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5181 : NodeCoverage113 [16,16,10,10,6] 6 55 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5182 : NodeCoverage113 [16,16,10,10,5] 5 56 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5183 : NodeCoverage113 [16,16,10,10,3] 3 58 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5184 : NodeCoverage113 [16,16,10,10] 10 61 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5177
    (ChildrenCoverage113.cons _ _ compact113_node_5178
    (ChildrenCoverage113.cons _ _ compact113_node_5179
    (ChildrenCoverage113.cons _ _ compact113_node_5180
    (ChildrenCoverage113.cons _ _ compact113_node_5181
    (ChildrenCoverage113.cons _ _ compact113_node_5182
    (ChildrenCoverage113.cons _ _ compact113_node_5183
    ChildrenCoverage113.nil)))))))

theorem compact113_node_5185 : NodeCoverage113 [16,16,10,9] 9 62 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5186 : NodeCoverage113 [16,16,10,8] 8 63 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5187 : NodeCoverage113 [16,16,10,7] 7 64 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5188 : NodeCoverage113 [16,16,10,6] 6 65 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5189 : NodeCoverage113 [16,16,10,5] 5 66 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5190 : NodeCoverage113 [16,16,10,3] 3 68 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5191 : NodeCoverage113 [16,16,10] 10 71 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5184
    (ChildrenCoverage113.cons _ _ compact113_node_5185
    (ChildrenCoverage113.cons _ _ compact113_node_5186
    (ChildrenCoverage113.cons _ _ compact113_node_5187
    (ChildrenCoverage113.cons _ _ compact113_node_5188
    (ChildrenCoverage113.cons _ _ compact113_node_5189
    (ChildrenCoverage113.cons _ _ compact113_node_5190
    ChildrenCoverage113.nil)))))))

theorem compact113_node_5192 : NodeCoverage113 [16,16,9,9,9] 9 54 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5193 : NodeCoverage113 [16,16,9,9,8] 8 55 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5194 : NodeCoverage113 [16,16,9,9,7] 7 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5195 : NodeCoverage113 [16,16,9,9,6] 6 57 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5196 : NodeCoverage113 [16,16,9,9,5] 5 58 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5197 : NodeCoverage113 [16,16,9,9,3] 3 60 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5198 : NodeCoverage113 [16,16,9,9] 9 63 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5192
    (ChildrenCoverage113.cons _ _ compact113_node_5193
    (ChildrenCoverage113.cons _ _ compact113_node_5194
    (ChildrenCoverage113.cons _ _ compact113_node_5195
    (ChildrenCoverage113.cons _ _ compact113_node_5196
    (ChildrenCoverage113.cons _ _ compact113_node_5197
    ChildrenCoverage113.nil))))))

theorem compact113_node_5199 : NodeCoverage113 [16,16,9,8] 8 64 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5200 : NodeCoverage113 [16,16,9,7] 7 65 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5201 : NodeCoverage113 [16,16,9,6] 6 66 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5202 : NodeCoverage113 [16,16,9,5] 5 67 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5203 : NodeCoverage113 [16,16,9,3] 3 69 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5204 : NodeCoverage113 [16,16,9] 9 72 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5198
    (ChildrenCoverage113.cons _ _ compact113_node_5199
    (ChildrenCoverage113.cons _ _ compact113_node_5200
    (ChildrenCoverage113.cons _ _ compact113_node_5201
    (ChildrenCoverage113.cons _ _ compact113_node_5202
    (ChildrenCoverage113.cons _ _ compact113_node_5203
    ChildrenCoverage113.nil))))))

theorem compact113_node_5205 : NodeCoverage113 [16,16,8] 8 73 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5206 : NodeCoverage113 [16,16,7] 7 74 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5207 : NodeCoverage113 [16,16,6] 6 75 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5208 : NodeCoverage113 [16,16,5] 5 76 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5209 : NodeCoverage113 [16,16,3] 3 78 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5210 : NodeCoverage113 [16,16] 16 81 :=
  node_fork113 (B := [16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5104
    (ChildrenCoverage113.cons _ _ compact113_node_5117
    (ChildrenCoverage113.cons _ _ compact113_node_5129
    (ChildrenCoverage113.cons _ _ compact113_node_5140
    (ChildrenCoverage113.cons _ _ compact113_node_5159
    (ChildrenCoverage113.cons _ _ compact113_node_5176
    (ChildrenCoverage113.cons _ _ compact113_node_5191
    (ChildrenCoverage113.cons _ _ compact113_node_5204
    (ChildrenCoverage113.cons _ _ compact113_node_5205
    (ChildrenCoverage113.cons _ _ compact113_node_5206
    (ChildrenCoverage113.cons _ _ compact113_node_5207
    (ChildrenCoverage113.cons _ _ compact113_node_5208
    (ChildrenCoverage113.cons _ _ compact113_node_5209
    ChildrenCoverage113.nil)))))))))))))

theorem compact113_node_5211 : NodeCoverage113 [16,15] 15 82 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5212 : NodeCoverage113 [16,14] 14 83 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5213 : NodeCoverage113 [16,13] 13 84 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5214 : NodeCoverage113 [16,12] 12 85 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5215 : NodeCoverage113 [16,11] 11 86 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5216 : NodeCoverage113 [16,10] 10 87 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5217 : NodeCoverage113 [16,9] 9 88 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5218 : NodeCoverage113 [16,8] 8 89 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5219 : NodeCoverage113 [16,7] 7 90 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5220 : NodeCoverage113 [16,6] 6 91 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5221 : NodeCoverage113 [16,5] 5 92 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5222 : NodeCoverage113 [16,3] 3 94 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5223 : NodeCoverage113 [16] 16 97 :=
  node_fork113 (B := [16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5210
    (ChildrenCoverage113.cons _ _ compact113_node_5211
    (ChildrenCoverage113.cons _ _ compact113_node_5212
    (ChildrenCoverage113.cons _ _ compact113_node_5213
    (ChildrenCoverage113.cons _ _ compact113_node_5214
    (ChildrenCoverage113.cons _ _ compact113_node_5215
    (ChildrenCoverage113.cons _ _ compact113_node_5216
    (ChildrenCoverage113.cons _ _ compact113_node_5217
    (ChildrenCoverage113.cons _ _ compact113_node_5218
    (ChildrenCoverage113.cons _ _ compact113_node_5219
    (ChildrenCoverage113.cons _ _ compact113_node_5220
    (ChildrenCoverage113.cons _ _ compact113_node_5221
    (ChildrenCoverage113.cons _ _ compact113_node_5222
    ChildrenCoverage113.nil)))))))))))))

theorem compact113_node_5224 : NodeCoverage113 [15,15,15,15,15,15,15,8] 8 0 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5225 : NodeCoverage113 [15,15,15,15,15,15,15,5,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_5226 : NodeCoverage113 [15,15,15,15,15,15,15,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5225
    ChildrenCoverage113.nil)

theorem compact113_node_5227 : NodeCoverage113 [15,15,15,15,15,15,15,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_5228 : NodeCoverage113 [15,15,15,15,15,15,15] 15 8 :=
  node_fork113 (B := [8,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5224
    (ChildrenCoverage113.cons _ _ compact113_node_5226
    (ChildrenCoverage113.cons _ _ compact113_node_5227
    ChildrenCoverage113.nil)))

theorem compact113_node_5229 : NodeCoverage113 [15,15,15,15,15,15,14] 14 9 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5230 : NodeCoverage113 [15,15,15,15,15,15,13] 13 10 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

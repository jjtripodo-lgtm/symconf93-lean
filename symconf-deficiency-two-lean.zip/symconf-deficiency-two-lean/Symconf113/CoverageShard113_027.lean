import Symconf113.CoverageShard113_025
import Symconf113.CoverageShard113_026

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1140 : NodeCoverage113 [42,14,12] 12 45 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1141 : NodeCoverage113 [42,14,11] 11 46 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1142 : NodeCoverage113 [42,14,10] 10 47 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1143 : NodeCoverage113 [42,14,9] 9 48 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1144 : NodeCoverage113 [42,14,8] 8 49 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1145 : NodeCoverage113 [42,14,7] 7 50 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1146 : NodeCoverage113 [42,14,6] 6 51 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1147 : NodeCoverage113 [42,14,5] 5 52 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1148 : NodeCoverage113 [42,14,3] 3 54 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1149 : NodeCoverage113 [42,14] 14 57 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1138
    (ChildrenCoverage113.cons _ _ compact113_node_1139
    (ChildrenCoverage113.cons _ _ compact113_node_1140
    (ChildrenCoverage113.cons _ _ compact113_node_1141
    (ChildrenCoverage113.cons _ _ compact113_node_1142
    (ChildrenCoverage113.cons _ _ compact113_node_1143
    (ChildrenCoverage113.cons _ _ compact113_node_1144
    (ChildrenCoverage113.cons _ _ compact113_node_1145
    (ChildrenCoverage113.cons _ _ compact113_node_1146
    (ChildrenCoverage113.cons _ _ compact113_node_1147
    (ChildrenCoverage113.cons _ _ compact113_node_1148
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_1150 : NodeCoverage113 [42,13] 13 58 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1151 : NodeCoverage113 [42,12] 12 59 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1152 : NodeCoverage113 [42,11] 11 60 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1153 : NodeCoverage113 [42,10] 10 61 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1154 : NodeCoverage113 [42,9] 9 62 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1155 : NodeCoverage113 [42,8] 8 63 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1156 : NodeCoverage113 [42,7] 7 64 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1157 : NodeCoverage113 [42,6] 6 65 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1158 : NodeCoverage113 [42,5] 5 66 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1159 : NodeCoverage113 [42,3] 3 68 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1160 : NodeCoverage113 [42] 42 71 :=
  node_fork113 (B := [42,41,40,39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1067
    (ChildrenCoverage113.cons _ _ compact113_node_1068
    (ChildrenCoverage113.cons _ _ compact113_node_1069
    (ChildrenCoverage113.cons _ _ compact113_node_1070
    (ChildrenCoverage113.cons _ _ compact113_node_1071
    (ChildrenCoverage113.cons _ _ compact113_node_1072
    (ChildrenCoverage113.cons _ _ compact113_node_1073
    (ChildrenCoverage113.cons _ _ compact113_node_1074
    (ChildrenCoverage113.cons _ _ compact113_node_1075
    (ChildrenCoverage113.cons _ _ compact113_node_1076
    (ChildrenCoverage113.cons _ _ compact113_node_1077
    (ChildrenCoverage113.cons _ _ compact113_node_1078
    (ChildrenCoverage113.cons _ _ compact113_node_1079
    (ChildrenCoverage113.cons _ _ compact113_node_1080
    (ChildrenCoverage113.cons _ _ compact113_node_1081
    (ChildrenCoverage113.cons _ _ compact113_node_1082
    (ChildrenCoverage113.cons _ _ compact113_node_1083
    (ChildrenCoverage113.cons _ _ compact113_node_1084
    (ChildrenCoverage113.cons _ _ compact113_node_1085
    (ChildrenCoverage113.cons _ _ compact113_node_1086
    (ChildrenCoverage113.cons _ _ compact113_node_1087
    (ChildrenCoverage113.cons _ _ compact113_node_1088
    (ChildrenCoverage113.cons _ _ compact113_node_1089
    (ChildrenCoverage113.cons _ _ compact113_node_1090
    (ChildrenCoverage113.cons _ _ compact113_node_1091
    (ChildrenCoverage113.cons _ _ compact113_node_1092
    (ChildrenCoverage113.cons _ _ compact113_node_1093
    (ChildrenCoverage113.cons _ _ compact113_node_1094
    (ChildrenCoverage113.cons _ _ compact113_node_1149
    (ChildrenCoverage113.cons _ _ compact113_node_1150
    (ChildrenCoverage113.cons _ _ compact113_node_1151
    (ChildrenCoverage113.cons _ _ compact113_node_1152
    (ChildrenCoverage113.cons _ _ compact113_node_1153
    (ChildrenCoverage113.cons _ _ compact113_node_1154
    (ChildrenCoverage113.cons _ _ compact113_node_1155
    (ChildrenCoverage113.cons _ _ compact113_node_1156
    (ChildrenCoverage113.cons _ _ compact113_node_1157
    (ChildrenCoverage113.cons _ _ compact113_node_1158
    (ChildrenCoverage113.cons _ _ compact113_node_1159
    ChildrenCoverage113.nil)))))))))))))))))))))))))))))))))))))))

theorem compact113_node_1161 : NodeCoverage113 [41] 41 72 :=
  demand_node_prune113 41 compact113_demands_041 compact113_demands_041_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1162 : NodeCoverage113 [40,40,33] 33 0 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1163 : NodeCoverage113 [40,40,30] 30 3 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1164 : NodeCoverage113 [40,40,29] 29 4 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1165 : NodeCoverage113 [40,40,28] 28 5 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1166 : NodeCoverage113 [40,40,27] 27 6 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1167 : NodeCoverage113 [40,40,26] 26 7 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1168 : NodeCoverage113 [40,40,25] 25 8 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

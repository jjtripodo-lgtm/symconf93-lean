import Symconf113.CoverageShard113_034

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1415 : NodeCoverage113 [37,37,15] 15 24 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1416 : NodeCoverage113 [37,37,14] 14 25 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1417 : NodeCoverage113 [37,37,13] 13 26 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1418 : NodeCoverage113 [37,37,12] 12 27 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1419 : NodeCoverage113 [37,37,11] 11 28 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1420 : NodeCoverage113 [37,37,10] 10 29 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1421 : NodeCoverage113 [37,37,9] 9 30 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1422 : NodeCoverage113 [37,37,8] 8 31 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1423 : NodeCoverage113 [37,37,7] 7 32 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1424 : NodeCoverage113 [37,37,6] 6 33 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1425 : NodeCoverage113 [37,37,5] 5 34 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1426 : NodeCoverage113 [37,37,3] 3 36 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1427 : NodeCoverage113 [37,37] 37 39 :=
  node_fork113 (B := [36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1394
    (ChildrenCoverage113.cons _ _ compact113_node_1395
    (ChildrenCoverage113.cons _ _ compact113_node_1396
    (ChildrenCoverage113.cons _ _ compact113_node_1397
    (ChildrenCoverage113.cons _ _ compact113_node_1398
    (ChildrenCoverage113.cons _ _ compact113_node_1399
    (ChildrenCoverage113.cons _ _ compact113_node_1400
    (ChildrenCoverage113.cons _ _ compact113_node_1401
    (ChildrenCoverage113.cons _ _ compact113_node_1402
    (ChildrenCoverage113.cons _ _ compact113_node_1403
    (ChildrenCoverage113.cons _ _ compact113_node_1404
    (ChildrenCoverage113.cons _ _ compact113_node_1405
    (ChildrenCoverage113.cons _ _ compact113_node_1406
    (ChildrenCoverage113.cons _ _ compact113_node_1407
    (ChildrenCoverage113.cons _ _ compact113_node_1408
    (ChildrenCoverage113.cons _ _ compact113_node_1409
    (ChildrenCoverage113.cons _ _ compact113_node_1410
    (ChildrenCoverage113.cons _ _ compact113_node_1411
    (ChildrenCoverage113.cons _ _ compact113_node_1412
    (ChildrenCoverage113.cons _ _ compact113_node_1413
    (ChildrenCoverage113.cons _ _ compact113_node_1414
    (ChildrenCoverage113.cons _ _ compact113_node_1415
    (ChildrenCoverage113.cons _ _ compact113_node_1416
    (ChildrenCoverage113.cons _ _ compact113_node_1417
    (ChildrenCoverage113.cons _ _ compact113_node_1418
    (ChildrenCoverage113.cons _ _ compact113_node_1419
    (ChildrenCoverage113.cons _ _ compact113_node_1420
    (ChildrenCoverage113.cons _ _ compact113_node_1421
    (ChildrenCoverage113.cons _ _ compact113_node_1422
    (ChildrenCoverage113.cons _ _ compact113_node_1423
    (ChildrenCoverage113.cons _ _ compact113_node_1424
    (ChildrenCoverage113.cons _ _ compact113_node_1425
    (ChildrenCoverage113.cons _ _ compact113_node_1426
    ChildrenCoverage113.nil)))))))))))))))))))))))))))))))))

theorem compact113_node_1428 : NodeCoverage113 [37,36] 36 40 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1429 : NodeCoverage113 [37,35] 35 41 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1430 : NodeCoverage113 [37,34] 34 42 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1431 : NodeCoverage113 [37,33] 33 43 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1432 : NodeCoverage113 [37,32] 32 44 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1433 : NodeCoverage113 [37,31] 31 45 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1434 : NodeCoverage113 [37,30] 30 46 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1435 : NodeCoverage113 [37,29] 29 47 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1436 : NodeCoverage113 [37,28] 28 48 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1437 : NodeCoverage113 [37,27] 27 49 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1438 : NodeCoverage113 [37,26] 26 50 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1439 : NodeCoverage113 [37,25] 25 51 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1440 : NodeCoverage113 [37,24] 24 52 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1441 : NodeCoverage113 [37,23] 23 53 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1442 : NodeCoverage113 [37,22] 22 54 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1443 : NodeCoverage113 [37,21] 21 55 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1444 : NodeCoverage113 [37,20] 20 56 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1445 : NodeCoverage113 [37,19] 19 57 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3208 : NodeCoverage113 [24,16,16] 16 57 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3209 : NodeCoverage113 [24,16,15] 15 58 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3210 : NodeCoverage113 [24,16,14] 14 59 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3211 : NodeCoverage113 [24,16,13] 13 60 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3212 : NodeCoverage113 [24,16,12] 12 61 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3213 : NodeCoverage113 [24,16,11] 11 62 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3214 : NodeCoverage113 [24,16,10] 10 63 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3215 : NodeCoverage113 [24,16,9] 9 64 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3216 : NodeCoverage113 [24,16,8] 8 65 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3217 : NodeCoverage113 [24,16,7] 7 66 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3218 : NodeCoverage113 [24,16,6] 6 67 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3219 : NodeCoverage113 [24,16,5] 5 68 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3220 : NodeCoverage113 [24,16,3] 3 70 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3221 : NodeCoverage113 [24,16] 16 73 :=
  node_fork113 (B := [16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3208
    (ChildrenCoverage113.cons _ _ compact113_node_3209
    (ChildrenCoverage113.cons _ _ compact113_node_3210
    (ChildrenCoverage113.cons _ _ compact113_node_3211
    (ChildrenCoverage113.cons _ _ compact113_node_3212
    (ChildrenCoverage113.cons _ _ compact113_node_3213
    (ChildrenCoverage113.cons _ _ compact113_node_3214
    (ChildrenCoverage113.cons _ _ compact113_node_3215
    (ChildrenCoverage113.cons _ _ compact113_node_3216
    (ChildrenCoverage113.cons _ _ compact113_node_3217
    (ChildrenCoverage113.cons _ _ compact113_node_3218
    (ChildrenCoverage113.cons _ _ compact113_node_3219
    (ChildrenCoverage113.cons _ _ compact113_node_3220
    ChildrenCoverage113.nil)))))))))))))

theorem compact113_node_3222 : NodeCoverage113 [24,15,15] 15 59 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3223 : NodeCoverage113 [24,15,14] 14 60 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3224 : NodeCoverage113 [24,15,13] 13 61 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3225 : NodeCoverage113 [24,15,12] 12 62 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3226 : NodeCoverage113 [24,15,11] 11 63 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3227 : NodeCoverage113 [24,15,10] 10 64 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3228 : NodeCoverage113 [24,15,9] 9 65 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3229 : NodeCoverage113 [24,15,8] 8 66 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3230 : NodeCoverage113 [24,15,7] 7 67 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3231 : NodeCoverage113 [24,15,6] 6 68 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3232 : NodeCoverage113 [24,15,5] 5 69 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3233 : NodeCoverage113 [24,15,3] 3 71 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3234 : NodeCoverage113 [24,15] 15 74 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3222
    (ChildrenCoverage113.cons _ _ compact113_node_3223
    (ChildrenCoverage113.cons _ _ compact113_node_3224
    (ChildrenCoverage113.cons _ _ compact113_node_3225
    (ChildrenCoverage113.cons _ _ compact113_node_3226
    (ChildrenCoverage113.cons _ _ compact113_node_3227
    (ChildrenCoverage113.cons _ _ compact113_node_3228
    (ChildrenCoverage113.cons _ _ compact113_node_3229
    (ChildrenCoverage113.cons _ _ compact113_node_3230
    (ChildrenCoverage113.cons _ _ compact113_node_3231
    (ChildrenCoverage113.cons _ _ compact113_node_3232
    (ChildrenCoverage113.cons _ _ compact113_node_3233
    ChildrenCoverage113.nil))))))))))))

end Symconf113

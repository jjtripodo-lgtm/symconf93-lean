import Symconf113.CoverageShard113_097

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3421 : NodeCoverage113 [23,23,23,23,12] 12 9 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3422 : NodeCoverage113 [23,23,23,23,11] 11 10 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3423 : NodeCoverage113 [23,23,23,23,10] 10 11 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3424 : NodeCoverage113 [23,23,23,23,9] 9 12 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3425 : NodeCoverage113 [23,23,23,23,8] 8 13 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3426 : NodeCoverage113 [23,23,23,23,7] 7 14 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3427 : NodeCoverage113 [23,23,23,23,6] 6 15 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3428 : NodeCoverage113 [23,23,23,23,5] 5 16 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3429 : NodeCoverage113 [23,23,23,23,3] 3 18 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3430 : NodeCoverage113 [23,23,23,23] 23 21 :=
  node_fork113 (B := [21,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3414
    (ChildrenCoverage113.cons _ _ compact113_node_3415
    (ChildrenCoverage113.cons _ _ compact113_node_3416
    (ChildrenCoverage113.cons _ _ compact113_node_3417
    (ChildrenCoverage113.cons _ _ compact113_node_3418
    (ChildrenCoverage113.cons _ _ compact113_node_3419
    (ChildrenCoverage113.cons _ _ compact113_node_3420
    (ChildrenCoverage113.cons _ _ compact113_node_3421
    (ChildrenCoverage113.cons _ _ compact113_node_3422
    (ChildrenCoverage113.cons _ _ compact113_node_3423
    (ChildrenCoverage113.cons _ _ compact113_node_3424
    (ChildrenCoverage113.cons _ _ compact113_node_3425
    (ChildrenCoverage113.cons _ _ compact113_node_3426
    (ChildrenCoverage113.cons _ _ compact113_node_3427
    (ChildrenCoverage113.cons _ _ compact113_node_3428
    (ChildrenCoverage113.cons _ _ compact113_node_3429
    ChildrenCoverage113.nil))))))))))))))))

theorem compact113_node_3431 : NodeCoverage113 [23,23,23,22] 22 22 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3432 : NodeCoverage113 [23,23,23,21] 21 23 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3433 : NodeCoverage113 [23,23,23,20] 20 24 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3434 : NodeCoverage113 [23,23,23,19] 19 25 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3435 : NodeCoverage113 [23,23,23,18] 18 26 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3436 : NodeCoverage113 [23,23,23,17] 17 27 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3437 : NodeCoverage113 [23,23,23,16] 16 28 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3438 : NodeCoverage113 [23,23,23,15] 15 29 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3439 : NodeCoverage113 [23,23,23,14] 14 30 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3440 : NodeCoverage113 [23,23,23,13] 13 31 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3441 : NodeCoverage113 [23,23,23,12] 12 32 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3442 : NodeCoverage113 [23,23,23,11] 11 33 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3443 : NodeCoverage113 [23,23,23,10] 10 34 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3444 : NodeCoverage113 [23,23,23,9] 9 35 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3445 : NodeCoverage113 [23,23,23,8] 8 36 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3446 : NodeCoverage113 [23,23,23,7] 7 37 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3447 : NodeCoverage113 [23,23,23,6] 6 38 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3448 : NodeCoverage113 [23,23,23,5] 5 39 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3449 : NodeCoverage113 [23,23,23,3] 3 41 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3450 : NodeCoverage113 [23,23,23] 23 44 :=
  node_fork113 (B := [23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3430
    (ChildrenCoverage113.cons _ _ compact113_node_3431
    (ChildrenCoverage113.cons _ _ compact113_node_3432
    (ChildrenCoverage113.cons _ _ compact113_node_3433
    (ChildrenCoverage113.cons _ _ compact113_node_3434
    (ChildrenCoverage113.cons _ _ compact113_node_3435
    (ChildrenCoverage113.cons _ _ compact113_node_3436
    (ChildrenCoverage113.cons _ _ compact113_node_3437
    (ChildrenCoverage113.cons _ _ compact113_node_3438
    (ChildrenCoverage113.cons _ _ compact113_node_3439
    (ChildrenCoverage113.cons _ _ compact113_node_3440
    (ChildrenCoverage113.cons _ _ compact113_node_3441
    (ChildrenCoverage113.cons _ _ compact113_node_3442
    (ChildrenCoverage113.cons _ _ compact113_node_3443
    (ChildrenCoverage113.cons _ _ compact113_node_3444
    (ChildrenCoverage113.cons _ _ compact113_node_3445
    (ChildrenCoverage113.cons _ _ compact113_node_3446
    (ChildrenCoverage113.cons _ _ compact113_node_3447
    (ChildrenCoverage113.cons _ _ compact113_node_3448
    (ChildrenCoverage113.cons _ _ compact113_node_3449
    ChildrenCoverage113.nil))))))))))))))))))))

theorem compact113_node_3451 : NodeCoverage113 [23,23,22] 22 45 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3452 : NodeCoverage113 [23,23,21] 21 46 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3453 : NodeCoverage113 [23,23,20] 20 47 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3454 : NodeCoverage113 [23,23,19] 19 48 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3455 : NodeCoverage113 [23,23,18] 18 49 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3456 : NodeCoverage113 [23,23,17] 17 50 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3457 : NodeCoverage113 [23,23,16] 16 51 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3458 : NodeCoverage113 [23,23,15] 15 52 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3459 : NodeCoverage113 [23,23,14] 14 53 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3460 : NodeCoverage113 [23,23,13] 13 54 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3461 : NodeCoverage113 [23,23,12] 12 55 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3462 : NodeCoverage113 [23,23,11] 11 56 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3463 : NodeCoverage113 [23,23,10] 10 57 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

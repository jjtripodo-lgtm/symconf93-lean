import Symconf113.CoverageShard113_061

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2395 : NodeCoverage113 [30,30,10,5] 5 38 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2396 : NodeCoverage113 [30,30,10,3] 3 40 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2397 : NodeCoverage113 [30,30,10] 10 43 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2390
    (ChildrenCoverage113.cons _ _ compact113_node_2391
    (ChildrenCoverage113.cons _ _ compact113_node_2392
    (ChildrenCoverage113.cons _ _ compact113_node_2393
    (ChildrenCoverage113.cons _ _ compact113_node_2394
    (ChildrenCoverage113.cons _ _ compact113_node_2395
    (ChildrenCoverage113.cons _ _ compact113_node_2396
    ChildrenCoverage113.nil)))))))

theorem compact113_node_2398 : NodeCoverage113 [30,30,9] 9 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2399 : NodeCoverage113 [30,30,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2400 : NodeCoverage113 [30,30,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2401 : NodeCoverage113 [30,30,6] 6 47 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2402 : NodeCoverage113 [30,30,5] 5 48 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

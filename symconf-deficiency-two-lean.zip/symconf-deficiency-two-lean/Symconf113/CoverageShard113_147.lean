import Symconf113.CoverageShard113_146

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_6151 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6152 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,6,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6153 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,6,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6152
    ChildrenCoverage113.nil)

theorem compact113_node_6154 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,6,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6153
    ChildrenCoverage113.nil)

theorem compact113_node_6155 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,6,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6154
    ChildrenCoverage113.nil)

theorem compact113_node_6156 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6150
    (ChildrenCoverage113.cons _ _ compact113_node_6151
    (ChildrenCoverage113.cons _ _ compact113_node_6155
    ChildrenCoverage113.nil)))

theorem compact113_node_6157 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6158 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6159 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6158
    ChildrenCoverage113.nil)

theorem compact113_node_6160 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6159
    ChildrenCoverage113.nil)

theorem compact113_node_6161 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6160
    ChildrenCoverage113.nil)

theorem compact113_node_6162 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6161
    ChildrenCoverage113.nil)

theorem compact113_node_6163 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6162
    ChildrenCoverage113.nil)

theorem compact113_node_6164 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,6] 6 23 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6156
    (ChildrenCoverage113.cons _ _ compact113_node_6157
    (ChildrenCoverage113.cons _ _ compact113_node_6163
    ChildrenCoverage113.nil)))

theorem compact113_node_6165 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6166 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6167 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6166
    ChildrenCoverage113.nil)

theorem compact113_node_6168 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6167
    ChildrenCoverage113.nil)

theorem compact113_node_6169 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6168
    ChildrenCoverage113.nil)

theorem compact113_node_6170 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6169
    ChildrenCoverage113.nil)

theorem compact113_node_6171 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6170
    ChildrenCoverage113.nil)

theorem compact113_node_6172 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6171
    ChildrenCoverage113.nil)

theorem compact113_node_6173 : NodeCoverage113 [12,12,12,12,12,6,6,6,6,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6172
    ChildrenCoverage113.nil)

theorem compact113_node_6174 : NodeCoverage113 [12,12,12,12,12,6,6,6,6] 6 29 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6164
    (ChildrenCoverage113.cons _ _ compact113_node_6165
    (ChildrenCoverage113.cons _ _ compact113_node_6173
    ChildrenCoverage113.nil)))

theorem compact113_node_6175 : NodeCoverage113 [12,12,12,12,12,6,6,6,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6176 : NodeCoverage113 [12,12,12,12,12,6,6,6,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6177 : NodeCoverage113 [12,12,12,12,12,6,6,6,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6176
    ChildrenCoverage113.nil)

theorem compact113_node_6178 : NodeCoverage113 [12,12,12,12,12,6,6,6,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6177
    ChildrenCoverage113.nil)

theorem compact113_node_6179 : NodeCoverage113 [12,12,12,12,12,6,6,6,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6178
    ChildrenCoverage113.nil)

theorem compact113_node_6180 : NodeCoverage113 [12,12,12,12,12,6,6,6,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6179
    ChildrenCoverage113.nil)

theorem compact113_node_6181 : NodeCoverage113 [12,12,12,12,12,6,6,6,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6180
    ChildrenCoverage113.nil)

theorem compact113_node_6182 : NodeCoverage113 [12,12,12,12,12,6,6,6,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6181
    ChildrenCoverage113.nil)

theorem compact113_node_6183 : NodeCoverage113 [12,12,12,12,12,6,6,6,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6182
    ChildrenCoverage113.nil)

theorem compact113_node_6184 : NodeCoverage113 [12,12,12,12,12,6,6,6,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6183
    ChildrenCoverage113.nil)

theorem compact113_node_6185 : NodeCoverage113 [12,12,12,12,12,6,6,6,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6184
    ChildrenCoverage113.nil)

theorem compact113_node_6186 : NodeCoverage113 [12,12,12,12,12,6,6,6] 6 35 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6174
    (ChildrenCoverage113.cons _ _ compact113_node_6175
    (ChildrenCoverage113.cons _ _ compact113_node_6185
    ChildrenCoverage113.nil)))

theorem compact113_node_6187 : NodeCoverage113 [12,12,12,12,12,6,6,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6188 : NodeCoverage113 [12,12,12,12,12,6,6,3] 3 38 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6189 : NodeCoverage113 [12,12,12,12,12,6,6] 6 41 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6186
    (ChildrenCoverage113.cons _ _ compact113_node_6187
    (ChildrenCoverage113.cons _ _ compact113_node_6188
    ChildrenCoverage113.nil)))

theorem compact113_node_6190 : NodeCoverage113 [12,12,12,12,12,6,5] 5 42 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6191 : NodeCoverage113 [12,12,12,12,12,6,3] 3 44 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6192 : NodeCoverage113 [12,12,12,12,12,6] 6 47 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6189
    (ChildrenCoverage113.cons _ _ compact113_node_6190
    (ChildrenCoverage113.cons _ _ compact113_node_6191
    ChildrenCoverage113.nil)))

theorem compact113_node_6193 : NodeCoverage113 [12,12,12,12,12,5] 5 48 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6194 : NodeCoverage113 [12,12,12,12,12,3] 3 50 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6195 : NodeCoverage113 [12,12,12,12,12] 12 53 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6139
    (ChildrenCoverage113.cons _ _ compact113_node_6140
    (ChildrenCoverage113.cons _ _ compact113_node_6141
    (ChildrenCoverage113.cons _ _ compact113_node_6142
    (ChildrenCoverage113.cons _ _ compact113_node_6143
    (ChildrenCoverage113.cons _ _ compact113_node_6144
    (ChildrenCoverage113.cons _ _ compact113_node_6192
    (ChildrenCoverage113.cons _ _ compact113_node_6193
    (ChildrenCoverage113.cons _ _ compact113_node_6194
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_6196 : NodeCoverage113 [12,12,12,12,11] 11 54 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6197 : NodeCoverage113 [12,12,12,12,10] 10 55 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6198 : NodeCoverage113 [12,12,12,12,9] 9 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6199 : NodeCoverage113 [12,12,12,12,8] 8 57 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6200 : NodeCoverage113 [12,12,12,12,7,7,7,7,7,7] 7 23 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6201 : NodeCoverage113 [12,12,12,12,7,7,7,7,7,6] 6 24 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6202 : NodeCoverage113 [12,12,12,12,7,7,7,7,7,5] 5 25 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6203 : NodeCoverage113 [12,12,12,12,7,7,7,7,7,3] 3 27 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6204 : NodeCoverage113 [12,12,12,12,7,7,7,7,7] 7 30 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6200
    (ChildrenCoverage113.cons _ _ compact113_node_6201
    (ChildrenCoverage113.cons _ _ compact113_node_6202
    (ChildrenCoverage113.cons _ _ compact113_node_6203
    ChildrenCoverage113.nil))))

theorem compact113_node_6205 : NodeCoverage113 [12,12,12,12,7,7,7,7,6] 6 31 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6206 : NodeCoverage113 [12,12,12,12,7,7,7,7,5] 5 32 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6207 : NodeCoverage113 [12,12,12,12,7,7,7,7,3] 3 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6208 : NodeCoverage113 [12,12,12,12,7,7,7,7] 7 37 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6204
    (ChildrenCoverage113.cons _ _ compact113_node_6205
    (ChildrenCoverage113.cons _ _ compact113_node_6206
    (ChildrenCoverage113.cons _ _ compact113_node_6207
    ChildrenCoverage113.nil))))

theorem compact113_node_6209 : NodeCoverage113 [12,12,12,12,7,7,7,6] 6 38 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6210 : NodeCoverage113 [12,12,12,12,7,7,7,5] 5 39 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6211 : NodeCoverage113 [12,12,12,12,7,7,7,3] 3 41 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6212 : NodeCoverage113 [12,12,12,12,7,7,7] 7 44 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6208
    (ChildrenCoverage113.cons _ _ compact113_node_6209
    (ChildrenCoverage113.cons _ _ compact113_node_6210
    (ChildrenCoverage113.cons _ _ compact113_node_6211
    ChildrenCoverage113.nil))))

theorem compact113_node_6213 : NodeCoverage113 [12,12,12,12,7,7,6] 6 45 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6214 : NodeCoverage113 [12,12,12,12,7,7,5] 5 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6215 : NodeCoverage113 [12,12,12,12,7,7,3] 3 48 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6216 : NodeCoverage113 [12,12,12,12,7,7] 7 51 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6212
    (ChildrenCoverage113.cons _ _ compact113_node_6213
    (ChildrenCoverage113.cons _ _ compact113_node_6214
    (ChildrenCoverage113.cons _ _ compact113_node_6215
    ChildrenCoverage113.nil))))

theorem compact113_node_6217 : NodeCoverage113 [12,12,12,12,7,6] 6 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6218 : NodeCoverage113 [12,12,12,12,7,5] 5 53 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6219 : NodeCoverage113 [12,12,12,12,7,3] 3 55 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6220 : NodeCoverage113 [12,12,12,12,7] 7 58 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6216
    (ChildrenCoverage113.cons _ _ compact113_node_6217
    (ChildrenCoverage113.cons _ _ compact113_node_6218
    (ChildrenCoverage113.cons _ _ compact113_node_6219
    ChildrenCoverage113.nil))))

theorem compact113_node_6221 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6222 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6221
    ChildrenCoverage113.nil)

theorem compact113_node_6223 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6224 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6225 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6224
    ChildrenCoverage113.nil)

end Symconf113

import Symconf113.LeafDemand113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

def compact113_demands_100 : List (List Nat) := [

]
theorem compact113_demands_100_exact : rowDemand113 100=compact113_demands_100 := by decide +kernel

def compact113_demands_101 : List (List Nat) := [

]
theorem compact113_demands_101_exact : rowDemand113 101=compact113_demands_101 := by decide +kernel

def compact113_demands_102 : List (List Nat) := [

]
theorem compact113_demands_102_exact : rowDemand113 102=compact113_demands_102 := by decide +kernel

def compact113_demands_103 : List (List Nat) := [

]
theorem compact113_demands_103_exact : rowDemand113 103=compact113_demands_103 := by decide +kernel

def compact113_demands_104 : List (List Nat) := [

]
theorem compact113_demands_104_exact : rowDemand113 104=compact113_demands_104 := by decide +kernel

def compact113_demands_105 : List (List Nat) := [

]
theorem compact113_demands_105_exact : rowDemand113 105=compact113_demands_105 := by decide +kernel

def compact113_demands_106 : List (List Nat) := [

]
theorem compact113_demands_106_exact : rowDemand113 106=compact113_demands_106 := by decide +kernel

def compact113_demands_107 : List (List Nat) := [

]
theorem compact113_demands_107_exact : rowDemand113 107=compact113_demands_107 := by decide +kernel

end Symconf113

import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1091 : NodeCoverage113 [42,18] 18 53 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1092 : NodeCoverage113 [42,17] 17 54 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1093 : NodeCoverage113 [42,16] 16 55 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1094 : NodeCoverage113 [42,15] 15 56 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1095 : NodeCoverage113 [42,14,14,14,14,12] 12 3 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1096 : NodeCoverage113 [42,14,14,14,14,11] 11 4 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1097 : NodeCoverage113 [42,14,14,14,14,10] 10 5 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1098 : NodeCoverage113 [42,14,14,14,14,9] 9 6 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1099 : NodeCoverage113 [42,14,14,14,14,8] 8 7 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1100 : NodeCoverage113 [42,14,14,14,14,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1101 : NodeCoverage113 [42,14,14,14,14,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1102 : NodeCoverage113 [42,14,14,14,14,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1100
    (ChildrenCoverage113.cons _ _ compact113_node_1101
    ChildrenCoverage113.nil))

theorem compact113_node_1103 : NodeCoverage113 [42,14,14,14,14,6] 6 9 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1104 : NodeCoverage113 [42,14,14,14,14,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1105 : NodeCoverage113 [42,14,14,14,14,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1106 : NodeCoverage113 [42,14,14,14,14] 14 15 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1095
    (ChildrenCoverage113.cons _ _ compact113_node_1096
    (ChildrenCoverage113.cons _ _ compact113_node_1097
    (ChildrenCoverage113.cons _ _ compact113_node_1098
    (ChildrenCoverage113.cons _ _ compact113_node_1099
    (ChildrenCoverage113.cons _ _ compact113_node_1102
    (ChildrenCoverage113.cons _ _ compact113_node_1103
    (ChildrenCoverage113.cons _ _ compact113_node_1104
    (ChildrenCoverage113.cons _ _ compact113_node_1105
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_1107 : NodeCoverage113 [42,14,14,14,13] 13 16 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1108 : NodeCoverage113 [42,14,14,14,12] 12 17 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1109 : NodeCoverage113 [42,14,14,14,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1110 : NodeCoverage113 [42,14,14,14,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1111 : NodeCoverage113 [42,14,14,14,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1112 : NodeCoverage113 [42,14,14,14,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1113 : NodeCoverage113 [42,14,14,14,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1114 : NodeCoverage113 [42,14,14,14,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1115 : NodeCoverage113 [42,14,14,14,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1113
    (ChildrenCoverage113.cons _ _ compact113_node_1114
    ChildrenCoverage113.nil))

theorem compact113_node_1116 : NodeCoverage113 [42,14,14,14,7,7,6] 6 9 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1117 : NodeCoverage113 [42,14,14,14,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1118 : NodeCoverage113 [42,14,14,14,7,7,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1119 : NodeCoverage113 [42,14,14,14,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1115
    (ChildrenCoverage113.cons _ _ compact113_node_1116
    (ChildrenCoverage113.cons _ _ compact113_node_1117
    (ChildrenCoverage113.cons _ _ compact113_node_1118
    ChildrenCoverage113.nil))))

theorem compact113_node_1120 : NodeCoverage113 [42,14,14,14,7,6] 6 16 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1121 : NodeCoverage113 [42,14,14,14,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1122 : NodeCoverage113 [42,14,14,14,7,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1123 : NodeCoverage113 [42,14,14,14,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1119
    (ChildrenCoverage113.cons _ _ compact113_node_1120
    (ChildrenCoverage113.cons _ _ compact113_node_1121
    (ChildrenCoverage113.cons _ _ compact113_node_1122
    ChildrenCoverage113.nil))))

theorem compact113_node_1124 : NodeCoverage113 [42,14,14,14,6] 6 23 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1125 : NodeCoverage113 [42,14,14,14,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1126 : NodeCoverage113 [42,14,14,14,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1127 : NodeCoverage113 [42,14,14,14] 14 29 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1106
    (ChildrenCoverage113.cons _ _ compact113_node_1107
    (ChildrenCoverage113.cons _ _ compact113_node_1108
    (ChildrenCoverage113.cons _ _ compact113_node_1109
    (ChildrenCoverage113.cons _ _ compact113_node_1110
    (ChildrenCoverage113.cons _ _ compact113_node_1111
    (ChildrenCoverage113.cons _ _ compact113_node_1112
    (ChildrenCoverage113.cons _ _ compact113_node_1123
    (ChildrenCoverage113.cons _ _ compact113_node_1124
    (ChildrenCoverage113.cons _ _ compact113_node_1125
    (ChildrenCoverage113.cons _ _ compact113_node_1126
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_1128 : NodeCoverage113 [42,14,14,13] 13 30 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1129 : NodeCoverage113 [42,14,14,12] 12 31 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1130 : NodeCoverage113 [42,14,14,11] 11 32 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1131 : NodeCoverage113 [42,14,14,10] 10 33 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1132 : NodeCoverage113 [42,14,14,9] 9 34 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1133 : NodeCoverage113 [42,14,14,8] 8 35 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1134 : NodeCoverage113 [42,14,14,7] 7 36 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1135 : NodeCoverage113 [42,14,14,6] 6 37 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1136 : NodeCoverage113 [42,14,14,5] 5 38 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1137 : NodeCoverage113 [42,14,14,3] 3 40 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1138 : NodeCoverage113 [42,14,14] 14 43 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1127
    (ChildrenCoverage113.cons _ _ compact113_node_1128
    (ChildrenCoverage113.cons _ _ compact113_node_1129
    (ChildrenCoverage113.cons _ _ compact113_node_1130
    (ChildrenCoverage113.cons _ _ compact113_node_1131
    (ChildrenCoverage113.cons _ _ compact113_node_1132
    (ChildrenCoverage113.cons _ _ compact113_node_1133
    (ChildrenCoverage113.cons _ _ compact113_node_1134
    (ChildrenCoverage113.cons _ _ compact113_node_1135
    (ChildrenCoverage113.cons _ _ compact113_node_1136
    (ChildrenCoverage113.cons _ _ compact113_node_1137
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_1139 : NodeCoverage113 [42,14,13] 13 44 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

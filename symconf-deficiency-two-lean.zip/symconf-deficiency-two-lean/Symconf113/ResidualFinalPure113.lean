import Symconf113.ResidualCensusSound113
import Symconf113.ResidualShort113
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.IntervalCases

/-! Finite facts on `ZMod 15` for the last step of the residual case. If a
residue class mod 3 and some pairs `{p, p+s}` with `s = ±d`,
`d ∈ {2,4,5,7}`, partition `ZMod 15`, then the signed distances `cD d`
sum to `10 mod 15`. Weight each point by `φ`, which is `+w` on the class
`r+1`, `-w` on the class `r+2`, and `0` on the class `r`. -/
namespace Symconf113
open scoped BigOperators

def phiR (r : ℕ) (w : ZMod 15) : ℤ :=
  if w.val%3=(r+1)%3 then (w.val : ℤ) else if w.val%3=(r+2)%3 then -(w.val : ℤ) else 0

theorem phi_sum : ∀ r<3, (∑ w, phiR r w)%15=10 := by decide

theorem phi_class (r : ℕ) (_hr : r<3) (w : ZMod 15) (h : w.val%3=r) : phiR r w=0 := by
  unfold phiR
  have h1 : w.val%3≠(r+1)%3 := by omega
  have h2 : w.val%3≠(r+2)%3 := by omega
  simp [h1, h2]

theorem phi_pair : ∀ r<3, ∀ p : ZMod 15, ∀ d : ℕ, d ∈ [2,4,5,7] → ∀ b : Bool,
    p.val%3≠r → (p+(if b then (d : ZMod 15) else -(d : ZMod 15))).val%3≠r →
      (phiR r p+phiR r (p+(if b then (d : ZMod 15) else -(d : ZMod 15))))%15=(cD d : ℤ)%15 := by
  decide

theorem phi_pair' (r : ℕ) (hr : r<3) (p s : ZMod 15) (d : ℕ) (hd : d ∈ [2,4,5,7])
    (hs : s=d ∨ s=-(d : ZMod 15)) (h1 : p.val%3≠r) (h2 : (p+s).val%3≠r) :
    (phiR r p+phiR r (p+s))%15=(cD d : ℤ)%15 := by
  rcases hs with rfl|rfl
  · exact phi_pair r hr p d hd true h1 h2
  · exact phi_pair r hr p d hd false h1 h2

/-- The partition argument. -/
theorem partition_mod (r : ℕ) (hr : r<3) (sh : Fin 7 → Prop) [DecidablePred sh]
    (p s : Fin 7 → ZMod 15) (d : Fin 7 → ℕ) (hd : ∀ j, sh j → d j ∈ [2,4,5,7])
    (hs : ∀ j, sh j → s j=d j ∨ s j=-(d j : ZMod 15))
    (h : ∀ w : ZMod 15, (if w.val%3=r then (1:ℤ) else 0)+
      ∑ j, (if sh j then ((if w=p j then (1:ℤ) else 0)+(if w=p j+s j then 1 else 0)) else 0)=1) :
    (∑ j, if sh j then (cD (d j) : ℤ) else 0)%15=10 := by
  set T : ZMod 15 → Fin 7 → ℤ := fun w j =>
    if sh j then ((if w=p j then (1:ℤ) else 0)+(if w=p j+s j then 1 else 0)) else 0 with hT
  have hnn : ∀ w j, 0≤T w j := by
    intro w j; simp only [hT]; split_ifs <;> norm_num
  have hone : ∀ j, sh j → ∀ w, (w=p j ∨ w=p j+s j) → 1≤T w j := by
    intro j hj w hw; simp only [hT, if_pos hj]
    rcases hw with rfl|rfl
    · rw [if_pos rfl]; split_ifs <;> norm_num
    · rw [if_pos rfl]; split_ifs <;> norm_num
  have hcls : ∀ j, sh j → ∀ w, (w=p j ∨ w=p j+s j) → w.val%3≠r := by
    intro j hj w hw hc
    have h0 := h w
    rw [if_pos hc] at h0
    have := Finset.single_le_sum (fun k _ => hnn w k) (Finset.mem_univ j)
    have := hone j hj w hw
    change 1+∑ k, T w k=1 at h0
    linarith
  have key : (∑ w, phiR r w)=∑ j, if sh j then phiR r (p j)+phiR r (p j+s j) else 0 := by
    have e1 : (∑ w, phiR r w)=∑ w, phiR r w*((if w.val%3=r then (1:ℤ) else 0)+∑ j, T w j) := by
      apply Finset.sum_congr rfl; intro w _; rw [h w, mul_one]
    rw [e1]
    simp only [mul_add, Finset.mul_sum, Finset.sum_add_distrib]
    have e2 : (∑ w, phiR r w*(if w.val%3=r then (1:ℤ) else 0))=0 := by
      apply Finset.sum_eq_zero; intro w _
      split_ifs with hw
      · rw [phi_class r hr w hw, zero_mul]
      · rw [mul_zero]
    rw [e2, zero_add, Finset.sum_comm]
    apply Finset.sum_congr rfl; intro j _
    simp only [hT]
    split_ifs with hj
    · simp only [mul_add, mul_ite, mul_one, mul_zero, Finset.sum_add_distrib, Finset.sum_ite_eq',
        Finset.mem_univ, if_true]
    · simp
  have hterm : ∀ j, (if sh j then phiR r (p j)+phiR r (p j+s j) else 0)%15=
      (if sh j then (cD (d j) : ℤ) else 0)%15 := by
    intro j
    split_ifs with hj
    · exact phi_pair' r hr (p j) (s j) (d j) (hd j hj) (hs j hj) (hcls j hj _ (Or.inl rfl))
        (hcls j hj _ (Or.inr rfl))
    · rfl
  rw [Finset.sum_int_mod, ← Finset.sum_congr rfl (fun j _ => hterm j), ← Finset.sum_int_mod, ← key]
  exact phi_sum r hr

/-! Supports of small 0/1 functions on `ZMod 15`. -/

theorem bnn {a : ℤ} (h : a=0 ∨ a=1) : 0≤a := by rcases h with rfl|rfl <;> norm_num

theorem zero_supp {α : Type*} [Fintype α] (e : α → ℤ) (hb : ∀ u, e u=0 ∨ e u=1) (hs : (∑ u, e u)=0) :
    ∀ y, e y=0 := by
  intro y
  have := Finset.single_le_sum (fun u _ => bnn (hb u)) (Finset.mem_univ y)
  rcases hb y with h|h
  · exact h
  · rw [h, hs] at this; linarith

theorem single_supp {α : Type*} [Fintype α] [DecidableEq α] (e : α → ℤ) (hb : ∀ u, e u=0 ∨ e u=1) (hs : (∑ u, e u)=1) :
    ∃ a, ∀ y, e y=if y=a then 1 else 0 := by
  obtain ⟨a,-,ha⟩ := Finset.exists_ne_zero_of_sum_ne_zero (s := Finset.univ) (f := e)
    (by rw [hs]; norm_num)
  have ha1 : e a=1 := (hb a).resolve_left ha
  refine ⟨a, fun y => ?_⟩
  split_ifs with hy
  · rw [hy, ha1]
  · have hsum := Finset.add_sum_erase Finset.univ e (Finset.mem_univ a)
    have := Finset.single_le_sum (s := Finset.univ.erase a) (f := e)
      (fun u _ => bnn (hb u)) (Finset.mem_erase.mpr ⟨hy, Finset.mem_univ y⟩)
    rcases hb y with h|h
    · exact h
    · rw [hs, ha1] at hsum; linarith

theorem pair_supp (e : ZMod 15 → ℤ) (hb : ∀ u, e u=0 ∨ e u=1) (hs : (∑ u, e u)=2) (d : ZMod 15)
    (hd : d≠0) (hac : acZ e d=1) :
    ∃ b, ∀ y, e y=(if y=b then 1 else 0)+(if y=b+d then 1 else 0) := by
  obtain ⟨b,-,hbd⟩ := Finset.exists_ne_zero_of_sum_ne_zero (s := Finset.univ)
    (f := fun u => e u*e (u+d)) (by unfold acZ at hac; rw [hac]; norm_num)
  have hb1 : e b=1 := by rcases hb b with h|h <;> simp_all
  have hb2 : e (b+d)=1 := by rcases hb (b+d) with h|h <;> simp_all
  have hne : b+d≠b := fun h => hd (by simpa using h)
  refine ⟨b, fun y => ?_⟩
  have hsum := Finset.add_sum_erase Finset.univ e (Finset.mem_univ b)
  have hmem : b+d ∈ Finset.univ.erase b := Finset.mem_erase.mpr ⟨hne, Finset.mem_univ _⟩
  have hsum2 := Finset.add_sum_erase (Finset.univ.erase b) e hmem
  by_cases hy1 : y=b
  · subst hy1; rw [if_pos rfl, if_neg (Ne.symm hne), hb1]; norm_num
  by_cases hy2 : y=b+d
  · subst hy2; rw [if_neg hne, if_pos rfl, hb2]; norm_num
  rw [if_neg hy1, if_neg hy2]
  have := Finset.single_le_sum (s := (Finset.univ.erase b).erase (b+d)) (f := e)
    (fun u _ => bnn (hb u))
    (Finset.mem_erase.mpr ⟨hy2, Finset.mem_erase.mpr ⟨hy1, Finset.mem_univ y⟩⟩)
  rcases hb y with h|h
  · exact h
  · rw [hs, hb1] at hsum; rw [hb2] at hsum2; linarith

/-- A 3-periodic 0/1 function on `ZMod 15` with five ones is one residue
class mod 3. -/
theorem class_ind (g : ZMod 15 → ℤ) (hb : ∀ u, g u=0 ∨ g u=1)
    (hp : ∀ x, g (x+((3 : ℕ) : ZMod 15))=g x) (hs : (∑ u, g u)=5) :
    ∃ r<3, ∀ x, g x=if x.val%3=r then 1 else 0 := by
  have hS := sum_per (m := 3) (Or.inl rfl) g hp
  rw [hs] at hS
  simp only [Finset.sum_range_succ, Finset.sum_range_zero, zero_add, Nat.cast_zero, Nat.cast_one,
    Nat.cast_ofNat] at hS
  norm_num at hS
  have hx : ∀ x, g x=g ((x.val%3 : ℕ) : ZMod 15) := per_mod g hp
  have hcase : (g 0=1 ∧ g 1=0 ∧ g 2=0) ∨ (g 0=0 ∧ g 1=1 ∧ g 2=0) ∨ (g 0=0 ∧ g 1=0 ∧ g 2=1) := by
    rcases hb 0 with a|a <;> rcases hb 1 with b|b <;> rcases hb 2 with c|c <;>
      rw [a,b,c] at hS <;> norm_num at hS <;> simp [a,b,c]
  have fin3 : ∀ x : ZMod 15, x.val%3=0 ∨ x.val%3=1 ∨ x.val%3=2 := fun x => by omega
  rcases hcase with ⟨a,b,c⟩|⟨a,b,c⟩|⟨a,b,c⟩
  · refine ⟨0, by norm_num, fun x => ?_⟩
    rw [hx x]; rcases fin3 x with k|k|k <;> rw [k] <;> simp [a,b,c]
  · refine ⟨1, by norm_num, fun x => ?_⟩
    rw [hx x]; rcases fin3 x with k|k|k <;> rw [k] <;> simp [a,b,c]
  · refine ⟨2, by norm_num, fun x => ?_⟩
    rw [hx x]; rcases fin3 x with k|k|k <;> rw [k] <;> simp [a,b,c]

theorem dist_two : ∀ s ∈ realList 2, 1≤distOf s ∧ distOf s≤7 ∧ gd s (distOf s-1)=1 := by decide

/-- Solving `a + o*x = c` for `x` when `o = ±1`. -/
theorem solve_lin {o : ZMod 15} (ho : o=1 ∨ o=-1) (a x c : ZMod 15) :
    (a+o*x=c ↔ x=o*(c-a)) := by
  have ho2 : o*o=1 := by rcases ho with rfl|rfl <;> norm_num
  constructor
  · intro h; subst h; linear_combination (-x)*ho2
  · intro h; subst h; linear_combination (c-a)*ho2

/-- Row `x` of a long block of row cycle `A` (first row `e0`, orientation
`o`) against row `0` of the block of row cycle `B` (first row `e1`), when one
has one point and the other two points at distance `d`: the overlap, as a
function of `x`, is the indicator of a pair `{p, p+s}` with `s = ±d`. -/
theorem pair_ov (e0 e1 : ZMod 15 → ℤ) (b0 : ∀ u, e0 u=0 ∨ e0 u=1) (b1 : ∀ u, e1 u=0 ∨ e1 u=1)
    {o : ZMod 15} (ho : o=1 ∨ o=-1) (d : ℕ) (hd1 : 1≤d) (hd7 : d≤7)
    (hcase : ((∑ u, e0 u)=1 ∧ (∑ u, e1 u)=2 ∧ acZ e1 d=1) ∨
      ((∑ u, e0 u)=2 ∧ (∑ u, e1 u)=1 ∧ acZ e0 d=1)) :
    ∃ p s : ZMod 15, (s=d ∨ s=-(d : ZMod 15)) ∧
      ∀ x, (∑ y, e0 (y-o*x)*e1 y)=(if x=p then 1 else 0)+(if x=p+s then 1 else 0) := by
  have hd0 : (d : ZMod 15)≠0 := by
    intro h; rw [ZMod.natCast_eq_zero_iff] at h; omega
  have hos : o*d=d ∨ o*d=-(d : ZMod 15) := by rcases ho with rfl|rfl <;> simp
  rcases hcase with ⟨s0,s1,hac⟩|⟨s0,s1,hac⟩
  · obtain ⟨a,ha⟩ := single_supp e0 b0 s0
    obtain ⟨b,hb⟩ := pair_supp e1 b1 s1 d hd0 hac
    refine ⟨o*(b-a), o*d, hos, fun x => ?_⟩
    have e : (∑ y, e0 (y-o*x)*e1 y)=e1 (a+o*x) := by
      simp only [ha, ite_mul, one_mul, zero_mul]
      have : ∀ y, (y-o*x=a ↔ y=a+o*x) := fun y => sub_eq_iff_eq_add
      simp only [this, Finset.sum_ite_eq', Finset.mem_univ, if_true]
    rw [e, hb]
    simp only [solve_lin ho a x b, solve_lin ho a x (b+d),
      show o*(b+(d : ZMod 15)-a)=o*(b-a)+o*d by ring]
  · obtain ⟨b,hb⟩ := pair_supp e0 b0 s0 d hd0 hac
    obtain ⟨a,ha⟩ := single_supp e1 b1 s1
    refine ⟨o*(a-(b+d)), o*d, hos, fun x => ?_⟩
    have e : (∑ y, e0 (y-o*x)*e1 y)=e0 (a-o*x) := by
      simp only [ha, mul_ite, mul_one, mul_zero, Finset.sum_ite_eq', Finset.mem_univ, if_true]
    have hl : ∀ c, (a-o*x=c ↔ x=o*(a-c)) := by
      intro c
      have := solve_lin ho c x a
      constructor
      · intro h; exact (this.mp (by rw [← h]; ring)).trans (by ring)
      · intro h; have := this.mpr (h.trans (by ring)); rw [← this]; ring
    rw [e, hb]
    simp only [hl b, hl (b+d), show o*(a-b)=o*(a-(b+(d : ZMod 15)))+o*d by ring]
    ring

end Symconf113

import Symconf113.CoverageShard113_086

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3143 : NodeCoverage113 [24,24,12,12,6,6,6,3] 3 20 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3144 : NodeCoverage113 [24,24,12,12,6,6,6] 6 23 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3141
    (ChildrenCoverage113.cons _ _ compact113_node_3142
    (ChildrenCoverage113.cons _ _ compact113_node_3143
    ChildrenCoverage113.nil)))

theorem compact113_node_3145 : NodeCoverage113 [24,24,12,12,6,6,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3146 : NodeCoverage113 [24,24,12,12,6,6,3] 3 26 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3147 : NodeCoverage113 [24,24,12,12,6,6] 6 29 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3144
    (ChildrenCoverage113.cons _ _ compact113_node_3145
    (ChildrenCoverage113.cons _ _ compact113_node_3146
    ChildrenCoverage113.nil)))

theorem compact113_node_3148 : NodeCoverage113 [24,24,12,12,6,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3149 : NodeCoverage113 [24,24,12,12,6,3] 3 32 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3150 : NodeCoverage113 [24,24,12,12,6] 6 35 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3147
    (ChildrenCoverage113.cons _ _ compact113_node_3148
    (ChildrenCoverage113.cons _ _ compact113_node_3149
    ChildrenCoverage113.nil)))

theorem compact113_node_3151 : NodeCoverage113 [24,24,12,12,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3152 : NodeCoverage113 [24,24,12,12,3] 3 38 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3153 : NodeCoverage113 [24,24,12,12] 12 41 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3127
    (ChildrenCoverage113.cons _ _ compact113_node_3128
    (ChildrenCoverage113.cons _ _ compact113_node_3129
    (ChildrenCoverage113.cons _ _ compact113_node_3130
    (ChildrenCoverage113.cons _ _ compact113_node_3131
    (ChildrenCoverage113.cons _ _ compact113_node_3132
    (ChildrenCoverage113.cons _ _ compact113_node_3150
    (ChildrenCoverage113.cons _ _ compact113_node_3151
    (ChildrenCoverage113.cons _ _ compact113_node_3152
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_3154 : NodeCoverage113 [24,24,12,11] 11 42 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3155 : NodeCoverage113 [24,24,12,10] 10 43 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3156 : NodeCoverage113 [24,24,12,9] 9 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3157 : NodeCoverage113 [24,24,12,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3158 : NodeCoverage113 [24,24,12,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3159 : NodeCoverage113 [24,24,12,6] 6 47 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3160 : NodeCoverage113 [24,24,12,5] 5 48 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3161 : NodeCoverage113 [24,24,12,3] 3 50 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3162 : NodeCoverage113 [24,24,12] 12 53 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3153
    (ChildrenCoverage113.cons _ _ compact113_node_3154
    (ChildrenCoverage113.cons _ _ compact113_node_3155
    (ChildrenCoverage113.cons _ _ compact113_node_3156
    (ChildrenCoverage113.cons _ _ compact113_node_3157
    (ChildrenCoverage113.cons _ _ compact113_node_3158
    (ChildrenCoverage113.cons _ _ compact113_node_3159
    (ChildrenCoverage113.cons _ _ compact113_node_3160
    (ChildrenCoverage113.cons _ _ compact113_node_3161
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_3163 : NodeCoverage113 [24,24,11] 11 54 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3164 : NodeCoverage113 [24,24,10] 10 55 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3165 : NodeCoverage113 [24,24,9] 9 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3166 : NodeCoverage113 [24,24,8] 8 57 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

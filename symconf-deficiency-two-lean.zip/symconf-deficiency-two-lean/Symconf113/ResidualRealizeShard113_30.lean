import Symconf113.ResidualRealizeShardDefs113

/-! Kernel check: realizability for the subsets starting with bits true,true,true,true,false. -/
namespace Symconf113
set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
theorem realShard_30 : bools10.all (fun l => realB ([true,true,true,true,false] ++ l))=true := by decide +kernel
end Symconf113

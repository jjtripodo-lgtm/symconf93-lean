import Symconf113.ResidualDegDefs113

/-! Kernel check: the degree search below type-`A` rows 114 and 115. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem degShard_114 : ((degTopList.drop 114).take 2).all degTop=true := by decide +kernel
end Symconf113

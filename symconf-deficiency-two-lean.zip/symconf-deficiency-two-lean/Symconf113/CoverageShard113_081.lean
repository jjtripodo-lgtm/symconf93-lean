import Symconf113.CoverageShard113_080

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2918 : NodeCoverage113 [25,25,25,24] 24 14 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2919 : NodeCoverage113 [25,25,25,23] 23 15 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2920 : NodeCoverage113 [25,25,25,22] 22 16 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2921 : NodeCoverage113 [25,25,25,21] 21 17 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2922 : NodeCoverage113 [25,25,25,20] 20 18 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2923 : NodeCoverage113 [25,25,25,19] 19 19 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2924 : NodeCoverage113 [25,25,25,18] 18 20 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2925 : NodeCoverage113 [25,25,25,17] 17 21 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2926 : NodeCoverage113 [25,25,25,16] 16 22 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2927 : NodeCoverage113 [25,25,25,15] 15 23 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2928 : NodeCoverage113 [25,25,25,14] 14 24 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2929 : NodeCoverage113 [25,25,25,13] 13 25 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2930 : NodeCoverage113 [25,25,25,12] 12 26 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2931 : NodeCoverage113 [25,25,25,11] 11 27 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2932 : NodeCoverage113 [25,25,25,10] 10 28 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2933 : NodeCoverage113 [25,25,25,9] 9 29 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2934 : NodeCoverage113 [25,25,25,8] 8 30 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2935 : NodeCoverage113 [25,25,25,7] 7 31 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2936 : NodeCoverage113 [25,25,25,6] 6 32 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2937 : NodeCoverage113 [25,25,25,5] 5 33 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2938 : NodeCoverage113 [25,25,25,3] 3 35 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2939 : NodeCoverage113 [25,25,25] 25 38 :=
  node_fork113 (B := [25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2917
    (ChildrenCoverage113.cons _ _ compact113_node_2918
    (ChildrenCoverage113.cons _ _ compact113_node_2919
    (ChildrenCoverage113.cons _ _ compact113_node_2920
    (ChildrenCoverage113.cons _ _ compact113_node_2921
    (ChildrenCoverage113.cons _ _ compact113_node_2922
    (ChildrenCoverage113.cons _ _ compact113_node_2923
    (ChildrenCoverage113.cons _ _ compact113_node_2924
    (ChildrenCoverage113.cons _ _ compact113_node_2925
    (ChildrenCoverage113.cons _ _ compact113_node_2926
    (ChildrenCoverage113.cons _ _ compact113_node_2927
    (ChildrenCoverage113.cons _ _ compact113_node_2928
    (ChildrenCoverage113.cons _ _ compact113_node_2929
    (ChildrenCoverage113.cons _ _ compact113_node_2930
    (ChildrenCoverage113.cons _ _ compact113_node_2931
    (ChildrenCoverage113.cons _ _ compact113_node_2932
    (ChildrenCoverage113.cons _ _ compact113_node_2933
    (ChildrenCoverage113.cons _ _ compact113_node_2934
    (ChildrenCoverage113.cons _ _ compact113_node_2935
    (ChildrenCoverage113.cons _ _ compact113_node_2936
    (ChildrenCoverage113.cons _ _ compact113_node_2937
    (ChildrenCoverage113.cons _ _ compact113_node_2938
    ChildrenCoverage113.nil))))))))))))))))))))))

theorem compact113_node_2940 : NodeCoverage113 [25,25,24] 24 39 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2941 : NodeCoverage113 [25,25,23] 23 40 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2942 : NodeCoverage113 [25,25,22] 22 41 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2943 : NodeCoverage113 [25,25,21] 21 42 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2944 : NodeCoverage113 [25,25,20] 20 43 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2945 : NodeCoverage113 [25,25,19] 19 44 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2946 : NodeCoverage113 [25,25,18] 18 45 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2947 : NodeCoverage113 [25,25,17] 17 46 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2948 : NodeCoverage113 [25,25,16] 16 47 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

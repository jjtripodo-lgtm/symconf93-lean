import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3963 : NodeCoverage113 [20,20,20,18] 18 35 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3964 : NodeCoverage113 [20,20,20,17] 17 36 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3965 : NodeCoverage113 [20,20,20,16] 16 37 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3966 : NodeCoverage113 [20,20,20,15] 15 38 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3967 : NodeCoverage113 [20,20,20,14] 14 39 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3968 : NodeCoverage113 [20,20,20,13] 13 40 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3969 : NodeCoverage113 [20,20,20,12] 12 41 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3970 : NodeCoverage113 [20,20,20,11] 11 42 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3971 : NodeCoverage113 [20,20,20,10,10,10,10,10] 10 3 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3972 : NodeCoverage113 [20,20,20,10,10,10,10,9] 9 4 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3973 : NodeCoverage113 [20,20,20,10,10,10,10,8] 8 5 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3974 : NodeCoverage113 [20,20,20,10,10,10,10,7] 7 6 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3975 : NodeCoverage113 [20,20,20,10,10,10,10,6] 6 7 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3976 : NodeCoverage113 [20,20,20,10,10,10,10,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3977 : NodeCoverage113 [20,20,20,10,10,10,10,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3976
    ChildrenCoverage113.nil)

theorem compact113_node_3978 : NodeCoverage113 [20,20,20,10,10,10,10,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3979 : NodeCoverage113 [20,20,20,10,10,10,10,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3977
    (ChildrenCoverage113.cons _ _ compact113_node_3978
    ChildrenCoverage113.nil))

theorem compact113_node_3980 : NodeCoverage113 [20,20,20,10,10,10,10,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3981 : NodeCoverage113 [20,20,20,10,10,10,10] 10 13 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3971
    (ChildrenCoverage113.cons _ _ compact113_node_3972
    (ChildrenCoverage113.cons _ _ compact113_node_3973
    (ChildrenCoverage113.cons _ _ compact113_node_3974
    (ChildrenCoverage113.cons _ _ compact113_node_3975
    (ChildrenCoverage113.cons _ _ compact113_node_3979
    (ChildrenCoverage113.cons _ _ compact113_node_3980
    ChildrenCoverage113.nil)))))))

theorem compact113_node_3982 : NodeCoverage113 [20,20,20,10,10,10,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3983 : NodeCoverage113 [20,20,20,10,10,10,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3984 : NodeCoverage113 [20,20,20,10,10,10,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3985 : NodeCoverage113 [20,20,20,10,10,10,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3986 : NodeCoverage113 [20,20,20,10,10,10,5,5,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3987 : NodeCoverage113 [20,20,20,10,10,10,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3986
    ChildrenCoverage113.nil)

theorem compact113_node_3988 : NodeCoverage113 [20,20,20,10,10,10,5,5,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3989 : NodeCoverage113 [20,20,20,10,10,10,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3987
    (ChildrenCoverage113.cons _ _ compact113_node_3988
    ChildrenCoverage113.nil))

theorem compact113_node_3990 : NodeCoverage113 [20,20,20,10,10,10,5,5,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3991 : NodeCoverage113 [20,20,20,10,10,10,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3989
    (ChildrenCoverage113.cons _ _ compact113_node_3990
    ChildrenCoverage113.nil))

theorem compact113_node_3992 : NodeCoverage113 [20,20,20,10,10,10,5,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3993 : NodeCoverage113 [20,20,20,10,10,10,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3991
    (ChildrenCoverage113.cons _ _ compact113_node_3992
    ChildrenCoverage113.nil))

theorem compact113_node_3994 : NodeCoverage113 [20,20,20,10,10,10,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3995 : NodeCoverage113 [20,20,20,10,10,10] 10 23 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3981
    (ChildrenCoverage113.cons _ _ compact113_node_3982
    (ChildrenCoverage113.cons _ _ compact113_node_3983
    (ChildrenCoverage113.cons _ _ compact113_node_3984
    (ChildrenCoverage113.cons _ _ compact113_node_3985
    (ChildrenCoverage113.cons _ _ compact113_node_3993
    (ChildrenCoverage113.cons _ _ compact113_node_3994
    ChildrenCoverage113.nil)))))))

theorem compact113_node_3996 : NodeCoverage113 [20,20,20,10,10,9] 9 24 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3997 : NodeCoverage113 [20,20,20,10,10,8] 8 25 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3998 : NodeCoverage113 [20,20,20,10,10,7] 7 26 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3999 : NodeCoverage113 [20,20,20,10,10,6] 6 27 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4000 : NodeCoverage113 [20,20,20,10,10,5,5,5,5,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4001 : NodeCoverage113 [20,20,20,10,10,5,5,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4000
    ChildrenCoverage113.nil)

theorem compact113_node_4002 : NodeCoverage113 [20,20,20,10,10,5,5,5,5,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4003 : NodeCoverage113 [20,20,20,10,10,5,5,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4001
    (ChildrenCoverage113.cons _ _ compact113_node_4002
    ChildrenCoverage113.nil))

theorem compact113_node_4004 : NodeCoverage113 [20,20,20,10,10,5,5,5,5,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4005 : NodeCoverage113 [20,20,20,10,10,5,5,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4003
    (ChildrenCoverage113.cons _ _ compact113_node_4004
    ChildrenCoverage113.nil))

theorem compact113_node_4006 : NodeCoverage113 [20,20,20,10,10,5,5,5,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4007 : NodeCoverage113 [20,20,20,10,10,5,5,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4005
    (ChildrenCoverage113.cons _ _ compact113_node_4006
    ChildrenCoverage113.nil))

theorem compact113_node_4008 : NodeCoverage113 [20,20,20,10,10,5,5,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4009 : NodeCoverage113 [20,20,20,10,10,5,5] 5 23 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4007
    (ChildrenCoverage113.cons _ _ compact113_node_4008
    ChildrenCoverage113.nil))

theorem compact113_node_4010 : NodeCoverage113 [20,20,20,10,10,5,3] 3 25 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4011 : NodeCoverage113 [20,20,20,10,10,5] 5 28 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4009
    (ChildrenCoverage113.cons _ _ compact113_node_4010
    ChildrenCoverage113.nil))

theorem compact113_node_4012 : NodeCoverage113 [20,20,20,10,10,3] 3 30 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4013 : NodeCoverage113 [20,20,20,10,10] 10 33 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3995
    (ChildrenCoverage113.cons _ _ compact113_node_3996
    (ChildrenCoverage113.cons _ _ compact113_node_3997
    (ChildrenCoverage113.cons _ _ compact113_node_3998
    (ChildrenCoverage113.cons _ _ compact113_node_3999
    (ChildrenCoverage113.cons _ _ compact113_node_4011
    (ChildrenCoverage113.cons _ _ compact113_node_4012
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4014 : NodeCoverage113 [20,20,20,10,9] 9 34 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4015 : NodeCoverage113 [20,20,20,10,8] 8 35 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4016 : NodeCoverage113 [20,20,20,10,7] 7 36 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4017 : NodeCoverage113 [20,20,20,10,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4018 : NodeCoverage113 [20,20,20,10,5] 5 38 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4019 : NodeCoverage113 [20,20,20,10,3] 3 40 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4020 : NodeCoverage113 [20,20,20,10] 10 43 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4013
    (ChildrenCoverage113.cons _ _ compact113_node_4014
    (ChildrenCoverage113.cons _ _ compact113_node_4015
    (ChildrenCoverage113.cons _ _ compact113_node_4016
    (ChildrenCoverage113.cons _ _ compact113_node_4017
    (ChildrenCoverage113.cons _ _ compact113_node_4018
    (ChildrenCoverage113.cons _ _ compact113_node_4019
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4021 : NodeCoverage113 [20,20,20,9] 9 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4022 : NodeCoverage113 [20,20,20,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

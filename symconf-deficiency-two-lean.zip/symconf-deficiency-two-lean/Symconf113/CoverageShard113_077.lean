import Symconf113.CoverageShard113_076

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2726 : NodeCoverage113 [28,14,14,14] 14 43 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2715
    (ChildrenCoverage113.cons _ _ compact113_node_2716
    (ChildrenCoverage113.cons _ _ compact113_node_2717
    (ChildrenCoverage113.cons _ _ compact113_node_2718
    (ChildrenCoverage113.cons _ _ compact113_node_2719
    (ChildrenCoverage113.cons _ _ compact113_node_2720
    (ChildrenCoverage113.cons _ _ compact113_node_2721
    (ChildrenCoverage113.cons _ _ compact113_node_2722
    (ChildrenCoverage113.cons _ _ compact113_node_2723
    (ChildrenCoverage113.cons _ _ compact113_node_2724
    (ChildrenCoverage113.cons _ _ compact113_node_2725
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_2727 : NodeCoverage113 [28,14,14,13] 13 44 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2728 : NodeCoverage113 [28,14,14,12] 12 45 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2729 : NodeCoverage113 [28,14,14,11] 11 46 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2730 : NodeCoverage113 [28,14,14,10] 10 47 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2731 : NodeCoverage113 [28,14,14,9] 9 48 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2732 : NodeCoverage113 [28,14,14,8] 8 49 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2733 : NodeCoverage113 [28,14,14,7,7,7,7,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2734 : NodeCoverage113 [28,14,14,7,7,7,7,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2735 : NodeCoverage113 [28,14,14,7,7,7,7,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2733
    (ChildrenCoverage113.cons _ _ compact113_node_2734
    ChildrenCoverage113.nil))

theorem compact113_node_2736 : NodeCoverage113 [28,14,14,7,7,7,7,7,7,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2737 : NodeCoverage113 [28,14,14,7,7,7,7,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2738 : NodeCoverage113 [28,14,14,7,7,7,7,7,7,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2739 : NodeCoverage113 [28,14,14,7,7,7,7,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2735
    (ChildrenCoverage113.cons _ _ compact113_node_2736
    (ChildrenCoverage113.cons _ _ compact113_node_2737
    (ChildrenCoverage113.cons _ _ compact113_node_2738
    ChildrenCoverage113.nil))))

theorem compact113_node_2740 : NodeCoverage113 [28,14,14,7,7,7,7,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2741 : NodeCoverage113 [28,14,14,7,7,7,7,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2742 : NodeCoverage113 [28,14,14,7,7,7,7,7,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2743 : NodeCoverage113 [28,14,14,7,7,7,7,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2739
    (ChildrenCoverage113.cons _ _ compact113_node_2740
    (ChildrenCoverage113.cons _ _ compact113_node_2741
    (ChildrenCoverage113.cons _ _ compact113_node_2742
    ChildrenCoverage113.nil))))

theorem compact113_node_2744 : NodeCoverage113 [28,14,14,7,7,7,7,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2745 : NodeCoverage113 [28,14,14,7,7,7,7,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2746 : NodeCoverage113 [28,14,14,7,7,7,7,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2747 : NodeCoverage113 [28,14,14,7,7,7,7] 7 29 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2743
    (ChildrenCoverage113.cons _ _ compact113_node_2744
    (ChildrenCoverage113.cons _ _ compact113_node_2745
    (ChildrenCoverage113.cons _ _ compact113_node_2746
    ChildrenCoverage113.nil))))

theorem compact113_node_2748 : NodeCoverage113 [28,14,14,7,7,7,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2749 : NodeCoverage113 [28,14,14,7,7,7,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2750 : NodeCoverage113 [28,14,14,7,7,7,3] 3 33 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2751 : NodeCoverage113 [28,14,14,7,7,7] 7 36 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2747
    (ChildrenCoverage113.cons _ _ compact113_node_2748
    (ChildrenCoverage113.cons _ _ compact113_node_2749
    (ChildrenCoverage113.cons _ _ compact113_node_2750
    ChildrenCoverage113.nil))))

theorem compact113_node_2752 : NodeCoverage113 [28,14,14,7,7,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2753 : NodeCoverage113 [28,14,14,7,7,5] 5 38 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2754 : NodeCoverage113 [28,14,14,7,7,3] 3 40 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2755 : NodeCoverage113 [28,14,14,7,7] 7 43 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2751
    (ChildrenCoverage113.cons _ _ compact113_node_2752
    (ChildrenCoverage113.cons _ _ compact113_node_2753
    (ChildrenCoverage113.cons _ _ compact113_node_2754
    ChildrenCoverage113.nil))))

theorem compact113_node_2756 : NodeCoverage113 [28,14,14,7,6] 6 44 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2757 : NodeCoverage113 [28,14,14,7,5] 5 45 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2758 : NodeCoverage113 [28,14,14,7,3] 3 47 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2759 : NodeCoverage113 [28,14,14,7] 7 50 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2755
    (ChildrenCoverage113.cons _ _ compact113_node_2756
    (ChildrenCoverage113.cons _ _ compact113_node_2757
    (ChildrenCoverage113.cons _ _ compact113_node_2758
    ChildrenCoverage113.nil))))

theorem compact113_node_2760 : NodeCoverage113 [28,14,14,6] 6 51 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2761 : NodeCoverage113 [28,14,14,5] 5 52 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2762 : NodeCoverage113 [28,14,14,3] 3 54 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2763 : NodeCoverage113 [28,14,14] 14 57 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2726
    (ChildrenCoverage113.cons _ _ compact113_node_2727
    (ChildrenCoverage113.cons _ _ compact113_node_2728
    (ChildrenCoverage113.cons _ _ compact113_node_2729
    (ChildrenCoverage113.cons _ _ compact113_node_2730
    (ChildrenCoverage113.cons _ _ compact113_node_2731
    (ChildrenCoverage113.cons _ _ compact113_node_2732
    (ChildrenCoverage113.cons _ _ compact113_node_2759
    (ChildrenCoverage113.cons _ _ compact113_node_2760
    (ChildrenCoverage113.cons _ _ compact113_node_2761
    (ChildrenCoverage113.cons _ _ compact113_node_2762
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_2764 : NodeCoverage113 [28,14,13] 13 58 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2765 : NodeCoverage113 [28,14,12] 12 59 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2766 : NodeCoverage113 [28,14,11] 11 60 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2767 : NodeCoverage113 [28,14,10] 10 61 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2768 : NodeCoverage113 [28,14,9] 9 62 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2769 : NodeCoverage113 [28,14,8] 8 63 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2770 : NodeCoverage113 [28,14,7] 7 64 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2771 : NodeCoverage113 [28,14,6] 6 65 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2772 : NodeCoverage113 [28,14,5] 5 66 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2773 : NodeCoverage113 [28,14,3] 3 68 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2774 : NodeCoverage113 [28,14] 14 71 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2763
    (ChildrenCoverage113.cons _ _ compact113_node_2764
    (ChildrenCoverage113.cons _ _ compact113_node_2765
    (ChildrenCoverage113.cons _ _ compact113_node_2766
    (ChildrenCoverage113.cons _ _ compact113_node_2767
    (ChildrenCoverage113.cons _ _ compact113_node_2768
    (ChildrenCoverage113.cons _ _ compact113_node_2769
    (ChildrenCoverage113.cons _ _ compact113_node_2770
    (ChildrenCoverage113.cons _ _ compact113_node_2771
    (ChildrenCoverage113.cons _ _ compact113_node_2772
    (ChildrenCoverage113.cons _ _ compact113_node_2773
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_2775 : NodeCoverage113 [28,13] 13 72 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2776 : NodeCoverage113 [28,12] 12 73 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2777 : NodeCoverage113 [28,11] 11 74 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2778 : NodeCoverage113 [28,10] 10 75 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2779 : NodeCoverage113 [28,9] 9 76 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2780 : NodeCoverage113 [28,8] 8 77 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2781 : NodeCoverage113 [28,7] 7 78 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2782 : NodeCoverage113 [28,6] 6 79 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2783 : NodeCoverage113 [28,5] 5 80 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2784 : NodeCoverage113 [28,3] 3 82 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2785 : NodeCoverage113 [28] 28 85 :=
  node_fork113 (B := [28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2680
    (ChildrenCoverage113.cons _ _ compact113_node_2681
    (ChildrenCoverage113.cons _ _ compact113_node_2682
    (ChildrenCoverage113.cons _ _ compact113_node_2683
    (ChildrenCoverage113.cons _ _ compact113_node_2684
    (ChildrenCoverage113.cons _ _ compact113_node_2685
    (ChildrenCoverage113.cons _ _ compact113_node_2686
    (ChildrenCoverage113.cons _ _ compact113_node_2687
    (ChildrenCoverage113.cons _ _ compact113_node_2688
    (ChildrenCoverage113.cons _ _ compact113_node_2689
    (ChildrenCoverage113.cons _ _ compact113_node_2690
    (ChildrenCoverage113.cons _ _ compact113_node_2691
    (ChildrenCoverage113.cons _ _ compact113_node_2692
    (ChildrenCoverage113.cons _ _ compact113_node_2693
    (ChildrenCoverage113.cons _ _ compact113_node_2774
    (ChildrenCoverage113.cons _ _ compact113_node_2775
    (ChildrenCoverage113.cons _ _ compact113_node_2776
    (ChildrenCoverage113.cons _ _ compact113_node_2777
    (ChildrenCoverage113.cons _ _ compact113_node_2778
    (ChildrenCoverage113.cons _ _ compact113_node_2779
    (ChildrenCoverage113.cons _ _ compact113_node_2780
    (ChildrenCoverage113.cons _ _ compact113_node_2781
    (ChildrenCoverage113.cons _ _ compact113_node_2782
    (ChildrenCoverage113.cons _ _ compact113_node_2783
    (ChildrenCoverage113.cons _ _ compact113_node_2784
    ChildrenCoverage113.nil)))))))))))))))))))))))))

theorem compact113_node_2786 : NodeCoverage113 [27,27,27,27,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2787 : NodeCoverage113 [27,27,27,27] 27 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2786
    ChildrenCoverage113.nil)

theorem compact113_node_2788 : NodeCoverage113 [27,27,27,26] 26 6 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2789 : NodeCoverage113 [27,27,27,25] 25 7 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

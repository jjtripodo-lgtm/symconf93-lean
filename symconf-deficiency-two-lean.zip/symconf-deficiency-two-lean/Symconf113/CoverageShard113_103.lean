import Symconf113.CoverageShard113_101
import Symconf113.CoverageShard113_102

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3706 : NodeCoverage113 [22,11,11,11,10] 10 48 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3707 : NodeCoverage113 [22,11,11,11,9] 9 49 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3708 : NodeCoverage113 [22,11,11,11,8] 8 50 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3709 : NodeCoverage113 [22,11,11,11,7] 7 51 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3710 : NodeCoverage113 [22,11,11,11,6] 6 52 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3711 : NodeCoverage113 [22,11,11,11,5] 5 53 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3712 : NodeCoverage113 [22,11,11,11,3] 3 55 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3713 : NodeCoverage113 [22,11,11,11] 11 58 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3705
    (ChildrenCoverage113.cons _ _ compact113_node_3706
    (ChildrenCoverage113.cons _ _ compact113_node_3707
    (ChildrenCoverage113.cons _ _ compact113_node_3708
    (ChildrenCoverage113.cons _ _ compact113_node_3709
    (ChildrenCoverage113.cons _ _ compact113_node_3710
    (ChildrenCoverage113.cons _ _ compact113_node_3711
    (ChildrenCoverage113.cons _ _ compact113_node_3712
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3714 : NodeCoverage113 [22,11,11,10] 10 59 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3715 : NodeCoverage113 [22,11,11,9] 9 60 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3716 : NodeCoverage113 [22,11,11,8] 8 61 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3717 : NodeCoverage113 [22,11,11,7] 7 62 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3718 : NodeCoverage113 [22,11,11,6] 6 63 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3719 : NodeCoverage113 [22,11,11,5] 5 64 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3720 : NodeCoverage113 [22,11,11,3] 3 66 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3721 : NodeCoverage113 [22,11,11] 11 69 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3713
    (ChildrenCoverage113.cons _ _ compact113_node_3714
    (ChildrenCoverage113.cons _ _ compact113_node_3715
    (ChildrenCoverage113.cons _ _ compact113_node_3716
    (ChildrenCoverage113.cons _ _ compact113_node_3717
    (ChildrenCoverage113.cons _ _ compact113_node_3718
    (ChildrenCoverage113.cons _ _ compact113_node_3719
    (ChildrenCoverage113.cons _ _ compact113_node_3720
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3722 : NodeCoverage113 [22,11,10] 10 70 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3723 : NodeCoverage113 [22,11,9] 9 71 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3724 : NodeCoverage113 [22,11,8] 8 72 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3725 : NodeCoverage113 [22,11,7] 7 73 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3726 : NodeCoverage113 [22,11,6] 6 74 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3727 : NodeCoverage113 [22,11,5] 5 75 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3728 : NodeCoverage113 [22,11,3] 3 77 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3729 : NodeCoverage113 [22,11] 11 80 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3721
    (ChildrenCoverage113.cons _ _ compact113_node_3722
    (ChildrenCoverage113.cons _ _ compact113_node_3723
    (ChildrenCoverage113.cons _ _ compact113_node_3724
    (ChildrenCoverage113.cons _ _ compact113_node_3725
    (ChildrenCoverage113.cons _ _ compact113_node_3726
    (ChildrenCoverage113.cons _ _ compact113_node_3727
    (ChildrenCoverage113.cons _ _ compact113_node_3728
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3730 : NodeCoverage113 [22,10] 10 81 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3731 : NodeCoverage113 [22,9] 9 82 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3732 : NodeCoverage113 [22,8] 8 83 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3733 : NodeCoverage113 [22,7] 7 84 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3734 : NodeCoverage113 [22,6] 6 85 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3735 : NodeCoverage113 [22,5] 5 86 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3736 : NodeCoverage113 [22,3] 3 88 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3737 : NodeCoverage113 [22] 22 91 :=
  node_fork113 (B := [22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3623
    (ChildrenCoverage113.cons _ _ compact113_node_3624
    (ChildrenCoverage113.cons _ _ compact113_node_3625
    (ChildrenCoverage113.cons _ _ compact113_node_3626
    (ChildrenCoverage113.cons _ _ compact113_node_3627
    (ChildrenCoverage113.cons _ _ compact113_node_3628
    (ChildrenCoverage113.cons _ _ compact113_node_3629
    (ChildrenCoverage113.cons _ _ compact113_node_3630
    (ChildrenCoverage113.cons _ _ compact113_node_3650
    (ChildrenCoverage113.cons _ _ compact113_node_3661
    (ChildrenCoverage113.cons _ _ compact113_node_3671
    (ChildrenCoverage113.cons _ _ compact113_node_3729
    (ChildrenCoverage113.cons _ _ compact113_node_3730
    (ChildrenCoverage113.cons _ _ compact113_node_3731
    (ChildrenCoverage113.cons _ _ compact113_node_3732
    (ChildrenCoverage113.cons _ _ compact113_node_3733
    (ChildrenCoverage113.cons _ _ compact113_node_3734
    (ChildrenCoverage113.cons _ _ compact113_node_3735
    (ChildrenCoverage113.cons _ _ compact113_node_3736
    ChildrenCoverage113.nil)))))))))))))))))))

theorem compact113_node_3738 : NodeCoverage113 [21,21,21,21,21,8] 8 0 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3739 : NodeCoverage113 [21,21,21,21,21,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3740 : NodeCoverage113 [21,21,21,21,21,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3741 : NodeCoverage113 [21,21,21,21,21] 21 8 :=
  node_fork113 (B := [8,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3738
    (ChildrenCoverage113.cons _ _ compact113_node_3739
    (ChildrenCoverage113.cons _ _ compact113_node_3740
    ChildrenCoverage113.nil)))

theorem compact113_node_3742 : NodeCoverage113 [21,21,21,21,20] 20 9 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3743 : NodeCoverage113 [21,21,21,21,19] 19 10 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3744 : NodeCoverage113 [21,21,21,21,18] 18 11 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3745 : NodeCoverage113 [21,21,21,21,17] 17 12 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3746 : NodeCoverage113 [21,21,21,21,16] 16 13 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3747 : NodeCoverage113 [21,21,21,21,15] 15 14 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3748 : NodeCoverage113 [21,21,21,21,14] 14 15 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3749 : NodeCoverage113 [21,21,21,21,13] 13 16 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3750 : NodeCoverage113 [21,21,21,21,12] 12 17 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3751 : NodeCoverage113 [21,21,21,21,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3752 : NodeCoverage113 [21,21,21,21,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3753 : NodeCoverage113 [21,21,21,21,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3754 : NodeCoverage113 [21,21,21,21,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3755 : NodeCoverage113 [21,21,21,21,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3756 : NodeCoverage113 [21,21,21,21,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3757 : NodeCoverage113 [21,21,21,21,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3755
    (ChildrenCoverage113.cons _ _ compact113_node_3756
    ChildrenCoverage113.nil))

theorem compact113_node_3758 : NodeCoverage113 [21,21,21,21,7,7,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3759 : NodeCoverage113 [21,21,21,21,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3760 : NodeCoverage113 [21,21,21,21,7,7,3] 3 12 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3761 : NodeCoverage113 [21,21,21,21,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3757
    (ChildrenCoverage113.cons _ _ compact113_node_3758
    (ChildrenCoverage113.cons _ _ compact113_node_3759
    (ChildrenCoverage113.cons _ _ compact113_node_3760
    ChildrenCoverage113.nil))))

theorem compact113_node_3762 : NodeCoverage113 [21,21,21,21,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3763 : NodeCoverage113 [21,21,21,21,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3764 : NodeCoverage113 [21,21,21,21,7,3] 3 19 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3765 : NodeCoverage113 [21,21,21,21,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3761
    (ChildrenCoverage113.cons _ _ compact113_node_3762
    (ChildrenCoverage113.cons _ _ compact113_node_3763
    (ChildrenCoverage113.cons _ _ compact113_node_3764
    ChildrenCoverage113.nil))))

theorem compact113_node_3766 : NodeCoverage113 [21,21,21,21,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3767 : NodeCoverage113 [21,21,21,21,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3768 : NodeCoverage113 [21,21,21,21,3] 3 26 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3769 : NodeCoverage113 [21,21,21,21] 21 29 :=
  node_fork113 (B := [21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3741
    (ChildrenCoverage113.cons _ _ compact113_node_3742
    (ChildrenCoverage113.cons _ _ compact113_node_3743
    (ChildrenCoverage113.cons _ _ compact113_node_3744
    (ChildrenCoverage113.cons _ _ compact113_node_3745
    (ChildrenCoverage113.cons _ _ compact113_node_3746
    (ChildrenCoverage113.cons _ _ compact113_node_3747
    (ChildrenCoverage113.cons _ _ compact113_node_3748
    (ChildrenCoverage113.cons _ _ compact113_node_3749
    (ChildrenCoverage113.cons _ _ compact113_node_3750
    (ChildrenCoverage113.cons _ _ compact113_node_3751
    (ChildrenCoverage113.cons _ _ compact113_node_3752
    (ChildrenCoverage113.cons _ _ compact113_node_3753
    (ChildrenCoverage113.cons _ _ compact113_node_3754
    (ChildrenCoverage113.cons _ _ compact113_node_3765
    (ChildrenCoverage113.cons _ _ compact113_node_3766
    (ChildrenCoverage113.cons _ _ compact113_node_3767
    (ChildrenCoverage113.cons _ _ compact113_node_3768
    ChildrenCoverage113.nil))))))))))))))))))

theorem compact113_node_3770 : NodeCoverage113 [21,21,21,20] 20 30 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3771 : NodeCoverage113 [21,21,21,19] 19 31 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

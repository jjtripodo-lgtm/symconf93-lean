import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0526 : NodeCoverage113 [56,21] 21 36 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0527 : NodeCoverage113 [56,20] 20 37 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0528 : NodeCoverage113 [56,19] 19 38 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0529 : NodeCoverage113 [56,18] 18 39 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0530 : NodeCoverage113 [56,17] 17 40 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0531 : NodeCoverage113 [56,16] 16 41 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0532 : NodeCoverage113 [56,15] 15 42 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0533 : NodeCoverage113 [56,14,14,14,12] 12 3 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0534 : NodeCoverage113 [56,14,14,14,11] 11 4 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0535 : NodeCoverage113 [56,14,14,14,10] 10 5 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0536 : NodeCoverage113 [56,14,14,14,9] 9 6 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0537 : NodeCoverage113 [56,14,14,14,8] 8 7 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0538 : NodeCoverage113 [56,14,14,14,7] 7 8 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0539 : NodeCoverage113 [56,14,14,14,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0540 : NodeCoverage113 [56,14,14,14,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0541 : NodeCoverage113 [56,14,14,14,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0542 : NodeCoverage113 [56,14,14,14] 14 15 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0533
    (ChildrenCoverage113.cons _ _ compact113_node_0534
    (ChildrenCoverage113.cons _ _ compact113_node_0535
    (ChildrenCoverage113.cons _ _ compact113_node_0536
    (ChildrenCoverage113.cons _ _ compact113_node_0537
    (ChildrenCoverage113.cons _ _ compact113_node_0538
    (ChildrenCoverage113.cons _ _ compact113_node_0539
    (ChildrenCoverage113.cons _ _ compact113_node_0540
    (ChildrenCoverage113.cons _ _ compact113_node_0541
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_0543 : NodeCoverage113 [56,14,14,13] 13 16 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0544 : NodeCoverage113 [56,14,14,12] 12 17 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0545 : NodeCoverage113 [56,14,14,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0546 : NodeCoverage113 [56,14,14,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0547 : NodeCoverage113 [56,14,14,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0548 : NodeCoverage113 [56,14,14,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0549 : NodeCoverage113 [56,14,14,7] 7 22 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0550 : NodeCoverage113 [56,14,14,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0551 : NodeCoverage113 [56,14,14,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0552 : NodeCoverage113 [56,14,14,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0553 : NodeCoverage113 [56,14,14] 14 29 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0542
    (ChildrenCoverage113.cons _ _ compact113_node_0543
    (ChildrenCoverage113.cons _ _ compact113_node_0544
    (ChildrenCoverage113.cons _ _ compact113_node_0545
    (ChildrenCoverage113.cons _ _ compact113_node_0546
    (ChildrenCoverage113.cons _ _ compact113_node_0547
    (ChildrenCoverage113.cons _ _ compact113_node_0548
    (ChildrenCoverage113.cons _ _ compact113_node_0549
    (ChildrenCoverage113.cons _ _ compact113_node_0550
    (ChildrenCoverage113.cons _ _ compact113_node_0551
    (ChildrenCoverage113.cons _ _ compact113_node_0552
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_0554 : NodeCoverage113 [56,14,13] 13 30 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0555 : NodeCoverage113 [56,14,12] 12 31 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0556 : NodeCoverage113 [56,14,11] 11 32 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0557 : NodeCoverage113 [56,14,10] 10 33 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0558 : NodeCoverage113 [56,14,9] 9 34 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0559 : NodeCoverage113 [56,14,8] 8 35 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0560 : NodeCoverage113 [56,14,7] 7 36 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0561 : NodeCoverage113 [56,14,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0562 : NodeCoverage113 [56,14,5] 5 38 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0563 : NodeCoverage113 [56,14,3] 3 40 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0564 : NodeCoverage113 [56,14] 14 43 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0553
    (ChildrenCoverage113.cons _ _ compact113_node_0554
    (ChildrenCoverage113.cons _ _ compact113_node_0555
    (ChildrenCoverage113.cons _ _ compact113_node_0556
    (ChildrenCoverage113.cons _ _ compact113_node_0557
    (ChildrenCoverage113.cons _ _ compact113_node_0558
    (ChildrenCoverage113.cons _ _ compact113_node_0559
    (ChildrenCoverage113.cons _ _ compact113_node_0560
    (ChildrenCoverage113.cons _ _ compact113_node_0561
    (ChildrenCoverage113.cons _ _ compact113_node_0562
    (ChildrenCoverage113.cons _ _ compact113_node_0563
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_0565 : NodeCoverage113 [56,13] 13 44 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0566 : NodeCoverage113 [56,12] 12 45 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0567 : NodeCoverage113 [56,11] 11 46 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0568 : NodeCoverage113 [56,10] 10 47 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0569 : NodeCoverage113 [56,9] 9 48 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0570 : NodeCoverage113 [56,8] 8 49 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0571 : NodeCoverage113 [56,7] 7 50 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0572 : NodeCoverage113 [56,6] 6 51 :=
  demand_node_prune113 56 compact113_demands_056 compact113_demands_056_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0573 : NodeCoverage113 [56,5] 5 52 :=
  demand_node_prune113 56 compact113_demands_056 compact113_demands_056_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

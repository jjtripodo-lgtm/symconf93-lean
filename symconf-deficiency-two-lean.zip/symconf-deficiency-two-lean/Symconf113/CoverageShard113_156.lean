import Symconf113.CoverageShard113_155

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_6756 : NodeCoverage113 [10,10,10,10,10,10,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6757 : NodeCoverage113 [10,10,10,10,10,10,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6758 : NodeCoverage113 [10,10,10,10,10,10,6] 6 47 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6759 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,5,5,5,5,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6760 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,5,5,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6759
    ChildrenCoverage113.nil)

theorem compact113_node_6761 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,5,5,5,5,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6762 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,5,5,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6760
    (ChildrenCoverage113.cons _ _ compact113_node_6761
    ChildrenCoverage113.nil))

theorem compact113_node_6763 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,5,5,5,5,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6764 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,5,5,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6762
    (ChildrenCoverage113.cons _ _ compact113_node_6763
    ChildrenCoverage113.nil))

theorem compact113_node_6765 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,5,5,5,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6766 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,5,5,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6764
    (ChildrenCoverage113.cons _ _ compact113_node_6765
    ChildrenCoverage113.nil))

theorem compact113_node_6767 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,5,5,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6768 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,5,5] 5 23 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6766
    (ChildrenCoverage113.cons _ _ compact113_node_6767
    ChildrenCoverage113.nil))

theorem compact113_node_6769 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,5,3] 3 25 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6770 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,5] 5 28 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6768
    (ChildrenCoverage113.cons _ _ compact113_node_6769
    ChildrenCoverage113.nil))

theorem compact113_node_6771 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3] 3 0 :=
  node_no_weak_demand113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6772 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,3,3,3,3,3,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6771
    ChildrenCoverage113.nil)

theorem compact113_node_6773 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,3,3,3,3,3,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6772
    ChildrenCoverage113.nil)

theorem compact113_node_6774 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,3,3,3,3,3,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6773
    ChildrenCoverage113.nil)

theorem compact113_node_6775 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,3,3,3,3,3,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6774
    ChildrenCoverage113.nil)

theorem compact113_node_6776 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,3,3,3,3,3,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6775
    ChildrenCoverage113.nil)

theorem compact113_node_6777 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,3,3,3,3,3] 3 18 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6776
    ChildrenCoverage113.nil)

theorem compact113_node_6778 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,3,3,3,3] 3 21 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6777
    ChildrenCoverage113.nil)

theorem compact113_node_6779 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,3,3,3] 3 24 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6778
    ChildrenCoverage113.nil)

theorem compact113_node_6780 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,3,3] 3 27 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6779
    ChildrenCoverage113.nil)

theorem compact113_node_6781 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5,3] 3 30 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6780
    ChildrenCoverage113.nil)

theorem compact113_node_6782 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,5] 5 33 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6770
    (ChildrenCoverage113.cons _ _ compact113_node_6781
    ChildrenCoverage113.nil))

theorem compact113_node_6783 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,3,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6784 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,3,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6783
    ChildrenCoverage113.nil)

theorem compact113_node_6785 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,3,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6784
    ChildrenCoverage113.nil)

theorem compact113_node_6786 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,3,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6785
    ChildrenCoverage113.nil)

theorem compact113_node_6787 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,3,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6786
    ChildrenCoverage113.nil)

theorem compact113_node_6788 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,3,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6787
    ChildrenCoverage113.nil)

theorem compact113_node_6789 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,3,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6788
    ChildrenCoverage113.nil)

theorem compact113_node_6790 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,3,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6789
    ChildrenCoverage113.nil)

theorem compact113_node_6791 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,3,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6790
    ChildrenCoverage113.nil)

theorem compact113_node_6792 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,3,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6791
    ChildrenCoverage113.nil)

theorem compact113_node_6793 : NodeCoverage113 [10,10,10,10,10,10,5,5,5,3] 3 35 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6792
    ChildrenCoverage113.nil)

theorem compact113_node_6794 : NodeCoverage113 [10,10,10,10,10,10,5,5,5] 5 38 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6782
    (ChildrenCoverage113.cons _ _ compact113_node_6793
    ChildrenCoverage113.nil))

theorem compact113_node_6795 : NodeCoverage113 [10,10,10,10,10,10,5,5,3] 3 40 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6796 : NodeCoverage113 [10,10,10,10,10,10,5,5] 5 43 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6794
    (ChildrenCoverage113.cons _ _ compact113_node_6795
    ChildrenCoverage113.nil))

theorem compact113_node_6797 : NodeCoverage113 [10,10,10,10,10,10,5,3] 3 45 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6798 : NodeCoverage113 [10,10,10,10,10,10,5] 5 48 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6796
    (ChildrenCoverage113.cons _ _ compact113_node_6797
    ChildrenCoverage113.nil))

theorem compact113_node_6799 : NodeCoverage113 [10,10,10,10,10,10,3] 3 50 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6800 : NodeCoverage113 [10,10,10,10,10,10] 10 53 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6754
    (ChildrenCoverage113.cons _ _ compact113_node_6755
    (ChildrenCoverage113.cons _ _ compact113_node_6756
    (ChildrenCoverage113.cons _ _ compact113_node_6757
    (ChildrenCoverage113.cons _ _ compact113_node_6758
    (ChildrenCoverage113.cons _ _ compact113_node_6798
    (ChildrenCoverage113.cons _ _ compact113_node_6799
    ChildrenCoverage113.nil)))))))

theorem compact113_node_6801 : NodeCoverage113 [10,10,10,10,10,9] 9 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6802 : NodeCoverage113 [10,10,10,10,10,8] 8 55 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6803 : NodeCoverage113 [10,10,10,10,10,7,7,7,7,7,7] 7 21 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6804 : NodeCoverage113 [10,10,10,10,10,7,7,7,7,7,6] 6 22 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6805 : NodeCoverage113 [10,10,10,10,10,7,7,7,7,7,5] 5 23 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6806 : NodeCoverage113 [10,10,10,10,10,7,7,7,7,7,3] 3 25 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6807 : NodeCoverage113 [10,10,10,10,10,7,7,7,7,7] 7 28 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6803
    (ChildrenCoverage113.cons _ _ compact113_node_6804
    (ChildrenCoverage113.cons _ _ compact113_node_6805
    (ChildrenCoverage113.cons _ _ compact113_node_6806
    ChildrenCoverage113.nil))))

theorem compact113_node_6808 : NodeCoverage113 [10,10,10,10,10,7,7,7,7,6] 6 29 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6809 : NodeCoverage113 [10,10,10,10,10,7,7,7,7,5] 5 30 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6810 : NodeCoverage113 [10,10,10,10,10,7,7,7,7,3] 3 32 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6811 : NodeCoverage113 [10,10,10,10,10,7,7,7,7] 7 35 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6807
    (ChildrenCoverage113.cons _ _ compact113_node_6808
    (ChildrenCoverage113.cons _ _ compact113_node_6809
    (ChildrenCoverage113.cons _ _ compact113_node_6810
    ChildrenCoverage113.nil))))

theorem compact113_node_6812 : NodeCoverage113 [10,10,10,10,10,7,7,7,6] 6 36 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6813 : NodeCoverage113 [10,10,10,10,10,7,7,7,5] 5 37 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6814 : NodeCoverage113 [10,10,10,10,10,7,7,7,3] 3 39 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6815 : NodeCoverage113 [10,10,10,10,10,7,7,7] 7 42 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6811
    (ChildrenCoverage113.cons _ _ compact113_node_6812
    (ChildrenCoverage113.cons _ _ compact113_node_6813
    (ChildrenCoverage113.cons _ _ compact113_node_6814
    ChildrenCoverage113.nil))))

theorem compact113_node_6816 : NodeCoverage113 [10,10,10,10,10,7,7,6] 6 43 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6817 : NodeCoverage113 [10,10,10,10,10,7,7,5] 5 44 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6818 : NodeCoverage113 [10,10,10,10,10,7,7,3] 3 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6819 : NodeCoverage113 [10,10,10,10,10,7,7] 7 49 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6815
    (ChildrenCoverage113.cons _ _ compact113_node_6816
    (ChildrenCoverage113.cons _ _ compact113_node_6817
    (ChildrenCoverage113.cons _ _ compact113_node_6818
    ChildrenCoverage113.nil))))

theorem compact113_node_6820 : NodeCoverage113 [10,10,10,10,10,7,6] 6 50 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6821 : NodeCoverage113 [10,10,10,10,10,7,5] 5 51 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6822 : NodeCoverage113 [10,10,10,10,10,7,3] 3 53 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6823 : NodeCoverage113 [10,10,10,10,10,7] 7 56 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6819
    (ChildrenCoverage113.cons _ _ compact113_node_6820
    (ChildrenCoverage113.cons _ _ compact113_node_6821
    (ChildrenCoverage113.cons _ _ compact113_node_6822
    ChildrenCoverage113.nil))))

theorem compact113_node_6824 : NodeCoverage113 [10,10,10,10,10,6,6,6,6,6,6,6] 6 21 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6825 : NodeCoverage113 [10,10,10,10,10,6,6,6,6,6,6,5] 5 22 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6826 : NodeCoverage113 [10,10,10,10,10,6,6,6,6,6,6,3] 3 24 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6827 : NodeCoverage113 [10,10,10,10,10,6,6,6,6,6,6] 6 27 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6824
    (ChildrenCoverage113.cons _ _ compact113_node_6825
    (ChildrenCoverage113.cons _ _ compact113_node_6826
    ChildrenCoverage113.nil)))

theorem compact113_node_6828 : NodeCoverage113 [10,10,10,10,10,6,6,6,6,6,5] 5 28 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6829 : NodeCoverage113 [10,10,10,10,10,6,6,6,6,6,3] 3 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6830 : NodeCoverage113 [10,10,10,10,10,6,6,6,6,6] 6 33 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6827
    (ChildrenCoverage113.cons _ _ compact113_node_6828
    (ChildrenCoverage113.cons _ _ compact113_node_6829
    ChildrenCoverage113.nil)))

end Symconf113

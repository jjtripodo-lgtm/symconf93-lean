import Symconf113.CoverageShard113_151

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_6490 : NodeCoverage113 [12,12,9,7] 7 73 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6491 : NodeCoverage113 [12,12,9,6] 6 74 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6492 : NodeCoverage113 [12,12,9,5] 5 75 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6493 : NodeCoverage113 [12,12,9,3] 3 77 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6494 : NodeCoverage113 [12,12,9] 9 80 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6488
    (ChildrenCoverage113.cons _ _ compact113_node_6489
    (ChildrenCoverage113.cons _ _ compact113_node_6490
    (ChildrenCoverage113.cons _ _ compact113_node_6491
    (ChildrenCoverage113.cons _ _ compact113_node_6492
    (ChildrenCoverage113.cons _ _ compact113_node_6493
    ChildrenCoverage113.nil))))))

theorem compact113_node_6495 : NodeCoverage113 [12,12,8] 8 81 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6496 : NodeCoverage113 [12,12,7,7,7,7,7,7] 7 47 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6497 : NodeCoverage113 [12,12,7,7,7,7,7,6] 6 48 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6498 : NodeCoverage113 [12,12,7,7,7,7,7,5] 5 49 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6499 : NodeCoverage113 [12,12,7,7,7,7,7,3] 3 51 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6500 : NodeCoverage113 [12,12,7,7,7,7,7] 7 54 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6496
    (ChildrenCoverage113.cons _ _ compact113_node_6497
    (ChildrenCoverage113.cons _ _ compact113_node_6498
    (ChildrenCoverage113.cons _ _ compact113_node_6499
    ChildrenCoverage113.nil))))

theorem compact113_node_6501 : NodeCoverage113 [12,12,7,7,7,7,6] 6 55 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6502 : NodeCoverage113 [12,12,7,7,7,7,5] 5 56 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6503 : NodeCoverage113 [12,12,7,7,7,7,3] 3 58 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6504 : NodeCoverage113 [12,12,7,7,7,7] 7 61 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6500
    (ChildrenCoverage113.cons _ _ compact113_node_6501
    (ChildrenCoverage113.cons _ _ compact113_node_6502
    (ChildrenCoverage113.cons _ _ compact113_node_6503
    ChildrenCoverage113.nil))))

theorem compact113_node_6505 : NodeCoverage113 [12,12,7,7,7,6] 6 62 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6506 : NodeCoverage113 [12,12,7,7,7,5] 5 63 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6507 : NodeCoverage113 [12,12,7,7,7,3] 3 65 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6508 : NodeCoverage113 [12,12,7,7,7] 7 68 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6504
    (ChildrenCoverage113.cons _ _ compact113_node_6505
    (ChildrenCoverage113.cons _ _ compact113_node_6506
    (ChildrenCoverage113.cons _ _ compact113_node_6507
    ChildrenCoverage113.nil))))

theorem compact113_node_6509 : NodeCoverage113 [12,12,7,7,6] 6 69 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6510 : NodeCoverage113 [12,12,7,7,5] 5 70 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6511 : NodeCoverage113 [12,12,7,7,3] 3 72 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6512 : NodeCoverage113 [12,12,7,7] 7 75 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6508
    (ChildrenCoverage113.cons _ _ compact113_node_6509
    (ChildrenCoverage113.cons _ _ compact113_node_6510
    (ChildrenCoverage113.cons _ _ compact113_node_6511
    ChildrenCoverage113.nil))))

theorem compact113_node_6513 : NodeCoverage113 [12,12,7,6] 6 76 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6514 : NodeCoverage113 [12,12,7,5] 5 77 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6515 : NodeCoverage113 [12,12,7,3] 3 79 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6516 : NodeCoverage113 [12,12,7] 7 82 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6512
    (ChildrenCoverage113.cons _ _ compact113_node_6513
    (ChildrenCoverage113.cons _ _ compact113_node_6514
    (ChildrenCoverage113.cons _ _ compact113_node_6515
    ChildrenCoverage113.nil))))

theorem compact113_node_6517 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6518 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6517
    ChildrenCoverage113.nil)

theorem compact113_node_6519 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6520 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6521 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6520
    ChildrenCoverage113.nil)

theorem compact113_node_6522 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6518
    (ChildrenCoverage113.cons _ _ compact113_node_6519
    (ChildrenCoverage113.cons _ _ compact113_node_6521
    ChildrenCoverage113.nil)))

theorem compact113_node_6523 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6524 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6525 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,6,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6524
    ChildrenCoverage113.nil)

theorem compact113_node_6526 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,6,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6525
    ChildrenCoverage113.nil)

theorem compact113_node_6527 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,6,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6526
    ChildrenCoverage113.nil)

theorem compact113_node_6528 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6522
    (ChildrenCoverage113.cons _ _ compact113_node_6523
    (ChildrenCoverage113.cons _ _ compact113_node_6527
    ChildrenCoverage113.nil)))

theorem compact113_node_6529 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6530 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6531 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6530
    ChildrenCoverage113.nil)

theorem compact113_node_6532 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6531
    ChildrenCoverage113.nil)

theorem compact113_node_6533 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6532
    ChildrenCoverage113.nil)

theorem compact113_node_6534 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6533
    ChildrenCoverage113.nil)

theorem compact113_node_6535 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6534
    ChildrenCoverage113.nil)

theorem compact113_node_6536 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,6] 6 23 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6528
    (ChildrenCoverage113.cons _ _ compact113_node_6529
    (ChildrenCoverage113.cons _ _ compact113_node_6535
    ChildrenCoverage113.nil)))

theorem compact113_node_6537 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6538 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6539 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6538
    ChildrenCoverage113.nil)

theorem compact113_node_6540 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6539
    ChildrenCoverage113.nil)

theorem compact113_node_6541 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6540
    ChildrenCoverage113.nil)

theorem compact113_node_6542 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6541
    ChildrenCoverage113.nil)

theorem compact113_node_6543 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6542
    ChildrenCoverage113.nil)

theorem compact113_node_6544 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6543
    ChildrenCoverage113.nil)

theorem compact113_node_6545 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6544
    ChildrenCoverage113.nil)

theorem compact113_node_6546 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,6] 6 29 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6536
    (ChildrenCoverage113.cons _ _ compact113_node_6537
    (ChildrenCoverage113.cons _ _ compact113_node_6545
    ChildrenCoverage113.nil)))

theorem compact113_node_6547 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6548 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6549 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6548
    ChildrenCoverage113.nil)

theorem compact113_node_6550 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6549
    ChildrenCoverage113.nil)

theorem compact113_node_6551 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6550
    ChildrenCoverage113.nil)

theorem compact113_node_6552 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6551
    ChildrenCoverage113.nil)

theorem compact113_node_6553 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6552
    ChildrenCoverage113.nil)

theorem compact113_node_6554 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6553
    ChildrenCoverage113.nil)

theorem compact113_node_6555 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6554
    ChildrenCoverage113.nil)

theorem compact113_node_6556 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6555
    ChildrenCoverage113.nil)

theorem compact113_node_6557 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6556
    ChildrenCoverage113.nil)

theorem compact113_node_6558 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,6] 6 35 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6546
    (ChildrenCoverage113.cons _ _ compact113_node_6547
    (ChildrenCoverage113.cons _ _ compact113_node_6557
    ChildrenCoverage113.nil)))

theorem compact113_node_6559 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6560 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6,3] 3 38 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6561 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,6] 6 41 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6558
    (ChildrenCoverage113.cons _ _ compact113_node_6559
    (ChildrenCoverage113.cons _ _ compact113_node_6560
    ChildrenCoverage113.nil)))

theorem compact113_node_6562 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,5] 5 42 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6563 : NodeCoverage113 [12,12,6,6,6,6,6,6,6,3] 3 44 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6564 : NodeCoverage113 [12,12,6,6,6,6,6,6,6] 6 47 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6561
    (ChildrenCoverage113.cons _ _ compact113_node_6562
    (ChildrenCoverage113.cons _ _ compact113_node_6563
    ChildrenCoverage113.nil)))

end Symconf113

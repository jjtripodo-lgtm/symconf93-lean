import Symconf113.CoverageShard113_024

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1054 : NodeCoverage113 [42,42,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1055 : NodeCoverage113 [42,42,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1053
    (ChildrenCoverage113.cons _ _ compact113_node_1054
    ChildrenCoverage113.nil))

theorem compact113_node_1056 : NodeCoverage113 [42,42,7,7,6] 6 9 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1057 : NodeCoverage113 [42,42,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1058 : NodeCoverage113 [42,42,7,7,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1059 : NodeCoverage113 [42,42,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1055
    (ChildrenCoverage113.cons _ _ compact113_node_1056
    (ChildrenCoverage113.cons _ _ compact113_node_1057
    (ChildrenCoverage113.cons _ _ compact113_node_1058
    ChildrenCoverage113.nil))))

theorem compact113_node_1060 : NodeCoverage113 [42,42,7,6] 6 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1061 : NodeCoverage113 [42,42,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1062 : NodeCoverage113 [42,42,7,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1063 : NodeCoverage113 [42,42,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1059
    (ChildrenCoverage113.cons _ _ compact113_node_1060
    (ChildrenCoverage113.cons _ _ compact113_node_1061
    (ChildrenCoverage113.cons _ _ compact113_node_1062
    ChildrenCoverage113.nil))))

theorem compact113_node_1064 : NodeCoverage113 [42,42,6] 6 23 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1065 : NodeCoverage113 [42,42,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1066 : NodeCoverage113 [42,42,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1067 : NodeCoverage113 [42,42] 42 29 :=
  node_fork113 (B := [29,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1030
    (ChildrenCoverage113.cons _ _ compact113_node_1031
    (ChildrenCoverage113.cons _ _ compact113_node_1032
    (ChildrenCoverage113.cons _ _ compact113_node_1033
    (ChildrenCoverage113.cons _ _ compact113_node_1034
    (ChildrenCoverage113.cons _ _ compact113_node_1035
    (ChildrenCoverage113.cons _ _ compact113_node_1039
    (ChildrenCoverage113.cons _ _ compact113_node_1040
    (ChildrenCoverage113.cons _ _ compact113_node_1041
    (ChildrenCoverage113.cons _ _ compact113_node_1042
    (ChildrenCoverage113.cons _ _ compact113_node_1043
    (ChildrenCoverage113.cons _ _ compact113_node_1044
    (ChildrenCoverage113.cons _ _ compact113_node_1045
    (ChildrenCoverage113.cons _ _ compact113_node_1046
    (ChildrenCoverage113.cons _ _ compact113_node_1047
    (ChildrenCoverage113.cons _ _ compact113_node_1048
    (ChildrenCoverage113.cons _ _ compact113_node_1049
    (ChildrenCoverage113.cons _ _ compact113_node_1050
    (ChildrenCoverage113.cons _ _ compact113_node_1051
    (ChildrenCoverage113.cons _ _ compact113_node_1052
    (ChildrenCoverage113.cons _ _ compact113_node_1063
    (ChildrenCoverage113.cons _ _ compact113_node_1064
    (ChildrenCoverage113.cons _ _ compact113_node_1065
    (ChildrenCoverage113.cons _ _ compact113_node_1066
    ChildrenCoverage113.nil))))))))))))))))))))))))

theorem compact113_node_1068 : NodeCoverage113 [42,41] 41 30 :=
  demand_node_prune113 41 compact113_demands_041 compact113_demands_041_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1069 : NodeCoverage113 [42,40] 40 31 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1070 : NodeCoverage113 [42,39] 39 32 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1071 : NodeCoverage113 [42,38] 38 33 :=
  demand_node_prune113 38 compact113_demands_038 compact113_demands_038_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1072 : NodeCoverage113 [42,37] 37 34 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1073 : NodeCoverage113 [42,36] 36 35 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1074 : NodeCoverage113 [42,35] 35 36 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1075 : NodeCoverage113 [42,34] 34 37 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1076 : NodeCoverage113 [42,33] 33 38 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1077 : NodeCoverage113 [42,32] 32 39 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1078 : NodeCoverage113 [42,31] 31 40 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1079 : NodeCoverage113 [42,30] 30 41 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1080 : NodeCoverage113 [42,29] 29 42 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1081 : NodeCoverage113 [42,28] 28 43 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1082 : NodeCoverage113 [42,27] 27 44 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1083 : NodeCoverage113 [42,26] 26 45 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1084 : NodeCoverage113 [42,25] 25 46 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1085 : NodeCoverage113 [42,24] 24 47 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1086 : NodeCoverage113 [42,23] 23 48 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1087 : NodeCoverage113 [42,22] 22 49 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1088 : NodeCoverage113 [42,21] 21 50 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1089 : NodeCoverage113 [42,20] 20 51 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1090 : NodeCoverage113 [42,19] 19 52 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

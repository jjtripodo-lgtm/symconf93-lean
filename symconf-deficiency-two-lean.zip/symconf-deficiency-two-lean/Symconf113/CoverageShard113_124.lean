import Symconf113.CoverageShard113_123

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4805 : NodeCoverage113 [18,14,9,3] 3 69 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4806 : NodeCoverage113 [18,14,9] 9 72 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4800
    (ChildrenCoverage113.cons _ _ compact113_node_4801
    (ChildrenCoverage113.cons _ _ compact113_node_4802
    (ChildrenCoverage113.cons _ _ compact113_node_4803
    (ChildrenCoverage113.cons _ _ compact113_node_4804
    (ChildrenCoverage113.cons _ _ compact113_node_4805
    ChildrenCoverage113.nil))))))

theorem compact113_node_4807 : NodeCoverage113 [18,14,8] 8 73 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4808 : NodeCoverage113 [18,14,7] 7 74 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4809 : NodeCoverage113 [18,14,6] 6 75 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4810 : NodeCoverage113 [18,14,5] 5 76 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4811 : NodeCoverage113 [18,14,3] 3 78 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4812 : NodeCoverage113 [18,14] 14 81 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4765
    (ChildrenCoverage113.cons _ _ compact113_node_4766
    (ChildrenCoverage113.cons _ _ compact113_node_4776
    (ChildrenCoverage113.cons _ _ compact113_node_4785
    (ChildrenCoverage113.cons _ _ compact113_node_4793
    (ChildrenCoverage113.cons _ _ compact113_node_4806
    (ChildrenCoverage113.cons _ _ compact113_node_4807
    (ChildrenCoverage113.cons _ _ compact113_node_4808
    (ChildrenCoverage113.cons _ _ compact113_node_4809
    (ChildrenCoverage113.cons _ _ compact113_node_4810
    (ChildrenCoverage113.cons _ _ compact113_node_4811
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_4813 : NodeCoverage113 [18,13,13,13] 13 56 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4814 : NodeCoverage113 [18,13,13,12] 12 57 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4815 : NodeCoverage113 [18,13,13,11] 11 58 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4816 : NodeCoverage113 [18,13,13,10] 10 59 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4817 : NodeCoverage113 [18,13,13,9] 9 60 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4818 : NodeCoverage113 [18,13,13,8] 8 61 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4819 : NodeCoverage113 [18,13,13,7] 7 62 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4820 : NodeCoverage113 [18,13,13,6] 6 63 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4821 : NodeCoverage113 [18,13,13,5] 5 64 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4822 : NodeCoverage113 [18,13,13,3] 3 66 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4823 : NodeCoverage113 [18,13,13] 13 69 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4813
    (ChildrenCoverage113.cons _ _ compact113_node_4814
    (ChildrenCoverage113.cons _ _ compact113_node_4815
    (ChildrenCoverage113.cons _ _ compact113_node_4816
    (ChildrenCoverage113.cons _ _ compact113_node_4817
    (ChildrenCoverage113.cons _ _ compact113_node_4818
    (ChildrenCoverage113.cons _ _ compact113_node_4819
    (ChildrenCoverage113.cons _ _ compact113_node_4820
    (ChildrenCoverage113.cons _ _ compact113_node_4821
    (ChildrenCoverage113.cons _ _ compact113_node_4822
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_4824 : NodeCoverage113 [18,13,12] 12 70 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4825 : NodeCoverage113 [18,13,11] 11 71 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4826 : NodeCoverage113 [18,13,10] 10 72 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4827 : NodeCoverage113 [18,13,9] 9 73 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4828 : NodeCoverage113 [18,13,8] 8 74 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4829 : NodeCoverage113 [18,13,7] 7 75 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4830 : NodeCoverage113 [18,13,6] 6 76 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4831 : NodeCoverage113 [18,13,5] 5 77 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4832 : NodeCoverage113 [18,13,3] 3 79 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4833 : NodeCoverage113 [18,13] 13 82 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4823
    (ChildrenCoverage113.cons _ _ compact113_node_4824
    (ChildrenCoverage113.cons _ _ compact113_node_4825
    (ChildrenCoverage113.cons _ _ compact113_node_4826
    (ChildrenCoverage113.cons _ _ compact113_node_4827
    (ChildrenCoverage113.cons _ _ compact113_node_4828
    (ChildrenCoverage113.cons _ _ compact113_node_4829
    (ChildrenCoverage113.cons _ _ compact113_node_4830
    (ChildrenCoverage113.cons _ _ compact113_node_4831
    (ChildrenCoverage113.cons _ _ compact113_node_4832
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_4834 : NodeCoverage113 [18,12,12,12] 12 59 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4835 : NodeCoverage113 [18,12,12,11] 11 60 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4836 : NodeCoverage113 [18,12,12,10] 10 61 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4837 : NodeCoverage113 [18,12,12,9,9] 9 53 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4838 : NodeCoverage113 [18,12,12,9,8] 8 54 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4839 : NodeCoverage113 [18,12,12,9,7] 7 55 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4840 : NodeCoverage113 [18,12,12,9,6] 6 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4841 : NodeCoverage113 [18,12,12,9,5] 5 57 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4842 : NodeCoverage113 [18,12,12,9,3] 3 59 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4843 : NodeCoverage113 [18,12,12,9] 9 62 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4837
    (ChildrenCoverage113.cons _ _ compact113_node_4838
    (ChildrenCoverage113.cons _ _ compact113_node_4839
    (ChildrenCoverage113.cons _ _ compact113_node_4840
    (ChildrenCoverage113.cons _ _ compact113_node_4841
    (ChildrenCoverage113.cons _ _ compact113_node_4842
    ChildrenCoverage113.nil))))))

theorem compact113_node_4844 : NodeCoverage113 [18,12,12,8] 8 63 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4845 : NodeCoverage113 [18,12,12,7] 7 64 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4846 : NodeCoverage113 [18,12,12,6] 6 65 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4847 : NodeCoverage113 [18,12,12,5] 5 66 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4848 : NodeCoverage113 [18,12,12,3] 3 68 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4849 : NodeCoverage113 [18,12,12] 12 71 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4834
    (ChildrenCoverage113.cons _ _ compact113_node_4835
    (ChildrenCoverage113.cons _ _ compact113_node_4836
    (ChildrenCoverage113.cons _ _ compact113_node_4843
    (ChildrenCoverage113.cons _ _ compact113_node_4844
    (ChildrenCoverage113.cons _ _ compact113_node_4845
    (ChildrenCoverage113.cons _ _ compact113_node_4846
    (ChildrenCoverage113.cons _ _ compact113_node_4847
    (ChildrenCoverage113.cons _ _ compact113_node_4848
    ChildrenCoverage113.nil)))))))))

end Symconf113

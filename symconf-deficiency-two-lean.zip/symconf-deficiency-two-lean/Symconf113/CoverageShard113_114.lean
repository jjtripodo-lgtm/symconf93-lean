import Symconf113.CoverageShard113_110
import Symconf113.CoverageShard113_111
import Symconf113.CoverageShard113_112
import Symconf113.CoverageShard113_113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4263 : NodeCoverage113 [20,10,10,10,9] 9 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4264 : NodeCoverage113 [20,10,10,10,8] 8 55 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4265 : NodeCoverage113 [20,10,10,10,7] 7 56 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4266 : NodeCoverage113 [20,10,10,10,6] 6 57 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4267 : NodeCoverage113 [20,10,10,10,5] 5 58 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4268 : NodeCoverage113 [20,10,10,10,3] 3 60 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4269 : NodeCoverage113 [20,10,10,10] 10 63 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4262
    (ChildrenCoverage113.cons _ _ compact113_node_4263
    (ChildrenCoverage113.cons _ _ compact113_node_4264
    (ChildrenCoverage113.cons _ _ compact113_node_4265
    (ChildrenCoverage113.cons _ _ compact113_node_4266
    (ChildrenCoverage113.cons _ _ compact113_node_4267
    (ChildrenCoverage113.cons _ _ compact113_node_4268
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4270 : NodeCoverage113 [20,10,10,9] 9 64 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4271 : NodeCoverage113 [20,10,10,8] 8 65 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4272 : NodeCoverage113 [20,10,10,7] 7 66 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4273 : NodeCoverage113 [20,10,10,6] 6 67 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4274 : NodeCoverage113 [20,10,10,5] 5 68 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4275 : NodeCoverage113 [20,10,10,3] 3 70 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4276 : NodeCoverage113 [20,10,10] 10 73 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4269
    (ChildrenCoverage113.cons _ _ compact113_node_4270
    (ChildrenCoverage113.cons _ _ compact113_node_4271
    (ChildrenCoverage113.cons _ _ compact113_node_4272
    (ChildrenCoverage113.cons _ _ compact113_node_4273
    (ChildrenCoverage113.cons _ _ compact113_node_4274
    (ChildrenCoverage113.cons _ _ compact113_node_4275
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4277 : NodeCoverage113 [20,10,9] 9 74 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4278 : NodeCoverage113 [20,10,8] 8 75 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4279 : NodeCoverage113 [20,10,7] 7 76 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4280 : NodeCoverage113 [20,10,6] 6 77 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4281 : NodeCoverage113 [20,10,5] 5 78 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4282 : NodeCoverage113 [20,10,3] 3 80 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4283 : NodeCoverage113 [20,10] 10 83 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4276
    (ChildrenCoverage113.cons _ _ compact113_node_4277
    (ChildrenCoverage113.cons _ _ compact113_node_4278
    (ChildrenCoverage113.cons _ _ compact113_node_4279
    (ChildrenCoverage113.cons _ _ compact113_node_4280
    (ChildrenCoverage113.cons _ _ compact113_node_4281
    (ChildrenCoverage113.cons _ _ compact113_node_4282
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4284 : NodeCoverage113 [20,9] 9 84 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4285 : NodeCoverage113 [20,8] 8 85 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4286 : NodeCoverage113 [20,7] 7 86 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4287 : NodeCoverage113 [20,6] 6 87 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4288 : NodeCoverage113 [20,5] 5 88 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4289 : NodeCoverage113 [20,3] 3 90 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4290 : NodeCoverage113 [20] 20 93 :=
  node_fork113 (B := [20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4107
    (ChildrenCoverage113.cons _ _ compact113_node_4108
    (ChildrenCoverage113.cons _ _ compact113_node_4124
    (ChildrenCoverage113.cons _ _ compact113_node_4139
    (ChildrenCoverage113.cons _ _ compact113_node_4153
    (ChildrenCoverage113.cons _ _ compact113_node_4166
    (ChildrenCoverage113.cons _ _ compact113_node_4185
    (ChildrenCoverage113.cons _ _ compact113_node_4196
    (ChildrenCoverage113.cons _ _ compact113_node_4206
    (ChildrenCoverage113.cons _ _ compact113_node_4215
    (ChildrenCoverage113.cons _ _ compact113_node_4283
    (ChildrenCoverage113.cons _ _ compact113_node_4284
    (ChildrenCoverage113.cons _ _ compact113_node_4285
    (ChildrenCoverage113.cons _ _ compact113_node_4286
    (ChildrenCoverage113.cons _ _ compact113_node_4287
    (ChildrenCoverage113.cons _ _ compact113_node_4288
    (ChildrenCoverage113.cons _ _ compact113_node_4289
    ChildrenCoverage113.nil)))))))))))))))))

theorem compact113_node_4291 : NodeCoverage113 [19,19,19,19,19,18] 18 0 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4292 : NodeCoverage113 [19,19,19,19,19,15] 15 3 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4293 : NodeCoverage113 [19,19,19,19,19,14] 14 4 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4294 : NodeCoverage113 [19,19,19,19,19,13] 13 5 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4295 : NodeCoverage113 [19,19,19,19,19,12] 12 6 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4296 : NodeCoverage113 [19,19,19,19,19,11] 11 7 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4297 : NodeCoverage113 [19,19,19,19,19,10] 10 8 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4298 : NodeCoverage113 [19,19,19,19,19,9] 9 9 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4299 : NodeCoverage113 [19,19,19,19,19,8] 8 10 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4300 : NodeCoverage113 [19,19,19,19,19,7] 7 11 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4301 : NodeCoverage113 [19,19,19,19,19,6] 6 12 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4302 : NodeCoverage113 [19,19,19,19,19,5] 5 13 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4303 : NodeCoverage113 [19,19,19,19,19,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4304 : NodeCoverage113 [19,19,19,19,19] 19 18 :=
  node_fork113 (B := [18,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4291
    (ChildrenCoverage113.cons _ _ compact113_node_4292
    (ChildrenCoverage113.cons _ _ compact113_node_4293
    (ChildrenCoverage113.cons _ _ compact113_node_4294
    (ChildrenCoverage113.cons _ _ compact113_node_4295
    (ChildrenCoverage113.cons _ _ compact113_node_4296
    (ChildrenCoverage113.cons _ _ compact113_node_4297
    (ChildrenCoverage113.cons _ _ compact113_node_4298
    (ChildrenCoverage113.cons _ _ compact113_node_4299
    (ChildrenCoverage113.cons _ _ compact113_node_4300
    (ChildrenCoverage113.cons _ _ compact113_node_4301
    (ChildrenCoverage113.cons _ _ compact113_node_4302
    (ChildrenCoverage113.cons _ _ compact113_node_4303
    ChildrenCoverage113.nil)))))))))))))

theorem compact113_node_4305 : NodeCoverage113 [19,19,19,19,18] 18 19 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4306 : NodeCoverage113 [19,19,19,19,17] 17 20 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4307 : NodeCoverage113 [19,19,19,19,16] 16 21 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

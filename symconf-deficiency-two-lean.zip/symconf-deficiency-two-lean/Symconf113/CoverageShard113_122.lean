import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4738 : NodeCoverage113 [18,16,16] 16 63 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4739 : NodeCoverage113 [18,16,15] 15 64 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4740 : NodeCoverage113 [18,16,14] 14 65 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4741 : NodeCoverage113 [18,16,13] 13 66 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4742 : NodeCoverage113 [18,16,12] 12 67 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4743 : NodeCoverage113 [18,16,11] 11 68 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4744 : NodeCoverage113 [18,16,10] 10 69 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4745 : NodeCoverage113 [18,16,9] 9 70 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4746 : NodeCoverage113 [18,16,8] 8 71 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4747 : NodeCoverage113 [18,16,7] 7 72 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4748 : NodeCoverage113 [18,16,6] 6 73 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4749 : NodeCoverage113 [18,16,5] 5 74 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4750 : NodeCoverage113 [18,16,3] 3 76 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4751 : NodeCoverage113 [18,16] 16 79 :=
  node_fork113 (B := [16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4738
    (ChildrenCoverage113.cons _ _ compact113_node_4739
    (ChildrenCoverage113.cons _ _ compact113_node_4740
    (ChildrenCoverage113.cons _ _ compact113_node_4741
    (ChildrenCoverage113.cons _ _ compact113_node_4742
    (ChildrenCoverage113.cons _ _ compact113_node_4743
    (ChildrenCoverage113.cons _ _ compact113_node_4744
    (ChildrenCoverage113.cons _ _ compact113_node_4745
    (ChildrenCoverage113.cons _ _ compact113_node_4746
    (ChildrenCoverage113.cons _ _ compact113_node_4747
    (ChildrenCoverage113.cons _ _ compact113_node_4748
    (ChildrenCoverage113.cons _ _ compact113_node_4749
    (ChildrenCoverage113.cons _ _ compact113_node_4750
    ChildrenCoverage113.nil)))))))))))))

theorem compact113_node_4752 : NodeCoverage113 [18,15,15] 15 65 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4753 : NodeCoverage113 [18,15,14] 14 66 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4754 : NodeCoverage113 [18,15,13] 13 67 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4755 : NodeCoverage113 [18,15,12] 12 68 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4756 : NodeCoverage113 [18,15,11] 11 69 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4757 : NodeCoverage113 [18,15,10] 10 70 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4758 : NodeCoverage113 [18,15,9] 9 71 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4759 : NodeCoverage113 [18,15,8] 8 72 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4760 : NodeCoverage113 [18,15,7] 7 73 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4761 : NodeCoverage113 [18,15,6] 6 74 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4762 : NodeCoverage113 [18,15,5] 5 75 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

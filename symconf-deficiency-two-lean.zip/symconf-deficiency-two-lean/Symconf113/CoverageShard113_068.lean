import Symconf113.CoverageShard113_067

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2501 : NodeCoverage113 [30,10,10,10,10,10,10,5] 5 18 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2502 : NodeCoverage113 [30,10,10,10,10,10,10,3] 3 20 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2503 : NodeCoverage113 [30,10,10,10,10,10,10] 10 23 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2496
    (ChildrenCoverage113.cons _ _ compact113_node_2497
    (ChildrenCoverage113.cons _ _ compact113_node_2498
    (ChildrenCoverage113.cons _ _ compact113_node_2499
    (ChildrenCoverage113.cons _ _ compact113_node_2500
    (ChildrenCoverage113.cons _ _ compact113_node_2501
    (ChildrenCoverage113.cons _ _ compact113_node_2502
    ChildrenCoverage113.nil)))))))

theorem compact113_node_2504 : NodeCoverage113 [30,10,10,10,10,10,9] 9 24 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2505 : NodeCoverage113 [30,10,10,10,10,10,8] 8 25 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2506 : NodeCoverage113 [30,10,10,10,10,10,7] 7 26 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2507 : NodeCoverage113 [30,10,10,10,10,10,6] 6 27 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2508 : NodeCoverage113 [30,10,10,10,10,10,5] 5 28 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2509 : NodeCoverage113 [30,10,10,10,10,10,3] 3 30 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2510 : NodeCoverage113 [30,10,10,10,10,10] 10 33 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2503
    (ChildrenCoverage113.cons _ _ compact113_node_2504
    (ChildrenCoverage113.cons _ _ compact113_node_2505
    (ChildrenCoverage113.cons _ _ compact113_node_2506
    (ChildrenCoverage113.cons _ _ compact113_node_2507
    (ChildrenCoverage113.cons _ _ compact113_node_2508
    (ChildrenCoverage113.cons _ _ compact113_node_2509
    ChildrenCoverage113.nil)))))))

theorem compact113_node_2511 : NodeCoverage113 [30,10,10,10,10,9] 9 34 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2512 : NodeCoverage113 [30,10,10,10,10,8] 8 35 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2513 : NodeCoverage113 [30,10,10,10,10,7] 7 36 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

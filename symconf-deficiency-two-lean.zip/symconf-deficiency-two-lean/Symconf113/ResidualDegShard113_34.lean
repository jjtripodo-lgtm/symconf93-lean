import Symconf113.ResidualDegDefs113

/-! Kernel check: the degree search below type-`A` rows 34 and 35. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem degShard_34 : ((degTopList.drop 34).take 2).all degTop=true := by decide +kernel
end Symconf113

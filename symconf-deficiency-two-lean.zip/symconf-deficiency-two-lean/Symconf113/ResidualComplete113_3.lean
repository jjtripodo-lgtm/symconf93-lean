import Symconf113.ResidualCands113

/-! Kernel check: every full row of type index 3 passing the row tests is listed. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem complete_3 : ∀ v ∈ vecs, rowOK 3 v=true → v ∈ candC := by decide +kernel
end Symconf113

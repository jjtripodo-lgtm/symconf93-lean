import Symconf113.CoverageShard113_164

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_7416 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7415
    ChildrenCoverage113.nil)

theorem compact113_node_7417 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7416
    ChildrenCoverage113.nil)

theorem compact113_node_7418 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7417
    ChildrenCoverage113.nil)

theorem compact113_node_7419 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7418
    ChildrenCoverage113.nil)

theorem compact113_node_7420 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7419
    ChildrenCoverage113.nil)

theorem compact113_node_7421 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7420
    ChildrenCoverage113.nil)

theorem compact113_node_7422 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7421
    ChildrenCoverage113.nil)

theorem compact113_node_7423 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3] 3 35 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7422
    ChildrenCoverage113.nil)

theorem compact113_node_7424 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3] 3 38 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7423
    ChildrenCoverage113.nil)

theorem compact113_node_7425 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3] 3 41 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7424
    ChildrenCoverage113.nil)

theorem compact113_node_7426 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3,3,3] 3 44 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7425
    ChildrenCoverage113.nil)

theorem compact113_node_7427 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3,3] 3 47 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7426
    ChildrenCoverage113.nil)

theorem compact113_node_7428 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3] 3 50 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7427
    ChildrenCoverage113.nil)

theorem compact113_node_7429 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3] 3 53 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7428
    ChildrenCoverage113.nil)

theorem compact113_node_7430 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3] 3 56 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7429
    ChildrenCoverage113.nil)

theorem compact113_node_7431 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3] 3 59 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7430
    ChildrenCoverage113.nil)

theorem compact113_node_7432 : NodeCoverage113 [6,6,6,6,6,6,6,6,3] 3 62 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7431
    ChildrenCoverage113.nil)

theorem compact113_node_7433 : NodeCoverage113 [6,6,6,6,6,6,6,6] 6 65 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7384
    (ChildrenCoverage113.cons _ _ compact113_node_7412
    (ChildrenCoverage113.cons _ _ compact113_node_7432
    ChildrenCoverage113.nil)))

theorem compact113_node_7434 : NodeCoverage113 [6,6,6,6,6,6,6,5] 5 66 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7435 : NodeCoverage113 [6,6,6,6,6,6,6,3] 3 68 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7436 : NodeCoverage113 [6,6,6,6,6,6,6] 6 71 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7433
    (ChildrenCoverage113.cons _ _ compact113_node_7434
    (ChildrenCoverage113.cons _ _ compact113_node_7435
    ChildrenCoverage113.nil)))

theorem compact113_node_7437 : NodeCoverage113 [6,6,6,6,6,6,5] 5 72 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7438 : NodeCoverage113 [6,6,6,6,6,6,3] 3 74 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7439 : NodeCoverage113 [6,6,6,6,6,6] 6 77 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7436
    (ChildrenCoverage113.cons _ _ compact113_node_7437
    (ChildrenCoverage113.cons _ _ compact113_node_7438
    ChildrenCoverage113.nil)))

theorem compact113_node_7440 : NodeCoverage113 [6,6,6,6,6,5] 5 78 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7441 : NodeCoverage113 [6,6,6,6,6,3] 3 80 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7442 : NodeCoverage113 [6,6,6,6,6] 6 83 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7439
    (ChildrenCoverage113.cons _ _ compact113_node_7440
    (ChildrenCoverage113.cons _ _ compact113_node_7441
    ChildrenCoverage113.nil)))

theorem compact113_node_7443 : NodeCoverage113 [6,6,6,6,5] 5 84 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7444 : NodeCoverage113 [6,6,6,6,3] 3 86 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7445 : NodeCoverage113 [6,6,6,6] 6 89 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7442
    (ChildrenCoverage113.cons _ _ compact113_node_7443
    (ChildrenCoverage113.cons _ _ compact113_node_7444
    ChildrenCoverage113.nil)))

theorem compact113_node_7446 : NodeCoverage113 [6,6,6,5] 5 90 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7447 : NodeCoverage113 [6,6,6,3] 3 92 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7448 : NodeCoverage113 [6,6,6] 6 95 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7445
    (ChildrenCoverage113.cons _ _ compact113_node_7446
    (ChildrenCoverage113.cons _ _ compact113_node_7447
    ChildrenCoverage113.nil)))

theorem compact113_node_7449 : NodeCoverage113 [6,6,5] 5 96 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7450 : NodeCoverage113 [6,6,3] 3 98 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7451 : NodeCoverage113 [6,6] 6 101 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7448
    (ChildrenCoverage113.cons _ _ compact113_node_7449
    (ChildrenCoverage113.cons _ _ compact113_node_7450
    ChildrenCoverage113.nil)))

theorem compact113_node_7452 : NodeCoverage113 [6,5] 5 102 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7453 : NodeCoverage113 [6,3] 3 104 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7454 : NodeCoverage113 [6] 6 107 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7451
    (ChildrenCoverage113.cons _ _ compact113_node_7452
    (ChildrenCoverage113.cons _ _ compact113_node_7453
    ChildrenCoverage113.nil)))

theorem compact113_node_7455 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7456 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7455
    ChildrenCoverage113.nil)

theorem compact113_node_7457 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7458 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7456
    (ChildrenCoverage113.cons _ _ compact113_node_7457
    ChildrenCoverage113.nil))

theorem compact113_node_7459 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7460 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7458
    (ChildrenCoverage113.cons _ _ compact113_node_7459
    ChildrenCoverage113.nil))

theorem compact113_node_7461 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7462 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7460
    (ChildrenCoverage113.cons _ _ compact113_node_7461
    ChildrenCoverage113.nil))

theorem compact113_node_7463 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7464 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5] 5 23 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7462
    (ChildrenCoverage113.cons _ _ compact113_node_7463
    ChildrenCoverage113.nil))

theorem compact113_node_7465 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3] 3 25 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7466 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5] 5 28 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7464
    (ChildrenCoverage113.cons _ _ compact113_node_7465
    ChildrenCoverage113.nil))

theorem compact113_node_7467 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_7468 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7467
    ChildrenCoverage113.nil)

theorem compact113_node_7469 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7468
    ChildrenCoverage113.nil)

theorem compact113_node_7470 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7469
    ChildrenCoverage113.nil)

theorem compact113_node_7471 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7470
    ChildrenCoverage113.nil)

theorem compact113_node_7472 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7471
    ChildrenCoverage113.nil)

theorem compact113_node_7473 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3] 3 18 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7472
    ChildrenCoverage113.nil)

theorem compact113_node_7474 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3] 3 21 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7473
    ChildrenCoverage113.nil)

theorem compact113_node_7475 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3] 3 24 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7474
    ChildrenCoverage113.nil)

theorem compact113_node_7476 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3] 3 27 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7475
    ChildrenCoverage113.nil)

theorem compact113_node_7477 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3] 3 30 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7476
    ChildrenCoverage113.nil)

theorem compact113_node_7478 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5] 5 33 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7466
    (ChildrenCoverage113.cons _ _ compact113_node_7477
    ChildrenCoverage113.nil))

theorem compact113_node_7479 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7480 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7479
    ChildrenCoverage113.nil)

theorem compact113_node_7481 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7480
    ChildrenCoverage113.nil)

theorem compact113_node_7482 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7481
    ChildrenCoverage113.nil)

theorem compact113_node_7483 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7482
    ChildrenCoverage113.nil)

theorem compact113_node_7484 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7483
    ChildrenCoverage113.nil)

theorem compact113_node_7485 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7484
    ChildrenCoverage113.nil)

theorem compact113_node_7486 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7485
    ChildrenCoverage113.nil)

theorem compact113_node_7487 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7486
    ChildrenCoverage113.nil)

theorem compact113_node_7488 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7487
    ChildrenCoverage113.nil)

theorem compact113_node_7489 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3] 3 35 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7488
    ChildrenCoverage113.nil)

theorem compact113_node_7490 : NodeCoverage113 [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5] 5 38 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7478
    (ChildrenCoverage113.cons _ _ compact113_node_7489
    ChildrenCoverage113.nil))

end Symconf113

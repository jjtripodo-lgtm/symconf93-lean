import Symconf113.ResidualCensusDefs113
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Data.Fintype.Card
import Mathlib.Tactic.Ring

/-! Sorting the seven long cycles into canonical type order. Given 0/1 marks
`a` (meets the 3-cycle) and `b` (meets the 5-cycle) with `∑ a = 2`,
`∑ b = 3` and `∑ a*b = 1`, some permutation puts them in the order
`(1,1),(1,0),(0,1),(0,1),(0,0),(0,0),(0,0)` used by the census. -/
namespace Symconf113
open scoped BigOperators

theorem bin_fiber_sum (a b : Fin 7 → ℤ) (ha : ∀ i, a i=0 ∨ a i=1) (hb : ∀ i, b i=0 ∨ b i=1)
    (sa : (∑ i, a i)=2) (sb : (∑ i, b i)=3) (sab : (∑ i, a i*b i)=1) (I : ℤ → ℤ → ℤ) :
    (∑ i, I (a i) (b i))=I 1 1+I 1 0+2*I 0 1+3*I 0 0 := by
  have hk : ∀ i, I (a i) (b i)=I 0 0+a i*(I 1 0-I 0 0)+b i*(I 0 1-I 0 0)+
      (a i*b i)*(I 1 1-I 1 0-I 0 1+I 0 0) := fun i => by
    rcases ha i with h|h <;> rcases hb i with h'|h' <;> rw [h,h'] <;> ring
  rw [Finset.sum_congr rfl (fun i _ => hk i)]
  simp only [Finset.sum_add_distrib, ← Finset.sum_mul, Finset.sum_const, Finset.card_univ,
    Fintype.card_fin, sa, sb, sab, nsmul_eq_mul]
  push_cast; ring

theorem pat_sums : (∑ i : Fin 7, (xF i : ℤ))=2 ∧ (∑ i : Fin 7, (yF i : ℤ))=3 ∧
    (∑ i : Fin 7, (xF i : ℤ)*(yF i : ℤ))=1 := by
  simp only [Fin.sum_univ_seven]; norm_num [xF, yF]

theorem fiber_card (a b : Fin 7 → ℤ) (ha : ∀ i, a i=0 ∨ a i=1) (hb : ∀ i, b i=0 ∨ b i=1)
    (sa : (∑ i, a i)=2) (sb : (∑ i, b i)=3) (sab : (∑ i, a i*b i)=1) (c : ℤ × ℤ) :
    (Finset.univ.filter fun i : Fin 7 => ((xF i : ℤ),(yF i : ℤ))=c).card=
      (Finset.univ.filter fun i => (a i,b i)=c).card := by
  have hcast : ∀ (u v : Fin 7 → ℤ), ((Finset.univ.filter fun i => (u i,v i)=c).card : ℤ)=
      ∑ i, (fun x y => if (x,y)=c then (1:ℤ) else 0) (u i) (v i) := by
    intro u v
    rw [Finset.card_filter]; push_cast; rfl
  have hx : ∀ i : Fin 7, ((xF i : ℕ) : ℤ)=0 ∨ ((xF i : ℕ) : ℤ)=1 := by decide
  have hy : ∀ i : Fin 7, ((yF i : ℕ) : ℤ)=0 ∨ ((yF i : ℕ) : ℤ)=1 := by decide
  obtain ⟨px,py,pxy⟩ := pat_sums
  let I : ℤ → ℤ → ℤ := fun x y => if (x,y)=c then 1 else 0
  have h1 := (hcast (fun i => (xF i : ℤ)) (fun i => (yF i : ℤ))).trans
    (bin_fiber_sum _ _ hx hy px py pxy I)
  have h2 := (hcast a b).trans (bin_fiber_sum _ _ ha hb sa sb sab I)
  exact_mod_cast h1.trans h2.symm

theorem exists_canon (a b : Fin 7 → ℤ) (ha : ∀ i, a i=0 ∨ a i=1) (hb : ∀ i, b i=0 ∨ b i=1)
    (sa : (∑ i, a i)=2) (sb : (∑ i, b i)=3) (sab : (∑ i, a i*b i)=1) :
    ∃ σ : Fin 7 ≃ Fin 7, ∀ i, a (σ i)=xF i ∧ b (σ i)=yF i := by
  let p : Fin 7 → ℤ × ℤ := fun i => ((xF i : ℤ),(yF i : ℤ))
  let k : Fin 7 → ℤ × ℤ := fun i => (a i,b i)
  have e : ∀ c, {i // p i=c} ≃ {i // k i=c} := fun c =>
    Fintype.equivOfCardEq (by
      rw [Fintype.card_subtype, Fintype.card_subtype]
      exact fiber_card a b ha hb sa sb sab c)
  refine ⟨Equiv.ofFiberEquiv e, fun i => ?_⟩
  have h := Equiv.ofFiberEquiv_map e i
  exact Prod.mk.inj h

end Symconf113

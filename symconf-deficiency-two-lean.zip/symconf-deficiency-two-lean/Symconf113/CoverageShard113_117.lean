import Symconf113.CoverageShard113_116

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4443 : NodeCoverage113 [18,18,18,18,9,9,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4442
    ChildrenCoverage113.nil)

theorem compact113_node_4444 : NodeCoverage113 [18,18,18,18,9,9] 9 23 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4425
    (ChildrenCoverage113.cons _ _ compact113_node_4426
    (ChildrenCoverage113.cons _ _ compact113_node_4427
    (ChildrenCoverage113.cons _ _ compact113_node_4436
    (ChildrenCoverage113.cons _ _ compact113_node_4437
    (ChildrenCoverage113.cons _ _ compact113_node_4443
    ChildrenCoverage113.nil))))))

theorem compact113_node_4445 : NodeCoverage113 [18,18,18,18,9,8] 8 24 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4446 : NodeCoverage113 [18,18,18,18,9,7] 7 25 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4447 : NodeCoverage113 [18,18,18,18,9,6,6,6,6,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4448 : NodeCoverage113 [18,18,18,18,9,6,6,6,6,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4449 : NodeCoverage113 [18,18,18,18,9,6,6,6,6] 6 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4447
    (ChildrenCoverage113.cons _ _ compact113_node_4448
    ChildrenCoverage113.nil))

theorem compact113_node_4450 : NodeCoverage113 [18,18,18,18,9,6,6,6,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4451 : NodeCoverage113 [18,18,18,18,9,6,6,6,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4452 : NodeCoverage113 [18,18,18,18,9,6,6,6,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4451
    ChildrenCoverage113.nil)

theorem compact113_node_4453 : NodeCoverage113 [18,18,18,18,9,6,6,6,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4452
    ChildrenCoverage113.nil)

theorem compact113_node_4454 : NodeCoverage113 [18,18,18,18,9,6,6,6] 6 14 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4449
    (ChildrenCoverage113.cons _ _ compact113_node_4450
    (ChildrenCoverage113.cons _ _ compact113_node_4453
    ChildrenCoverage113.nil)))

theorem compact113_node_4455 : NodeCoverage113 [18,18,18,18,9,6,6,5] 5 15 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4456 : NodeCoverage113 [18,18,18,18,9,6,6,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4457 : NodeCoverage113 [18,18,18,18,9,6,6,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4456
    ChildrenCoverage113.nil)

theorem compact113_node_4458 : NodeCoverage113 [18,18,18,18,9,6,6,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4457
    ChildrenCoverage113.nil)

theorem compact113_node_4459 : NodeCoverage113 [18,18,18,18,9,6,6,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4458
    ChildrenCoverage113.nil)

theorem compact113_node_4460 : NodeCoverage113 [18,18,18,18,9,6,6,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4459
    ChildrenCoverage113.nil)

theorem compact113_node_4461 : NodeCoverage113 [18,18,18,18,9,6,6] 6 20 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4454
    (ChildrenCoverage113.cons _ _ compact113_node_4455
    (ChildrenCoverage113.cons _ _ compact113_node_4460
    ChildrenCoverage113.nil)))

theorem compact113_node_4462 : NodeCoverage113 [18,18,18,18,9,6,5] 5 21 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4463 : NodeCoverage113 [18,18,18,18,9,6,3] 3 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4464 : NodeCoverage113 [18,18,18,18,9,6] 6 26 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4461
    (ChildrenCoverage113.cons _ _ compact113_node_4462
    (ChildrenCoverage113.cons _ _ compact113_node_4463
    ChildrenCoverage113.nil)))

theorem compact113_node_4465 : NodeCoverage113 [18,18,18,18,9,5] 5 27 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4466 : NodeCoverage113 [18,18,18,18,9,3] 3 29 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4467 : NodeCoverage113 [18,18,18,18,9] 9 32 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4444
    (ChildrenCoverage113.cons _ _ compact113_node_4445
    (ChildrenCoverage113.cons _ _ compact113_node_4446
    (ChildrenCoverage113.cons _ _ compact113_node_4464
    (ChildrenCoverage113.cons _ _ compact113_node_4465
    (ChildrenCoverage113.cons _ _ compact113_node_4466
    ChildrenCoverage113.nil))))))

theorem compact113_node_4468 : NodeCoverage113 [18,18,18,18,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4469 : NodeCoverage113 [18,18,18,18,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4470 : NodeCoverage113 [18,18,18,18,6] 6 35 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4471 : NodeCoverage113 [18,18,18,18,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4472 : NodeCoverage113 [18,18,18,18,3] 3 38 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4473 : NodeCoverage113 [18,18,18,18] 18 41 :=
  node_fork113 (B := [18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4407
    (ChildrenCoverage113.cons _ _ compact113_node_4408
    (ChildrenCoverage113.cons _ _ compact113_node_4409
    (ChildrenCoverage113.cons _ _ compact113_node_4410
    (ChildrenCoverage113.cons _ _ compact113_node_4411
    (ChildrenCoverage113.cons _ _ compact113_node_4412
    (ChildrenCoverage113.cons _ _ compact113_node_4413
    (ChildrenCoverage113.cons _ _ compact113_node_4414
    (ChildrenCoverage113.cons _ _ compact113_node_4415
    (ChildrenCoverage113.cons _ _ compact113_node_4467
    (ChildrenCoverage113.cons _ _ compact113_node_4468
    (ChildrenCoverage113.cons _ _ compact113_node_4469
    (ChildrenCoverage113.cons _ _ compact113_node_4470
    (ChildrenCoverage113.cons _ _ compact113_node_4471
    (ChildrenCoverage113.cons _ _ compact113_node_4472
    ChildrenCoverage113.nil)))))))))))))))

theorem compact113_node_4474 : NodeCoverage113 [18,18,18,17] 17 42 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4475 : NodeCoverage113 [18,18,18,16] 16 43 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4476 : NodeCoverage113 [18,18,18,15] 15 44 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4477 : NodeCoverage113 [18,18,18,14] 14 45 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4478 : NodeCoverage113 [18,18,18,13] 13 46 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4479 : NodeCoverage113 [18,18,18,12] 12 47 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4480 : NodeCoverage113 [18,18,18,11] 11 48 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4481 : NodeCoverage113 [18,18,18,10] 10 49 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4482 : NodeCoverage113 [18,18,18,9,9,9,9,9,9,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4483 : NodeCoverage113 [18,18,18,9,9,9,9,9,9] 9 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4482
    ChildrenCoverage113.nil)

theorem compact113_node_4484 : NodeCoverage113 [18,18,18,9,9,9,9,9,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4485 : NodeCoverage113 [18,18,18,9,9,9,9,9,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4486 : NodeCoverage113 [18,18,18,9,9,9,9,9,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4487 : NodeCoverage113 [18,18,18,9,9,9,9,9,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4488 : NodeCoverage113 [18,18,18,9,9,9,9,9,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4489 : NodeCoverage113 [18,18,18,9,9,9,9,9,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4488
    ChildrenCoverage113.nil)

theorem compact113_node_4490 : NodeCoverage113 [18,18,18,9,9,9,9,9,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4489
    ChildrenCoverage113.nil)

theorem compact113_node_4491 : NodeCoverage113 [18,18,18,9,9,9,9,9] 9 14 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4483
    (ChildrenCoverage113.cons _ _ compact113_node_4484
    (ChildrenCoverage113.cons _ _ compact113_node_4485
    (ChildrenCoverage113.cons _ _ compact113_node_4486
    (ChildrenCoverage113.cons _ _ compact113_node_4487
    (ChildrenCoverage113.cons _ _ compact113_node_4490
    ChildrenCoverage113.nil))))))

theorem compact113_node_4492 : NodeCoverage113 [18,18,18,9,9,9,9,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4493 : NodeCoverage113 [18,18,18,9,9,9,9,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4494 : NodeCoverage113 [18,18,18,9,9,9,9,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4495 : NodeCoverage113 [18,18,18,9,9,9,9,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4494
    ChildrenCoverage113.nil)

theorem compact113_node_4496 : NodeCoverage113 [18,18,18,9,9,9,9,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4497 : NodeCoverage113 [18,18,18,9,9,9,9,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4498 : NodeCoverage113 [18,18,18,9,9,9,9,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4497
    ChildrenCoverage113.nil)

theorem compact113_node_4499 : NodeCoverage113 [18,18,18,9,9,9,9,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4495
    (ChildrenCoverage113.cons _ _ compact113_node_4496
    (ChildrenCoverage113.cons _ _ compact113_node_4498
    ChildrenCoverage113.nil)))

theorem compact113_node_4500 : NodeCoverage113 [18,18,18,9,9,9,9,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4501 : NodeCoverage113 [18,18,18,9,9,9,9,6,3] 3 14 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4502 : NodeCoverage113 [18,18,18,9,9,9,9,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4499
    (ChildrenCoverage113.cons _ _ compact113_node_4500
    (ChildrenCoverage113.cons _ _ compact113_node_4501
    ChildrenCoverage113.nil)))

theorem compact113_node_4503 : NodeCoverage113 [18,18,18,9,9,9,9,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4504 : NodeCoverage113 [18,18,18,9,9,9,9,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4505 : NodeCoverage113 [18,18,18,9,9,9,9,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4504
    ChildrenCoverage113.nil)

theorem compact113_node_4506 : NodeCoverage113 [18,18,18,9,9,9,9,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4505
    ChildrenCoverage113.nil)

theorem compact113_node_4507 : NodeCoverage113 [18,18,18,9,9,9,9,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4506
    ChildrenCoverage113.nil)

theorem compact113_node_4508 : NodeCoverage113 [18,18,18,9,9,9,9,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4507
    ChildrenCoverage113.nil)

theorem compact113_node_4509 : NodeCoverage113 [18,18,18,9,9,9,9,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4508
    ChildrenCoverage113.nil)

theorem compact113_node_4510 : NodeCoverage113 [18,18,18,9,9,9,9] 9 23 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4491
    (ChildrenCoverage113.cons _ _ compact113_node_4492
    (ChildrenCoverage113.cons _ _ compact113_node_4493
    (ChildrenCoverage113.cons _ _ compact113_node_4502
    (ChildrenCoverage113.cons _ _ compact113_node_4503
    (ChildrenCoverage113.cons _ _ compact113_node_4509
    ChildrenCoverage113.nil))))))

theorem compact113_node_4511 : NodeCoverage113 [18,18,18,9,9,9,8] 8 24 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4512 : NodeCoverage113 [18,18,18,9,9,9,7] 7 25 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4513 : NodeCoverage113 [18,18,18,9,9,9,6,6,6,6,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4514 : NodeCoverage113 [18,18,18,9,9,9,6,6,6,6,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4515 : NodeCoverage113 [18,18,18,9,9,9,6,6,6,6] 6 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4513
    (ChildrenCoverage113.cons _ _ compact113_node_4514
    ChildrenCoverage113.nil))

theorem compact113_node_4516 : NodeCoverage113 [18,18,18,9,9,9,6,6,6,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4517 : NodeCoverage113 [18,18,18,9,9,9,6,6,6,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

end Symconf113

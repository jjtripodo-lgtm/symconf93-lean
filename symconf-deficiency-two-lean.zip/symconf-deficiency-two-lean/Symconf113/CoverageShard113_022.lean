import Symconf113.CoverageShard113_019
import Symconf113.CoverageShard113_020
import Symconf113.CoverageShard113_021

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0929 : NodeCoverage113 [45,9,9,9,9,9,9,3] 3 11 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0930 : NodeCoverage113 [45,9,9,9,9,9,9] 9 14 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0924
    (ChildrenCoverage113.cons _ _ compact113_node_0925
    (ChildrenCoverage113.cons _ _ compact113_node_0926
    (ChildrenCoverage113.cons _ _ compact113_node_0927
    (ChildrenCoverage113.cons _ _ compact113_node_0928
    (ChildrenCoverage113.cons _ _ compact113_node_0929
    ChildrenCoverage113.nil))))))

theorem compact113_node_0931 : NodeCoverage113 [45,9,9,9,9,9,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0932 : NodeCoverage113 [45,9,9,9,9,9,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0933 : NodeCoverage113 [45,9,9,9,9,9,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0934 : NodeCoverage113 [45,9,9,9,9,9,5] 5 18 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0935 : NodeCoverage113 [45,9,9,9,9,9,3] 3 20 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0936 : NodeCoverage113 [45,9,9,9,9,9] 9 23 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0930
    (ChildrenCoverage113.cons _ _ compact113_node_0931
    (ChildrenCoverage113.cons _ _ compact113_node_0932
    (ChildrenCoverage113.cons _ _ compact113_node_0933
    (ChildrenCoverage113.cons _ _ compact113_node_0934
    (ChildrenCoverage113.cons _ _ compact113_node_0935
    ChildrenCoverage113.nil))))))

theorem compact113_node_0937 : NodeCoverage113 [45,9,9,9,9,8] 8 24 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0938 : NodeCoverage113 [45,9,9,9,9,7] 7 25 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0939 : NodeCoverage113 [45,9,9,9,9,6] 6 26 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0940 : NodeCoverage113 [45,9,9,9,9,5] 5 27 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0941 : NodeCoverage113 [45,9,9,9,9,3] 3 29 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0942 : NodeCoverage113 [45,9,9,9,9] 9 32 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0936
    (ChildrenCoverage113.cons _ _ compact113_node_0937
    (ChildrenCoverage113.cons _ _ compact113_node_0938
    (ChildrenCoverage113.cons _ _ compact113_node_0939
    (ChildrenCoverage113.cons _ _ compact113_node_0940
    (ChildrenCoverage113.cons _ _ compact113_node_0941
    ChildrenCoverage113.nil))))))

theorem compact113_node_0943 : NodeCoverage113 [45,9,9,9,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0944 : NodeCoverage113 [45,9,9,9,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0945 : NodeCoverage113 [45,9,9,9,6] 6 35 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0946 : NodeCoverage113 [45,9,9,9,5] 5 36 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0947 : NodeCoverage113 [45,9,9,9,3] 3 38 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0948 : NodeCoverage113 [45,9,9,9] 9 41 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0942
    (ChildrenCoverage113.cons _ _ compact113_node_0943
    (ChildrenCoverage113.cons _ _ compact113_node_0944
    (ChildrenCoverage113.cons _ _ compact113_node_0945
    (ChildrenCoverage113.cons _ _ compact113_node_0946
    (ChildrenCoverage113.cons _ _ compact113_node_0947
    ChildrenCoverage113.nil))))))

theorem compact113_node_0949 : NodeCoverage113 [45,9,9,8] 8 42 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0950 : NodeCoverage113 [45,9,9,7] 7 43 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0951 : NodeCoverage113 [45,9,9,6] 6 44 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0952 : NodeCoverage113 [45,9,9,5] 5 45 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0953 : NodeCoverage113 [45,9,9,3] 3 47 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0954 : NodeCoverage113 [45,9,9] 9 50 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0948
    (ChildrenCoverage113.cons _ _ compact113_node_0949
    (ChildrenCoverage113.cons _ _ compact113_node_0950
    (ChildrenCoverage113.cons _ _ compact113_node_0951
    (ChildrenCoverage113.cons _ _ compact113_node_0952
    (ChildrenCoverage113.cons _ _ compact113_node_0953
    ChildrenCoverage113.nil))))))

theorem compact113_node_0955 : NodeCoverage113 [45,9,8] 8 51 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0956 : NodeCoverage113 [45,9,7] 7 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0957 : NodeCoverage113 [45,9,6] 6 53 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0958 : NodeCoverage113 [45,9,5] 5 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0959 : NodeCoverage113 [45,9,3] 3 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0960 : NodeCoverage113 [45,9] 9 59 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0954
    (ChildrenCoverage113.cons _ _ compact113_node_0955
    (ChildrenCoverage113.cons _ _ compact113_node_0956
    (ChildrenCoverage113.cons _ _ compact113_node_0957
    (ChildrenCoverage113.cons _ _ compact113_node_0958
    (ChildrenCoverage113.cons _ _ compact113_node_0959
    ChildrenCoverage113.nil))))))

theorem compact113_node_0961 : NodeCoverage113 [45,8] 8 60 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0962 : NodeCoverage113 [45,7] 7 61 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0963 : NodeCoverage113 [45,6] 6 62 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0964 : NodeCoverage113 [45,5] 5 63 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0965 : NodeCoverage113 [45,3] 3 65 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0966 : NodeCoverage113 [45] 45 68 :=
  node_fork113 (B := [45,44,43,42,41,40,39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0851
    (ChildrenCoverage113.cons _ _ compact113_node_0852
    (ChildrenCoverage113.cons _ _ compact113_node_0853
    (ChildrenCoverage113.cons _ _ compact113_node_0854
    (ChildrenCoverage113.cons _ _ compact113_node_0855
    (ChildrenCoverage113.cons _ _ compact113_node_0856
    (ChildrenCoverage113.cons _ _ compact113_node_0857
    (ChildrenCoverage113.cons _ _ compact113_node_0858
    (ChildrenCoverage113.cons _ _ compact113_node_0859
    (ChildrenCoverage113.cons _ _ compact113_node_0860
    (ChildrenCoverage113.cons _ _ compact113_node_0861
    (ChildrenCoverage113.cons _ _ compact113_node_0862
    (ChildrenCoverage113.cons _ _ compact113_node_0863
    (ChildrenCoverage113.cons _ _ compact113_node_0864
    (ChildrenCoverage113.cons _ _ compact113_node_0865
    (ChildrenCoverage113.cons _ _ compact113_node_0866
    (ChildrenCoverage113.cons _ _ compact113_node_0867
    (ChildrenCoverage113.cons _ _ compact113_node_0868
    (ChildrenCoverage113.cons _ _ compact113_node_0869
    (ChildrenCoverage113.cons _ _ compact113_node_0870
    (ChildrenCoverage113.cons _ _ compact113_node_0871
    (ChildrenCoverage113.cons _ _ compact113_node_0872
    (ChildrenCoverage113.cons _ _ compact113_node_0873
    (ChildrenCoverage113.cons _ _ compact113_node_0874
    (ChildrenCoverage113.cons _ _ compact113_node_0875
    (ChildrenCoverage113.cons _ _ compact113_node_0876
    (ChildrenCoverage113.cons _ _ compact113_node_0877
    (ChildrenCoverage113.cons _ _ compact113_node_0878
    (ChildrenCoverage113.cons _ _ compact113_node_0879
    (ChildrenCoverage113.cons _ _ compact113_node_0880
    (ChildrenCoverage113.cons _ _ compact113_node_0917
    (ChildrenCoverage113.cons _ _ compact113_node_0918
    (ChildrenCoverage113.cons _ _ compact113_node_0919
    (ChildrenCoverage113.cons _ _ compact113_node_0920
    (ChildrenCoverage113.cons _ _ compact113_node_0921
    (ChildrenCoverage113.cons _ _ compact113_node_0922
    (ChildrenCoverage113.cons _ _ compact113_node_0960
    (ChildrenCoverage113.cons _ _ compact113_node_0961
    (ChildrenCoverage113.cons _ _ compact113_node_0962
    (ChildrenCoverage113.cons _ _ compact113_node_0963
    (ChildrenCoverage113.cons _ _ compact113_node_0964
    (ChildrenCoverage113.cons _ _ compact113_node_0965
    ChildrenCoverage113.nil))))))))))))))))))))))))))))))))))))))))))

theorem compact113_node_0967 : NodeCoverage113 [44,44,25] 25 0 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0968 : NodeCoverage113 [44,44,22] 22 3 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0969 : NodeCoverage113 [44,44,21] 21 4 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0970 : NodeCoverage113 [44,44,20] 20 5 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0971 : NodeCoverage113 [44,44,19] 19 6 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0972 : NodeCoverage113 [44,44,18] 18 7 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0973 : NodeCoverage113 [44,44,17] 17 8 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0974 : NodeCoverage113 [44,44,16] 16 9 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

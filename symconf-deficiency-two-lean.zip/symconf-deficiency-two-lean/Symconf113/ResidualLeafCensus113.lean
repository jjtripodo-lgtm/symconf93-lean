import Symconf113.ResidualSigShard113_0
import Symconf113.ResidualSigShard113_16
import Symconf113.ResidualSigShard113_32
import Symconf113.ResidualSigShard113_48
import Symconf113.ResidualSigShard113_64
import Symconf113.ResidualSigShard113_80
import Symconf113.ResidualSigShard113_96
import Symconf113.ResidualSigShard113_112
import Symconf113.ResidualSigShard113_128
import Symconf113.ResidualSigShard113_144
import Symconf113.ResidualSigShard113_160
import Symconf113.ResidualSigShard113_176
import Symconf113.ResidualSigShard113_192
import Symconf113.ResidualSigShard113_208
import Symconf113.ResidualSigShard113_224
import Symconf113.ResidualSigShard113_240
import Symconf113.ResidualSigShard113_256
import Symconf113.ResidualSigShard113_272
import Symconf113.ResidualDegLeaves113

/-! The residual census, assembled: degree leaves, then signatures. -/
namespace Symconf113

theorem leaves_drop_end : leaves.drop 288=[] := by decide +kernel

theorem leaves_sig : leaves.all sigStage=true := by
  rw [← List.drop_zero (l := leaves)]
  rw [all_drop_split _ _ 0 16, sigShard_0, Bool.true_and,
    all_drop_split _ _ 16 16, sigShard_16, Bool.true_and,
    all_drop_split _ _ 32 16, sigShard_32, Bool.true_and,
    all_drop_split _ _ 48 16, sigShard_48, Bool.true_and,
    all_drop_split _ _ 64 16, sigShard_64, Bool.true_and,
    all_drop_split _ _ 80 16, sigShard_80, Bool.true_and,
    all_drop_split _ _ 96 16, sigShard_96, Bool.true_and,
    all_drop_split _ _ 112 16, sigShard_112, Bool.true_and,
    all_drop_split _ _ 128 16, sigShard_128, Bool.true_and,
    all_drop_split _ _ 144 16, sigShard_144, Bool.true_and,
    all_drop_split _ _ 160 16, sigShard_160, Bool.true_and,
    all_drop_split _ _ 176 16, sigShard_176, Bool.true_and,
    all_drop_split _ _ 192 16, sigShard_192, Bool.true_and,
    all_drop_split _ _ 208 16, sigShard_208, Bool.true_and,
    all_drop_split _ _ 224 16, sigShard_224, Bool.true_and,
    all_drop_split _ _ 240 16, sigShard_240, Bool.true_and,
    all_drop_split _ _ 256 16, sigShard_256, Bool.true_and,
    all_drop_split _ _ 272 16, sigShard_272, Bool.true_and]
  rw [leaves_drop_end]; rfl

theorem canon_census_leaves {V : ℕ → ℕ → ℕ} {S : ℕ → ℕ → List ℕ} (G : CanonGood V S)
    (hcomp : ∀ i<7, ∀ v ∈ vecs, rowOK i v=true → (i,v) ∈ degLists.getD i []) :
    abOK (rowsOf V) (sigsOf S)=true := by
  have hF : List.Forall₂ (fun a L => a ∈ L) (rowsOf V) degLists := by
    rw [degLists_eq]
    exact forall₂_map_range _ _ _ 7 (fun i hi =>
      hcomp i hi _ (good_row_vecs G hi) (good_rowOK G hi))
  have hP : List.Pairwise (fun a b => degCompat a b=true) (rowsOf V) := by
    apply pairwise_range7
    intro i hi k hk hik
    unfold degCompat
    simp only [decide_eq_true_eq]
    rw [dotL_ofF]
    exact G.rowGram i hi k hk (by omega)
  have h := dfs_sound degCompat leafIn 7 [] degLists (rowsOf V) (by rfl) hF (by simpa using hP)
    degree_leaves
  simp only [List.reverse_nil, List.nil_append, leafIn, good_colOK G, Bool.not_true,
    Bool.false_or, decide_eq_true_eq] at h
  have hs := List.all_eq_true.mp leaves_sig _ h
  exact good_sigStage G hs

end Symconf113

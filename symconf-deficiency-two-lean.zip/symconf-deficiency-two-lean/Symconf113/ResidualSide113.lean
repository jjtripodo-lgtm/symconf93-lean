import Symconf113.ResidualShort113

/-! One side of the residual profile `3+5+15^7`: the row facts of a 113_11
incidence in cycle coordinates `R` (rows) and `C` (columns). Column facts
are the same statements for the transpose. -/
namespace Symconf113
open Matrix Symconf59
open scoped BigOperators

def ovR (A : Int113) (p q : Site) : ℤ := ∑ t, A p t*A q t

theorem zblk_wave {P : List ℕ} {A : Int113} (hA : Incidence113 A)
    (R : OrderedCycles (rowLeave A) P) (C : OrderedCycles (colLeave A) P)
    (k k' : Fin P.length) {n m : ℕ} [NeZero n] [NeZero m] (h : P.get k=n) (h' : P.get k'=m) :
    BlockWave (fun x y => A (zsite R k h x) (zsite C k' h' y)) := by
  subst h; subst h'; exact zblock_wave R C k k' hA

section Overlap
variable {A : Int113} (hA : Incidence113 A) (R : OrderedCycles (rowLeave A) RP)

theorem ovR_same (k : Fin RP.length) {n : ℕ} [NeZero n] (h : RP.get k=n) (x y : ZMod n)
    (hxy : x≠y) : ovR A (zsite R k h x) (zsite R k h y)=
      1-((if y=x+1 then 1 else 0)+(if y=x-1 then 1 else 0)) := by
  have hne : zsite R k h x≠zsite R k h y := fun e => hxy ((zsite_eq_iff R k h x y).mp e)
  have h1 := rowLeave_offdiag (A := A) hne
  rw [zsite_same R k h x y] at h1
  rw [h1]; unfold ovR; ring

theorem ovR_diff {k k' : Fin RP.length} {n m : ℕ} [NeZero n] [NeZero m] (h : RP.get k=n)
    (h' : RP.get k'=m) (hk : k≠k') (x : ZMod n) (y : ZMod m) :
    ovR A (zsite R k h x) (zsite R k' h' y)=1 := by
  have hne : zsite R k h x≠zsite R k' h' y := zsite_ne_of_ne R k k' h h' hk x y
  have h1 := rowLeave_offdiag (A := A) hne
  rw [zsite_diff R k k' h h' hk] at h1
  unfold ovR; linarith

include hA in
theorem ovR_le (p q : Site) (hpq : p≠q) : ovR A p q≤1 := hA.overlap p q hpq

end Overlap

/-! ### Sum helpers -/

theorem gram_gen {γ : Type*} [Fintype γ] (f g : ZMod 15 → γ → ℤ) (a b : ℤ)
    (hf : ∀ y, (∑ x, f x y)=a) (hg : ∀ y, (∑ x, g x y)=b) :
    (∑ x, ∑ x', ∑ y, f x y*g x' y)=(Fintype.card γ : ℤ)*(a*b) := by
  calc (∑ x, ∑ x', ∑ y, f x y*g x' y)=∑ x, ∑ y, ∑ x', f x y*g x' y :=
        Finset.sum_congr rfl (fun x _ => Finset.sum_comm)
    _ = ∑ y, ∑ x, ∑ x', f x y*g x' y := Finset.sum_comm
    _ = ∑ y, (∑ x, f x y)*(∑ x', g x' y) := by
        apply Finset.sum_congr rfl; intro y _; rw [Finset.sum_mul_sum]
    _ = _ := by simp [hf, hg, Finset.sum_const, Finset.card_univ]

theorem swap3 {α β γ : Type*} [Fintype α] [Fintype β] [Fintype γ] (F : α → β → γ → ℤ) :
    (∑ x, ∑ x', ∑ j, F x x' j)=∑ j, ∑ x, ∑ x', F x x' j := by
  calc (∑ x, ∑ x', ∑ j, F x x' j)=∑ x, ∑ j, ∑ x', F x x' j :=
        Finset.sum_congr rfl (fun x _ => Finset.sum_comm)
    _ = _ := Finset.sum_comm

theorem const_of_succ {n : ℕ} [NeZero n] (h : ZMod n → ℤ) (hp : ∀ x, h (x+1)=h x) (x : ZMod n) :
    h x=h 0 := by
  have key : ∀ k : ℕ, h (k : ZMod n)=h 0 := by
    intro k
    induction k with
    | zero => simp
    | succ k ih => rw [Nat.cast_succ, hp, ih]
  rw [← ZMod.natCast_zmod_val x]
  exact key _

theorem coprime_block_const {a b : ℕ} [NeZero a] [NeZero b] (hab : Nat.gcd a b=1)
    (g : ZMod a → ZMod b → ℤ) (hw : BlockWave g) (hb : ∀ x y, g x y=0 ∨ g x y=1) :
    ∀ x y, g x y=g 0 0 := by
  have hr := cyclic_block_binary_gcd_period g hw hb 1 (by rw [hab])
  have hwT : BlockWave (fun y x => g x y) := fun y x => (hw x y).symm
  have hba : Nat.gcd b a=1 := by rw [Nat.gcd_comm]; exact hab
  have hc := cyclic_block_binary_gcd_period (fun y x => g x y) hwT (fun y x => hb x y) 1 (by rw [hba])
  simp only [Nat.cast_one] at hr hc
  intro x y
  rw [const_of_succ (fun x => g x y) (fun x => hr x y) x,
    const_of_succ (fun y => g 0 y) (fun y => hc y 0) y]

theorem sum3_le (g : ZMod 3 → ℤ) (hb : ∀ z, g z=0 ∨ g z=1)
    (h : ∀ a b, a≠b → g a*g b≤0) : (∑ z, g z)≤1 := by
  change (∑ z : Fin 3, g z)≤1
  rw [Fin.sum_univ_three]
  change g (0:ZMod 3)+g (1:ZMod 3)+g (2:ZMod 3)≤1
  have h01 := h 0 1 (by decide)
  have h02 := h 0 2 (by decide)
  have h12 := h 1 2 (by decide)
  rcases hb 0 with a|a <;> rcases hb 1 with b|b <;> rcases hb 2 with c|c <;>
    (simp only [a,b,c] at h01 h02 h12 ⊢; nlinarith)

theorem sum5_le (g : ZMod 5 → ℤ) (hb : ∀ z, g z=0 ∨ g z=1)
    (h : ∀ a, g a*g (a+1)≤0) : (∑ z, g z)≤2 := by
  change (∑ z : Fin 5, g z)≤2
  rw [Fin.sum_univ_five]
  change g (0:ZMod 5)+g (1:ZMod 5)+g (2:ZMod 5)+g (3:ZMod 5)+g (4:ZMod 5)≤2
  have h0 := h 0
  have h1 := h 1
  have h2 := h 2
  have h3 := h 3
  have h4 := h 4
  rw [show (0:ZMod 5)+1=1 from rfl] at h0
  rw [show (1:ZMod 5)+1=2 from rfl] at h1
  rw [show (2:ZMod 5)+1=3 from rfl] at h2
  rw [show (3:ZMod 5)+1=4 from rfl] at h3
  rw [show (4:ZMod 5)+1=0 from rfl] at h4
  change g 0*g 1≤0 at h0
  rcases hb 0 with a|a <;> rcases hb 1 with b|b <;> rcases hb 2 with c|c <;>
    rcases hb 3 with d|d <;> rcases hb 4 with e|e <;>
    (simp only [a,b,c,d,e] at h0 h1 h2 h3 h4 ⊢; nlinarith)

def ovC (A : Int113) (q q' : Site) : ℤ := ∑ p, A p q*A p q'

theorem ovC_same {A : Int113} (C : OrderedCycles (colLeave A) RP) (k : Fin RP.length) {n : ℕ}
    [NeZero n] (h : RP.get k=n) (x y : ZMod n) (hxy : x≠y) :
    ovC A (zsite C k h x) (zsite C k h y)=1-((if y=x+1 then 1 else 0)+(if y=x-1 then 1 else 0)) :=
  ovR_same (A := Aᵀ) C k h x y hxy

theorem ovC_diff {A : Int113} (C : OrderedCycles (colLeave A) RP) {k k' : Fin RP.length} {n m : ℕ}
    [NeZero n] [NeZero m] (h : RP.get k=n) (h' : RP.get k'=m) (hk : k≠k') (x : ZMod n) (y : ZMod m) :
    ovC A (zsite C k h x) (zsite C k' h' y)=1 :=
  ovR_diff (A := Aᵀ) C h h' hk x y

section Side
variable {A : Int113} (R : OrderedCycles (rowLeave A) RP) (C : OrderedCycles (colLeave A) RP)

def LB (i j : Fin 7) (x y : ZMod 15) : ℤ := A (sL R i x) (sL C j y)
def B5 (i : Fin 7) (x : ZMod 15) (z : ZMod 5) : ℤ := A (sL R i x) (s5 C z)
def B3 (i : Fin 7) (x : ZMod 15) (z : ZMod 3) : ℤ := A (sL R i x) (s3 C z)
def eR (i j : Fin 7) : ZMod 15 → ℤ := LB R C i j 0
def d5R (i : Fin 7) : ℤ := ∑ z, B5 R C i 0 z
def d3R (i : Fin 7) : ℤ := ∑ z, B3 R C i 0 z

variable (hA : Incidence113 A)
include R C hA

theorem LB_wave (i j : Fin 7) : BlockWave (LB R C i j) := zblk_wave hA R C (lg i) (lg j) (hL i) (hL j)
theorem B5_wave (i : Fin 7) : BlockWave (B5 R C i) := zblk_wave hA R C (lg i) j5 (hL i) h5
theorem B3_wave (i : Fin 7) : BlockWave (B3 R C i) := zblk_wave hA R C (lg i) j3 (hL i) h3
theorem LB_bin (i j : Fin 7) : ∀ x y, LB R C i j x y=0 ∨ LB R C i j x y=1 := fun _ _ => hA.binary _ _
theorem B5_bin (i : Fin 7) : ∀ x z, B5 R C i x z=0 ∨ B5 R C i x z=1 := fun _ _ => hA.binary _ _
theorem B3_bin (i : Fin 7) : ∀ x z, B3 R C i x z=0 ∨ B3 R C i x z=1 := fun _ _ => hA.binary _ _

/-- A row overlap split along the column cycles. -/
theorem ovR_split (p q : Site) : ovR A p q=(∑ j : Fin 7, ∑ y, A p (sL C j y)*A q (sL C j y))+
    (∑ z, A p (s5 C z)*A q (s5 C z))+∑ z, A p (s3 C z)*A q (s3 C z) :=
  residual_sum C (fun t => A p t*A q t)

theorem prod_nonneg (p q t : Site) : 0≤A p t*A q t := by
  rcases hA.binary p t with h|h <;> rcases hA.binary q t with h'|h' <;> simp [h,h']

theorem parts_nonneg (p q : Site) :
    (∀ j, 0≤∑ y, A p (sL C j y)*A q (sL C j y)) ∧ 0≤(∑ z, A p (s5 C z)*A q (s5 C z)) ∧
      0≤∑ z, A p (s3 C z)*A q (s3 C z) :=
  ⟨fun _ => Finset.sum_nonneg (fun _ _ => prod_nonneg R C hA _ _ _),
   Finset.sum_nonneg (fun _ _ => prod_nonneg R C hA _ _ _),
   Finset.sum_nonneg (fun _ _ => prod_nonneg R C hA _ _ _)⟩

theorem long_part_le (p q : Site) (j : Fin 7) :
    (∑ y, A p (sL C j y)*A q (sL C j y))≤ovR A p q := by
  rw [ovR_split R C hA]
  obtain ⟨h1,h2,h3⟩ := parts_nonneg R C hA p q
  have := Finset.single_le_sum (fun j _ => h1 j) (Finset.mem_univ j)
  linarith

theorem s5_part_le (p q : Site) : (∑ z, A p (s5 C z)*A q (s5 C z))≤ovR A p q := by
  rw [ovR_split R C hA]
  obtain ⟨h1,h2,h3⟩ := parts_nonneg R C hA p q
  have := Finset.sum_nonneg (fun j (_ : j ∈ Finset.univ) => h1 j)
  linarith

theorem s3_part_le (p q : Site) : (∑ z, A p (s3 C z)*A q (s3 C z))≤ovR A p q := by
  rw [ovR_split R C hA]
  obtain ⟨h1,h2,h3⟩ := parts_nonneg R C hA p q
  have := Finset.sum_nonneg (fun j (_ : j ∈ Finset.univ) => h1 j)
  linarith

theorem ovR_long_same (i : Fin 7) (x y : ZMod 15) (hxy : x≠y) :
    ovR A (sL R i x) (sL R i y)=1-((if y=x+1 then 1 else 0)+(if y=x-1 then 1 else 0)) :=
  ovR_same R (lg i) (hL i) x y hxy

theorem ovR_long_diff {i k : Fin 7} (hik : i≠k) (x y : ZMod 15) :
    ovR A (sL R i x) (sL R k y)=1 :=
  ovR_diff R (hL i) (hL k) (fun h => hik (lg_inj h)) x y

/-! Short degrees are at most one. -/

theorem d5_le (i : Fin 7) : d5R R C i≤1 := by
  have hper := cyclic_block_binary_gcd_period (B5 R C i) (B5_wave R C hA i) (B5_bin R C hA i) 5
    (by norm_num)
  have hov := ovR_long_same R C hA i 0 5 (by decide)
  have h55 : ((5 : ℕ) : ZMod 15)=5 := rfl
  simp only [show (5:ZMod 15)≠0+1 by decide, show (5:ZMod 15)≠0-1 by decide, if_false,
    add_zero, sub_zero] at hov
  have hle := s5_part_le R C hA (sL R i 0) (sL R i 5)
  rw [hov] at hle
  have he : ∀ z, A (sL R i 5) (s5 C z)=B5 R C i 0 z := by
    intro z
    have := hper 0 z
    rw [zero_add, h55] at this
    exact this
  simp only [he] at hle
  unfold d5R
  calc (∑ z, B5 R C i 0 z)=∑ z, B5 R C i 0 z*B5 R C i 0 z :=
        Finset.sum_congr rfl (fun z _ => (bin_sq (B5_bin R C hA i 0 z)).symm)
    _ ≤ 1 := hle

theorem d3_le (i : Fin 7) : d3R R C i≤1 := by
  have hper := cyclic_block_binary_gcd_period (B3 R C i) (B3_wave R C hA i) (B3_bin R C hA i) 3
    (by norm_num)
  have hov := ovR_long_same R C hA i 0 3 (by decide)
  have h33 : ((3 : ℕ) : ZMod 15)=3 := rfl
  simp only [show (3:ZMod 15)≠0+1 by decide, show (3:ZMod 15)≠0-1 by decide, if_false,
    add_zero, sub_zero] at hov
  have hle := s3_part_le R C hA (sL R i 0) (sL R i 3)
  rw [hov] at hle
  have he : ∀ z, A (sL R i 3) (s3 C z)=B3 R C i 0 z := by
    intro z
    have := hper 0 z
    rw [zero_add, h33] at this
    exact this
  simp only [he] at hle
  unfold d3R
  calc (∑ z, B3 R C i 0 z)=∑ z, B3 R C i 0 z*B3 R C i 0 z :=
        Finset.sum_congr rfl (fun z _ => (bin_sq (B3_bin R C hA i 0 z)).symm)
    _ ≤ 1 := hle

/-! Row sum, signature and realizability of one long row cycle. -/

theorem side_rowSum (i : Fin 7) :
    (∑ j, ∑ y, eR R C i j y)+d5R R C i+d3R R C i=11 := by
  have h := residual_sum C (fun t => A (sL R i 0) t)
  rw [hA.rows] at h
  unfold eR LB d5R d3R B5 B3
  linarith

omit R C hA in
theorem dist_facts : ∀ t<7, ((t+1 : ℕ) : ZMod 15)≠0 ∧ (((t+1 : ℕ) : ZMod 15)=0+1 ↔ t=0) ∧
    ((t+1 : ℕ) : ZMod 15)≠0-1 := by decide

theorem side_sig (i : Fin 7) (t : ℕ) (ht : t<7) :
    (∑ j, acZ (eR R C i j) ((t+1 : ℕ) : ZMod 15))+(if (t+1)%5=0 then d5R R C i else 0)+
      (if (t+1)%3=0 then d3R R C i else 0)=if t=0 then 0 else 1 := by
  obtain ⟨hne,h1,h2⟩ := dist_facts t ht
  set δ : ZMod 15 := ((t+1 : ℕ) : ZMod 15) with hδ
  have hov := ovR_long_same R C hA i 0 δ (Ne.symm hne)
  rw [if_neg h2] at hov
  have hval : δ.val=t+1 := by
    rw [hδ, ZMod.val_natCast]; exact Nat.mod_eq_of_lt (by omega)
  have hsplit := ovR_split R C hA (sL R i 0) (sL R i δ)
  have hL : ∀ j, (∑ y, A (sL R i 0) (sL C j y)*A (sL R i δ) (sL C j y))=acZ (eR R C i j) δ := by
    intro j
    have := long_rowov (LB R C i j) (LB_wave R C hA i j) (LB_bin R C hA i j) 0 δ
    rw [zero_add] at this
    exact this
  have h5 := short_overlap (m := 5) (Or.inr rfl) (B5 R C i) (B5_wave R C hA i) (B5_bin R C hA i)
    (d5_le R C hA i) 0 δ
  have h3 := short_overlap (m := 3) (Or.inl rfl) (B3 R C i) (B3_wave R C hA i) (B3_bin R C hA i)
    (d3_le R C hA i) 0 δ
  rw [zero_add, hval] at h5 h3
  simp only [Finset.sum_congr rfl (fun j _ => hL j)] at hsplit
  unfold B5 at h5
  unfold B3 at h3
  rw [h5, h3, hov] at hsplit
  unfold d5R d3R B5 B3
  by_cases ht0 : t=0
  · simp only [h1.mpr ht0, if_true, ht0] at hsplit ⊢; linarith
  · have : ¬ δ=0+1 := fun h => ht0 (h1.mp h)
    simp only [this, if_false, ht0] at hsplit ⊢; linarith

theorem side_ac1 (i j : Fin 7) : acZ (eR R C i j) 1=0 := by
  have hov := ovR_long_same R C hA i 0 1 (by decide)
  rw [if_pos (by decide : (1:ZMod 15)=0+1), if_neg (by decide : ¬ (1:ZMod 15)=0-1)] at hov
  have hle := long_part_le R C hA (sL R i 0) (sL R i 1) j
  rw [hov] at hle
  have h := long_rowov (LB R C i j) (LB_wave R C hA i j) (LB_bin R C hA i j) 0 1
  rw [zero_add] at h
  have hn := (parts_nonneg R C hA (sL R i 0) (sL R i 1)).1 j
  change (∑ y, LB R C i j 0 y*LB R C i j 1 y)≤1-(1+0) at hle
  change 0≤∑ y, LB R C i j 0 y*LB R C i j 1 y at hn
  unfold eR
  linarith

theorem side_acle (i j : Fin 7) (δ : ZMod 15) (hδ : δ≠0) : acZ (eR R C i j) δ≤1 := by
  have hne : sL R i 0≠sL R i δ := fun h => hδ ((zsite_eq_iff R (lg i) (hL i) 0 δ).mp h).symm
  have hle := long_part_le R C hA (sL R i 0) (sL R i δ) j
  have hov := hA.overlap _ _ hne
  have h := long_rowov (LB R C i j) (LB_wave R C hA i j) (LB_bin R C hA i j) 0 δ
  rw [zero_add] at h
  change (∑ y, LB R C i j 0 y*LB R C i j δ y)≤ovR A (sL R i 0) (sL R i δ) at hle
  unfold eR
  unfold ovR at hle
  linarith

theorem side_ebin (i j : Fin 7) : ∀ y, eR R C i j y=0 ∨ eR R C i j y=1 := fun _ => hA.binary _ _

/-- The first column of a long block has the same degree and autocorrelation
as its first row. -/
theorem side_col (i j : Fin 7) :
    (∑ x, LB R C i j x 0)=(∑ y, eR R C i j y) ∧
      ∀ δ, acZ (fun x => LB R C i j x 0) δ=acZ (eR R C i j) δ := by
  refine ⟨long_colsum _ (LB_wave R C hA i j) (LB_bin R C hA i j) 0, fun δ => ?_⟩
  have h := long_colov (LB R C i j) (LB_wave R C hA i j) (LB_bin R C hA i j) 0 δ
  rw [zero_add] at h
  -- the transposed block is again a binary wave
  have hwT : BlockWave (fun y x => LB R C i j x y) := fun y x => (LB_wave R C hA i j x y).symm
  have h2 := long_rowov (fun y x => LB R C i j x y) hwT (fun y x => LB_bin R C hA i j x y) 0 δ
  rw [zero_add] at h2
  exact h2.symm.trans h

/-! Gram identity between two long row cycles. -/

theorem B5_colsum (i : Fin 7) (z : ZMod 5) : (∑ x, B5 R C i x z)=3*d5R R C i := by
  have hc := cyclic_block_cols_constant (B5 R C i) (B5_wave R C hA i) z
  have ht := cyclic_block_totals (B5 R C i) (B5_wave R C hA i)
  simp only [Nat.cast_ofNat] at ht
  unfold d5R; rw [hc]; linarith

theorem B3_colsum (i : Fin 7) (z : ZMod 3) : (∑ x, B3 R C i x z)=5*d3R R C i := by
  have hc := cyclic_block_cols_constant (B3 R C i) (B3_wave R C hA i) z
  have ht := cyclic_block_totals (B3 R C i) (B3_wave R C hA i)
  simp only [Nat.cast_ofNat] at ht
  unfold d3R; rw [hc]; linarith

theorem side_gram {i k : Fin 7} (hik : i≠k) :
    (∑ j, (∑ y, eR R C i j y)*(∑ y, eR R C k j y))+3*d5R R C i*d5R R C k+
      5*d3R R C i*d3R R C k=15 := by
  have htot : (∑ x, ∑ x', ovR A (sL R i x) (sL R k x'))=225 := by
    simp only [ovR_long_diff R C hA hik, Finset.sum_const, Finset.card_univ, ZMod.card]
    norm_num
  simp only [ovR_split R C hA, Finset.sum_add_distrib] at htot
  have hL : (∑ x, ∑ x', ∑ j : Fin 7, ∑ y, A (sL R i x) (sL C j y)*A (sL R k x') (sL C j y))=
      15*∑ j, (∑ y, eR R C i j y)*(∑ y, eR R C k j y) := by
    rw [swap3, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j _
    have := gram_gen (LB R C i j) (LB R C k j) _ _
      (long_colsum _ (LB_wave R C hA i j) (LB_bin R C hA i j))
      (long_colsum _ (LB_wave R C hA k j) (LB_bin R C hA k j))
    simp only [ZMod.card, Nat.cast_ofNat] at this
    exact this
  have h5 := gram_gen (B5 R C i) (B5 R C k) _ _ (B5_colsum R C hA i) (B5_colsum R C hA k)
  have h3 := gram_gen (B3 R C i) (B3 R C k) _ _ (B3_colsum R C hA i) (B3_colsum R C hA k)
  simp only [ZMod.card, Nat.cast_ofNat] at h5 h3
  unfold B5 at h5
  unfold B3 at h3
  rw [hL, h5, h3] at htot
  linarith

/-! The short cycles. -/

theorem Q53_zero : ∀ z' z, A (s5 R z') (s3 C z)=0 := by
  have hc := coprime_block_const (a := 5) (b := 3) (by norm_num) (fun z' z => A (s5 R z') (s3 C z))
    (zblk_wave hA R C j5 j3 h5 h3) (fun _ _ => hA.binary _ _)
  intro z' z
  rw [hc z' z]
  rcases hA.binary (s5 R 0) (s3 C 0) with h|h
  · exact h
  · exfalso
    have hov := ovC_same C j3 h3 0 1 (by decide)
    rw [if_pos (by decide : (1:ZMod 3)=0+1), if_neg (by decide : ¬ (1:ZMod 3)=0-1)] at hov
    have h1 : A (s5 R 0) (s3 C 1)=1 := by rw [hc 0 1]; exact h
    have hle := Finset.single_le_sum (f := fun p => A p (s3 C 0)*A p (s3 C 1))
      (fun p _ => by
        rcases hA.binary p (s3 C 0) with a|a <;> rcases hA.binary p (s3 C 1) with b|b <;> simp [a,b])
      (Finset.mem_univ (s5 R 0))
    unfold ovC at hov
    change (∑ p, A p (s3 C 0)*A p (s3 C 1))=1-(1+0) at hov
    simp only [h, h1] at hle
    unfold s3 at hle hov
    linarith

theorem Q35_zero : ∀ z' z, A (s3 R z') (s5 C z)=0 := by
  have hc := coprime_block_const (a := 3) (b := 5) (by norm_num) (fun z' z => A (s3 R z') (s5 C z))
    (zblk_wave hA R C j3 j5 h3 h5) (fun _ _ => hA.binary _ _)
  intro z' z
  rw [hc z' z]
  rcases hA.binary (s3 R 0) (s5 C 0) with h|h
  · exact h
  · exfalso
    have hov := ovC_same C j5 h5 0 1 (by decide)
    rw [if_pos (by decide : (1:ZMod 5)=0+1), if_neg (by decide : ¬ (1:ZMod 5)=0-1)] at hov
    have h1 : A (s3 R 0) (s5 C 1)=1 := by rw [hc 0 1]; exact h
    have hle := Finset.single_le_sum (f := fun p => A p (s5 C 0)*A p (s5 C 1))
      (fun p _ => by
        rcases hA.binary p (s5 C 0) with a|a <;> rcases hA.binary p (s5 C 1) with b|b <;> simp [a,b])
      (Finset.mem_univ (s3 R 0))
    unfold ovC at hov
    change (∑ p, A p (s5 C 0)*A p (s5 C 1))=1-(1+0) at hov
    simp only [h, h1] at hle
    unfold s5 at hle hov
    linarith

theorem d5_nonneg (i : Fin 7) : 0≤d5R R C i :=
  Finset.sum_nonneg (fun z _ => bin_nonneg (B5_bin R C hA i 0 z))

theorem d3_nonneg (i : Fin 7) : 0≤d3R R C i :=
  Finset.sum_nonneg (fun z _ => bin_nonneg (B3_bin R C hA i 0 z))

/-! Counting the long row cycles that meet each short column cycle. -/

theorem count3 : (∑ i, d3R R C i)=2 := by
  have h := residual_sum R (fun p => A p (s3 C 0))
  rw [hA.cols] at h
  have h1 : ∀ i, (∑ x, A (sL R i x) (s3 C 0))=5*d3R R C i := fun i => B3_colsum R C hA i 0
  simp only [h1, Q53_zero R C hA, Finset.sum_const_zero] at h
  have hn : 0≤∑ z : ZMod 3, A (s3 R z) (s3 C 0) :=
    Finset.sum_nonneg (fun z _ => bin_nonneg (hA.binary _ _))
  have hb : (∑ z : ZMod 3, A (s3 R z) (s3 C 0))≤3 := by
    calc (∑ z : ZMod 3, A (s3 R z) (s3 C 0))≤∑ _z : ZMod 3, (1:ℤ) :=
          Finset.sum_le_sum (fun z _ => by rcases hA.binary (s3 R z) (s3 C 0) with e|e <;> rw [e] <;> norm_num)
      _ = 3 := by simp
  rw [← Finset.mul_sum] at h
  omega

theorem count5 : (∑ i, d5R R C i)=3 := by
  have h := residual_sum R (fun p => A p (s5 C 0))
  rw [hA.cols] at h
  have h1 : ∀ i, (∑ x, A (sL R i x) (s5 C 0))=3*d5R R C i := fun i => B5_colsum R C hA i 0
  simp only [h1, Q35_zero R C hA, Finset.sum_const_zero] at h
  have hn : 0≤∑ z : ZMod 5, A (s5 R z) (s5 C 0) :=
    Finset.sum_nonneg (fun z _ => bin_nonneg (hA.binary _ _))
  have hb : (∑ z : ZMod 5, A (s5 R z) (s5 C 0))≤2 := by
    apply sum5_le (fun z => A (s5 R z) (s5 C 0)) (fun z => hA.binary _ _)
    intro a
    have hne1 : ∀ a : ZMod 5, a≠a+1 := by decide
    have hne2 : ∀ a : ZMod 5, ¬ a+1=a-1 := by decide
    have hov := ovR_same R j5 h5 a (a+1) (hne1 a)
    rw [if_pos rfl, if_neg (hne2 a)] at hov
    have hle := Finset.single_le_sum (f := fun t => A (s5 R a) t*A (s5 R (a+1)) t)
      (fun t _ => prod_nonneg R C hA _ _ _) (Finset.mem_univ (s5 C 0))
    beta_reduce at hle
    show A (s5 R a) (s5 C 0)*A (s5 R (a+1)) (s5 C 0)≤0
    unfold ovR at hov
    unfold s5 at hle ⊢
    linarith
  rw [← Finset.mul_sum] at h
  omega

theorem count35 : (∑ i, d3R R C i*d5R R C i)=1 := by
  have htot : (∑ z : ZMod 3, ∑ w : ZMod 5, ovC A (s3 C z) (s5 C w))=15 := by
    have : ∀ z w, ovC A (s3 C z) (s5 C w)=1 := fun z w =>
      ovC_diff C h3 h5 (by decide) z w
    simp only [this, Finset.sum_const, Finset.card_univ, ZMod.card]
    norm_num
  unfold ovC at htot
  have hsw : (∑ z : ZMod 3, ∑ w : ZMod 5, ∑ p, A p (s3 C z)*A p (s5 C w))=
      ∑ p, (∑ z : ZMod 3, A p (s3 C z))*(∑ w : ZMod 5, A p (s5 C w)) := by
    simp_rw [Finset.sum_mul_sum]
    conv_rhs => rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun z _ => ?_
    exact Finset.sum_comm
  rw [hsw, residual_sum R] at htot
  have hrow3 : ∀ i x, (∑ z : ZMod 3, A (sL R i x) (s3 C z))=d3R R C i := fun i x =>
    cyclic_block_rows_constant (B3 R C i) (B3_wave R C hA i) x
  have hrow5 : ∀ i x, (∑ w : ZMod 5, A (sL R i x) (s5 C w))=d5R R C i := fun i x =>
    cyclic_block_rows_constant (B5 R C i) (B5_wave R C hA i) x
  simp only [hrow3, hrow5, Q53_zero R C hA, Q35_zero R C hA, Finset.sum_const_zero, zero_mul,
    mul_zero, add_zero, Finset.sum_const, Finset.card_univ, ZMod.card, nsmul_eq_mul] at htot
  rw [← Finset.mul_sum] at htot
  push_cast at htot
  omega

end Side
end Symconf113

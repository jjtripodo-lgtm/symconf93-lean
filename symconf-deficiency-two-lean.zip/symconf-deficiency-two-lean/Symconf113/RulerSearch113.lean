import Mathlib.Data.ZMod.Basic
import Mathlib.Data.Finset.Max

/-! Kernel search: no 11-subset of `ZMod 113` containing `0` and `1` has all
nonzero differences distinct. Elements are naturals below `113`, chosen in
increasing order; used differences are kept as a bit mask. This file holds
the search and its completeness; the kernel runs are in `RulerShard113_*`. -/
namespace Symconf113.Ruler113

/-- The difference `a - b` in `ZMod 113`, as a natural below `113`. -/
def dd (a b : ℕ) : ℕ := (a+113-b)%113

/-- Add the differences `x-y` and `y-x` for `y ∈ s` to the mask `m`, failing on a repeat. -/
def addDiffs (x : ℕ) : List ℕ → ℕ → Option ℕ
  | [], m => some m
  | y :: s, m =>
    if m.testBit (dd x y) then none else
    if (m ||| 2^(dd x y)).testBit (dd y x) then none else
    addDiffs x s (m ||| 2^(dd x y) ||| 2^(dd y x))

/-- Can `s` (mask `m`) be extended by `k` more elements from `[lo,113)`? -/
def ext : ℕ → List ℕ → ℕ → ℕ → Bool
  | 0, _, _, _ => true
  | k+1, s, m, lo => (List.range' lo (113-lo)).any fun x =>
      match addDiffs x s m with
      | none => false
      | some m' => ext k (x :: s) m' (x+1)

/-- The mask of the differences of `{0,1}`. -/
def m01 : ℕ := 2^1 ||| 2^112

/-- One branch of the search at the third element `x`. -/
def stepF (x : ℕ) : Bool :=
  match addDiffs x [1,0] m01 with
  | none => false
  | some m' => ext 8 [x,1,0] m' (x+1)

theorem ext_root : ext 9 [1,0] m01 2=(List.range' 2 111).any stepF := rfl

/-- All differences distinct on the points satisfying `M`. -/
def GoodSet (M : ℕ → Prop) : Prop :=
  ∀ a b c e, M a → M b → M c → M e → a≠b → c≠e → dd a b=dd c e → a=c ∧ b=e

/-- `e` is a difference of two distinct entries of `s`. -/
def Dl (s : List ℕ) (e : ℕ) : Prop := ∃ a ∈ s, ∃ b ∈ s, a≠b ∧ dd a b=e

theorem testBit_or_pow (m d e : ℕ) : (m ||| 2^d).testBit e=true ↔ m.testBit e=true ∨ d=e := by
  rw [Nat.testBit_or, Nat.testBit_two_pow]; simp

theorem addDiffs_ok (x : ℕ) (M : ℕ → Prop) (hG : GoodSet M) (hx : M x) :
    ∀ (r : List ℕ) (m : ℕ) (S : ℕ → Prop), (∀ y ∈ r, M y ∧ y≠x) → r.Nodup →
      (∀ e, m.testBit e=true → S e) → (∀ y ∈ r, ¬ S (dd x y) ∧ ¬ S (dd y x)) →
      ∃ m', addDiffs x r m=some m' ∧
        ∀ e, m'.testBit e=true → S e ∨ ∃ y ∈ r, e=dd x y ∨ e=dd y x := by
  intro r
  induction r with
  | nil => intro m S _ _ hm _; exact ⟨m,rfl,fun e he => Or.inl (hm e he)⟩
  | cons y r ih =>
    intro m S hr hnd hm hf
    obtain ⟨hMy,hyx⟩ := hr y (List.mem_cons_self ..)
    have hnd' := List.nodup_cons.mp hnd
    have h1 : m.testBit (dd x y)=false := by
      cases h : m.testBit (dd x y)
      · rfl
      · exact absurd (hm _ h) (hf y (List.mem_cons_self ..)).1
    have hne : dd x y≠dd y x := fun h => hyx (hG _ _ _ _ hx hMy hMy hx (Ne.symm hyx) hyx h).2
    have h2 : (m ||| 2^(dd x y)).testBit (dd y x)=false := by
      cases h : (m ||| 2^(dd x y)).testBit (dd y x)
      · rfl
      · rcases (testBit_or_pow _ _ _).mp h with h'|h'
        · exact absurd (hm _ h') (hf y (List.mem_cons_self ..)).2
        · exact absurd h' hne
    obtain ⟨m',hm',hres⟩ := ih (m ||| 2^(dd x y) ||| 2^(dd y x))
      (fun e => S e ∨ e=dd x y ∨ e=dd y x)
      (fun z hz => hr z (List.mem_cons_of_mem _ hz)) hnd'.2
      (by
        intro e he
        rcases (testBit_or_pow _ _ _).mp he with h|h
        · rcases (testBit_or_pow _ _ _).mp h with h|h
          · exact Or.inl (hm e h)
          · exact Or.inr (Or.inl h.symm)
        · exact Or.inr (Or.inr h.symm))
      (by
        intro z hz
        obtain ⟨hMz,hzx⟩ := hr z (List.mem_cons_of_mem _ hz)
        have hzy : z≠y := fun h => hnd'.1 (h ▸ hz)
        obtain ⟨f1,f2⟩ := hf z (List.mem_cons_of_mem _ hz)
        refine ⟨?_,?_⟩
        · rintro (h|h|h)
          · exact f1 h
          · exact hzy (hG _ _ _ _ hx hMz hx hMy (Ne.symm hzx) (Ne.symm hyx) h).2
          · exact hzx (hG _ _ _ _ hx hMz hMy hx (Ne.symm hzx) hyx h).2
        · rintro (h|h|h)
          · exact f2 h
          · exact hzx (hG _ _ _ _ hMz hx hx hMy hzx (Ne.symm hyx) h).1
          · exact hzy (hG _ _ _ _ hMz hx hMy hx hzx hyx h).1)
    refine ⟨m',?_,?_⟩
    · simp only [addDiffs, h1, h2, Bool.false_eq_true, if_false]; exact hm'
    · intro e he
      rcases hres e he with (h|h|h)|⟨z,hz,h⟩
      · exact Or.inl h
      · exact Or.inr ⟨y,List.mem_cons_self ..,Or.inl h⟩
      · exact Or.inr ⟨y,List.mem_cons_self ..,Or.inr h⟩
      · exact Or.inr ⟨z,List.mem_cons_of_mem _ hz,h⟩

/-- Completeness of the search: a good set above `lo` extending `s` is found. -/
theorem ext_complete : ∀ (k : ℕ) (T : Finset ℕ) (s : List ℕ) (m lo : ℕ),
    T.card=k → (∀ t ∈ T, lo≤t ∧ t<113) → (∀ y ∈ s, y<lo) → s.Nodup →
    GoodSet (fun z => z ∈ T ∨ z ∈ s) → (∀ e, m.testBit e=true → Dl s e) →
    ext k s m lo=true := by
  intro k
  induction k with
  | zero => intro _ _ _ _ _ _ _ _ _ _; rfl
  | succ k ih =>
    intro T s m lo hc hT hs hnd hG hm
    have hne : T.Nonempty := Finset.card_pos.mp (by omega)
    set x := T.min' hne with hxdef
    have hxT : x ∈ T := Finset.min'_mem T hne
    obtain ⟨hlo,h113⟩ := hT x hxT
    have hxs : ∀ y ∈ s, y≠x := fun y hy h => by have := hs y hy; omega
    have hMx : x ∈ T ∨ x ∈ s := Or.inl hxT
    obtain ⟨m',hm',hres⟩ := addDiffs_ok x _ hG hMx s m (Dl s)
      (fun y hy => ⟨Or.inr hy,hxs y hy⟩) hnd hm
      (by
        intro y hy
        refine ⟨?_,?_⟩
        · rintro ⟨a,ha,b,hb,hab,h⟩
          have := (hG _ _ _ _ (Or.inr ha) (Or.inr hb) hMx (Or.inr hy) hab (Ne.symm (hxs y hy)) h).1
          exact hxs a ha this
        · rintro ⟨a,ha,b,hb,hab,h⟩
          have := (hG _ _ _ _ (Or.inr ha) (Or.inr hb) (Or.inr hy) hMx hab (hxs y hy) h).2
          exact hxs b hb this)
    unfold ext
    rw [List.any_eq_true]
    refine ⟨x,List.mem_range'_1.mpr ⟨hlo,by omega⟩,?_⟩
    rw [hm']
    apply ih (T.erase x) (x :: s) m' (x+1)
    · rw [Finset.card_erase_of_mem hxT]; omega
    · intro t ht
      obtain ⟨htx,htT⟩ := Finset.mem_erase.mp ht
      have := Finset.min'_le T t htT
      exact ⟨by rw [← hxdef] at this; omega,(hT t htT).2⟩
    · intro y hy
      rcases List.mem_cons.mp hy with h|h
      · omega
      · have := hs y h; omega
    · exact List.nodup_cons.mpr ⟨fun h => hxs x h rfl,hnd⟩
    · have hiff : ∀ z, (z ∈ T.erase x ∨ z ∈ x :: s) ↔ (z ∈ T ∨ z ∈ s) := by
        intro z
        simp only [Finset.mem_erase, List.mem_cons]
        constructor
        · rintro (⟨_,h⟩|h|h)
          · exact Or.inl h
          · exact Or.inl (h ▸ hxT)
          · exact Or.inr h
        · rintro (h|h)
          · by_cases hz : z=x
            · exact Or.inr (Or.inl hz)
            · exact Or.inl ⟨hz,h⟩
          · exact Or.inr (Or.inr h)
      intro a b c e ha hb hc he
      exact hG a b c e ((hiff a).mp ha) ((hiff b).mp hb) ((hiff c).mp hc) ((hiff e).mp he)
    · intro e he
      rcases hres e he with ⟨a,ha,b,hb,hab,h⟩|⟨y,hy,h|h⟩
      · exact ⟨a,List.mem_cons_of_mem _ ha,b,List.mem_cons_of_mem _ hb,hab,h⟩
      · exact ⟨x,List.mem_cons_self ..,y,List.mem_cons_of_mem _ hy,(hxs y hy).symm,h.symm⟩
      · exact ⟨y,List.mem_cons_of_mem _ hy,x,List.mem_cons_self ..,hxs y hy,h.symm⟩

theorem m01_bits (e : ℕ) (h : m01.testBit e=true) : Dl [1,0] e := by
  unfold m01 at h
  rcases (testBit_or_pow _ _ _).mp h with h|h
  · rw [Nat.testBit_two_pow] at h
    have : e=1 := by simp at h; omega
    exact ⟨1,by simp,0,by simp,by decide,by rw [this]; rfl⟩
  · exact ⟨0,by simp,1,by simp,by decide,by rw [← h]; rfl⟩

end Symconf113.Ruler113

import Symconf113.CoverageShard113_016
import Symconf113.CoverageShard113_017
import Symconf113.CoverageShard113_018

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0815 : NodeCoverage113 [48,12,5] 5 48 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0816 : NodeCoverage113 [48,12,3] 3 50 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0817 : NodeCoverage113 [48,12] 12 53 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0808
    (ChildrenCoverage113.cons _ _ compact113_node_0809
    (ChildrenCoverage113.cons _ _ compact113_node_0810
    (ChildrenCoverage113.cons _ _ compact113_node_0811
    (ChildrenCoverage113.cons _ _ compact113_node_0812
    (ChildrenCoverage113.cons _ _ compact113_node_0813
    (ChildrenCoverage113.cons _ _ compact113_node_0814
    (ChildrenCoverage113.cons _ _ compact113_node_0815
    (ChildrenCoverage113.cons _ _ compact113_node_0816
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_0818 : NodeCoverage113 [48,11] 11 54 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0819 : NodeCoverage113 [48,10] 10 55 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0820 : NodeCoverage113 [48,9] 9 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0821 : NodeCoverage113 [48,8] 8 57 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0822 : NodeCoverage113 [48,7] 7 58 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0823 : NodeCoverage113 [48,6] 6 59 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0824 : NodeCoverage113 [48,5] 5 60 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0825 : NodeCoverage113 [48,3] 3 62 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0826 : NodeCoverage113 [48] 48 65 :=
  node_fork113 (B := [48,47,46,45,44,43,42,41,40,39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0705
    (ChildrenCoverage113.cons _ _ compact113_node_0706
    (ChildrenCoverage113.cons _ _ compact113_node_0707
    (ChildrenCoverage113.cons _ _ compact113_node_0708
    (ChildrenCoverage113.cons _ _ compact113_node_0709
    (ChildrenCoverage113.cons _ _ compact113_node_0710
    (ChildrenCoverage113.cons _ _ compact113_node_0711
    (ChildrenCoverage113.cons _ _ compact113_node_0712
    (ChildrenCoverage113.cons _ _ compact113_node_0713
    (ChildrenCoverage113.cons _ _ compact113_node_0714
    (ChildrenCoverage113.cons _ _ compact113_node_0715
    (ChildrenCoverage113.cons _ _ compact113_node_0716
    (ChildrenCoverage113.cons _ _ compact113_node_0717
    (ChildrenCoverage113.cons _ _ compact113_node_0718
    (ChildrenCoverage113.cons _ _ compact113_node_0719
    (ChildrenCoverage113.cons _ _ compact113_node_0720
    (ChildrenCoverage113.cons _ _ compact113_node_0721
    (ChildrenCoverage113.cons _ _ compact113_node_0722
    (ChildrenCoverage113.cons _ _ compact113_node_0723
    (ChildrenCoverage113.cons _ _ compact113_node_0724
    (ChildrenCoverage113.cons _ _ compact113_node_0725
    (ChildrenCoverage113.cons _ _ compact113_node_0726
    (ChildrenCoverage113.cons _ _ compact113_node_0727
    (ChildrenCoverage113.cons _ _ compact113_node_0728
    (ChildrenCoverage113.cons _ _ compact113_node_0729
    (ChildrenCoverage113.cons _ _ compact113_node_0730
    (ChildrenCoverage113.cons _ _ compact113_node_0731
    (ChildrenCoverage113.cons _ _ compact113_node_0732
    (ChildrenCoverage113.cons _ _ compact113_node_0733
    (ChildrenCoverage113.cons _ _ compact113_node_0734
    (ChildrenCoverage113.cons _ _ compact113_node_0735
    (ChildrenCoverage113.cons _ _ compact113_node_0736
    (ChildrenCoverage113.cons _ _ compact113_node_0776
    (ChildrenCoverage113.cons _ _ compact113_node_0777
    (ChildrenCoverage113.cons _ _ compact113_node_0778
    (ChildrenCoverage113.cons _ _ compact113_node_0779
    (ChildrenCoverage113.cons _ _ compact113_node_0817
    (ChildrenCoverage113.cons _ _ compact113_node_0818
    (ChildrenCoverage113.cons _ _ compact113_node_0819
    (ChildrenCoverage113.cons _ _ compact113_node_0820
    (ChildrenCoverage113.cons _ _ compact113_node_0821
    (ChildrenCoverage113.cons _ _ compact113_node_0822
    (ChildrenCoverage113.cons _ _ compact113_node_0823
    (ChildrenCoverage113.cons _ _ compact113_node_0824
    (ChildrenCoverage113.cons _ _ compact113_node_0825
    ChildrenCoverage113.nil)))))))))))))))))))))))))))))))))))))))))))))

theorem compact113_node_0827 : NodeCoverage113 [47] 47 66 :=
  demand_node_prune113 47 compact113_demands_047 compact113_demands_047_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0828 : NodeCoverage113 [46] 46 67 :=
  demand_node_prune113 46 compact113_demands_046 compact113_demands_046_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0829 : NodeCoverage113 [45,45,23] 23 0 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0830 : NodeCoverage113 [45,45,20] 20 3 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0831 : NodeCoverage113 [45,45,19] 19 4 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0832 : NodeCoverage113 [45,45,18] 18 5 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0833 : NodeCoverage113 [45,45,17] 17 6 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0834 : NodeCoverage113 [45,45,16] 16 7 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0835 : NodeCoverage113 [45,45,15,8] 8 0 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0836 : NodeCoverage113 [45,45,15,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0837 : NodeCoverage113 [45,45,15,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0836
    ChildrenCoverage113.nil)

theorem compact113_node_0838 : NodeCoverage113 [45,45,15,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0839 : NodeCoverage113 [45,45,15] 15 8 :=
  node_fork113 (B := [8,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0835
    (ChildrenCoverage113.cons _ _ compact113_node_0837
    (ChildrenCoverage113.cons _ _ compact113_node_0838
    ChildrenCoverage113.nil)))

theorem compact113_node_0840 : NodeCoverage113 [45,45,14] 14 9 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0841 : NodeCoverage113 [45,45,13] 13 10 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0842 : NodeCoverage113 [45,45,12] 12 11 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0843 : NodeCoverage113 [45,45,11] 11 12 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0844 : NodeCoverage113 [45,45,10] 10 13 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0845 : NodeCoverage113 [45,45,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0846 : NodeCoverage113 [45,45,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0847 : NodeCoverage113 [45,45,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0848 : NodeCoverage113 [45,45,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0849 : NodeCoverage113 [45,45,5] 5 18 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0850 : NodeCoverage113 [45,45,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0851 : NodeCoverage113 [45,45] 45 23 :=
  node_fork113 (B := [23,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0829
    (ChildrenCoverage113.cons _ _ compact113_node_0830
    (ChildrenCoverage113.cons _ _ compact113_node_0831
    (ChildrenCoverage113.cons _ _ compact113_node_0832
    (ChildrenCoverage113.cons _ _ compact113_node_0833
    (ChildrenCoverage113.cons _ _ compact113_node_0834
    (ChildrenCoverage113.cons _ _ compact113_node_0839
    (ChildrenCoverage113.cons _ _ compact113_node_0840
    (ChildrenCoverage113.cons _ _ compact113_node_0841
    (ChildrenCoverage113.cons _ _ compact113_node_0842
    (ChildrenCoverage113.cons _ _ compact113_node_0843
    (ChildrenCoverage113.cons _ _ compact113_node_0844
    (ChildrenCoverage113.cons _ _ compact113_node_0845
    (ChildrenCoverage113.cons _ _ compact113_node_0846
    (ChildrenCoverage113.cons _ _ compact113_node_0847
    (ChildrenCoverage113.cons _ _ compact113_node_0848
    (ChildrenCoverage113.cons _ _ compact113_node_0849
    (ChildrenCoverage113.cons _ _ compact113_node_0850
    ChildrenCoverage113.nil))))))))))))))))))

theorem compact113_node_0852 : NodeCoverage113 [45,44] 44 24 :=
  demand_node_prune113 44 compact113_demands_044 compact113_demands_044_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0853 : NodeCoverage113 [45,43] 43 25 :=
  demand_node_prune113 43 compact113_demands_043 compact113_demands_043_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0854 : NodeCoverage113 [45,42] 42 26 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0855 : NodeCoverage113 [45,41] 41 27 :=
  demand_node_prune113 41 compact113_demands_041 compact113_demands_041_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_069

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2522 : NodeCoverage113 [30,10,10,10,5] 5 48 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2523 : NodeCoverage113 [30,10,10,10,3] 3 50 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2524 : NodeCoverage113 [30,10,10,10] 10 53 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2517
    (ChildrenCoverage113.cons _ _ compact113_node_2518
    (ChildrenCoverage113.cons _ _ compact113_node_2519
    (ChildrenCoverage113.cons _ _ compact113_node_2520
    (ChildrenCoverage113.cons _ _ compact113_node_2521
    (ChildrenCoverage113.cons _ _ compact113_node_2522
    (ChildrenCoverage113.cons _ _ compact113_node_2523
    ChildrenCoverage113.nil)))))))

theorem compact113_node_2525 : NodeCoverage113 [30,10,10,9] 9 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2526 : NodeCoverage113 [30,10,10,8] 8 55 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2527 : NodeCoverage113 [30,10,10,7] 7 56 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2528 : NodeCoverage113 [30,10,10,6] 6 57 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

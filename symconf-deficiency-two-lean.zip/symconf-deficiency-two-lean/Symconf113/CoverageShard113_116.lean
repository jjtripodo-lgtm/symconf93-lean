import Symconf113.CoverageShard113_115

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4368 : NodeCoverage113 [19] 19 94 :=
  node_fork113 (B := [19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4352
    (ChildrenCoverage113.cons _ _ compact113_node_4353
    (ChildrenCoverage113.cons _ _ compact113_node_4354
    (ChildrenCoverage113.cons _ _ compact113_node_4355
    (ChildrenCoverage113.cons _ _ compact113_node_4356
    (ChildrenCoverage113.cons _ _ compact113_node_4357
    (ChildrenCoverage113.cons _ _ compact113_node_4358
    (ChildrenCoverage113.cons _ _ compact113_node_4359
    (ChildrenCoverage113.cons _ _ compact113_node_4360
    (ChildrenCoverage113.cons _ _ compact113_node_4361
    (ChildrenCoverage113.cons _ _ compact113_node_4362
    (ChildrenCoverage113.cons _ _ compact113_node_4363
    (ChildrenCoverage113.cons _ _ compact113_node_4364
    (ChildrenCoverage113.cons _ _ compact113_node_4365
    (ChildrenCoverage113.cons _ _ compact113_node_4366
    (ChildrenCoverage113.cons _ _ compact113_node_4367
    ChildrenCoverage113.nil))))))))))))))))

theorem compact113_node_4369 : NodeCoverage113 [18,18,18,18,18,18,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4370 : NodeCoverage113 [18,18,18,18,18,18] 18 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4369
    ChildrenCoverage113.nil)

theorem compact113_node_4371 : NodeCoverage113 [18,18,18,18,18,17] 17 6 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4372 : NodeCoverage113 [18,18,18,18,18,16] 16 7 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4373 : NodeCoverage113 [18,18,18,18,18,15] 15 8 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4374 : NodeCoverage113 [18,18,18,18,18,14] 14 9 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4375 : NodeCoverage113 [18,18,18,18,18,13] 13 10 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4376 : NodeCoverage113 [18,18,18,18,18,12] 12 11 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4377 : NodeCoverage113 [18,18,18,18,18,11] 11 12 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4378 : NodeCoverage113 [18,18,18,18,18,10] 10 13 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4379 : NodeCoverage113 [18,18,18,18,18,9,9,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4380 : NodeCoverage113 [18,18,18,18,18,9,9] 9 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4379
    ChildrenCoverage113.nil)

theorem compact113_node_4381 : NodeCoverage113 [18,18,18,18,18,9,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4382 : NodeCoverage113 [18,18,18,18,18,9,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4383 : NodeCoverage113 [18,18,18,18,18,9,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4384 : NodeCoverage113 [18,18,18,18,18,9,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4385 : NodeCoverage113 [18,18,18,18,18,9,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4386 : NodeCoverage113 [18,18,18,18,18,9,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4385
    ChildrenCoverage113.nil)

theorem compact113_node_4387 : NodeCoverage113 [18,18,18,18,18,9,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4386
    ChildrenCoverage113.nil)

theorem compact113_node_4388 : NodeCoverage113 [18,18,18,18,18,9] 9 14 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4380
    (ChildrenCoverage113.cons _ _ compact113_node_4381
    (ChildrenCoverage113.cons _ _ compact113_node_4382
    (ChildrenCoverage113.cons _ _ compact113_node_4383
    (ChildrenCoverage113.cons _ _ compact113_node_4384
    (ChildrenCoverage113.cons _ _ compact113_node_4387
    ChildrenCoverage113.nil))))))

theorem compact113_node_4389 : NodeCoverage113 [18,18,18,18,18,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4390 : NodeCoverage113 [18,18,18,18,18,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4391 : NodeCoverage113 [18,18,18,18,18,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4392 : NodeCoverage113 [18,18,18,18,18,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4391
    ChildrenCoverage113.nil)

theorem compact113_node_4393 : NodeCoverage113 [18,18,18,18,18,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4394 : NodeCoverage113 [18,18,18,18,18,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4395 : NodeCoverage113 [18,18,18,18,18,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4394
    ChildrenCoverage113.nil)

theorem compact113_node_4396 : NodeCoverage113 [18,18,18,18,18,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4392
    (ChildrenCoverage113.cons _ _ compact113_node_4393
    (ChildrenCoverage113.cons _ _ compact113_node_4395
    ChildrenCoverage113.nil)))

theorem compact113_node_4397 : NodeCoverage113 [18,18,18,18,18,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4398 : NodeCoverage113 [18,18,18,18,18,6,3] 3 14 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4399 : NodeCoverage113 [18,18,18,18,18,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4396
    (ChildrenCoverage113.cons _ _ compact113_node_4397
    (ChildrenCoverage113.cons _ _ compact113_node_4398
    ChildrenCoverage113.nil)))

theorem compact113_node_4400 : NodeCoverage113 [18,18,18,18,18,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4401 : NodeCoverage113 [18,18,18,18,18,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4402 : NodeCoverage113 [18,18,18,18,18,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4401
    ChildrenCoverage113.nil)

theorem compact113_node_4403 : NodeCoverage113 [18,18,18,18,18,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4402
    ChildrenCoverage113.nil)

theorem compact113_node_4404 : NodeCoverage113 [18,18,18,18,18,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4403
    ChildrenCoverage113.nil)

theorem compact113_node_4405 : NodeCoverage113 [18,18,18,18,18,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4404
    ChildrenCoverage113.nil)

theorem compact113_node_4406 : NodeCoverage113 [18,18,18,18,18,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4405
    ChildrenCoverage113.nil)

theorem compact113_node_4407 : NodeCoverage113 [18,18,18,18,18] 18 23 :=
  node_fork113 (B := [18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4370
    (ChildrenCoverage113.cons _ _ compact113_node_4371
    (ChildrenCoverage113.cons _ _ compact113_node_4372
    (ChildrenCoverage113.cons _ _ compact113_node_4373
    (ChildrenCoverage113.cons _ _ compact113_node_4374
    (ChildrenCoverage113.cons _ _ compact113_node_4375
    (ChildrenCoverage113.cons _ _ compact113_node_4376
    (ChildrenCoverage113.cons _ _ compact113_node_4377
    (ChildrenCoverage113.cons _ _ compact113_node_4378
    (ChildrenCoverage113.cons _ _ compact113_node_4388
    (ChildrenCoverage113.cons _ _ compact113_node_4389
    (ChildrenCoverage113.cons _ _ compact113_node_4390
    (ChildrenCoverage113.cons _ _ compact113_node_4399
    (ChildrenCoverage113.cons _ _ compact113_node_4400
    (ChildrenCoverage113.cons _ _ compact113_node_4406
    ChildrenCoverage113.nil)))))))))))))))

theorem compact113_node_4408 : NodeCoverage113 [18,18,18,18,17] 17 24 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4409 : NodeCoverage113 [18,18,18,18,16] 16 25 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4410 : NodeCoverage113 [18,18,18,18,15] 15 26 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4411 : NodeCoverage113 [18,18,18,18,14] 14 27 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4412 : NodeCoverage113 [18,18,18,18,13] 13 28 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4413 : NodeCoverage113 [18,18,18,18,12] 12 29 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4414 : NodeCoverage113 [18,18,18,18,11] 11 30 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4415 : NodeCoverage113 [18,18,18,18,10] 10 31 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4416 : NodeCoverage113 [18,18,18,18,9,9,9,9,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4417 : NodeCoverage113 [18,18,18,18,9,9,9,9] 9 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4416
    ChildrenCoverage113.nil)

theorem compact113_node_4418 : NodeCoverage113 [18,18,18,18,9,9,9,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4419 : NodeCoverage113 [18,18,18,18,9,9,9,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4420 : NodeCoverage113 [18,18,18,18,9,9,9,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4421 : NodeCoverage113 [18,18,18,18,9,9,9,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4422 : NodeCoverage113 [18,18,18,18,9,9,9,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4423 : NodeCoverage113 [18,18,18,18,9,9,9,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4422
    ChildrenCoverage113.nil)

theorem compact113_node_4424 : NodeCoverage113 [18,18,18,18,9,9,9,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4423
    ChildrenCoverage113.nil)

theorem compact113_node_4425 : NodeCoverage113 [18,18,18,18,9,9,9] 9 14 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4417
    (ChildrenCoverage113.cons _ _ compact113_node_4418
    (ChildrenCoverage113.cons _ _ compact113_node_4419
    (ChildrenCoverage113.cons _ _ compact113_node_4420
    (ChildrenCoverage113.cons _ _ compact113_node_4421
    (ChildrenCoverage113.cons _ _ compact113_node_4424
    ChildrenCoverage113.nil))))))

theorem compact113_node_4426 : NodeCoverage113 [18,18,18,18,9,9,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4427 : NodeCoverage113 [18,18,18,18,9,9,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4428 : NodeCoverage113 [18,18,18,18,9,9,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4429 : NodeCoverage113 [18,18,18,18,9,9,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4428
    ChildrenCoverage113.nil)

theorem compact113_node_4430 : NodeCoverage113 [18,18,18,18,9,9,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4431 : NodeCoverage113 [18,18,18,18,9,9,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4432 : NodeCoverage113 [18,18,18,18,9,9,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4431
    ChildrenCoverage113.nil)

theorem compact113_node_4433 : NodeCoverage113 [18,18,18,18,9,9,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4429
    (ChildrenCoverage113.cons _ _ compact113_node_4430
    (ChildrenCoverage113.cons _ _ compact113_node_4432
    ChildrenCoverage113.nil)))

theorem compact113_node_4434 : NodeCoverage113 [18,18,18,18,9,9,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4435 : NodeCoverage113 [18,18,18,18,9,9,6,3] 3 14 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4436 : NodeCoverage113 [18,18,18,18,9,9,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4433
    (ChildrenCoverage113.cons _ _ compact113_node_4434
    (ChildrenCoverage113.cons _ _ compact113_node_4435
    ChildrenCoverage113.nil)))

theorem compact113_node_4437 : NodeCoverage113 [18,18,18,18,9,9,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4438 : NodeCoverage113 [18,18,18,18,9,9,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4439 : NodeCoverage113 [18,18,18,18,9,9,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4438
    ChildrenCoverage113.nil)

theorem compact113_node_4440 : NodeCoverage113 [18,18,18,18,9,9,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4439
    ChildrenCoverage113.nil)

theorem compact113_node_4441 : NodeCoverage113 [18,18,18,18,9,9,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4440
    ChildrenCoverage113.nil)

theorem compact113_node_4442 : NodeCoverage113 [18,18,18,18,9,9,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4441
    ChildrenCoverage113.nil)

end Symconf113

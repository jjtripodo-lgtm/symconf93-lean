import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3824 : NodeCoverage113 [21,21,15] 15 56 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3825 : NodeCoverage113 [21,21,14] 14 57 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3826 : NodeCoverage113 [21,21,13] 13 58 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3827 : NodeCoverage113 [21,21,12] 12 59 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3828 : NodeCoverage113 [21,21,11] 11 60 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3829 : NodeCoverage113 [21,21,10] 10 61 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3830 : NodeCoverage113 [21,21,9] 9 62 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3831 : NodeCoverage113 [21,21,8] 8 63 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3832 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3833 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3834 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3832
    (ChildrenCoverage113.cons _ _ compact113_node_3833
    ChildrenCoverage113.nil))

theorem compact113_node_3835 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,7,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3836 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3837 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,7,3,3,3,3,3] 3 0 :=
  node_no_weak_demand113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3838 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,7,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3837
    ChildrenCoverage113.nil)

theorem compact113_node_3839 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,7,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3838
    ChildrenCoverage113.nil)

theorem compact113_node_3840 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,7,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3839
    ChildrenCoverage113.nil)

theorem compact113_node_3841 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,7,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3840
    ChildrenCoverage113.nil)

theorem compact113_node_3842 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3834
    (ChildrenCoverage113.cons _ _ compact113_node_3835
    (ChildrenCoverage113.cons _ _ compact113_node_3836
    (ChildrenCoverage113.cons _ _ compact113_node_3841
    ChildrenCoverage113.nil))))

theorem compact113_node_3843 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3844 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3845 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,3,3,3,3,3,3] 3 4 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_3846 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,3,3,3,3,3] 3 7 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3845
    ChildrenCoverage113.nil)

theorem compact113_node_3847 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,3,3,3,3] 3 10 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3846
    ChildrenCoverage113.nil)

theorem compact113_node_3848 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,3,3,3] 3 13 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3847
    ChildrenCoverage113.nil)

theorem compact113_node_3849 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,3,3] 3 16 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3848
    ChildrenCoverage113.nil)

theorem compact113_node_3850 : NodeCoverage113 [21,21,7,7,7,7,7,7,7,3] 3 19 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3849
    ChildrenCoverage113.nil)

theorem compact113_node_3851 : NodeCoverage113 [21,21,7,7,7,7,7,7,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3842
    (ChildrenCoverage113.cons _ _ compact113_node_3843
    (ChildrenCoverage113.cons _ _ compact113_node_3844
    (ChildrenCoverage113.cons _ _ compact113_node_3850
    ChildrenCoverage113.nil))))

theorem compact113_node_3852 : NodeCoverage113 [21,21,7,7,7,7,7,7,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3853 : NodeCoverage113 [21,21,7,7,7,7,7,7,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3854 : NodeCoverage113 [21,21,7,7,7,7,7,7,3] 3 26 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3855 : NodeCoverage113 [21,21,7,7,7,7,7,7] 7 29 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3851
    (ChildrenCoverage113.cons _ _ compact113_node_3852
    (ChildrenCoverage113.cons _ _ compact113_node_3853
    (ChildrenCoverage113.cons _ _ compact113_node_3854
    ChildrenCoverage113.nil))))

theorem compact113_node_3856 : NodeCoverage113 [21,21,7,7,7,7,7,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3857 : NodeCoverage113 [21,21,7,7,7,7,7,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3858 : NodeCoverage113 [21,21,7,7,7,7,7,3] 3 33 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3859 : NodeCoverage113 [21,21,7,7,7,7,7] 7 36 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3855
    (ChildrenCoverage113.cons _ _ compact113_node_3856
    (ChildrenCoverage113.cons _ _ compact113_node_3857
    (ChildrenCoverage113.cons _ _ compact113_node_3858
    ChildrenCoverage113.nil))))

theorem compact113_node_3860 : NodeCoverage113 [21,21,7,7,7,7,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3861 : NodeCoverage113 [21,21,7,7,7,7,5] 5 38 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3862 : NodeCoverage113 [21,21,7,7,7,7,3] 3 40 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3863 : NodeCoverage113 [21,21,7,7,7,7] 7 43 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3859
    (ChildrenCoverage113.cons _ _ compact113_node_3860
    (ChildrenCoverage113.cons _ _ compact113_node_3861
    (ChildrenCoverage113.cons _ _ compact113_node_3862
    ChildrenCoverage113.nil))))

theorem compact113_node_3864 : NodeCoverage113 [21,21,7,7,7,6] 6 44 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3865 : NodeCoverage113 [21,21,7,7,7,5] 5 45 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3866 : NodeCoverage113 [21,21,7,7,7,3] 3 47 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3867 : NodeCoverage113 [21,21,7,7,7] 7 50 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3863
    (ChildrenCoverage113.cons _ _ compact113_node_3864
    (ChildrenCoverage113.cons _ _ compact113_node_3865
    (ChildrenCoverage113.cons _ _ compact113_node_3866
    ChildrenCoverage113.nil))))

theorem compact113_node_3868 : NodeCoverage113 [21,21,7,7,6] 6 51 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3869 : NodeCoverage113 [21,21,7,7,5] 5 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3870 : NodeCoverage113 [21,21,7,7,3] 3 54 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3871 : NodeCoverage113 [21,21,7,7] 7 57 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3867
    (ChildrenCoverage113.cons _ _ compact113_node_3868
    (ChildrenCoverage113.cons _ _ compact113_node_3869
    (ChildrenCoverage113.cons _ _ compact113_node_3870
    ChildrenCoverage113.nil))))

theorem compact113_node_3872 : NodeCoverage113 [21,21,7,6] 6 58 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3873 : NodeCoverage113 [21,21,7,5] 5 59 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3874 : NodeCoverage113 [21,21,7,3] 3 61 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3875 : NodeCoverage113 [21,21,7] 7 64 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3871
    (ChildrenCoverage113.cons _ _ compact113_node_3872
    (ChildrenCoverage113.cons _ _ compact113_node_3873
    (ChildrenCoverage113.cons _ _ compact113_node_3874
    ChildrenCoverage113.nil))))

theorem compact113_node_3876 : NodeCoverage113 [21,21,6] 6 65 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3877 : NodeCoverage113 [21,21,5] 5 66 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

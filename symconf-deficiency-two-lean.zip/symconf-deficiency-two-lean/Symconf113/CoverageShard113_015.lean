import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0659 : NodeCoverage113 [49,36] 36 28 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0660 : NodeCoverage113 [49,35] 35 29 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0661 : NodeCoverage113 [49,34] 34 30 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0662 : NodeCoverage113 [49,33] 33 31 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0663 : NodeCoverage113 [49,32] 32 32 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0664 : NodeCoverage113 [49,31] 31 33 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0665 : NodeCoverage113 [49,30] 30 34 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0666 : NodeCoverage113 [49,29] 29 35 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0667 : NodeCoverage113 [49,28] 28 36 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0668 : NodeCoverage113 [49,27] 27 37 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0669 : NodeCoverage113 [49,26] 26 38 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0670 : NodeCoverage113 [49,25] 25 39 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0671 : NodeCoverage113 [49,24] 24 40 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0672 : NodeCoverage113 [49,23] 23 41 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0673 : NodeCoverage113 [49,22] 22 42 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0674 : NodeCoverage113 [49,21] 21 43 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0675 : NodeCoverage113 [49,20] 20 44 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0676 : NodeCoverage113 [49,19] 19 45 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0677 : NodeCoverage113 [49,18] 18 46 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0678 : NodeCoverage113 [49,17] 17 47 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0679 : NodeCoverage113 [49,16] 16 48 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0680 : NodeCoverage113 [49,15] 15 49 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0681 : NodeCoverage113 [49,14] 14 50 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0682 : NodeCoverage113 [49,13] 13 51 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0683 : NodeCoverage113 [49,12] 12 52 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0684 : NodeCoverage113 [49,11] 11 53 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0685 : NodeCoverage113 [49,10] 10 54 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0686 : NodeCoverage113 [49,9] 9 55 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0687 : NodeCoverage113 [49,8] 8 56 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0688 : NodeCoverage113 [49,7] 7 57 :=
  demand_node_prune113 49 compact113_demands_049 compact113_demands_049_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0689 : NodeCoverage113 [49,6] 6 58 :=
  demand_node_prune113 49 compact113_demands_049 compact113_demands_049_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0690 : NodeCoverage113 [49,5] 5 59 :=
  demand_node_prune113 49 compact113_demands_049 compact113_demands_049_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

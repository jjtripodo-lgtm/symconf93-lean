import Symconf113.CoverageShard113_107
import Symconf113.CoverageShard113_108

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4023 : NodeCoverage113 [20,20,20,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4024 : NodeCoverage113 [20,20,20,6] 6 47 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4025 : NodeCoverage113 [20,20,20,5] 5 48 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4026 : NodeCoverage113 [20,20,20,3] 3 50 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4027 : NodeCoverage113 [20,20,20] 20 53 :=
  node_fork113 (B := [20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3961
    (ChildrenCoverage113.cons _ _ compact113_node_3962
    (ChildrenCoverage113.cons _ _ compact113_node_3963
    (ChildrenCoverage113.cons _ _ compact113_node_3964
    (ChildrenCoverage113.cons _ _ compact113_node_3965
    (ChildrenCoverage113.cons _ _ compact113_node_3966
    (ChildrenCoverage113.cons _ _ compact113_node_3967
    (ChildrenCoverage113.cons _ _ compact113_node_3968
    (ChildrenCoverage113.cons _ _ compact113_node_3969
    (ChildrenCoverage113.cons _ _ compact113_node_3970
    (ChildrenCoverage113.cons _ _ compact113_node_4020
    (ChildrenCoverage113.cons _ _ compact113_node_4021
    (ChildrenCoverage113.cons _ _ compact113_node_4022
    (ChildrenCoverage113.cons _ _ compact113_node_4023
    (ChildrenCoverage113.cons _ _ compact113_node_4024
    (ChildrenCoverage113.cons _ _ compact113_node_4025
    (ChildrenCoverage113.cons _ _ compact113_node_4026
    ChildrenCoverage113.nil)))))))))))))))))

theorem compact113_node_4028 : NodeCoverage113 [20,20,19] 19 54 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4029 : NodeCoverage113 [20,20,18] 18 55 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4030 : NodeCoverage113 [20,20,17] 17 56 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4031 : NodeCoverage113 [20,20,16] 16 57 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4032 : NodeCoverage113 [20,20,15] 15 58 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4033 : NodeCoverage113 [20,20,14] 14 59 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4034 : NodeCoverage113 [20,20,13] 13 60 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4035 : NodeCoverage113 [20,20,12] 12 61 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4036 : NodeCoverage113 [20,20,11] 11 62 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4037 : NodeCoverage113 [20,20,10,10,10,10,10,10,10] 10 3 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4038 : NodeCoverage113 [20,20,10,10,10,10,10,10,9] 9 4 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4039 : NodeCoverage113 [20,20,10,10,10,10,10,10,8] 8 5 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4040 : NodeCoverage113 [20,20,10,10,10,10,10,10,7] 7 6 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4041 : NodeCoverage113 [20,20,10,10,10,10,10,10,6] 6 7 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4042 : NodeCoverage113 [20,20,10,10,10,10,10,10,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4043 : NodeCoverage113 [20,20,10,10,10,10,10,10,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4042
    ChildrenCoverage113.nil)

theorem compact113_node_4044 : NodeCoverage113 [20,20,10,10,10,10,10,10,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4045 : NodeCoverage113 [20,20,10,10,10,10,10,10,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4043
    (ChildrenCoverage113.cons _ _ compact113_node_4044
    ChildrenCoverage113.nil))

theorem compact113_node_4046 : NodeCoverage113 [20,20,10,10,10,10,10,10,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4047 : NodeCoverage113 [20,20,10,10,10,10,10,10] 10 13 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4037
    (ChildrenCoverage113.cons _ _ compact113_node_4038
    (ChildrenCoverage113.cons _ _ compact113_node_4039
    (ChildrenCoverage113.cons _ _ compact113_node_4040
    (ChildrenCoverage113.cons _ _ compact113_node_4041
    (ChildrenCoverage113.cons _ _ compact113_node_4045
    (ChildrenCoverage113.cons _ _ compact113_node_4046
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4048 : NodeCoverage113 [20,20,10,10,10,10,10,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4049 : NodeCoverage113 [20,20,10,10,10,10,10,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4050 : NodeCoverage113 [20,20,10,10,10,10,10,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4051 : NodeCoverage113 [20,20,10,10,10,10,10,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4052 : NodeCoverage113 [20,20,10,10,10,10,10,5,5,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4053 : NodeCoverage113 [20,20,10,10,10,10,10,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4052
    ChildrenCoverage113.nil)

theorem compact113_node_4054 : NodeCoverage113 [20,20,10,10,10,10,10,5,5,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4055 : NodeCoverage113 [20,20,10,10,10,10,10,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4053
    (ChildrenCoverage113.cons _ _ compact113_node_4054
    ChildrenCoverage113.nil))

theorem compact113_node_4056 : NodeCoverage113 [20,20,10,10,10,10,10,5,5,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4057 : NodeCoverage113 [20,20,10,10,10,10,10,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4055
    (ChildrenCoverage113.cons _ _ compact113_node_4056
    ChildrenCoverage113.nil))

theorem compact113_node_4058 : NodeCoverage113 [20,20,10,10,10,10,10,5,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4059 : NodeCoverage113 [20,20,10,10,10,10,10,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4057
    (ChildrenCoverage113.cons _ _ compact113_node_4058
    ChildrenCoverage113.nil))

theorem compact113_node_4060 : NodeCoverage113 [20,20,10,10,10,10,10,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4061 : NodeCoverage113 [20,20,10,10,10,10,10] 10 23 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4047
    (ChildrenCoverage113.cons _ _ compact113_node_4048
    (ChildrenCoverage113.cons _ _ compact113_node_4049
    (ChildrenCoverage113.cons _ _ compact113_node_4050
    (ChildrenCoverage113.cons _ _ compact113_node_4051
    (ChildrenCoverage113.cons _ _ compact113_node_4059
    (ChildrenCoverage113.cons _ _ compact113_node_4060
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4062 : NodeCoverage113 [20,20,10,10,10,10,9] 9 24 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4063 : NodeCoverage113 [20,20,10,10,10,10,8] 8 25 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4064 : NodeCoverage113 [20,20,10,10,10,10,7] 7 26 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4065 : NodeCoverage113 [20,20,10,10,10,10,6] 6 27 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4066 : NodeCoverage113 [20,20,10,10,10,10,5,5,5,5,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4067 : NodeCoverage113 [20,20,10,10,10,10,5,5,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4066
    ChildrenCoverage113.nil)

theorem compact113_node_4068 : NodeCoverage113 [20,20,10,10,10,10,5,5,5,5,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4069 : NodeCoverage113 [20,20,10,10,10,10,5,5,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4067
    (ChildrenCoverage113.cons _ _ compact113_node_4068
    ChildrenCoverage113.nil))

theorem compact113_node_4070 : NodeCoverage113 [20,20,10,10,10,10,5,5,5,5,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4071 : NodeCoverage113 [20,20,10,10,10,10,5,5,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4069
    (ChildrenCoverage113.cons _ _ compact113_node_4070
    ChildrenCoverage113.nil))

theorem compact113_node_4072 : NodeCoverage113 [20,20,10,10,10,10,5,5,5,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4073 : NodeCoverage113 [20,20,10,10,10,10,5,5,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4071
    (ChildrenCoverage113.cons _ _ compact113_node_4072
    ChildrenCoverage113.nil))

theorem compact113_node_4074 : NodeCoverage113 [20,20,10,10,10,10,5,5,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4075 : NodeCoverage113 [20,20,10,10,10,10,5,5] 5 23 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4073
    (ChildrenCoverage113.cons _ _ compact113_node_4074
    ChildrenCoverage113.nil))

theorem compact113_node_4076 : NodeCoverage113 [20,20,10,10,10,10,5,3] 3 25 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4077 : NodeCoverage113 [20,20,10,10,10,10,5] 5 28 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4075
    (ChildrenCoverage113.cons _ _ compact113_node_4076
    ChildrenCoverage113.nil))

theorem compact113_node_4078 : NodeCoverage113 [20,20,10,10,10,10,3] 3 30 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4079 : NodeCoverage113 [20,20,10,10,10,10] 10 33 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4061
    (ChildrenCoverage113.cons _ _ compact113_node_4062
    (ChildrenCoverage113.cons _ _ compact113_node_4063
    (ChildrenCoverage113.cons _ _ compact113_node_4064
    (ChildrenCoverage113.cons _ _ compact113_node_4065
    (ChildrenCoverage113.cons _ _ compact113_node_4077
    (ChildrenCoverage113.cons _ _ compact113_node_4078
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4080 : NodeCoverage113 [20,20,10,10,10,9] 9 34 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4081 : NodeCoverage113 [20,20,10,10,10,8] 8 35 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4082 : NodeCoverage113 [20,20,10,10,10,7] 7 36 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4083 : NodeCoverage113 [20,20,10,10,10,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

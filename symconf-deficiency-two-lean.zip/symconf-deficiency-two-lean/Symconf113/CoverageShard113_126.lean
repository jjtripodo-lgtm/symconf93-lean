import Symconf113.CoverageShard113_125

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4914 : NodeCoverage113 [18,9,9,9,9,9,9,9,6] 6 26 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4915 : NodeCoverage113 [18,9,9,9,9,9,9,9,5] 5 27 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4916 : NodeCoverage113 [18,9,9,9,9,9,9,9,3] 3 29 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4917 : NodeCoverage113 [18,9,9,9,9,9,9,9] 9 32 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4911
    (ChildrenCoverage113.cons _ _ compact113_node_4912
    (ChildrenCoverage113.cons _ _ compact113_node_4913
    (ChildrenCoverage113.cons _ _ compact113_node_4914
    (ChildrenCoverage113.cons _ _ compact113_node_4915
    (ChildrenCoverage113.cons _ _ compact113_node_4916
    ChildrenCoverage113.nil))))))

theorem compact113_node_4918 : NodeCoverage113 [18,9,9,9,9,9,9,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4919 : NodeCoverage113 [18,9,9,9,9,9,9,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4920 : NodeCoverage113 [18,9,9,9,9,9,9,6,6,6,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4921 : NodeCoverage113 [18,9,9,9,9,9,9,6,6,6,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4920
    ChildrenCoverage113.nil)

theorem compact113_node_4922 : NodeCoverage113 [18,9,9,9,9,9,9,6,6,6,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4923 : NodeCoverage113 [18,9,9,9,9,9,9,6,6,6,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_4924 : NodeCoverage113 [18,9,9,9,9,9,9,6,6,6,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4923
    ChildrenCoverage113.nil)

theorem compact113_node_4925 : NodeCoverage113 [18,9,9,9,9,9,9,6,6,6,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4921
    (ChildrenCoverage113.cons _ _ compact113_node_4922
    (ChildrenCoverage113.cons _ _ compact113_node_4924
    ChildrenCoverage113.nil)))

theorem compact113_node_4926 : NodeCoverage113 [18,9,9,9,9,9,9,6,6,6,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4927 : NodeCoverage113 [18,9,9,9,9,9,9,6,6,6,6,3] 3 14 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4928 : NodeCoverage113 [18,9,9,9,9,9,9,6,6,6,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4925
    (ChildrenCoverage113.cons _ _ compact113_node_4926
    (ChildrenCoverage113.cons _ _ compact113_node_4927
    ChildrenCoverage113.nil)))

theorem compact113_node_4929 : NodeCoverage113 [18,9,9,9,9,9,9,6,6,6,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4930 : NodeCoverage113 [18,9,9,9,9,9,9,6,6,6,3] 3 20 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4931 : NodeCoverage113 [18,9,9,9,9,9,9,6,6,6] 6 23 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4928
    (ChildrenCoverage113.cons _ _ compact113_node_4929
    (ChildrenCoverage113.cons _ _ compact113_node_4930
    ChildrenCoverage113.nil)))

theorem compact113_node_4932 : NodeCoverage113 [18,9,9,9,9,9,9,6,6,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4933 : NodeCoverage113 [18,9,9,9,9,9,9,6,6,3] 3 26 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4934 : NodeCoverage113 [18,9,9,9,9,9,9,6,6] 6 29 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4931
    (ChildrenCoverage113.cons _ _ compact113_node_4932
    (ChildrenCoverage113.cons _ _ compact113_node_4933
    ChildrenCoverage113.nil)))

theorem compact113_node_4935 : NodeCoverage113 [18,9,9,9,9,9,9,6,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4936 : NodeCoverage113 [18,9,9,9,9,9,9,6,3] 3 32 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4937 : NodeCoverage113 [18,9,9,9,9,9,9,6] 6 35 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4934
    (ChildrenCoverage113.cons _ _ compact113_node_4935
    (ChildrenCoverage113.cons _ _ compact113_node_4936
    ChildrenCoverage113.nil)))

theorem compact113_node_4938 : NodeCoverage113 [18,9,9,9,9,9,9,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4939 : NodeCoverage113 [18,9,9,9,9,9,9,3] 3 38 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4940 : NodeCoverage113 [18,9,9,9,9,9,9] 9 41 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4917
    (ChildrenCoverage113.cons _ _ compact113_node_4918
    (ChildrenCoverage113.cons _ _ compact113_node_4919
    (ChildrenCoverage113.cons _ _ compact113_node_4937
    (ChildrenCoverage113.cons _ _ compact113_node_4938
    (ChildrenCoverage113.cons _ _ compact113_node_4939
    ChildrenCoverage113.nil))))))

theorem compact113_node_4941 : NodeCoverage113 [18,9,9,9,9,9,8] 8 42 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4942 : NodeCoverage113 [18,9,9,9,9,9,7] 7 43 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4943 : NodeCoverage113 [18,9,9,9,9,9,6] 6 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4944 : NodeCoverage113 [18,9,9,9,9,9,5] 5 45 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4945 : NodeCoverage113 [18,9,9,9,9,9,3] 3 47 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4946 : NodeCoverage113 [18,9,9,9,9,9] 9 50 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4940
    (ChildrenCoverage113.cons _ _ compact113_node_4941
    (ChildrenCoverage113.cons _ _ compact113_node_4942
    (ChildrenCoverage113.cons _ _ compact113_node_4943
    (ChildrenCoverage113.cons _ _ compact113_node_4944
    (ChildrenCoverage113.cons _ _ compact113_node_4945
    ChildrenCoverage113.nil))))))

theorem compact113_node_4947 : NodeCoverage113 [18,9,9,9,9,8] 8 51 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4948 : NodeCoverage113 [18,9,9,9,9,7] 7 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4949 : NodeCoverage113 [18,9,9,9,9,6] 6 53 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4950 : NodeCoverage113 [18,9,9,9,9,5] 5 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4951 : NodeCoverage113 [18,9,9,9,9,3] 3 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4952 : NodeCoverage113 [18,9,9,9,9] 9 59 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4946
    (ChildrenCoverage113.cons _ _ compact113_node_4947
    (ChildrenCoverage113.cons _ _ compact113_node_4948
    (ChildrenCoverage113.cons _ _ compact113_node_4949
    (ChildrenCoverage113.cons _ _ compact113_node_4950
    (ChildrenCoverage113.cons _ _ compact113_node_4951
    ChildrenCoverage113.nil))))))

theorem compact113_node_4953 : NodeCoverage113 [18,9,9,9,8] 8 60 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4954 : NodeCoverage113 [18,9,9,9,7] 7 61 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4955 : NodeCoverage113 [18,9,9,9,6] 6 62 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4956 : NodeCoverage113 [18,9,9,9,5] 5 63 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4957 : NodeCoverage113 [18,9,9,9,3] 3 65 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4958 : NodeCoverage113 [18,9,9,9] 9 68 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4952
    (ChildrenCoverage113.cons _ _ compact113_node_4953
    (ChildrenCoverage113.cons _ _ compact113_node_4954
    (ChildrenCoverage113.cons _ _ compact113_node_4955
    (ChildrenCoverage113.cons _ _ compact113_node_4956
    (ChildrenCoverage113.cons _ _ compact113_node_4957
    ChildrenCoverage113.nil))))))

theorem compact113_node_4959 : NodeCoverage113 [18,9,9,8] 8 69 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4960 : NodeCoverage113 [18,9,9,7] 7 70 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4961 : NodeCoverage113 [18,9,9,6] 6 71 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4962 : NodeCoverage113 [18,9,9,5] 5 72 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4963 : NodeCoverage113 [18,9,9,3] 3 74 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4964 : NodeCoverage113 [18,9,9] 9 77 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4958
    (ChildrenCoverage113.cons _ _ compact113_node_4959
    (ChildrenCoverage113.cons _ _ compact113_node_4960
    (ChildrenCoverage113.cons _ _ compact113_node_4961
    (ChildrenCoverage113.cons _ _ compact113_node_4962
    (ChildrenCoverage113.cons _ _ compact113_node_4963
    ChildrenCoverage113.nil))))))

theorem compact113_node_4965 : NodeCoverage113 [18,9,8] 8 78 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4966 : NodeCoverage113 [18,9,7] 7 79 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

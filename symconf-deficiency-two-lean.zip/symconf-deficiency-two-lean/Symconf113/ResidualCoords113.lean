import Symconf113.OneProfile113
import Symconf113.OddOrientation

/-! `ZMod`-indexed charts on the residual profile `3+5+15^7`.

For an ordered cycle chart `R` and a cycle `k` of length `n`, `zsite R k h`
names the sites of that cycle by `ZMod n`. This file proves the neighbour,
injectivity, sum-splitting and block-wave facts the residual argument uses. -/
namespace Symconf113
open Matrix Symconf59
open scoped BigOperators

section Chart
variable {M : Int113} {P : List ℕ} (R : OrderedCycles M P)

def zsite (k : Fin P.length) {n : ℕ} [NeZero n] (h : P.get k=n) (x : ZMod n) : Site :=
  R.sites ⟨k,finCongr h.symm ((ZMod.finEquiv n).symm x)⟩

theorem zsite_eq_iff (k : Fin P.length) {n : ℕ} [NeZero n] (h : P.get k=n) (x y : ZMod n) :
    zsite R k h x=zsite R k h y ↔ x=y := by
  constructor
  · intro he
    have h1 := eq_of_heq (Sigma.mk.inj_iff.mp (R.sites.injective he)).2
    exact (ZMod.finEquiv n).symm.injective ((finCongr h.symm).injective h1)
  · rintro rfl; rfl

theorem zsite_ne_of_ne (k k' : Fin P.length) {n m : ℕ} [NeZero n] [NeZero m]
    (h : P.get k=n) (h' : P.get k'=m) (hk : k≠k') (x : ZMod n) (y : ZMod m) :
    zsite R k h x≠zsite R k' h' y := by
  intro he
  exact hk (Sigma.mk.inj_iff.mp (R.sites.injective he)).1

private theorem chart_next (k : Fin P.length) {n : ℕ} [NeZero n] (h : P.get k=n) (x : ZMod n) :
    finCongr h.symm ((ZMod.finEquiv n).symm (x+1))=cnext (finCongr h.symm ((ZMod.finEquiv n).symm x)) := by
  subst h
  change (ZMod.finEquiv _).symm (x+1)=(ZMod.finEquiv _).symm x+1
  rw [map_add,map_one]

private theorem chart_prev (k : Fin P.length) {n : ℕ} [NeZero n] (h : P.get k=n) (x : ZMod n) :
    finCongr h.symm ((ZMod.finEquiv n).symm (x-1))=cprev (finCongr h.symm ((ZMod.finEquiv n).symm x)) := by
  subst h
  change (ZMod.finEquiv _).symm (x-1)=(ZMod.finEquiv _).symm x-1
  rw [map_sub,map_one]

theorem zsite_same (k : Fin P.length) {n : ℕ} [NeZero n] (h : P.get k=n) (x y : ZMod n) :
    M (zsite R k h x) (zsite R k h y)=(if y=x+1 then 1 else 0)+(if y=x-1 then 1 else 0) := by
  unfold zsite
  rw [R.same_block]
  have e1 : (finCongr h.symm ((ZMod.finEquiv n).symm y)=cnext (finCongr h.symm ((ZMod.finEquiv n).symm x)))
      ↔ y=x+1 := by
    rw [← chart_next k h x]
    exact ⟨fun he => (ZMod.finEquiv n).symm.injective ((finCongr h.symm).injective he),
      fun he => by rw [he]⟩
  have e2 : (finCongr h.symm ((ZMod.finEquiv n).symm y)=cprev (finCongr h.symm ((ZMod.finEquiv n).symm x)))
      ↔ y=x-1 := by
    rw [← chart_prev k h x]
    exact ⟨fun he => (ZMod.finEquiv n).symm.injective ((finCongr h.symm).injective he),
      fun he => by rw [he]⟩
  simp only [e1,e2]

theorem zsite_diff (k k' : Fin P.length) {n m : ℕ} [NeZero n] [NeZero m]
    (h : P.get k=n) (h' : P.get k'=m) (hk : k≠k') (x : ZMod n) (y : ZMod m) :
    M (zsite R k h x) (zsite R k' h' y)=0 :=
  R.different_blocks hk _ _

theorem fiber_sum (k : Fin P.length) {n : ℕ} [NeZero n] (h : P.get k=n) (F : Site → ℤ) :
    (∑ y : Fin (P.get k),F (R.sites ⟨k,y⟩))=∑ x : ZMod n,F (zsite R k h x) := by
  subst h
  exact (Equiv.sum_comp ((ZMod.finEquiv (P.get k)).symm.toEquiv.trans (finCongr rfl))
    (fun y => F (R.sites ⟨k,y⟩))).symm

end Chart

/-! The residual profile. -/
section Residual
abbrev RP : List ℕ := Residual113

def lg (i : Fin 7) : Fin RP.length := ⟨i.val,by have := i.isLt; simp [RP]; omega⟩
def j5 : Fin RP.length := ⟨7,by decide⟩
def j3 : Fin RP.length := ⟨8,by decide⟩

theorem hL (i : Fin 7) : RP.get (lg i)=15 := by fin_cases i <;> rfl
theorem h5 : RP.get j5=5 := rfl
theorem h3 : RP.get j3=3 := rfl

theorem lg_ne_j5 (i : Fin 7) : lg i≠j5 := by
  intro h; have := congrArg Fin.val h; simp [lg,j5] at this; omega
theorem lg_ne_j3 (i : Fin 7) : lg i≠j3 := by
  intro h; have := congrArg Fin.val h; simp [lg,j3] at this; omega
theorem j5_ne_j3 : j5≠j3 := by decide
theorem lg_inj {i i' : Fin 7} (h : lg i=lg i') : i=i' := by
  apply Fin.ext; have := congrArg Fin.val h; simpa [lg] using this

variable {M : Int113} (R : OrderedCycles M RP)

def sL (i : Fin 7) (x : ZMod 15) : Site := zsite R (lg i) (hL i) x
def s5 (z : ZMod 5) : Site := zsite R j5 h5 z
def s3 (z : ZMod 3) : Site := zsite R j3 h3 z

/-- Split a sum over all sites along the residual cycles. -/
theorem residual_sum (F : Site → ℤ) :
    (∑ q,F q)=(∑ i : Fin 7,∑ x : ZMod 15,F (sL R i x))+(∑ z : ZMod 5,F (s5 R z))+
      ∑ z : ZMod 3,F (s3 R z) := by
  rw [← Equiv.sum_comp R.sites F,Fintype.sum_sigma]
  change (∑ k : Fin 9, ∑ y : Fin (RP.get k), F (R.sites ⟨k,y⟩))=_
  rw [Fin.sum_univ_castSucc (n := 8),Fin.sum_univ_castSucc (n := 7)]
  have e3 := fiber_sum R j3 h3 F
  have e5 := fiber_sum R j5 h5 F
  have eL (i : Fin 7) := fiber_sum R (lg i) (hL i) F
  refine congrArg₂ (·+·) (congrArg₂ (·+·) (Finset.sum_congr rfl (fun i _ => eL i)) e5) e3

end Residual
end Symconf113

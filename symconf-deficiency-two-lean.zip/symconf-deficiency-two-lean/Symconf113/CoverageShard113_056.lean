import Symconf113.CoverageShard113_054
import Symconf113.CoverageShard113_055

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2276 : NodeCoverage113 [30,30,30,3] 3 20 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2277 : NodeCoverage113 [30,30,30] 30 23 :=
  node_fork113 (B := [23,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2245
    (ChildrenCoverage113.cons _ _ compact113_node_2246
    (ChildrenCoverage113.cons _ _ compact113_node_2247
    (ChildrenCoverage113.cons _ _ compact113_node_2248
    (ChildrenCoverage113.cons _ _ compact113_node_2249
    (ChildrenCoverage113.cons _ _ compact113_node_2250
    (ChildrenCoverage113.cons _ _ compact113_node_2255
    (ChildrenCoverage113.cons _ _ compact113_node_2256
    (ChildrenCoverage113.cons _ _ compact113_node_2257
    (ChildrenCoverage113.cons _ _ compact113_node_2258
    (ChildrenCoverage113.cons _ _ compact113_node_2259
    (ChildrenCoverage113.cons _ _ compact113_node_2270
    (ChildrenCoverage113.cons _ _ compact113_node_2271
    (ChildrenCoverage113.cons _ _ compact113_node_2272
    (ChildrenCoverage113.cons _ _ compact113_node_2273
    (ChildrenCoverage113.cons _ _ compact113_node_2274
    (ChildrenCoverage113.cons _ _ compact113_node_2275
    (ChildrenCoverage113.cons _ _ compact113_node_2276
    ChildrenCoverage113.nil))))))))))))))))))

theorem compact113_node_2278 : NodeCoverage113 [30,30,29] 29 24 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2279 : NodeCoverage113 [30,30,28] 28 25 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2280 : NodeCoverage113 [30,30,27] 27 26 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2281 : NodeCoverage113 [30,30,26] 26 27 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2282 : NodeCoverage113 [30,30,25] 25 28 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2283 : NodeCoverage113 [30,30,24] 24 29 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2284 : NodeCoverage113 [30,30,23] 23 30 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2285 : NodeCoverage113 [30,30,22] 22 31 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2286 : NodeCoverage113 [30,30,21] 21 32 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2287 : NodeCoverage113 [30,30,20] 20 33 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2288 : NodeCoverage113 [30,30,19] 19 34 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2289 : NodeCoverage113 [30,30,18] 18 35 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2290 : NodeCoverage113 [30,30,17] 17 36 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2291 : NodeCoverage113 [30,30,16] 16 37 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2292 : NodeCoverage113 [30,30,15,15,15,8] 8 0 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2293 : NodeCoverage113 [30,30,15,15,15,5,3] 3 0 :=
  node_no_weak_demand113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2294 : NodeCoverage113 [30,30,15,15,15,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2293
    ChildrenCoverage113.nil)

theorem compact113_node_2295 : NodeCoverage113 [30,30,15,15,15,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_2296 : NodeCoverage113 [30,30,15,15,15] 15 8 :=
  node_fork113 (B := [8,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2292
    (ChildrenCoverage113.cons _ _ compact113_node_2294
    (ChildrenCoverage113.cons _ _ compact113_node_2295
    ChildrenCoverage113.nil)))

theorem compact113_node_2297 : NodeCoverage113 [30,30,15,15,14] 14 9 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2298 : NodeCoverage113 [30,30,15,15,13] 13 10 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2299 : NodeCoverage113 [30,30,15,15,12] 12 11 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.RulerCoverDefs113
import Symconf113.RulerCoverShard113_00
import Symconf113.RulerCoverShard113_01
import Symconf113.RulerCoverShard113_02
import Symconf113.RulerCoverShard113_03
import Symconf113.RulerCoverShard113_04
import Symconf113.RulerCoverShard113_05
import Symconf113.RulerCoverShard113_06
import Symconf113.RulerCoverShard113_07
import Symconf113.RulerCoverShard113_08
import Symconf113.RulerCoverShard113_09
import Symconf113.RulerCoverShard113_10
import Symconf113.RulerCoverShard113_11
import Symconf113.RulerCoverShard113_12
import Symconf113.RulerCoverShard113_13
import Symconf113.RulerCoverShard113_14
import Symconf113.RulerCoverShard113_15
import Symconf113.RulerCoverShard113_16
import Symconf113.RulerCoverShard113_17
import Symconf113.RulerCoverShard113_18
import Symconf113.RulerCoverShard113_19
import Symconf113.RulerCoverShard113_20
import Symconf113.RulerCoverShard113_21
import Symconf113.RulerCoverShard113_22
import Symconf113.RulerCoverShard113_23
import Symconf113.RulerCoverShard113_24
import Symconf113.RulerCoverShard113_25
import Symconf113.RulerCoverShard113_26
import Symconf113.RulerCoverShard113_27
import Symconf113.RulerCoverShard113_28
import Symconf113.RulerCoverShard113_29
import Symconf113.RulerCoverShard113_30
import Symconf113.RulerCoverShard113_31
import Symconf113.RulerCoverShard113_32
import Symconf113.RulerCoverShard113_33
import Symconf113.RulerCoverShard113_34
import Symconf113.RulerCoverShard113_35
import Symconf113.RulerCoverShard113_36
import Symconf113.RulerCoverShard113_37
import Symconf113.RulerCoverShard113_38
import Symconf113.RulerCoverShard113_39
import Symconf113.RulerCoverShard113_40
import Symconf113.RulerCoverShard113_41
import Symconf113.RulerCoverShard113_42
import Symconf113.RulerCoverShard113_43
import Symconf113.RulerCoverShard113_44
import Symconf113.RulerCoverShard113_45
import Symconf113.RulerCoverShard113_46
import Symconf113.RulerCoverShard113_47
import Symconf113.RulerCoverShard113_48
import Symconf113.RulerCoverShard113_49
import Symconf113.RulerCoverShard113_50
import Symconf113.RulerCoverShard113_51
import Symconf113.RulerCoverShard113_52
import Symconf113.RulerCoverShard113_53
import Symconf113.RulerCoverShard113_54
import Symconf113.RulerCoverShard113_55
import Symconf113.RulerCoverShard113_56
import Symconf113.RulerCoverShard113_57
import Symconf113.RulerCoverShard113_58
import Symconf113.RulerCoverShard113_59
import Symconf113.RulerCoverShard113_60
import Symconf113.RulerCoverShard113_61
import Symconf113.RulerCoverShard113_62
import Symconf113.RulerCoverShard113_63
import Symconf113.RulerCoverShard113_64
import Symconf113.RulerCoverShard113_65
import Symconf113.RulerCoverShard113_66
import Symconf113.RulerCoverShard113_67
import Symconf113.RulerCoverShard113_68
import Symconf113.RulerCoverShard113_69
import Symconf113.RulerCoverShard113_70
import Symconf113.RulerCoverShard113_71
import Symconf113.RulerCoverShard113_72
import Symconf113.RulerCoverShard113_73
import Symconf113.RulerCoverShard113_74
import Symconf113.RulerCoverShard113_75
import Symconf113.RulerCoverShard113_76
import Symconf113.RulerCoverShard113_77
import Symconf113.RulerCoverShard113_78
import Symconf113.RulerCoverShard113_79
import Symconf113.RulerCoverShard113_80
import Symconf113.RulerCoverShard113_81
import Symconf113.RulerCoverShard113_82
import Symconf113.RulerCoverShard113_83
import Symconf113.RulerCoverShard113_84
import Symconf113.RulerCoverShard113_85
import Symconf113.RulerCoverShard113_86
import Symconf113.RulerCoverShard113_87
import Symconf113.RulerCoverShard113_88
import Symconf113.RulerCoverShard113_89
import Symconf113.RulerCoverShard113_90
import Symconf113.RulerCoverShard113_91
import Symconf113.RulerCoverShard113_92
import Symconf113.RulerCoverShard113_93
import Symconf113.RulerCoverShard113_94
import Symconf113.RulerCoverShard113_95
import Symconf113.RulerCoverShard113_96
import Symconf113.RulerCoverShard113_97
import Symconf113.RulerCoverShard113_98
import Symconf113.RulerCoverShard113_99
import Symconf113.RulerCoverShard113_100
import Symconf113.RulerCoverShard113_101
import Symconf113.RulerCoverShard113_102
import Symconf113.RulerCoverShard113_103
import Symconf113.RulerCoverShard113_104
import Symconf113.RulerCoverShard113_105
import Symconf113.RulerCoverShard113_106
import Symconf113.RulerCoverShard113_107
import Symconf113.RulerCoverShard113_108
import Symconf113.RulerCoverShard113_109
import Symconf113.RulerCoverShard113_110
import Symconf113.RulerCoverShard113_111
import Symconf113.RulerCoverShard113_112
import Symconf113.RulerCoverShard113_113
import Symconf113.RulerCoverShard113_114
import Symconf113.RulerCoverShard113_115
import Symconf113.RulerCoverShard113_116
import Symconf113.RulerCoverShard113_117
import Symconf113.RulerCoverShard113_118
import Symconf113.RulerCoverShard113_119

/-! No (113,11) modular Golomb ruler exists: the cover search from the normalized
start `{0,2}` fails, by the kernel shards above. -/
namespace Symconf113.Ruler113

theorem opt2_m1a : (List.range' 0 113).any (opt2At 4 (go 6) [5,2,0] m1a)=false :=
  (any_range'_split _ 0 101 12 (any_range'_split _ 0 88 13 (any_range'_split _ 0 76 12 (any_range'_split _ 0 64 12 (any_range'_split _ 0 47 17 (any_range'_split _ 0 36 11 (any_range'_split _ 0 24 12 coverShard113_03 coverShard113_04) coverShard113_05) coverShard113_06) coverShard113_07) coverShard113_08) coverShard113_09) coverShard113_10)

theorem go8_m1a : go 8 [5,2,0] m1a=false := by
  have hfg : firstGap m1a=4 := by decide
  show go (6+2) [5,2,0] m1a=false
  rw [go, hfg]
  show (4 == 0 || [5,2,0].any (opt1At 4 (go 7) [5,2,0] m1a) ||
    (List.range' 0 113).any (opt2At 4 (go 6) [5,2,0] m1a))=false
  rw [opt2_m1a]
  simp only [List.any_cons, List.any_nil, coverShard113_00, coverShard113_01, coverShard113_02]
  all_goals rfl

theorem opt2_m1b : (List.range' 0 113).any (opt2At 4 (go 6) [110,2,0] m1b)=false :=
  (any_range'_split _ 0 96 17 (any_range'_split _ 0 83 13 (any_range'_split _ 0 72 11 (any_range'_split _ 0 60 12 (any_range'_split _ 0 43 17 (any_range'_split _ 0 32 11 (any_range'_split _ 0 19 13 coverShard113_14 coverShard113_15) coverShard113_16) coverShard113_17) coverShard113_18) coverShard113_19) coverShard113_20) coverShard113_21)

theorem go8_m1b : go 8 [110,2,0] m1b=false := by
  have hfg : firstGap m1b=4 := by decide
  show go (6+2) [110,2,0] m1b=false
  rw [go, hfg]
  show (4 == 0 || [110,2,0].any (opt1At 4 (go 7) [110,2,0] m1b) ||
    (List.range' 0 113).any (opt2At 4 (go 6) [110,2,0] m1b))=false
  rw [opt2_m1b]
  simp only [List.any_cons, List.any_nil, coverShard113_11, coverShard113_12, coverShard113_13]
  all_goals rfl

theorem opt2_root : (List.range' 0 113).any (opt2At 3 (go 7) [2,0] m0)=false :=
  (any_range'_split _ 0 106 7 (any_range'_split _ 0 105 1 (any_range'_split _ 0 104 1 (any_range'_split _ 0 103 1 (any_range'_split _ 0 102 1 (any_range'_split _ 0 101 1 (any_range'_split _ 0 100 1 (any_range'_split _ 0 99 1 (any_range'_split _ 0 98 1 (any_range'_split _ 0 97 1 (any_range'_split _ 0 96 1 (any_range'_split _ 0 95 1 (any_range'_split _ 0 94 1 (any_range'_split _ 0 93 1 (any_range'_split _ 0 92 1 (any_range'_split _ 0 91 1 (any_range'_split _ 0 90 1 (any_range'_split _ 0 89 1 (any_range'_split _ 0 88 1 (any_range'_split _ 0 87 1 (any_range'_split _ 0 86 1 (any_range'_split _ 0 85 1 (any_range'_split _ 0 84 1 (any_range'_split _ 0 83 1 (any_range'_split _ 0 82 1 (any_range'_split _ 0 81 1 (any_range'_split _ 0 80 1 (any_range'_split _ 0 79 1 (any_range'_split _ 0 78 1 (any_range'_split _ 0 77 1 (any_range'_split _ 0 76 1 (any_range'_split _ 0 75 1 (any_range'_split _ 0 74 1 (any_range'_split _ 0 73 1 (any_range'_split _ 0 72 1 (any_range'_split _ 0 71 1 (any_range'_split _ 0 70 1 (any_range'_split _ 0 69 1 (any_range'_split _ 0 68 1 (any_range'_split _ 0 67 1 (any_range'_split _ 0 66 1 (any_range'_split _ 0 65 1 (any_range'_split _ 0 64 1 (any_range'_split _ 0 63 1 (any_range'_split _ 0 62 1 (any_range'_split _ 0 61 1 (any_range'_split _ 0 60 1 (any_range'_split _ 0 59 1 (any_range'_split _ 0 58 1 (any_range'_split _ 0 54 4 (any_range'_split _ 0 53 1 (any_range'_split _ 0 52 1 (any_range'_split _ 0 51 1 (any_range'_split _ 0 50 1 (any_range'_split _ 0 49 1 (any_range'_split _ 0 48 1 (any_range'_split _ 0 47 1 (any_range'_split _ 0 46 1 (any_range'_split _ 0 45 1 (any_range'_split _ 0 44 1 (any_range'_split _ 0 43 1 (any_range'_split _ 0 42 1 (any_range'_split _ 0 41 1 (any_range'_split _ 0 40 1 (any_range'_split _ 0 39 1 (any_range'_split _ 0 38 1 (any_range'_split _ 0 37 1 (any_range'_split _ 0 36 1 (any_range'_split _ 0 35 1 (any_range'_split _ 0 34 1 (any_range'_split _ 0 33 1 (any_range'_split _ 0 32 1 (any_range'_split _ 0 31 1 (any_range'_split _ 0 30 1 (any_range'_split _ 0 29 1 (any_range'_split _ 0 28 1 (any_range'_split _ 0 27 1 (any_range'_split _ 0 26 1 (any_range'_split _ 0 25 1 (any_range'_split _ 0 24 1 (any_range'_split _ 0 23 1 (any_range'_split _ 0 22 1 (any_range'_split _ 0 21 1 (any_range'_split _ 0 20 1 (any_range'_split _ 0 19 1 (any_range'_split _ 0 18 1 (any_range'_split _ 0 17 1 (any_range'_split _ 0 16 1 (any_range'_split _ 0 15 1 (any_range'_split _ 0 14 1 (any_range'_split _ 0 13 1 (any_range'_split _ 0 12 1 (any_range'_split _ 0 11 1 (any_range'_split _ 0 10 1 (any_range'_split _ 0 9 1 (any_range'_split _ 0 8 1 (any_range'_split _ 0 7 1 coverShard113_22 coverShard113_23) coverShard113_24) coverShard113_25) coverShard113_26) coverShard113_27) coverShard113_28) coverShard113_29) coverShard113_30) coverShard113_31) coverShard113_32) coverShard113_33) coverShard113_34) coverShard113_35) coverShard113_36) coverShard113_37) coverShard113_38) coverShard113_39) coverShard113_40) coverShard113_41) coverShard113_42) coverShard113_43) coverShard113_44) coverShard113_45) coverShard113_46) coverShard113_47) coverShard113_48) coverShard113_49) coverShard113_50) coverShard113_51) coverShard113_52) coverShard113_53) coverShard113_54) coverShard113_55) coverShard113_56) coverShard113_57) coverShard113_58) coverShard113_59) coverShard113_60) coverShard113_61) coverShard113_62) coverShard113_63) coverShard113_64) coverShard113_65) coverShard113_66) coverShard113_67) coverShard113_68) coverShard113_69) coverShard113_70) coverShard113_71) coverShard113_72) coverShard113_73) coverShard113_74) coverShard113_75) coverShard113_76) coverShard113_77) coverShard113_78) coverShard113_79) coverShard113_80) coverShard113_81) coverShard113_82) coverShard113_83) coverShard113_84) coverShard113_85) coverShard113_86) coverShard113_87) coverShard113_88) coverShard113_89) coverShard113_90) coverShard113_91) coverShard113_92) coverShard113_93) coverShard113_94) coverShard113_95) coverShard113_96) coverShard113_97) coverShard113_98) coverShard113_99) coverShard113_100) coverShard113_101) coverShard113_102) coverShard113_103) coverShard113_104) coverShard113_105) coverShard113_106) coverShard113_107) coverShard113_108) coverShard113_109) coverShard113_110) coverShard113_111) coverShard113_112) coverShard113_113) coverShard113_114) coverShard113_115) coverShard113_116) coverShard113_117) coverShard113_118) coverShard113_119)

theorem opt1_y2 : opt1At 3 (go 8) [2,0] m0 2=false := by
  have h5 : addDiffs 5 [2,0] m0=some m1a := by decide
  have h112 : addDiffs 112 [2,0] m0=none := by decide
  show [(2+3)%113, (2+113-3)%113].any (fun z => match addDiffs z [2,0] m0 with
    | none => false | some m' => go 8 (z :: [2,0]) m')=false
  simp only [show (2+3)%113=5 from rfl, show (2+113-3)%113=112 from rfl, List.any_cons,
    List.any_nil, h5, h112, go8_m1a]
  all_goals rfl

theorem opt1_y0 : opt1At 3 (go 8) [2,0] m0 0=false := by
  have h3 : addDiffs 3 [2,0] m0=none := by decide
  have h110 : addDiffs 110 [2,0] m0=some m1b := by decide
  show [(0+3)%113, (0+113-3)%113].any (fun z => match addDiffs z [2,0] m0 with
    | none => false | some m' => go 8 (z :: [2,0]) m')=false
  simp only [show (0+3)%113=3 from rfl, show (0+113-3)%113=110 from rfl, List.any_cons,
    List.any_nil, h3, h110, go8_m1b]
  all_goals rfl

theorem cover_root : go 9 [2,0] m0=false := by
  have hfg : firstGap m0=3 := by decide
  show go (7+2) [2,0] m0=false
  rw [go, hfg]
  show (3 == 0 || [2,0].any (opt1At 3 (go 8) [2,0] m0) ||
    (List.range' 0 113).any (opt2At 3 (go 7) [2,0] m0))=false
  rw [opt2_root]
  simp only [List.any_cons, List.any_nil, opt1_y2, opt1_y0]
  all_goals rfl

/-- The Buratti–Stinson case `(113,11)`: no modular Golomb ruler, proved in Lean. -/
theorem noModularGolombRuler113 : NoModularGolombRuler113 := no_ruler_of_cover cover_root

end Symconf113.Ruler113

import Symconf113.CoverageShard113_009

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0446 : NodeCoverage113 [60,15,5] 5 33 :=
  demand_node_prune113 60 compact113_demands_060 compact113_demands_060_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0447 : NodeCoverage113 [60,15,3] 3 35 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0448 : NodeCoverage113 [60,15] 15 38 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0402
    (ChildrenCoverage113.cons _ _ compact113_node_0403
    (ChildrenCoverage113.cons _ _ compact113_node_0404
    (ChildrenCoverage113.cons _ _ compact113_node_0422
    (ChildrenCoverage113.cons _ _ compact113_node_0423
    (ChildrenCoverage113.cons _ _ compact113_node_0441
    (ChildrenCoverage113.cons _ _ compact113_node_0442
    (ChildrenCoverage113.cons _ _ compact113_node_0443
    (ChildrenCoverage113.cons _ _ compact113_node_0444
    (ChildrenCoverage113.cons _ _ compact113_node_0445
    (ChildrenCoverage113.cons _ _ compact113_node_0446
    (ChildrenCoverage113.cons _ _ compact113_node_0447
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_0449 : NodeCoverage113 [60,14] 14 39 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0450 : NodeCoverage113 [60,13] 13 40 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0451 : NodeCoverage113 [60,12,12,12] 12 17 :=
  demand_node_prune113 60 compact113_demands_060 compact113_demands_060_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0452 : NodeCoverage113 [60,12,12,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0453 : NodeCoverage113 [60,12,12,10,10,9] 9 0 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0454 : NodeCoverage113 [60,12,12,10,10,6] 6 3 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0455 : NodeCoverage113 [60,12,12,10,10,5] 5 4 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0456 : NodeCoverage113 [60,12,12,10,10,3] 3 6 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0457 : NodeCoverage113 [60,12,12,10,10] 10 9 :=
  node_fork113 (B := [9,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0453
    (ChildrenCoverage113.cons _ _ compact113_node_0454
    (ChildrenCoverage113.cons _ _ compact113_node_0455
    (ChildrenCoverage113.cons _ _ compact113_node_0456
    ChildrenCoverage113.nil))))

theorem compact113_node_0458 : NodeCoverage113 [60,12,12,10,9] 9 10 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0459 : NodeCoverage113 [60,12,12,10,8] 8 11 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0460 : NodeCoverage113 [60,12,12,10,7] 7 12 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0461 : NodeCoverage113 [60,12,12,10,6] 6 13 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0462 : NodeCoverage113 [60,12,12,10,5] 5 14 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0463 : NodeCoverage113 [60,12,12,10,3] 3 16 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0464 : NodeCoverage113 [60,12,12,10] 10 19 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0457
    (ChildrenCoverage113.cons _ _ compact113_node_0458
    (ChildrenCoverage113.cons _ _ compact113_node_0459
    (ChildrenCoverage113.cons _ _ compact113_node_0460
    (ChildrenCoverage113.cons _ _ compact113_node_0461
    (ChildrenCoverage113.cons _ _ compact113_node_0462
    (ChildrenCoverage113.cons _ _ compact113_node_0463
    ChildrenCoverage113.nil)))))))

theorem compact113_node_0465 : NodeCoverage113 [60,12,12,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0466 : NodeCoverage113 [60,12,12,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0467 : NodeCoverage113 [60,12,12,7] 7 22 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0468 : NodeCoverage113 [60,12,12,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0469 : NodeCoverage113 [60,12,12,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0470 : NodeCoverage113 [60,12,12,3] 3 26 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0471 : NodeCoverage113 [60,12,12] 12 29 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0451
    (ChildrenCoverage113.cons _ _ compact113_node_0452
    (ChildrenCoverage113.cons _ _ compact113_node_0464
    (ChildrenCoverage113.cons _ _ compact113_node_0465
    (ChildrenCoverage113.cons _ _ compact113_node_0466
    (ChildrenCoverage113.cons _ _ compact113_node_0467
    (ChildrenCoverage113.cons _ _ compact113_node_0468
    (ChildrenCoverage113.cons _ _ compact113_node_0469
    (ChildrenCoverage113.cons _ _ compact113_node_0470
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_0472 : NodeCoverage113 [60,12,11] 11 30 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0473 : NodeCoverage113 [60,12,10] 10 31 :=
  demand_node_prune113 60 compact113_demands_060 compact113_demands_060_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0474 : NodeCoverage113 [60,12,9] 9 32 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0475 : NodeCoverage113 [60,12,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0476 : NodeCoverage113 [60,12,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0477 : NodeCoverage113 [60,12,6] 6 35 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0478 : NodeCoverage113 [60,12,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0479 : NodeCoverage113 [60,12,3] 3 38 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0480 : NodeCoverage113 [60,12] 12 41 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0471
    (ChildrenCoverage113.cons _ _ compact113_node_0472
    (ChildrenCoverage113.cons _ _ compact113_node_0473
    (ChildrenCoverage113.cons _ _ compact113_node_0474
    (ChildrenCoverage113.cons _ _ compact113_node_0475
    (ChildrenCoverage113.cons _ _ compact113_node_0476
    (ChildrenCoverage113.cons _ _ compact113_node_0477
    (ChildrenCoverage113.cons _ _ compact113_node_0478
    (ChildrenCoverage113.cons _ _ compact113_node_0479
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_0481 : NodeCoverage113 [60,11] 11 42 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0482 : NodeCoverage113 [60,10] 10 43 :=
  demand_node_prune113 60 compact113_demands_060 compact113_demands_060_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0483 : NodeCoverage113 [60,9] 9 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0484 : NodeCoverage113 [60,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0485 : NodeCoverage113 [60,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0486 : NodeCoverage113 [60,6] 6 47 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0487 : NodeCoverage113 [60,5] 5 48 :=
  demand_node_prune113 60 compact113_demands_060 compact113_demands_060_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_032

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1347 : NodeCoverage113 [39,39,12] 12 23 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1348 : NodeCoverage113 [39,39,11] 11 24 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1349 : NodeCoverage113 [39,39,10] 10 25 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1350 : NodeCoverage113 [39,39,9] 9 26 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1351 : NodeCoverage113 [39,39,8] 8 27 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1352 : NodeCoverage113 [39,39,7] 7 28 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1353 : NodeCoverage113 [39,39,6] 6 29 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1354 : NodeCoverage113 [39,39,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1355 : NodeCoverage113 [39,39,3] 3 32 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1356 : NodeCoverage113 [39,39] 39 35 :=
  node_fork113 (B := [35,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1326
    (ChildrenCoverage113.cons _ _ compact113_node_1327
    (ChildrenCoverage113.cons _ _ compact113_node_1328
    (ChildrenCoverage113.cons _ _ compact113_node_1329
    (ChildrenCoverage113.cons _ _ compact113_node_1330
    (ChildrenCoverage113.cons _ _ compact113_node_1331
    (ChildrenCoverage113.cons _ _ compact113_node_1332
    (ChildrenCoverage113.cons _ _ compact113_node_1333
    (ChildrenCoverage113.cons _ _ compact113_node_1334
    (ChildrenCoverage113.cons _ _ compact113_node_1335
    (ChildrenCoverage113.cons _ _ compact113_node_1336
    (ChildrenCoverage113.cons _ _ compact113_node_1337
    (ChildrenCoverage113.cons _ _ compact113_node_1338
    (ChildrenCoverage113.cons _ _ compact113_node_1339
    (ChildrenCoverage113.cons _ _ compact113_node_1340
    (ChildrenCoverage113.cons _ _ compact113_node_1341
    (ChildrenCoverage113.cons _ _ compact113_node_1342
    (ChildrenCoverage113.cons _ _ compact113_node_1343
    (ChildrenCoverage113.cons _ _ compact113_node_1344
    (ChildrenCoverage113.cons _ _ compact113_node_1345
    (ChildrenCoverage113.cons _ _ compact113_node_1346
    (ChildrenCoverage113.cons _ _ compact113_node_1347
    (ChildrenCoverage113.cons _ _ compact113_node_1348
    (ChildrenCoverage113.cons _ _ compact113_node_1349
    (ChildrenCoverage113.cons _ _ compact113_node_1350
    (ChildrenCoverage113.cons _ _ compact113_node_1351
    (ChildrenCoverage113.cons _ _ compact113_node_1352
    (ChildrenCoverage113.cons _ _ compact113_node_1353
    (ChildrenCoverage113.cons _ _ compact113_node_1354
    (ChildrenCoverage113.cons _ _ compact113_node_1355
    ChildrenCoverage113.nil))))))))))))))))))))))))))))))

theorem compact113_node_1357 : NodeCoverage113 [39,38] 38 36 :=
  demand_node_prune113 38 compact113_demands_038 compact113_demands_038_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1358 : NodeCoverage113 [39,37] 37 37 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1359 : NodeCoverage113 [39,36] 36 38 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1360 : NodeCoverage113 [39,35] 35 39 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1361 : NodeCoverage113 [39,34] 34 40 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1362 : NodeCoverage113 [39,33] 33 41 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1363 : NodeCoverage113 [39,32] 32 42 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1364 : NodeCoverage113 [39,31] 31 43 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1365 : NodeCoverage113 [39,30] 30 44 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1366 : NodeCoverage113 [39,29] 29 45 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1367 : NodeCoverage113 [39,28] 28 46 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1368 : NodeCoverage113 [39,27] 27 47 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1369 : NodeCoverage113 [39,26] 26 48 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1370 : NodeCoverage113 [39,25] 25 49 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1371 : NodeCoverage113 [39,24] 24 50 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1372 : NodeCoverage113 [39,23] 23 51 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1373 : NodeCoverage113 [39,22] 22 52 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1374 : NodeCoverage113 [39,21] 21 53 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1375 : NodeCoverage113 [39,20] 20 54 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1376 : NodeCoverage113 [39,19] 19 55 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1377 : NodeCoverage113 [39,18] 18 56 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1378 : NodeCoverage113 [39,17] 17 57 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1379 : NodeCoverage113 [39,16] 16 58 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_022

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0975 : NodeCoverage113 [44,44,15] 15 10 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0976 : NodeCoverage113 [44,44,14] 14 11 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0977 : NodeCoverage113 [44,44,13] 13 12 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0978 : NodeCoverage113 [44,44,12] 12 13 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0979 : NodeCoverage113 [44,44,11] 11 14 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0980 : NodeCoverage113 [44,44,10] 10 15 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0981 : NodeCoverage113 [44,44,9] 9 16 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0982 : NodeCoverage113 [44,44,8] 8 17 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0983 : NodeCoverage113 [44,44,7] 7 18 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0984 : NodeCoverage113 [44,44,6] 6 19 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0985 : NodeCoverage113 [44,44,5] 5 20 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0986 : NodeCoverage113 [44,44,3] 3 22 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0987 : NodeCoverage113 [44,44] 44 25 :=
  node_fork113 (B := [25,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0967
    (ChildrenCoverage113.cons _ _ compact113_node_0968
    (ChildrenCoverage113.cons _ _ compact113_node_0969
    (ChildrenCoverage113.cons _ _ compact113_node_0970
    (ChildrenCoverage113.cons _ _ compact113_node_0971
    (ChildrenCoverage113.cons _ _ compact113_node_0972
    (ChildrenCoverage113.cons _ _ compact113_node_0973
    (ChildrenCoverage113.cons _ _ compact113_node_0974
    (ChildrenCoverage113.cons _ _ compact113_node_0975
    (ChildrenCoverage113.cons _ _ compact113_node_0976
    (ChildrenCoverage113.cons _ _ compact113_node_0977
    (ChildrenCoverage113.cons _ _ compact113_node_0978
    (ChildrenCoverage113.cons _ _ compact113_node_0979
    (ChildrenCoverage113.cons _ _ compact113_node_0980
    (ChildrenCoverage113.cons _ _ compact113_node_0981
    (ChildrenCoverage113.cons _ _ compact113_node_0982
    (ChildrenCoverage113.cons _ _ compact113_node_0983
    (ChildrenCoverage113.cons _ _ compact113_node_0984
    (ChildrenCoverage113.cons _ _ compact113_node_0985
    (ChildrenCoverage113.cons _ _ compact113_node_0986
    ChildrenCoverage113.nil))))))))))))))))))))

theorem compact113_node_0988 : NodeCoverage113 [44,43] 43 26 :=
  demand_node_prune113 43 compact113_demands_043 compact113_demands_043_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0989 : NodeCoverage113 [44,42] 42 27 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0990 : NodeCoverage113 [44,41] 41 28 :=
  demand_node_prune113 41 compact113_demands_041 compact113_demands_041_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0991 : NodeCoverage113 [44,40] 40 29 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0992 : NodeCoverage113 [44,39] 39 30 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0993 : NodeCoverage113 [44,38] 38 31 :=
  demand_node_prune113 38 compact113_demands_038 compact113_demands_038_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0994 : NodeCoverage113 [44,37] 37 32 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0995 : NodeCoverage113 [44,36] 36 33 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0996 : NodeCoverage113 [44,35] 35 34 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0997 : NodeCoverage113 [44,34] 34 35 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0998 : NodeCoverage113 [44,33] 33 36 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0999 : NodeCoverage113 [44,32] 32 37 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1000 : NodeCoverage113 [44,31] 31 38 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1001 : NodeCoverage113 [44,30] 30 39 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1002 : NodeCoverage113 [44,29] 29 40 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1003 : NodeCoverage113 [44,28] 28 41 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1004 : NodeCoverage113 [44,27] 27 42 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1005 : NodeCoverage113 [44,26] 26 43 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1006 : NodeCoverage113 [44,25] 25 44 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1007 : NodeCoverage113 [44,24] 24 45 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1008 : NodeCoverage113 [44,23] 23 46 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1009 : NodeCoverage113 [44,22] 22 47 :=
  demand_node_prune113 44 compact113_demands_044 compact113_demands_044_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_057
import Symconf113.CoverageShard113_058

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2347 : NodeCoverage113 [30,30,15,10,6,6,3] 3 13 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2348 : NodeCoverage113 [30,30,15,10,6,6] 6 16 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2345
    (ChildrenCoverage113.cons _ _ compact113_node_2346
    (ChildrenCoverage113.cons _ _ compact113_node_2347
    ChildrenCoverage113.nil)))

theorem compact113_node_2349 : NodeCoverage113 [30,30,15,10,6,5] 5 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2350 : NodeCoverage113 [30,30,15,10,6,3] 3 19 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2351 : NodeCoverage113 [30,30,15,10,6] 6 22 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2348
    (ChildrenCoverage113.cons _ _ compact113_node_2349
    (ChildrenCoverage113.cons _ _ compact113_node_2350
    ChildrenCoverage113.nil)))

theorem compact113_node_2352 : NodeCoverage113 [30,30,15,10,5] 5 23 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2353 : NodeCoverage113 [30,30,15,10,3] 3 25 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2354 : NodeCoverage113 [30,30,15,10] 10 28 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2338
    (ChildrenCoverage113.cons _ _ compact113_node_2339
    (ChildrenCoverage113.cons _ _ compact113_node_2340
    (ChildrenCoverage113.cons _ _ compact113_node_2341
    (ChildrenCoverage113.cons _ _ compact113_node_2351
    (ChildrenCoverage113.cons _ _ compact113_node_2352
    (ChildrenCoverage113.cons _ _ compact113_node_2353
    ChildrenCoverage113.nil)))))))

theorem compact113_node_2355 : NodeCoverage113 [30,30,15,9] 9 29 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2356 : NodeCoverage113 [30,30,15,8] 8 30 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2357 : NodeCoverage113 [30,30,15,7] 7 31 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2358 : NodeCoverage113 [30,30,15,6] 6 32 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2359 : NodeCoverage113 [30,30,15,5] 5 33 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2360 : NodeCoverage113 [30,30,15,3] 3 35 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2361 : NodeCoverage113 [30,30,15] 15 38 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2318
    (ChildrenCoverage113.cons _ _ compact113_node_2319
    (ChildrenCoverage113.cons _ _ compact113_node_2320
    (ChildrenCoverage113.cons _ _ compact113_node_2321
    (ChildrenCoverage113.cons _ _ compact113_node_2322
    (ChildrenCoverage113.cons _ _ compact113_node_2354
    (ChildrenCoverage113.cons _ _ compact113_node_2355
    (ChildrenCoverage113.cons _ _ compact113_node_2356
    (ChildrenCoverage113.cons _ _ compact113_node_2357
    (ChildrenCoverage113.cons _ _ compact113_node_2358
    (ChildrenCoverage113.cons _ _ compact113_node_2359
    (ChildrenCoverage113.cons _ _ compact113_node_2360
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_2362 : NodeCoverage113 [30,30,14] 14 39 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2363 : NodeCoverage113 [30,30,13] 13 40 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2364 : NodeCoverage113 [30,30,12] 12 41 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

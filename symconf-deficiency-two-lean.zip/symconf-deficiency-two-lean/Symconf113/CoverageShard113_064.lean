import Symconf113.CoverageShard113_063

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2424 : NodeCoverage113 [30,15,15,15,15,10] 10 13 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2425 : NodeCoverage113 [30,15,15,15,15,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2426 : NodeCoverage113 [30,15,15,15,15,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2427 : NodeCoverage113 [30,15,15,15,15,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2428 : NodeCoverage113 [30,15,15,15,15,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2429 : NodeCoverage113 [30,15,15,15,15,5] 5 18 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2430 : NodeCoverage113 [30,15,15,15,15,3] 3 20 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2431 : NodeCoverage113 [30,15,15,15,15] 15 23 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2419
    (ChildrenCoverage113.cons _ _ compact113_node_2420
    (ChildrenCoverage113.cons _ _ compact113_node_2421
    (ChildrenCoverage113.cons _ _ compact113_node_2422
    (ChildrenCoverage113.cons _ _ compact113_node_2423
    (ChildrenCoverage113.cons _ _ compact113_node_2424
    (ChildrenCoverage113.cons _ _ compact113_node_2425
    (ChildrenCoverage113.cons _ _ compact113_node_2426
    (ChildrenCoverage113.cons _ _ compact113_node_2427
    (ChildrenCoverage113.cons _ _ compact113_node_2428
    (ChildrenCoverage113.cons _ _ compact113_node_2429
    (ChildrenCoverage113.cons _ _ compact113_node_2430
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_2432 : NodeCoverage113 [30,15,15,15,14] 14 24 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2433 : NodeCoverage113 [30,15,15,15,13] 13 25 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2434 : NodeCoverage113 [30,15,15,15,12] 12 26 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2435 : NodeCoverage113 [30,15,15,15,11] 11 27 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2436 : NodeCoverage113 [30,15,15,15,10] 10 28 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2437 : NodeCoverage113 [30,15,15,15,9] 9 29 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2438 : NodeCoverage113 [30,15,15,15,8] 8 30 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2439 : NodeCoverage113 [30,15,15,15,7] 7 31 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2440 : NodeCoverage113 [30,15,15,15,6] 6 32 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

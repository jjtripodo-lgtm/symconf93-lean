import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2040 : NodeCoverage113 [33,30] 30 50 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2041 : NodeCoverage113 [33,29] 29 51 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2042 : NodeCoverage113 [33,28] 28 52 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2043 : NodeCoverage113 [33,27] 27 53 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2044 : NodeCoverage113 [33,26] 26 54 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2045 : NodeCoverage113 [33,25] 25 55 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2046 : NodeCoverage113 [33,24] 24 56 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2047 : NodeCoverage113 [33,23] 23 57 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2048 : NodeCoverage113 [33,22] 22 58 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2049 : NodeCoverage113 [33,21] 21 59 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2050 : NodeCoverage113 [33,20] 20 60 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2051 : NodeCoverage113 [33,19] 19 61 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2052 : NodeCoverage113 [33,18] 18 62 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2053 : NodeCoverage113 [33,17] 17 63 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2054 : NodeCoverage113 [33,16] 16 64 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2055 : NodeCoverage113 [33,15] 15 65 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2056 : NodeCoverage113 [33,14] 14 66 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2057 : NodeCoverage113 [33,13] 13 67 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2058 : NodeCoverage113 [33,12] 12 68 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2059 : NodeCoverage113 [33,11,11,11,11,11,11,11,3] 3 0 :=
  node_no_weak_demand113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2060 : NodeCoverage113 [33,11,11,11,11,11,11,11] 11 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2059
    ChildrenCoverage113.nil)

theorem compact113_node_2061 : NodeCoverage113 [33,11,11,11,11,11,11,10] 10 4 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2062 : NodeCoverage113 [33,11,11,11,11,11,11,9] 9 5 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2063 : NodeCoverage113 [33,11,11,11,11,11,11,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2064 : NodeCoverage113 [33,11,11,11,11,11,11,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2065 : NodeCoverage113 [33,11,11,11,11,11,11,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2066 : NodeCoverage113 [33,11,11,11,11,11,11,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2067 : NodeCoverage113 [33,11,11,11,11,11,11,3] 3 11 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2068 : NodeCoverage113 [33,11,11,11,11,11,11] 11 14 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2060
    (ChildrenCoverage113.cons _ _ compact113_node_2061
    (ChildrenCoverage113.cons _ _ compact113_node_2062
    (ChildrenCoverage113.cons _ _ compact113_node_2063
    (ChildrenCoverage113.cons _ _ compact113_node_2064
    (ChildrenCoverage113.cons _ _ compact113_node_2065
    (ChildrenCoverage113.cons _ _ compact113_node_2066
    (ChildrenCoverage113.cons _ _ compact113_node_2067
    ChildrenCoverage113.nil))))))))

theorem compact113_node_2069 : NodeCoverage113 [33,11,11,11,11,11,10] 10 15 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2070 : NodeCoverage113 [33,11,11,11,11,11,9] 9 16 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2071 : NodeCoverage113 [33,11,11,11,11,11,8] 8 17 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2072 : NodeCoverage113 [33,11,11,11,11,11,7] 7 18 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_079

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2886 : NodeCoverage113 [27,24] 24 62 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2887 : NodeCoverage113 [27,23] 23 63 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2888 : NodeCoverage113 [27,22] 22 64 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2889 : NodeCoverage113 [27,21] 21 65 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2890 : NodeCoverage113 [27,20] 20 66 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2891 : NodeCoverage113 [27,19] 19 67 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2892 : NodeCoverage113 [27,18] 18 68 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2893 : NodeCoverage113 [27,17] 17 69 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2894 : NodeCoverage113 [27,16] 16 70 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2895 : NodeCoverage113 [27,15] 15 71 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2896 : NodeCoverage113 [27,14] 14 72 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2897 : NodeCoverage113 [27,13] 13 73 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2898 : NodeCoverage113 [27,12] 12 74 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2899 : NodeCoverage113 [27,11] 11 75 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2900 : NodeCoverage113 [27,10] 10 76 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2901 : NodeCoverage113 [27,9] 9 77 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2902 : NodeCoverage113 [27,8] 8 78 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2903 : NodeCoverage113 [27,7] 7 79 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2904 : NodeCoverage113 [27,6] 6 80 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2905 : NodeCoverage113 [27,5] 5 81 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2906 : NodeCoverage113 [27,3] 3 83 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2907 : NodeCoverage113 [27] 27 86 :=
  node_fork113 (B := [27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2883
    (ChildrenCoverage113.cons _ _ compact113_node_2884
    (ChildrenCoverage113.cons _ _ compact113_node_2885
    (ChildrenCoverage113.cons _ _ compact113_node_2886
    (ChildrenCoverage113.cons _ _ compact113_node_2887
    (ChildrenCoverage113.cons _ _ compact113_node_2888
    (ChildrenCoverage113.cons _ _ compact113_node_2889
    (ChildrenCoverage113.cons _ _ compact113_node_2890
    (ChildrenCoverage113.cons _ _ compact113_node_2891
    (ChildrenCoverage113.cons _ _ compact113_node_2892
    (ChildrenCoverage113.cons _ _ compact113_node_2893
    (ChildrenCoverage113.cons _ _ compact113_node_2894
    (ChildrenCoverage113.cons _ _ compact113_node_2895
    (ChildrenCoverage113.cons _ _ compact113_node_2896
    (ChildrenCoverage113.cons _ _ compact113_node_2897
    (ChildrenCoverage113.cons _ _ compact113_node_2898
    (ChildrenCoverage113.cons _ _ compact113_node_2899
    (ChildrenCoverage113.cons _ _ compact113_node_2900
    (ChildrenCoverage113.cons _ _ compact113_node_2901
    (ChildrenCoverage113.cons _ _ compact113_node_2902
    (ChildrenCoverage113.cons _ _ compact113_node_2903
    (ChildrenCoverage113.cons _ _ compact113_node_2904
    (ChildrenCoverage113.cons _ _ compact113_node_2905
    (ChildrenCoverage113.cons _ _ compact113_node_2906
    ChildrenCoverage113.nil))))))))))))))))))))))))

theorem compact113_node_2908 : NodeCoverage113 [26] 26 87 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2909 : NodeCoverage113 [25,25,25,25,13] 13 0 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2910 : NodeCoverage113 [25,25,25,25,10] 10 3 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2911 : NodeCoverage113 [25,25,25,25,9] 9 4 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2912 : NodeCoverage113 [25,25,25,25,8] 8 5 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2913 : NodeCoverage113 [25,25,25,25,7] 7 6 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2914 : NodeCoverage113 [25,25,25,25,6] 6 7 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2915 : NodeCoverage113 [25,25,25,25,5] 5 8 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2916 : NodeCoverage113 [25,25,25,25,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2917 : NodeCoverage113 [25,25,25,25] 25 13 :=
  node_fork113 (B := [13,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2909
    (ChildrenCoverage113.cons _ _ compact113_node_2910
    (ChildrenCoverage113.cons _ _ compact113_node_2911
    (ChildrenCoverage113.cons _ _ compact113_node_2912
    (ChildrenCoverage113.cons _ _ compact113_node_2913
    (ChildrenCoverage113.cons _ _ compact113_node_2914
    (ChildrenCoverage113.cons _ _ compact113_node_2915
    (ChildrenCoverage113.cons _ _ compact113_node_2916
    ChildrenCoverage113.nil))))))))

end Symconf113

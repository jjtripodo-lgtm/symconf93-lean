import Symconf113.CoverageShard113_128

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5070 : NodeCoverage113 [16,16,16,16,16,11] 11 22 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5071 : NodeCoverage113 [16,16,16,16,16,10] 10 23 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5072 : NodeCoverage113 [16,16,16,16,16,9] 9 24 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5073 : NodeCoverage113 [16,16,16,16,16,8] 8 25 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5074 : NodeCoverage113 [16,16,16,16,16,7] 7 26 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5075 : NodeCoverage113 [16,16,16,16,16,6] 6 27 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5076 : NodeCoverage113 [16,16,16,16,16,5] 5 28 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5077 : NodeCoverage113 [16,16,16,16,16,3] 3 30 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5078 : NodeCoverage113 [16,16,16,16,16] 16 33 :=
  node_fork113 (B := [16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5065
    (ChildrenCoverage113.cons _ _ compact113_node_5066
    (ChildrenCoverage113.cons _ _ compact113_node_5067
    (ChildrenCoverage113.cons _ _ compact113_node_5068
    (ChildrenCoverage113.cons _ _ compact113_node_5069
    (ChildrenCoverage113.cons _ _ compact113_node_5070
    (ChildrenCoverage113.cons _ _ compact113_node_5071
    (ChildrenCoverage113.cons _ _ compact113_node_5072
    (ChildrenCoverage113.cons _ _ compact113_node_5073
    (ChildrenCoverage113.cons _ _ compact113_node_5074
    (ChildrenCoverage113.cons _ _ compact113_node_5075
    (ChildrenCoverage113.cons _ _ compact113_node_5076
    (ChildrenCoverage113.cons _ _ compact113_node_5077
    ChildrenCoverage113.nil)))))))))))))

theorem compact113_node_5079 : NodeCoverage113 [16,16,16,16,15] 15 34 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5080 : NodeCoverage113 [16,16,16,16,14] 14 35 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5081 : NodeCoverage113 [16,16,16,16,13] 13 36 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5082 : NodeCoverage113 [16,16,16,16,12] 12 37 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5083 : NodeCoverage113 [16,16,16,16,11] 11 38 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5084 : NodeCoverage113 [16,16,16,16,10] 10 39 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5085 : NodeCoverage113 [16,16,16,16,9] 9 40 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5086 : NodeCoverage113 [16,16,16,16,8] 8 41 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5087 : NodeCoverage113 [16,16,16,16,7] 7 42 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5088 : NodeCoverage113 [16,16,16,16,6] 6 43 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5089 : NodeCoverage113 [16,16,16,16,5] 5 44 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5090 : NodeCoverage113 [16,16,16,16,3] 3 46 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5091 : NodeCoverage113 [16,16,16,16] 16 49 :=
  node_fork113 (B := [16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5078
    (ChildrenCoverage113.cons _ _ compact113_node_5079
    (ChildrenCoverage113.cons _ _ compact113_node_5080
    (ChildrenCoverage113.cons _ _ compact113_node_5081
    (ChildrenCoverage113.cons _ _ compact113_node_5082
    (ChildrenCoverage113.cons _ _ compact113_node_5083
    (ChildrenCoverage113.cons _ _ compact113_node_5084
    (ChildrenCoverage113.cons _ _ compact113_node_5085
    (ChildrenCoverage113.cons _ _ compact113_node_5086
    (ChildrenCoverage113.cons _ _ compact113_node_5087
    (ChildrenCoverage113.cons _ _ compact113_node_5088
    (ChildrenCoverage113.cons _ _ compact113_node_5089
    (ChildrenCoverage113.cons _ _ compact113_node_5090
    ChildrenCoverage113.nil)))))))))))))

theorem compact113_node_5092 : NodeCoverage113 [16,16,16,15] 15 50 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5093 : NodeCoverage113 [16,16,16,14] 14 51 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5094 : NodeCoverage113 [16,16,16,13] 13 52 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5095 : NodeCoverage113 [16,16,16,12] 12 53 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5096 : NodeCoverage113 [16,16,16,11] 11 54 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5097 : NodeCoverage113 [16,16,16,10] 10 55 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5098 : NodeCoverage113 [16,16,16,9] 9 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5099 : NodeCoverage113 [16,16,16,8] 8 57 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5100 : NodeCoverage113 [16,16,16,7] 7 58 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5101 : NodeCoverage113 [16,16,16,6] 6 59 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5102 : NodeCoverage113 [16,16,16,5] 5 60 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5103 : NodeCoverage113 [16,16,16,3] 3 62 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5104 : NodeCoverage113 [16,16,16] 16 65 :=
  node_fork113 (B := [16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5091
    (ChildrenCoverage113.cons _ _ compact113_node_5092
    (ChildrenCoverage113.cons _ _ compact113_node_5093
    (ChildrenCoverage113.cons _ _ compact113_node_5094
    (ChildrenCoverage113.cons _ _ compact113_node_5095
    (ChildrenCoverage113.cons _ _ compact113_node_5096
    (ChildrenCoverage113.cons _ _ compact113_node_5097
    (ChildrenCoverage113.cons _ _ compact113_node_5098
    (ChildrenCoverage113.cons _ _ compact113_node_5099
    (ChildrenCoverage113.cons _ _ compact113_node_5100
    (ChildrenCoverage113.cons _ _ compact113_node_5101
    (ChildrenCoverage113.cons _ _ compact113_node_5102
    (ChildrenCoverage113.cons _ _ compact113_node_5103
    ChildrenCoverage113.nil)))))))))))))

theorem compact113_node_5105 : NodeCoverage113 [16,16,15,15] 15 51 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5106 : NodeCoverage113 [16,16,15,14] 14 52 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5107 : NodeCoverage113 [16,16,15,13] 13 53 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5108 : NodeCoverage113 [16,16,15,12] 12 54 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5109 : NodeCoverage113 [16,16,15,11] 11 55 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5110 : NodeCoverage113 [16,16,15,10] 10 56 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5111 : NodeCoverage113 [16,16,15,9] 9 57 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5112 : NodeCoverage113 [16,16,15,8] 8 58 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5113 : NodeCoverage113 [16,16,15,7] 7 59 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5114 : NodeCoverage113 [16,16,15,6] 6 60 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

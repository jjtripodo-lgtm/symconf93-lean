import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3344 : NodeCoverage113 [24,12,10,10,10] 10 47 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3345 : NodeCoverage113 [24,12,10,10,9] 9 48 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3346 : NodeCoverage113 [24,12,10,10,8] 8 49 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3347 : NodeCoverage113 [24,12,10,10,7] 7 50 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3348 : NodeCoverage113 [24,12,10,10,6] 6 51 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3349 : NodeCoverage113 [24,12,10,10,5] 5 52 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3350 : NodeCoverage113 [24,12,10,10,3] 3 54 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3351 : NodeCoverage113 [24,12,10,10] 10 57 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3344
    (ChildrenCoverage113.cons _ _ compact113_node_3345
    (ChildrenCoverage113.cons _ _ compact113_node_3346
    (ChildrenCoverage113.cons _ _ compact113_node_3347
    (ChildrenCoverage113.cons _ _ compact113_node_3348
    (ChildrenCoverage113.cons _ _ compact113_node_3349
    (ChildrenCoverage113.cons _ _ compact113_node_3350
    ChildrenCoverage113.nil)))))))

theorem compact113_node_3352 : NodeCoverage113 [24,12,10,9] 9 58 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3353 : NodeCoverage113 [24,12,10,8] 8 59 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3354 : NodeCoverage113 [24,12,10,7] 7 60 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3355 : NodeCoverage113 [24,12,10,6] 6 61 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3356 : NodeCoverage113 [24,12,10,5] 5 62 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3357 : NodeCoverage113 [24,12,10,3] 3 64 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3358 : NodeCoverage113 [24,12,10] 10 67 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3351
    (ChildrenCoverage113.cons _ _ compact113_node_3352
    (ChildrenCoverage113.cons _ _ compact113_node_3353
    (ChildrenCoverage113.cons _ _ compact113_node_3354
    (ChildrenCoverage113.cons _ _ compact113_node_3355
    (ChildrenCoverage113.cons _ _ compact113_node_3356
    (ChildrenCoverage113.cons _ _ compact113_node_3357
    ChildrenCoverage113.nil)))))))

theorem compact113_node_3359 : NodeCoverage113 [24,12,9,9,9] 9 50 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3360 : NodeCoverage113 [24,12,9,9,8] 8 51 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3361 : NodeCoverage113 [24,12,9,9,7] 7 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3362 : NodeCoverage113 [24,12,9,9,6] 6 53 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3363 : NodeCoverage113 [24,12,9,9,5] 5 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3364 : NodeCoverage113 [24,12,9,9,3] 3 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3365 : NodeCoverage113 [24,12,9,9] 9 59 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3359
    (ChildrenCoverage113.cons _ _ compact113_node_3360
    (ChildrenCoverage113.cons _ _ compact113_node_3361
    (ChildrenCoverage113.cons _ _ compact113_node_3362
    (ChildrenCoverage113.cons _ _ compact113_node_3363
    (ChildrenCoverage113.cons _ _ compact113_node_3364
    ChildrenCoverage113.nil))))))

theorem compact113_node_3366 : NodeCoverage113 [24,12,9,8] 8 60 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3367 : NodeCoverage113 [24,12,9,7] 7 61 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3368 : NodeCoverage113 [24,12,9,6] 6 62 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3369 : NodeCoverage113 [24,12,9,5] 5 63 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3370 : NodeCoverage113 [24,12,9,3] 3 65 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3371 : NodeCoverage113 [24,12,9] 9 68 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3365
    (ChildrenCoverage113.cons _ _ compact113_node_3366
    (ChildrenCoverage113.cons _ _ compact113_node_3367
    (ChildrenCoverage113.cons _ _ compact113_node_3368
    (ChildrenCoverage113.cons _ _ compact113_node_3369
    (ChildrenCoverage113.cons _ _ compact113_node_3370
    ChildrenCoverage113.nil))))))

theorem compact113_node_3372 : NodeCoverage113 [24,12,8] 8 69 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3373 : NodeCoverage113 [24,12,7] 7 70 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

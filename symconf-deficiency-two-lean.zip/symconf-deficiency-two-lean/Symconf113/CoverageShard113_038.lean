import Symconf113.CoverageShard113_036
import Symconf113.CoverageShard113_037

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1533 : NodeCoverage113 [36,36,12,9,9] 9 11 :=
  node_fork113 (B := [8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1528
    (ChildrenCoverage113.cons _ _ compact113_node_1529
    (ChildrenCoverage113.cons _ _ compact113_node_1530
    (ChildrenCoverage113.cons _ _ compact113_node_1531
    (ChildrenCoverage113.cons _ _ compact113_node_1532
    ChildrenCoverage113.nil)))))

theorem compact113_node_1534 : NodeCoverage113 [36,36,12,9,8] 8 12 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1535 : NodeCoverage113 [36,36,12,9,7] 7 13 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1536 : NodeCoverage113 [36,36,12,9,6,6,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1537 : NodeCoverage113 [36,36,12,9,6,6,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_1538 : NodeCoverage113 [36,36,12,9,6,6] 6 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1536
    (ChildrenCoverage113.cons _ _ compact113_node_1537
    ChildrenCoverage113.nil))

theorem compact113_node_1539 : NodeCoverage113 [36,36,12,9,6,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1540 : NodeCoverage113 [36,36,12,9,6,3] 3 11 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1541 : NodeCoverage113 [36,36,12,9,6] 6 14 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1538
    (ChildrenCoverage113.cons _ _ compact113_node_1539
    (ChildrenCoverage113.cons _ _ compact113_node_1540
    ChildrenCoverage113.nil)))

theorem compact113_node_1542 : NodeCoverage113 [36,36,12,9,5] 5 15 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1543 : NodeCoverage113 [36,36,12,9,3] 3 17 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1544 : NodeCoverage113 [36,36,12,9] 9 20 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1533
    (ChildrenCoverage113.cons _ _ compact113_node_1534
    (ChildrenCoverage113.cons _ _ compact113_node_1535
    (ChildrenCoverage113.cons _ _ compact113_node_1541
    (ChildrenCoverage113.cons _ _ compact113_node_1542
    (ChildrenCoverage113.cons _ _ compact113_node_1543
    ChildrenCoverage113.nil))))))

theorem compact113_node_1545 : NodeCoverage113 [36,36,12,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1546 : NodeCoverage113 [36,36,12,7] 7 22 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1547 : NodeCoverage113 [36,36,12,6] 6 23 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1548 : NodeCoverage113 [36,36,12,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1549 : NodeCoverage113 [36,36,12,3] 3 26 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1550 : NodeCoverage113 [36,36,12] 12 29 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1525
    (ChildrenCoverage113.cons _ _ compact113_node_1526
    (ChildrenCoverage113.cons _ _ compact113_node_1527
    (ChildrenCoverage113.cons _ _ compact113_node_1544
    (ChildrenCoverage113.cons _ _ compact113_node_1545
    (ChildrenCoverage113.cons _ _ compact113_node_1546
    (ChildrenCoverage113.cons _ _ compact113_node_1547
    (ChildrenCoverage113.cons _ _ compact113_node_1548
    (ChildrenCoverage113.cons _ _ compact113_node_1549
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_1551 : NodeCoverage113 [36,36,11] 11 30 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1552 : NodeCoverage113 [36,36,10] 10 31 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1553 : NodeCoverage113 [36,36,9,9,9,9,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1554 : NodeCoverage113 [36,36,9,9,9,9] 9 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1553
    ChildrenCoverage113.nil)

theorem compact113_node_1555 : NodeCoverage113 [36,36,9,9,9,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1556 : NodeCoverage113 [36,36,9,9,9,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1557 : NodeCoverage113 [36,36,9,9,9,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1558 : NodeCoverage113 [36,36,9,9,9,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1559 : NodeCoverage113 [36,36,9,9,9,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_1560 : NodeCoverage113 [36,36,9,9,9,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1559
    ChildrenCoverage113.nil)

theorem compact113_node_1561 : NodeCoverage113 [36,36,9,9,9,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1560
    ChildrenCoverage113.nil)

theorem compact113_node_1562 : NodeCoverage113 [36,36,9,9,9] 9 14 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1554
    (ChildrenCoverage113.cons _ _ compact113_node_1555
    (ChildrenCoverage113.cons _ _ compact113_node_1556
    (ChildrenCoverage113.cons _ _ compact113_node_1557
    (ChildrenCoverage113.cons _ _ compact113_node_1558
    (ChildrenCoverage113.cons _ _ compact113_node_1561
    ChildrenCoverage113.nil))))))

theorem compact113_node_1563 : NodeCoverage113 [36,36,9,9,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1564 : NodeCoverage113 [36,36,9,9,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1565 : NodeCoverage113 [36,36,9,9,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1566 : NodeCoverage113 [36,36,9,9,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1565
    ChildrenCoverage113.nil)

theorem compact113_node_1567 : NodeCoverage113 [36,36,9,9,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1568 : NodeCoverage113 [36,36,9,9,6,6,3] 3 8 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1569 : NodeCoverage113 [36,36,9,9,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1566
    (ChildrenCoverage113.cons _ _ compact113_node_1567
    (ChildrenCoverage113.cons _ _ compact113_node_1568
    ChildrenCoverage113.nil)))

theorem compact113_node_1570 : NodeCoverage113 [36,36,9,9,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1571 : NodeCoverage113 [36,36,9,9,6,3] 3 14 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1572 : NodeCoverage113 [36,36,9,9,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1569
    (ChildrenCoverage113.cons _ _ compact113_node_1570
    (ChildrenCoverage113.cons _ _ compact113_node_1571
    ChildrenCoverage113.nil)))

theorem compact113_node_1573 : NodeCoverage113 [36,36,9,9,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1574 : NodeCoverage113 [36,36,9,9,3] 3 20 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1575 : NodeCoverage113 [36,36,9,9] 9 23 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1562
    (ChildrenCoverage113.cons _ _ compact113_node_1563
    (ChildrenCoverage113.cons _ _ compact113_node_1564
    (ChildrenCoverage113.cons _ _ compact113_node_1572
    (ChildrenCoverage113.cons _ _ compact113_node_1573
    (ChildrenCoverage113.cons _ _ compact113_node_1574
    ChildrenCoverage113.nil))))))

theorem compact113_node_1576 : NodeCoverage113 [36,36,9,8] 8 24 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1577 : NodeCoverage113 [36,36,9,7] 7 25 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1578 : NodeCoverage113 [36,36,9,6] 6 26 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1579 : NodeCoverage113 [36,36,9,5] 5 27 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1580 : NodeCoverage113 [36,36,9,3] 3 29 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1581 : NodeCoverage113 [36,36,9] 9 32 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1575
    (ChildrenCoverage113.cons _ _ compact113_node_1576
    (ChildrenCoverage113.cons _ _ compact113_node_1577
    (ChildrenCoverage113.cons _ _ compact113_node_1578
    (ChildrenCoverage113.cons _ _ compact113_node_1579
    (ChildrenCoverage113.cons _ _ compact113_node_1580
    ChildrenCoverage113.nil))))))

theorem compact113_node_1582 : NodeCoverage113 [36,36,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1583 : NodeCoverage113 [36,36,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1584 : NodeCoverage113 [36,36,6] 6 35 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1585 : NodeCoverage113 [36,36,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1586 : NodeCoverage113 [36,36,3] 3 38 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1587 : NodeCoverage113 [36,36] 36 41 :=
  node_fork113 (B := [36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1462
    (ChildrenCoverage113.cons _ _ compact113_node_1463
    (ChildrenCoverage113.cons _ _ compact113_node_1464
    (ChildrenCoverage113.cons _ _ compact113_node_1465
    (ChildrenCoverage113.cons _ _ compact113_node_1466
    (ChildrenCoverage113.cons _ _ compact113_node_1467
    (ChildrenCoverage113.cons _ _ compact113_node_1468
    (ChildrenCoverage113.cons _ _ compact113_node_1469
    (ChildrenCoverage113.cons _ _ compact113_node_1470
    (ChildrenCoverage113.cons _ _ compact113_node_1471
    (ChildrenCoverage113.cons _ _ compact113_node_1472
    (ChildrenCoverage113.cons _ _ compact113_node_1473
    (ChildrenCoverage113.cons _ _ compact113_node_1474
    (ChildrenCoverage113.cons _ _ compact113_node_1475
    (ChildrenCoverage113.cons _ _ compact113_node_1476
    (ChildrenCoverage113.cons _ _ compact113_node_1477
    (ChildrenCoverage113.cons _ _ compact113_node_1478
    (ChildrenCoverage113.cons _ _ compact113_node_1479
    (ChildrenCoverage113.cons _ _ compact113_node_1502
    (ChildrenCoverage113.cons _ _ compact113_node_1503
    (ChildrenCoverage113.cons _ _ compact113_node_1504
    (ChildrenCoverage113.cons _ _ compact113_node_1505
    (ChildrenCoverage113.cons _ _ compact113_node_1506
    (ChildrenCoverage113.cons _ _ compact113_node_1507
    (ChildrenCoverage113.cons _ _ compact113_node_1550
    (ChildrenCoverage113.cons _ _ compact113_node_1551
    (ChildrenCoverage113.cons _ _ compact113_node_1552
    (ChildrenCoverage113.cons _ _ compact113_node_1581
    (ChildrenCoverage113.cons _ _ compact113_node_1582
    (ChildrenCoverage113.cons _ _ compact113_node_1583
    (ChildrenCoverage113.cons _ _ compact113_node_1584
    (ChildrenCoverage113.cons _ _ compact113_node_1585
    (ChildrenCoverage113.cons _ _ compact113_node_1586
    ChildrenCoverage113.nil)))))))))))))))))))))))))))))))))

theorem compact113_node_1588 : NodeCoverage113 [36,35] 35 42 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1589 : NodeCoverage113 [36,34] 34 43 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1590 : NodeCoverage113 [36,33] 33 44 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1591 : NodeCoverage113 [36,32] 32 45 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1592 : NodeCoverage113 [36,31] 31 46 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

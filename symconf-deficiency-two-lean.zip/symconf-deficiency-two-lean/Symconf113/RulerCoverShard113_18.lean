import Symconf113.RulerCoverDefs113

namespace Symconf113.Ruler113

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem coverShard113_18 : (List.range' 60 12).any (opt2At 4 (go 6) [110,2,0] m1b)=false := by
  decide +kernel

end Symconf113.Ruler113

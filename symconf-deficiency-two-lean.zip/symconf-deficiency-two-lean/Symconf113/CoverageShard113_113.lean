import Symconf113.CoverageShard113_112

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4202 : NodeCoverage113 [20,12,7] 7 74 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4203 : NodeCoverage113 [20,12,6] 6 75 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4204 : NodeCoverage113 [20,12,5] 5 76 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4205 : NodeCoverage113 [20,12,3] 3 78 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4206 : NodeCoverage113 [20,12] 12 81 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4197
    (ChildrenCoverage113.cons _ _ compact113_node_4198
    (ChildrenCoverage113.cons _ _ compact113_node_4199
    (ChildrenCoverage113.cons _ _ compact113_node_4200
    (ChildrenCoverage113.cons _ _ compact113_node_4201
    (ChildrenCoverage113.cons _ _ compact113_node_4202
    (ChildrenCoverage113.cons _ _ compact113_node_4203
    (ChildrenCoverage113.cons _ _ compact113_node_4204
    (ChildrenCoverage113.cons _ _ compact113_node_4205
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_4207 : NodeCoverage113 [20,11,11] 11 71 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4208 : NodeCoverage113 [20,11,10] 10 72 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4209 : NodeCoverage113 [20,11,9] 9 73 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4210 : NodeCoverage113 [20,11,8] 8 74 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4211 : NodeCoverage113 [20,11,7] 7 75 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4212 : NodeCoverage113 [20,11,6] 6 76 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4213 : NodeCoverage113 [20,11,5] 5 77 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4214 : NodeCoverage113 [20,11,3] 3 79 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4215 : NodeCoverage113 [20,11] 11 82 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4207
    (ChildrenCoverage113.cons _ _ compact113_node_4208
    (ChildrenCoverage113.cons _ _ compact113_node_4209
    (ChildrenCoverage113.cons _ _ compact113_node_4210
    (ChildrenCoverage113.cons _ _ compact113_node_4211
    (ChildrenCoverage113.cons _ _ compact113_node_4212
    (ChildrenCoverage113.cons _ _ compact113_node_4213
    (ChildrenCoverage113.cons _ _ compact113_node_4214
    ChildrenCoverage113.nil))))))))

theorem compact113_node_4216 : NodeCoverage113 [20,10,10,10,10,10,10,10,10] 10 13 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4217 : NodeCoverage113 [20,10,10,10,10,10,10,10,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4218 : NodeCoverage113 [20,10,10,10,10,10,10,10,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4219 : NodeCoverage113 [20,10,10,10,10,10,10,10,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4220 : NodeCoverage113 [20,10,10,10,10,10,10,10,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4221 : NodeCoverage113 [20,10,10,10,10,10,10,10,5,5,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4222 : NodeCoverage113 [20,10,10,10,10,10,10,10,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4221
    ChildrenCoverage113.nil)

theorem compact113_node_4223 : NodeCoverage113 [20,10,10,10,10,10,10,10,5,5,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4224 : NodeCoverage113 [20,10,10,10,10,10,10,10,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4222
    (ChildrenCoverage113.cons _ _ compact113_node_4223
    ChildrenCoverage113.nil))

theorem compact113_node_4225 : NodeCoverage113 [20,10,10,10,10,10,10,10,5,5,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4226 : NodeCoverage113 [20,10,10,10,10,10,10,10,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4224
    (ChildrenCoverage113.cons _ _ compact113_node_4225
    ChildrenCoverage113.nil))

theorem compact113_node_4227 : NodeCoverage113 [20,10,10,10,10,10,10,10,5,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4228 : NodeCoverage113 [20,10,10,10,10,10,10,10,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4226
    (ChildrenCoverage113.cons _ _ compact113_node_4227
    ChildrenCoverage113.nil))

theorem compact113_node_4229 : NodeCoverage113 [20,10,10,10,10,10,10,10,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4230 : NodeCoverage113 [20,10,10,10,10,10,10,10] 10 23 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4216
    (ChildrenCoverage113.cons _ _ compact113_node_4217
    (ChildrenCoverage113.cons _ _ compact113_node_4218
    (ChildrenCoverage113.cons _ _ compact113_node_4219
    (ChildrenCoverage113.cons _ _ compact113_node_4220
    (ChildrenCoverage113.cons _ _ compact113_node_4228
    (ChildrenCoverage113.cons _ _ compact113_node_4229
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4231 : NodeCoverage113 [20,10,10,10,10,10,10,9] 9 24 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4232 : NodeCoverage113 [20,10,10,10,10,10,10,8] 8 25 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4233 : NodeCoverage113 [20,10,10,10,10,10,10,7] 7 26 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4234 : NodeCoverage113 [20,10,10,10,10,10,10,6] 6 27 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4235 : NodeCoverage113 [20,10,10,10,10,10,10,5,5,5,5,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4236 : NodeCoverage113 [20,10,10,10,10,10,10,5,5,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4235
    ChildrenCoverage113.nil)

theorem compact113_node_4237 : NodeCoverage113 [20,10,10,10,10,10,10,5,5,5,5,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4238 : NodeCoverage113 [20,10,10,10,10,10,10,5,5,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4236
    (ChildrenCoverage113.cons _ _ compact113_node_4237
    ChildrenCoverage113.nil))

theorem compact113_node_4239 : NodeCoverage113 [20,10,10,10,10,10,10,5,5,5,5,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4240 : NodeCoverage113 [20,10,10,10,10,10,10,5,5,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4238
    (ChildrenCoverage113.cons _ _ compact113_node_4239
    ChildrenCoverage113.nil))

theorem compact113_node_4241 : NodeCoverage113 [20,10,10,10,10,10,10,5,5,5,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4242 : NodeCoverage113 [20,10,10,10,10,10,10,5,5,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4240
    (ChildrenCoverage113.cons _ _ compact113_node_4241
    ChildrenCoverage113.nil))

theorem compact113_node_4243 : NodeCoverage113 [20,10,10,10,10,10,10,5,5,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4244 : NodeCoverage113 [20,10,10,10,10,10,10,5,5] 5 23 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4242
    (ChildrenCoverage113.cons _ _ compact113_node_4243
    ChildrenCoverage113.nil))

theorem compact113_node_4245 : NodeCoverage113 [20,10,10,10,10,10,10,5,3] 3 25 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4246 : NodeCoverage113 [20,10,10,10,10,10,10,5] 5 28 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4244
    (ChildrenCoverage113.cons _ _ compact113_node_4245
    ChildrenCoverage113.nil))

theorem compact113_node_4247 : NodeCoverage113 [20,10,10,10,10,10,10,3] 3 30 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4248 : NodeCoverage113 [20,10,10,10,10,10,10] 10 33 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4230
    (ChildrenCoverage113.cons _ _ compact113_node_4231
    (ChildrenCoverage113.cons _ _ compact113_node_4232
    (ChildrenCoverage113.cons _ _ compact113_node_4233
    (ChildrenCoverage113.cons _ _ compact113_node_4234
    (ChildrenCoverage113.cons _ _ compact113_node_4246
    (ChildrenCoverage113.cons _ _ compact113_node_4247
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4249 : NodeCoverage113 [20,10,10,10,10,10,9] 9 34 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4250 : NodeCoverage113 [20,10,10,10,10,10,8] 8 35 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4251 : NodeCoverage113 [20,10,10,10,10,10,7] 7 36 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4252 : NodeCoverage113 [20,10,10,10,10,10,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4253 : NodeCoverage113 [20,10,10,10,10,10,5] 5 38 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4254 : NodeCoverage113 [20,10,10,10,10,10,3] 3 40 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4255 : NodeCoverage113 [20,10,10,10,10,10] 10 43 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4248
    (ChildrenCoverage113.cons _ _ compact113_node_4249
    (ChildrenCoverage113.cons _ _ compact113_node_4250
    (ChildrenCoverage113.cons _ _ compact113_node_4251
    (ChildrenCoverage113.cons _ _ compact113_node_4252
    (ChildrenCoverage113.cons _ _ compact113_node_4253
    (ChildrenCoverage113.cons _ _ compact113_node_4254
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4256 : NodeCoverage113 [20,10,10,10,10,9] 9 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4257 : NodeCoverage113 [20,10,10,10,10,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4258 : NodeCoverage113 [20,10,10,10,10,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4259 : NodeCoverage113 [20,10,10,10,10,6] 6 47 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4260 : NodeCoverage113 [20,10,10,10,10,5] 5 48 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4261 : NodeCoverage113 [20,10,10,10,10,3] 3 50 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4262 : NodeCoverage113 [20,10,10,10,10] 10 53 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4255
    (ChildrenCoverage113.cons _ _ compact113_node_4256
    (ChildrenCoverage113.cons _ _ compact113_node_4257
    (ChildrenCoverage113.cons _ _ compact113_node_4258
    (ChildrenCoverage113.cons _ _ compact113_node_4259
    (ChildrenCoverage113.cons _ _ compact113_node_4260
    (ChildrenCoverage113.cons _ _ compact113_node_4261
    ChildrenCoverage113.nil)))))))

end Symconf113

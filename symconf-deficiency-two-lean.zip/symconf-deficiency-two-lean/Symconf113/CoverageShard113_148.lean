import Symconf113.CoverageShard113_147

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_6226 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6222
    (ChildrenCoverage113.cons _ _ compact113_node_6223
    (ChildrenCoverage113.cons _ _ compact113_node_6225
    ChildrenCoverage113.nil)))

theorem compact113_node_6227 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6228 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,6,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6229 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,6,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6228
    ChildrenCoverage113.nil)

theorem compact113_node_6230 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,6,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6229
    ChildrenCoverage113.nil)

theorem compact113_node_6231 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,6,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6230
    ChildrenCoverage113.nil)

theorem compact113_node_6232 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6226
    (ChildrenCoverage113.cons _ _ compact113_node_6227
    (ChildrenCoverage113.cons _ _ compact113_node_6231
    ChildrenCoverage113.nil)))

theorem compact113_node_6233 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6234 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6235 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6234
    ChildrenCoverage113.nil)

theorem compact113_node_6236 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6235
    ChildrenCoverage113.nil)

theorem compact113_node_6237 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6236
    ChildrenCoverage113.nil)

theorem compact113_node_6238 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6237
    ChildrenCoverage113.nil)

theorem compact113_node_6239 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6238
    ChildrenCoverage113.nil)

theorem compact113_node_6240 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,6] 6 23 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6232
    (ChildrenCoverage113.cons _ _ compact113_node_6233
    (ChildrenCoverage113.cons _ _ compact113_node_6239
    ChildrenCoverage113.nil)))

theorem compact113_node_6241 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6242 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6243 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6242
    ChildrenCoverage113.nil)

theorem compact113_node_6244 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6243
    ChildrenCoverage113.nil)

theorem compact113_node_6245 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6244
    ChildrenCoverage113.nil)

theorem compact113_node_6246 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6245
    ChildrenCoverage113.nil)

theorem compact113_node_6247 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6246
    ChildrenCoverage113.nil)

theorem compact113_node_6248 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6247
    ChildrenCoverage113.nil)

theorem compact113_node_6249 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6248
    ChildrenCoverage113.nil)

theorem compact113_node_6250 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,6] 6 29 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6240
    (ChildrenCoverage113.cons _ _ compact113_node_6241
    (ChildrenCoverage113.cons _ _ compact113_node_6249
    ChildrenCoverage113.nil)))

theorem compact113_node_6251 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,5] 5 30 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6252 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6253 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6252
    ChildrenCoverage113.nil)

theorem compact113_node_6254 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6253
    ChildrenCoverage113.nil)

theorem compact113_node_6255 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6254
    ChildrenCoverage113.nil)

theorem compact113_node_6256 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6255
    ChildrenCoverage113.nil)

theorem compact113_node_6257 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6256
    ChildrenCoverage113.nil)

theorem compact113_node_6258 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6257
    ChildrenCoverage113.nil)

theorem compact113_node_6259 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6258
    ChildrenCoverage113.nil)

theorem compact113_node_6260 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6259
    ChildrenCoverage113.nil)

theorem compact113_node_6261 : NodeCoverage113 [12,12,12,12,6,6,6,6,6,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6260
    ChildrenCoverage113.nil)

theorem compact113_node_6262 : NodeCoverage113 [12,12,12,12,6,6,6,6,6] 6 35 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6250
    (ChildrenCoverage113.cons _ _ compact113_node_6251
    (ChildrenCoverage113.cons _ _ compact113_node_6261
    ChildrenCoverage113.nil)))

theorem compact113_node_6263 : NodeCoverage113 [12,12,12,12,6,6,6,6,5] 5 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6264 : NodeCoverage113 [12,12,12,12,6,6,6,6,3] 3 38 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6265 : NodeCoverage113 [12,12,12,12,6,6,6,6] 6 41 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6262
    (ChildrenCoverage113.cons _ _ compact113_node_6263
    (ChildrenCoverage113.cons _ _ compact113_node_6264
    ChildrenCoverage113.nil)))

theorem compact113_node_6266 : NodeCoverage113 [12,12,12,12,6,6,6,5] 5 42 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6267 : NodeCoverage113 [12,12,12,12,6,6,6,3] 3 44 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6268 : NodeCoverage113 [12,12,12,12,6,6,6] 6 47 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6265
    (ChildrenCoverage113.cons _ _ compact113_node_6266
    (ChildrenCoverage113.cons _ _ compact113_node_6267
    ChildrenCoverage113.nil)))

theorem compact113_node_6269 : NodeCoverage113 [12,12,12,12,6,6,5] 5 48 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6270 : NodeCoverage113 [12,12,12,12,6,6,3] 3 50 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6271 : NodeCoverage113 [12,12,12,12,6,6] 6 53 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6268
    (ChildrenCoverage113.cons _ _ compact113_node_6269
    (ChildrenCoverage113.cons _ _ compact113_node_6270
    ChildrenCoverage113.nil)))

theorem compact113_node_6272 : NodeCoverage113 [12,12,12,12,6,5] 5 54 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6273 : NodeCoverage113 [12,12,12,12,6,3] 3 56 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6274 : NodeCoverage113 [12,12,12,12,6] 6 59 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6271
    (ChildrenCoverage113.cons _ _ compact113_node_6272
    (ChildrenCoverage113.cons _ _ compact113_node_6273
    ChildrenCoverage113.nil)))

theorem compact113_node_6275 : NodeCoverage113 [12,12,12,12,5] 5 60 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6276 : NodeCoverage113 [12,12,12,12,3] 3 62 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6277 : NodeCoverage113 [12,12,12,12] 12 65 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6195
    (ChildrenCoverage113.cons _ _ compact113_node_6196
    (ChildrenCoverage113.cons _ _ compact113_node_6197
    (ChildrenCoverage113.cons _ _ compact113_node_6198
    (ChildrenCoverage113.cons _ _ compact113_node_6199
    (ChildrenCoverage113.cons _ _ compact113_node_6220
    (ChildrenCoverage113.cons _ _ compact113_node_6274
    (ChildrenCoverage113.cons _ _ compact113_node_6275
    (ChildrenCoverage113.cons _ _ compact113_node_6276
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_6278 : NodeCoverage113 [12,12,12,11,11,11,11] 11 33 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6279 : NodeCoverage113 [12,12,12,11,11,11,10] 10 34 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6280 : NodeCoverage113 [12,12,12,11,11,11,9] 9 35 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6281 : NodeCoverage113 [12,12,12,11,11,11,8] 8 36 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6282 : NodeCoverage113 [12,12,12,11,11,11,7] 7 37 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6283 : NodeCoverage113 [12,12,12,11,11,11,6] 6 38 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6284 : NodeCoverage113 [12,12,12,11,11,11,5] 5 39 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6285 : NodeCoverage113 [12,12,12,11,11,11,3] 3 41 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6286 : NodeCoverage113 [12,12,12,11,11,11] 11 44 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6278
    (ChildrenCoverage113.cons _ _ compact113_node_6279
    (ChildrenCoverage113.cons _ _ compact113_node_6280
    (ChildrenCoverage113.cons _ _ compact113_node_6281
    (ChildrenCoverage113.cons _ _ compact113_node_6282
    (ChildrenCoverage113.cons _ _ compact113_node_6283
    (ChildrenCoverage113.cons _ _ compact113_node_6284
    (ChildrenCoverage113.cons _ _ compact113_node_6285
    ChildrenCoverage113.nil))))))))

theorem compact113_node_6287 : NodeCoverage113 [12,12,12,11,11,10] 10 45 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6288 : NodeCoverage113 [12,12,12,11,11,9] 9 46 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6289 : NodeCoverage113 [12,12,12,11,11,8] 8 47 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6290 : NodeCoverage113 [12,12,12,11,11,7] 7 48 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6291 : NodeCoverage113 [12,12,12,11,11,6] 6 49 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6292 : NodeCoverage113 [12,12,12,11,11,5] 5 50 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6293 : NodeCoverage113 [12,12,12,11,11,3] 3 52 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6294 : NodeCoverage113 [12,12,12,11,11] 11 55 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6286
    (ChildrenCoverage113.cons _ _ compact113_node_6287
    (ChildrenCoverage113.cons _ _ compact113_node_6288
    (ChildrenCoverage113.cons _ _ compact113_node_6289
    (ChildrenCoverage113.cons _ _ compact113_node_6290
    (ChildrenCoverage113.cons _ _ compact113_node_6291
    (ChildrenCoverage113.cons _ _ compact113_node_6292
    (ChildrenCoverage113.cons _ _ compact113_node_6293
    ChildrenCoverage113.nil))))))))

theorem compact113_node_6295 : NodeCoverage113 [12,12,12,11,10] 10 56 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6296 : NodeCoverage113 [12,12,12,11,9] 9 57 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6297 : NodeCoverage113 [12,12,12,11,8] 8 58 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6298 : NodeCoverage113 [12,12,12,11,7] 7 59 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6299 : NodeCoverage113 [12,12,12,11,6] 6 60 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6300 : NodeCoverage113 [12,12,12,11,5] 5 61 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_066

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2473 : NodeCoverage113 [30,12,9] 9 62 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2474 : NodeCoverage113 [30,12,8] 8 63 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2475 : NodeCoverage113 [30,12,7] 7 64 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2476 : NodeCoverage113 [30,12,6] 6 65 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2477 : NodeCoverage113 [30,12,5] 5 66 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2478 : NodeCoverage113 [30,12,3] 3 68 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2479 : NodeCoverage113 [30,12] 12 71 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2470
    (ChildrenCoverage113.cons _ _ compact113_node_2471
    (ChildrenCoverage113.cons _ _ compact113_node_2472
    (ChildrenCoverage113.cons _ _ compact113_node_2473
    (ChildrenCoverage113.cons _ _ compact113_node_2474
    (ChildrenCoverage113.cons _ _ compact113_node_2475
    (ChildrenCoverage113.cons _ _ compact113_node_2476
    (ChildrenCoverage113.cons _ _ compact113_node_2477
    (ChildrenCoverage113.cons _ _ compact113_node_2478
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_2480 : NodeCoverage113 [30,11,11] 11 61 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2481 : NodeCoverage113 [30,11,10] 10 62 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2482 : NodeCoverage113 [30,11,9] 9 63 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2483 : NodeCoverage113 [30,11,8] 8 64 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2484 : NodeCoverage113 [30,11,7] 7 65 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2485 : NodeCoverage113 [30,11,6] 6 66 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2486 : NodeCoverage113 [30,11,5] 5 67 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2487 : NodeCoverage113 [30,11,3] 3 69 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2488 : NodeCoverage113 [30,11] 11 72 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2480
    (ChildrenCoverage113.cons _ _ compact113_node_2481
    (ChildrenCoverage113.cons _ _ compact113_node_2482
    (ChildrenCoverage113.cons _ _ compact113_node_2483
    (ChildrenCoverage113.cons _ _ compact113_node_2484
    (ChildrenCoverage113.cons _ _ compact113_node_2485
    (ChildrenCoverage113.cons _ _ compact113_node_2486
    (ChildrenCoverage113.cons _ _ compact113_node_2487
    ChildrenCoverage113.nil))))))))

theorem compact113_node_2489 : NodeCoverage113 [30,10,10,10,10,10,10,10,10] 10 3 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2490 : NodeCoverage113 [30,10,10,10,10,10,10,10,9] 9 4 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2491 : NodeCoverage113 [30,10,10,10,10,10,10,10,8] 8 5 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2492 : NodeCoverage113 [30,10,10,10,10,10,10,10,7] 7 6 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2493 : NodeCoverage113 [30,10,10,10,10,10,10,10,6] 6 7 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2494 : NodeCoverage113 [30,10,10,10,10,10,10,10,5] 5 8 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2495 : NodeCoverage113 [30,10,10,10,10,10,10,10,3] 3 10 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2496 : NodeCoverage113 [30,10,10,10,10,10,10,10] 10 13 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2489
    (ChildrenCoverage113.cons _ _ compact113_node_2490
    (ChildrenCoverage113.cons _ _ compact113_node_2491
    (ChildrenCoverage113.cons _ _ compact113_node_2492
    (ChildrenCoverage113.cons _ _ compact113_node_2493
    (ChildrenCoverage113.cons _ _ compact113_node_2494
    (ChildrenCoverage113.cons _ _ compact113_node_2495
    ChildrenCoverage113.nil)))))))

theorem compact113_node_2497 : NodeCoverage113 [30,10,10,10,10,10,10,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2498 : NodeCoverage113 [30,10,10,10,10,10,10,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2499 : NodeCoverage113 [30,10,10,10,10,10,10,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2500 : NodeCoverage113 [30,10,10,10,10,10,10,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

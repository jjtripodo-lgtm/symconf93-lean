import Symconf113.CoverageShard113_085

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3103 : NodeCoverage113 [24,24,12,12,12,12,3] 3 14 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3104 : NodeCoverage113 [24,24,12,12,12,12] 12 17 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3090
    (ChildrenCoverage113.cons _ _ compact113_node_3091
    (ChildrenCoverage113.cons _ _ compact113_node_3092
    (ChildrenCoverage113.cons _ _ compact113_node_3093
    (ChildrenCoverage113.cons _ _ compact113_node_3094
    (ChildrenCoverage113.cons _ _ compact113_node_3095
    (ChildrenCoverage113.cons _ _ compact113_node_3101
    (ChildrenCoverage113.cons _ _ compact113_node_3102
    (ChildrenCoverage113.cons _ _ compact113_node_3103
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_3105 : NodeCoverage113 [24,24,12,12,12,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3106 : NodeCoverage113 [24,24,12,12,12,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3107 : NodeCoverage113 [24,24,12,12,12,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3108 : NodeCoverage113 [24,24,12,12,12,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3109 : NodeCoverage113 [24,24,12,12,12,7] 7 22 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3110 : NodeCoverage113 [24,24,12,12,12,6,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3111 : NodeCoverage113 [24,24,12,12,12,6,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3110
    ChildrenCoverage113.nil)

theorem compact113_node_3112 : NodeCoverage113 [24,24,12,12,12,6,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3113 : NodeCoverage113 [24,24,12,12,12,6,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_3114 : NodeCoverage113 [24,24,12,12,12,6,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3113
    ChildrenCoverage113.nil)

theorem compact113_node_3115 : NodeCoverage113 [24,24,12,12,12,6,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3111
    (ChildrenCoverage113.cons _ _ compact113_node_3112
    (ChildrenCoverage113.cons _ _ compact113_node_3114
    ChildrenCoverage113.nil)))

theorem compact113_node_3116 : NodeCoverage113 [24,24,12,12,12,6,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3117 : NodeCoverage113 [24,24,12,12,12,6,6,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_3118 : NodeCoverage113 [24,24,12,12,12,6,6,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3117
    ChildrenCoverage113.nil)

theorem compact113_node_3119 : NodeCoverage113 [24,24,12,12,12,6,6,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3118
    ChildrenCoverage113.nil)

theorem compact113_node_3120 : NodeCoverage113 [24,24,12,12,12,6,6,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3119
    ChildrenCoverage113.nil)

theorem compact113_node_3121 : NodeCoverage113 [24,24,12,12,12,6,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3115
    (ChildrenCoverage113.cons _ _ compact113_node_3116
    (ChildrenCoverage113.cons _ _ compact113_node_3120
    ChildrenCoverage113.nil)))

theorem compact113_node_3122 : NodeCoverage113 [24,24,12,12,12,6,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3123 : NodeCoverage113 [24,24,12,12,12,6,3] 3 20 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3124 : NodeCoverage113 [24,24,12,12,12,6] 6 23 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3121
    (ChildrenCoverage113.cons _ _ compact113_node_3122
    (ChildrenCoverage113.cons _ _ compact113_node_3123
    ChildrenCoverage113.nil)))

theorem compact113_node_3125 : NodeCoverage113 [24,24,12,12,12,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3126 : NodeCoverage113 [24,24,12,12,12,3] 3 26 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3127 : NodeCoverage113 [24,24,12,12,12] 12 29 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3104
    (ChildrenCoverage113.cons _ _ compact113_node_3105
    (ChildrenCoverage113.cons _ _ compact113_node_3106
    (ChildrenCoverage113.cons _ _ compact113_node_3107
    (ChildrenCoverage113.cons _ _ compact113_node_3108
    (ChildrenCoverage113.cons _ _ compact113_node_3109
    (ChildrenCoverage113.cons _ _ compact113_node_3124
    (ChildrenCoverage113.cons _ _ compact113_node_3125
    (ChildrenCoverage113.cons _ _ compact113_node_3126
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_3128 : NodeCoverage113 [24,24,12,12,11] 11 30 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3129 : NodeCoverage113 [24,24,12,12,10] 10 31 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3130 : NodeCoverage113 [24,24,12,12,9] 9 32 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3131 : NodeCoverage113 [24,24,12,12,8] 8 33 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3132 : NodeCoverage113 [24,24,12,12,7] 7 34 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3133 : NodeCoverage113 [24,24,12,12,6,6,6,6,6,6,5] 5 0 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3134 : NodeCoverage113 [24,24,12,12,6,6,6,6,6,6] 6 5 :=
  node_fork113 (B := [5]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3133
    ChildrenCoverage113.nil)

theorem compact113_node_3135 : NodeCoverage113 [24,24,12,12,6,6,6,6,6,5] 5 6 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3136 : NodeCoverage113 [24,24,12,12,6,6,6,6,6,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_3137 : NodeCoverage113 [24,24,12,12,6,6,6,6,6,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3136
    ChildrenCoverage113.nil)

theorem compact113_node_3138 : NodeCoverage113 [24,24,12,12,6,6,6,6,6] 6 11 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3134
    (ChildrenCoverage113.cons _ _ compact113_node_3135
    (ChildrenCoverage113.cons _ _ compact113_node_3137
    ChildrenCoverage113.nil)))

theorem compact113_node_3139 : NodeCoverage113 [24,24,12,12,6,6,6,6,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3140 : NodeCoverage113 [24,24,12,12,6,6,6,6,3] 3 14 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3141 : NodeCoverage113 [24,24,12,12,6,6,6,6] 6 17 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3138
    (ChildrenCoverage113.cons _ _ compact113_node_3139
    (ChildrenCoverage113.cons _ _ compact113_node_3140
    ChildrenCoverage113.nil)))

theorem compact113_node_3142 : NodeCoverage113 [24,24,12,12,6,6,6,5] 5 18 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

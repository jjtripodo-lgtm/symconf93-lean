import Symconf113.ResidualLeaves113

/-! Kernel check: the signature stage refutes leaves 112 to 127. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem sigShard_112 : ((leaves.drop 112).take 16).all sigStage=true := by decide +kernel
end Symconf113

import Symconf113.CoverageShard113_163

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_7341 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6,3] 3 50 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7340
    ChildrenCoverage113.nil)

theorem compact113_node_7342 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,6] 6 53 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7305
    (ChildrenCoverage113.cons _ _ compact113_node_7325
    (ChildrenCoverage113.cons _ _ compact113_node_7341
    ChildrenCoverage113.nil)))

theorem compact113_node_7343 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5,5] 5 4 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7344 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5,3,3,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_7345 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7344
    ChildrenCoverage113.nil)

theorem compact113_node_7346 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7345
    ChildrenCoverage113.nil)

theorem compact113_node_7347 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5] 5 9 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7343
    (ChildrenCoverage113.cons _ _ compact113_node_7346
    ChildrenCoverage113.nil))

theorem compact113_node_7348 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,3] 3 11 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7349 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5] 5 14 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7347
    (ChildrenCoverage113.cons _ _ compact113_node_7348
    ChildrenCoverage113.nil))

theorem compact113_node_7350 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,3] 3 16 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7351 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5] 5 19 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7349
    (ChildrenCoverage113.cons _ _ compact113_node_7350
    ChildrenCoverage113.nil))

theorem compact113_node_7352 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,3] 3 21 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7353 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,5] 5 24 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7351
    (ChildrenCoverage113.cons _ _ compact113_node_7352
    ChildrenCoverage113.nil))

theorem compact113_node_7354 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,5,5,3] 3 26 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7355 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,5,5] 5 29 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7353
    (ChildrenCoverage113.cons _ _ compact113_node_7354
    ChildrenCoverage113.nil))

theorem compact113_node_7356 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,5,3] 3 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7357 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,5] 5 34 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7355
    (ChildrenCoverage113.cons _ _ compact113_node_7356
    ChildrenCoverage113.nil))

theorem compact113_node_7358 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5,3] 3 36 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7359 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,5] 5 39 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7357
    (ChildrenCoverage113.cons _ _ compact113_node_7358
    ChildrenCoverage113.nil))

theorem compact113_node_7360 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5,3] 3 41 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7361 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,5] 5 44 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7359
    (ChildrenCoverage113.cons _ _ compact113_node_7360
    ChildrenCoverage113.nil))

theorem compact113_node_7362 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5,3] 3 46 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7363 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,5] 5 49 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7361
    (ChildrenCoverage113.cons _ _ compact113_node_7362
    ChildrenCoverage113.nil))

theorem compact113_node_7364 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5,3] 3 51 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7365 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,5] 5 54 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7363
    (ChildrenCoverage113.cons _ _ compact113_node_7364
    ChildrenCoverage113.nil))

theorem compact113_node_7366 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7367 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7366
    ChildrenCoverage113.nil)

theorem compact113_node_7368 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7367
    ChildrenCoverage113.nil)

theorem compact113_node_7369 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 14 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7368
    ChildrenCoverage113.nil)

theorem compact113_node_7370 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 17 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7369
    ChildrenCoverage113.nil)

theorem compact113_node_7371 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 20 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7370
    ChildrenCoverage113.nil)

theorem compact113_node_7372 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3] 3 23 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7371
    ChildrenCoverage113.nil)

theorem compact113_node_7373 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3] 3 26 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7372
    ChildrenCoverage113.nil)

theorem compact113_node_7374 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3] 3 29 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7373
    ChildrenCoverage113.nil)

theorem compact113_node_7375 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3] 3 32 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7374
    ChildrenCoverage113.nil)

theorem compact113_node_7376 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3] 3 35 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7375
    ChildrenCoverage113.nil)

theorem compact113_node_7377 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3,3,3,3,3] 3 38 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7376
    ChildrenCoverage113.nil)

theorem compact113_node_7378 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3,3,3,3] 3 41 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7377
    ChildrenCoverage113.nil)

theorem compact113_node_7379 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3,3,3] 3 44 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7378
    ChildrenCoverage113.nil)

theorem compact113_node_7380 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3,3] 3 47 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7379
    ChildrenCoverage113.nil)

theorem compact113_node_7381 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3,3] 3 50 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7380
    ChildrenCoverage113.nil)

theorem compact113_node_7382 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3,3] 3 53 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7381
    ChildrenCoverage113.nil)

theorem compact113_node_7383 : NodeCoverage113 [6,6,6,6,6,6,6,6,6,3] 3 56 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7382
    ChildrenCoverage113.nil)

theorem compact113_node_7384 : NodeCoverage113 [6,6,6,6,6,6,6,6,6] 6 59 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7342
    (ChildrenCoverage113.cons _ _ compact113_node_7365
    (ChildrenCoverage113.cons _ _ compact113_node_7383
    ChildrenCoverage113.nil)))

theorem compact113_node_7385 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5,5,5] 5 5 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7386 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5,5,3,3] 3 4 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7387 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5,5,3] 3 7 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7386
    ChildrenCoverage113.nil)

theorem compact113_node_7388 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5,5] 5 10 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7385
    (ChildrenCoverage113.cons _ _ compact113_node_7387
    ChildrenCoverage113.nil))

theorem compact113_node_7389 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5,3,3,3,3,3] 3 0 :=
  node_no_weak_demand113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7390 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7389
    ChildrenCoverage113.nil)

theorem compact113_node_7391 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7390
    ChildrenCoverage113.nil)

theorem compact113_node_7392 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7391
    ChildrenCoverage113.nil)

theorem compact113_node_7393 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7392
    ChildrenCoverage113.nil)

theorem compact113_node_7394 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,5] 5 15 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7388
    (ChildrenCoverage113.cons _ _ compact113_node_7393
    ChildrenCoverage113.nil))

theorem compact113_node_7395 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5,3] 3 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7396 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,5] 5 20 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7394
    (ChildrenCoverage113.cons _ _ compact113_node_7395
    ChildrenCoverage113.nil))

theorem compact113_node_7397 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5,3] 3 22 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7398 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,5] 5 25 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7396
    (ChildrenCoverage113.cons _ _ compact113_node_7397
    ChildrenCoverage113.nil))

theorem compact113_node_7399 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5,3] 3 27 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7400 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,5] 5 30 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7398
    (ChildrenCoverage113.cons _ _ compact113_node_7399
    ChildrenCoverage113.nil))

theorem compact113_node_7401 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5,3] 3 32 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7402 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,5] 5 35 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7400
    (ChildrenCoverage113.cons _ _ compact113_node_7401
    ChildrenCoverage113.nil))

theorem compact113_node_7403 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5,3] 3 37 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7404 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,5] 5 40 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7402
    (ChildrenCoverage113.cons _ _ compact113_node_7403
    ChildrenCoverage113.nil))

theorem compact113_node_7405 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5,3] 3 42 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7406 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,5] 5 45 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7404
    (ChildrenCoverage113.cons _ _ compact113_node_7405
    ChildrenCoverage113.nil))

theorem compact113_node_7407 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5,3] 3 47 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7408 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,5] 5 50 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7406
    (ChildrenCoverage113.cons _ _ compact113_node_7407
    ChildrenCoverage113.nil))

theorem compact113_node_7409 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5,3] 3 52 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7410 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,5] 5 55 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7408
    (ChildrenCoverage113.cons _ _ compact113_node_7409
    ChildrenCoverage113.nil))

theorem compact113_node_7411 : NodeCoverage113 [6,6,6,6,6,6,6,6,5,3] 3 57 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_7412 : NodeCoverage113 [6,6,6,6,6,6,6,6,5] 5 60 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7410
    (ChildrenCoverage113.cons _ _ compact113_node_7411
    ChildrenCoverage113.nil))

theorem compact113_node_7413 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_7414 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7413
    ChildrenCoverage113.nil)

theorem compact113_node_7415 : NodeCoverage113 [6,6,6,6,6,6,6,6,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_7414
    ChildrenCoverage113.nil)

end Symconf113

import Symconf113.CoverageShard113_153

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_6606 : NodeCoverage113 [11,11,11,11,11,11,11,11,9] 9 16 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6607 : NodeCoverage113 [11,11,11,11,11,11,11,11,8] 8 17 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6608 : NodeCoverage113 [11,11,11,11,11,11,11,11,7] 7 18 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6609 : NodeCoverage113 [11,11,11,11,11,11,11,11,6] 6 19 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6610 : NodeCoverage113 [11,11,11,11,11,11,11,11,5] 5 20 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6611 : NodeCoverage113 [11,11,11,11,11,11,11,11,3] 3 22 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6612 : NodeCoverage113 [11,11,11,11,11,11,11,11] 11 25 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6604
    (ChildrenCoverage113.cons _ _ compact113_node_6605
    (ChildrenCoverage113.cons _ _ compact113_node_6606
    (ChildrenCoverage113.cons _ _ compact113_node_6607
    (ChildrenCoverage113.cons _ _ compact113_node_6608
    (ChildrenCoverage113.cons _ _ compact113_node_6609
    (ChildrenCoverage113.cons _ _ compact113_node_6610
    (ChildrenCoverage113.cons _ _ compact113_node_6611
    ChildrenCoverage113.nil))))))))

theorem compact113_node_6613 : NodeCoverage113 [11,11,11,11,11,11,11,10] 10 26 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6614 : NodeCoverage113 [11,11,11,11,11,11,11,9] 9 27 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6615 : NodeCoverage113 [11,11,11,11,11,11,11,8] 8 28 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6616 : NodeCoverage113 [11,11,11,11,11,11,11,7] 7 29 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6617 : NodeCoverage113 [11,11,11,11,11,11,11,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6618 : NodeCoverage113 [11,11,11,11,11,11,11,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6619 : NodeCoverage113 [11,11,11,11,11,11,11,3,3,3,3,3,3,3,3,3,3,3,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_6620 : NodeCoverage113 [11,11,11,11,11,11,11,3,3,3,3,3,3,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6619
    ChildrenCoverage113.nil)

theorem compact113_node_6621 : NodeCoverage113 [11,11,11,11,11,11,11,3,3,3,3,3,3,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6620
    ChildrenCoverage113.nil)

theorem compact113_node_6622 : NodeCoverage113 [11,11,11,11,11,11,11,3,3,3,3,3,3,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6621
    ChildrenCoverage113.nil)

theorem compact113_node_6623 : NodeCoverage113 [11,11,11,11,11,11,11,3,3,3,3,3,3,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6622
    ChildrenCoverage113.nil)

theorem compact113_node_6624 : NodeCoverage113 [11,11,11,11,11,11,11,3,3,3,3,3,3,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6623
    ChildrenCoverage113.nil)

theorem compact113_node_6625 : NodeCoverage113 [11,11,11,11,11,11,11,3,3,3,3,3,3] 3 18 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6624
    ChildrenCoverage113.nil)

theorem compact113_node_6626 : NodeCoverage113 [11,11,11,11,11,11,11,3,3,3,3,3] 3 21 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6625
    ChildrenCoverage113.nil)

theorem compact113_node_6627 : NodeCoverage113 [11,11,11,11,11,11,11,3,3,3,3] 3 24 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6626
    ChildrenCoverage113.nil)

theorem compact113_node_6628 : NodeCoverage113 [11,11,11,11,11,11,11,3,3,3] 3 27 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6627
    ChildrenCoverage113.nil)

theorem compact113_node_6629 : NodeCoverage113 [11,11,11,11,11,11,11,3,3] 3 30 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6628
    ChildrenCoverage113.nil)

theorem compact113_node_6630 : NodeCoverage113 [11,11,11,11,11,11,11,3] 3 33 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6629
    ChildrenCoverage113.nil)

theorem compact113_node_6631 : NodeCoverage113 [11,11,11,11,11,11,11] 11 36 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6612
    (ChildrenCoverage113.cons _ _ compact113_node_6613
    (ChildrenCoverage113.cons _ _ compact113_node_6614
    (ChildrenCoverage113.cons _ _ compact113_node_6615
    (ChildrenCoverage113.cons _ _ compact113_node_6616
    (ChildrenCoverage113.cons _ _ compact113_node_6617
    (ChildrenCoverage113.cons _ _ compact113_node_6618
    (ChildrenCoverage113.cons _ _ compact113_node_6630
    ChildrenCoverage113.nil))))))))

theorem compact113_node_6632 : NodeCoverage113 [11,11,11,11,11,11,10] 10 37 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6633 : NodeCoverage113 [11,11,11,11,11,11,9] 9 38 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6634 : NodeCoverage113 [11,11,11,11,11,11,8] 8 39 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6635 : NodeCoverage113 [11,11,11,11,11,11,7] 7 40 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6636 : NodeCoverage113 [11,11,11,11,11,11,6] 6 41 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6637 : NodeCoverage113 [11,11,11,11,11,11,5] 5 42 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6638 : NodeCoverage113 [11,11,11,11,11,11,3] 3 44 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6639 : NodeCoverage113 [11,11,11,11,11,11] 11 47 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6631
    (ChildrenCoverage113.cons _ _ compact113_node_6632
    (ChildrenCoverage113.cons _ _ compact113_node_6633
    (ChildrenCoverage113.cons _ _ compact113_node_6634
    (ChildrenCoverage113.cons _ _ compact113_node_6635
    (ChildrenCoverage113.cons _ _ compact113_node_6636
    (ChildrenCoverage113.cons _ _ compact113_node_6637
    (ChildrenCoverage113.cons _ _ compact113_node_6638
    ChildrenCoverage113.nil))))))))

theorem compact113_node_6640 : NodeCoverage113 [11,11,11,11,11,10] 10 48 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6641 : NodeCoverage113 [11,11,11,11,11,9] 9 49 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6642 : NodeCoverage113 [11,11,11,11,11,8] 8 50 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6643 : NodeCoverage113 [11,11,11,11,11,7] 7 51 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6644 : NodeCoverage113 [11,11,11,11,11,6] 6 52 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6645 : NodeCoverage113 [11,11,11,11,11,5] 5 53 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6646 : NodeCoverage113 [11,11,11,11,11,3] 3 55 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6647 : NodeCoverage113 [11,11,11,11,11] 11 58 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6639
    (ChildrenCoverage113.cons _ _ compact113_node_6640
    (ChildrenCoverage113.cons _ _ compact113_node_6641
    (ChildrenCoverage113.cons _ _ compact113_node_6642
    (ChildrenCoverage113.cons _ _ compact113_node_6643
    (ChildrenCoverage113.cons _ _ compact113_node_6644
    (ChildrenCoverage113.cons _ _ compact113_node_6645
    (ChildrenCoverage113.cons _ _ compact113_node_6646
    ChildrenCoverage113.nil))))))))

theorem compact113_node_6648 : NodeCoverage113 [11,11,11,11,10] 10 59 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6649 : NodeCoverage113 [11,11,11,11,9] 9 60 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6650 : NodeCoverage113 [11,11,11,11,8] 8 61 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6651 : NodeCoverage113 [11,11,11,11,7] 7 62 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6652 : NodeCoverage113 [11,11,11,11,6] 6 63 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6653 : NodeCoverage113 [11,11,11,11,5] 5 64 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6654 : NodeCoverage113 [11,11,11,11,3] 3 66 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6655 : NodeCoverage113 [11,11,11,11] 11 69 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6647
    (ChildrenCoverage113.cons _ _ compact113_node_6648
    (ChildrenCoverage113.cons _ _ compact113_node_6649
    (ChildrenCoverage113.cons _ _ compact113_node_6650
    (ChildrenCoverage113.cons _ _ compact113_node_6651
    (ChildrenCoverage113.cons _ _ compact113_node_6652
    (ChildrenCoverage113.cons _ _ compact113_node_6653
    (ChildrenCoverage113.cons _ _ compact113_node_6654
    ChildrenCoverage113.nil))))))))

theorem compact113_node_6656 : NodeCoverage113 [11,11,11,10] 10 70 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6657 : NodeCoverage113 [11,11,11,9] 9 71 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6658 : NodeCoverage113 [11,11,11,8] 8 72 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6659 : NodeCoverage113 [11,11,11,7] 7 73 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6660 : NodeCoverage113 [11,11,11,6] 6 74 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6661 : NodeCoverage113 [11,11,11,5] 5 75 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6662 : NodeCoverage113 [11,11,11,3] 3 77 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6663 : NodeCoverage113 [11,11,11] 11 80 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6655
    (ChildrenCoverage113.cons _ _ compact113_node_6656
    (ChildrenCoverage113.cons _ _ compact113_node_6657
    (ChildrenCoverage113.cons _ _ compact113_node_6658
    (ChildrenCoverage113.cons _ _ compact113_node_6659
    (ChildrenCoverage113.cons _ _ compact113_node_6660
    (ChildrenCoverage113.cons _ _ compact113_node_6661
    (ChildrenCoverage113.cons _ _ compact113_node_6662
    ChildrenCoverage113.nil))))))))

theorem compact113_node_6664 : NodeCoverage113 [11,11,10] 10 81 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6665 : NodeCoverage113 [11,11,9] 9 82 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6666 : NodeCoverage113 [11,11,8] 8 83 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6667 : NodeCoverage113 [11,11,7] 7 84 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6668 : NodeCoverage113 [11,11,6] 6 85 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6669 : NodeCoverage113 [11,11,5] 5 86 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6670 : NodeCoverage113 [11,11,3] 3 88 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6671 : NodeCoverage113 [11,11] 11 91 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6663
    (ChildrenCoverage113.cons _ _ compact113_node_6664
    (ChildrenCoverage113.cons _ _ compact113_node_6665
    (ChildrenCoverage113.cons _ _ compact113_node_6666
    (ChildrenCoverage113.cons _ _ compact113_node_6667
    (ChildrenCoverage113.cons _ _ compact113_node_6668
    (ChildrenCoverage113.cons _ _ compact113_node_6669
    (ChildrenCoverage113.cons _ _ compact113_node_6670
    ChildrenCoverage113.nil))))))))

theorem compact113_node_6672 : NodeCoverage113 [11,10] 10 92 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6673 : NodeCoverage113 [11,9] 9 93 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6674 : NodeCoverage113 [11,8] 8 94 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6675 : NodeCoverage113 [11,7] 7 95 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6676 : NodeCoverage113 [11,6] 6 96 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6677 : NodeCoverage113 [11,5] 5 97 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6678 : NodeCoverage113 [11,3] 3 99 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6679 : NodeCoverage113 [11] 11 102 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6671
    (ChildrenCoverage113.cons _ _ compact113_node_6672
    (ChildrenCoverage113.cons _ _ compact113_node_6673
    (ChildrenCoverage113.cons _ _ compact113_node_6674
    (ChildrenCoverage113.cons _ _ compact113_node_6675
    (ChildrenCoverage113.cons _ _ compact113_node_6676
    (ChildrenCoverage113.cons _ _ compact113_node_6677
    (ChildrenCoverage113.cons _ _ compact113_node_6678
    ChildrenCoverage113.nil))))))))

theorem compact113_node_6680 : NodeCoverage113 [10,10,10,10,10,10,10,10,10,10,10] 10 3 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.ResidualDegDefs113

/-! Kernel check: the degree search below type-`A` rows 112 and 113. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem degShard_112 : ((degTopList.drop 112).take 2).all degTop=true := by decide +kernel
end Symconf113

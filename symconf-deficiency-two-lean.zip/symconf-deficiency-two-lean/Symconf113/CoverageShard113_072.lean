import Symconf113.CoverageShard113_071

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2536 : NodeCoverage113 [30,10,5] 5 68 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2537 : NodeCoverage113 [30,10,3] 3 70 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2538 : NodeCoverage113 [30,10] 10 73 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2531
    (ChildrenCoverage113.cons _ _ compact113_node_2532
    (ChildrenCoverage113.cons _ _ compact113_node_2533
    (ChildrenCoverage113.cons _ _ compact113_node_2534
    (ChildrenCoverage113.cons _ _ compact113_node_2535
    (ChildrenCoverage113.cons _ _ compact113_node_2536
    (ChildrenCoverage113.cons _ _ compact113_node_2537
    ChildrenCoverage113.nil)))))))

theorem compact113_node_2539 : NodeCoverage113 [30,9] 9 74 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2540 : NodeCoverage113 [30,8] 8 75 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2541 : NodeCoverage113 [30,7] 7 76 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2542 : NodeCoverage113 [30,6] 6 77 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_114

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4308 : NodeCoverage113 [19,19,19,19,15] 15 22 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4309 : NodeCoverage113 [19,19,19,19,14] 14 23 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4310 : NodeCoverage113 [19,19,19,19,13] 13 24 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4311 : NodeCoverage113 [19,19,19,19,12] 12 25 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4312 : NodeCoverage113 [19,19,19,19,11] 11 26 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4313 : NodeCoverage113 [19,19,19,19,10] 10 27 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4314 : NodeCoverage113 [19,19,19,19,9] 9 28 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4315 : NodeCoverage113 [19,19,19,19,8] 8 29 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4316 : NodeCoverage113 [19,19,19,19,7] 7 30 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4317 : NodeCoverage113 [19,19,19,19,6] 6 31 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4318 : NodeCoverage113 [19,19,19,19,5] 5 32 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4319 : NodeCoverage113 [19,19,19,19,3] 3 34 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4320 : NodeCoverage113 [19,19,19,19] 19 37 :=
  node_fork113 (B := [19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4304
    (ChildrenCoverage113.cons _ _ compact113_node_4305
    (ChildrenCoverage113.cons _ _ compact113_node_4306
    (ChildrenCoverage113.cons _ _ compact113_node_4307
    (ChildrenCoverage113.cons _ _ compact113_node_4308
    (ChildrenCoverage113.cons _ _ compact113_node_4309
    (ChildrenCoverage113.cons _ _ compact113_node_4310
    (ChildrenCoverage113.cons _ _ compact113_node_4311
    (ChildrenCoverage113.cons _ _ compact113_node_4312
    (ChildrenCoverage113.cons _ _ compact113_node_4313
    (ChildrenCoverage113.cons _ _ compact113_node_4314
    (ChildrenCoverage113.cons _ _ compact113_node_4315
    (ChildrenCoverage113.cons _ _ compact113_node_4316
    (ChildrenCoverage113.cons _ _ compact113_node_4317
    (ChildrenCoverage113.cons _ _ compact113_node_4318
    (ChildrenCoverage113.cons _ _ compact113_node_4319
    ChildrenCoverage113.nil))))))))))))))))

theorem compact113_node_4321 : NodeCoverage113 [19,19,19,18] 18 38 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4322 : NodeCoverage113 [19,19,19,17] 17 39 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4323 : NodeCoverage113 [19,19,19,16] 16 40 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4324 : NodeCoverage113 [19,19,19,15] 15 41 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4325 : NodeCoverage113 [19,19,19,14] 14 42 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4326 : NodeCoverage113 [19,19,19,13] 13 43 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4327 : NodeCoverage113 [19,19,19,12] 12 44 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4328 : NodeCoverage113 [19,19,19,11] 11 45 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4329 : NodeCoverage113 [19,19,19,10] 10 46 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4330 : NodeCoverage113 [19,19,19,9] 9 47 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4331 : NodeCoverage113 [19,19,19,8] 8 48 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4332 : NodeCoverage113 [19,19,19,7] 7 49 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4333 : NodeCoverage113 [19,19,19,6] 6 50 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4334 : NodeCoverage113 [19,19,19,5] 5 51 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4335 : NodeCoverage113 [19,19,19,3] 3 53 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4336 : NodeCoverage113 [19,19,19] 19 56 :=
  node_fork113 (B := [19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4320
    (ChildrenCoverage113.cons _ _ compact113_node_4321
    (ChildrenCoverage113.cons _ _ compact113_node_4322
    (ChildrenCoverage113.cons _ _ compact113_node_4323
    (ChildrenCoverage113.cons _ _ compact113_node_4324
    (ChildrenCoverage113.cons _ _ compact113_node_4325
    (ChildrenCoverage113.cons _ _ compact113_node_4326
    (ChildrenCoverage113.cons _ _ compact113_node_4327
    (ChildrenCoverage113.cons _ _ compact113_node_4328
    (ChildrenCoverage113.cons _ _ compact113_node_4329
    (ChildrenCoverage113.cons _ _ compact113_node_4330
    (ChildrenCoverage113.cons _ _ compact113_node_4331
    (ChildrenCoverage113.cons _ _ compact113_node_4332
    (ChildrenCoverage113.cons _ _ compact113_node_4333
    (ChildrenCoverage113.cons _ _ compact113_node_4334
    (ChildrenCoverage113.cons _ _ compact113_node_4335
    ChildrenCoverage113.nil))))))))))))))))

theorem compact113_node_4337 : NodeCoverage113 [19,19,18] 18 57 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4338 : NodeCoverage113 [19,19,17] 17 58 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4339 : NodeCoverage113 [19,19,16] 16 59 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4340 : NodeCoverage113 [19,19,15] 15 60 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4341 : NodeCoverage113 [19,19,14] 14 61 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4342 : NodeCoverage113 [19,19,13] 13 62 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4343 : NodeCoverage113 [19,19,12] 12 63 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4344 : NodeCoverage113 [19,19,11] 11 64 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4345 : NodeCoverage113 [19,19,10] 10 65 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4346 : NodeCoverage113 [19,19,9] 9 66 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4347 : NodeCoverage113 [19,19,8] 8 67 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4348 : NodeCoverage113 [19,19,7] 7 68 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4349 : NodeCoverage113 [19,19,6] 6 69 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4350 : NodeCoverage113 [19,19,5] 5 70 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4351 : NodeCoverage113 [19,19,3] 3 72 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4352 : NodeCoverage113 [19,19] 19 75 :=
  node_fork113 (B := [19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4336
    (ChildrenCoverage113.cons _ _ compact113_node_4337
    (ChildrenCoverage113.cons _ _ compact113_node_4338
    (ChildrenCoverage113.cons _ _ compact113_node_4339
    (ChildrenCoverage113.cons _ _ compact113_node_4340
    (ChildrenCoverage113.cons _ _ compact113_node_4341
    (ChildrenCoverage113.cons _ _ compact113_node_4342
    (ChildrenCoverage113.cons _ _ compact113_node_4343
    (ChildrenCoverage113.cons _ _ compact113_node_4344
    (ChildrenCoverage113.cons _ _ compact113_node_4345
    (ChildrenCoverage113.cons _ _ compact113_node_4346
    (ChildrenCoverage113.cons _ _ compact113_node_4347
    (ChildrenCoverage113.cons _ _ compact113_node_4348
    (ChildrenCoverage113.cons _ _ compact113_node_4349
    (ChildrenCoverage113.cons _ _ compact113_node_4350
    (ChildrenCoverage113.cons _ _ compact113_node_4351
    ChildrenCoverage113.nil))))))))))))))))

theorem compact113_node_4353 : NodeCoverage113 [19,18] 18 76 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4354 : NodeCoverage113 [19,17] 17 77 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4355 : NodeCoverage113 [19,16] 16 78 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4356 : NodeCoverage113 [19,15] 15 79 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4357 : NodeCoverage113 [19,14] 14 80 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4358 : NodeCoverage113 [19,13] 13 81 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4359 : NodeCoverage113 [19,12] 12 82 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4360 : NodeCoverage113 [19,11] 11 83 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4361 : NodeCoverage113 [19,10] 10 84 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4362 : NodeCoverage113 [19,9] 9 85 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4363 : NodeCoverage113 [19,8] 8 86 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4364 : NodeCoverage113 [19,7] 7 87 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4365 : NodeCoverage113 [19,6] 6 88 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4366 : NodeCoverage113 [19,5] 5 89 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4367 : NodeCoverage113 [19,3] 3 91 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

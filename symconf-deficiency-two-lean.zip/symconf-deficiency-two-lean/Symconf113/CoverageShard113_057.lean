import Symconf113.CoverageShard113_056

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2300 : NodeCoverage113 [30,30,15,15,11] 11 12 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2301 : NodeCoverage113 [30,30,15,15,10,10] 10 3 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2302 : NodeCoverage113 [30,30,15,15,10,9] 9 4 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2303 : NodeCoverage113 [30,30,15,15,10,8] 8 5 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2304 : NodeCoverage113 [30,30,15,15,10,7] 7 6 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2305 : NodeCoverage113 [30,30,15,15,10,6] 6 7 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2306 : NodeCoverage113 [30,30,15,15,10,5,5,3] 3 0 :=
  node_no_weak_demand113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2307 : NodeCoverage113 [30,30,15,15,10,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2306
    ChildrenCoverage113.nil)

theorem compact113_node_2308 : NodeCoverage113 [30,30,15,15,10,5,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_2309 : NodeCoverage113 [30,30,15,15,10,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2307
    (ChildrenCoverage113.cons _ _ compact113_node_2308
    ChildrenCoverage113.nil))

theorem compact113_node_2310 : NodeCoverage113 [30,30,15,15,10,3] 3 10 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2311 : NodeCoverage113 [30,30,15,15,10] 10 13 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2301
    (ChildrenCoverage113.cons _ _ compact113_node_2302
    (ChildrenCoverage113.cons _ _ compact113_node_2303
    (ChildrenCoverage113.cons _ _ compact113_node_2304
    (ChildrenCoverage113.cons _ _ compact113_node_2305
    (ChildrenCoverage113.cons _ _ compact113_node_2309
    (ChildrenCoverage113.cons _ _ compact113_node_2310
    ChildrenCoverage113.nil)))))))

theorem compact113_node_2312 : NodeCoverage113 [30,30,15,15,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2313 : NodeCoverage113 [30,30,15,15,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2314 : NodeCoverage113 [30,30,15,15,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2315 : NodeCoverage113 [30,30,15,15,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2316 : NodeCoverage113 [30,30,15,15,5] 5 18 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2317 : NodeCoverage113 [30,30,15,15,3] 3 20 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2318 : NodeCoverage113 [30,30,15,15] 15 23 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2296
    (ChildrenCoverage113.cons _ _ compact113_node_2297
    (ChildrenCoverage113.cons _ _ compact113_node_2298
    (ChildrenCoverage113.cons _ _ compact113_node_2299
    (ChildrenCoverage113.cons _ _ compact113_node_2300
    (ChildrenCoverage113.cons _ _ compact113_node_2311
    (ChildrenCoverage113.cons _ _ compact113_node_2312
    (ChildrenCoverage113.cons _ _ compact113_node_2313
    (ChildrenCoverage113.cons _ _ compact113_node_2314
    (ChildrenCoverage113.cons _ _ compact113_node_2315
    (ChildrenCoverage113.cons _ _ compact113_node_2316
    (ChildrenCoverage113.cons _ _ compact113_node_2317
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_2319 : NodeCoverage113 [30,30,15,14] 14 24 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2320 : NodeCoverage113 [30,30,15,13] 13 25 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2321 : NodeCoverage113 [30,30,15,12] 12 26 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_137
import Symconf113.CoverageShard113_138
import Symconf113.CoverageShard113_139

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5666 : NodeCoverage113 [14,14,9,3] 3 73 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5667 : NodeCoverage113 [14,14,9] 9 76 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5661
    (ChildrenCoverage113.cons _ _ compact113_node_5662
    (ChildrenCoverage113.cons _ _ compact113_node_5663
    (ChildrenCoverage113.cons _ _ compact113_node_5664
    (ChildrenCoverage113.cons _ _ compact113_node_5665
    (ChildrenCoverage113.cons _ _ compact113_node_5666
    ChildrenCoverage113.nil))))))

theorem compact113_node_5668 : NodeCoverage113 [14,14,8] 8 77 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5669 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,7,7,7,7,5] 5 3 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5670 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,7,7,7,7,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5671 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,7,7,7,7] 7 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5669
    (ChildrenCoverage113.cons _ _ compact113_node_5670
    ChildrenCoverage113.nil))

theorem compact113_node_5672 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,7,7,7,6] 6 9 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5673 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,7,7,7,5] 5 10 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5674 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,7,7,7,3] 3 12 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5675 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,7,7,7] 7 15 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5671
    (ChildrenCoverage113.cons _ _ compact113_node_5672
    (ChildrenCoverage113.cons _ _ compact113_node_5673
    (ChildrenCoverage113.cons _ _ compact113_node_5674
    ChildrenCoverage113.nil))))

theorem compact113_node_5676 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,7,7,6] 6 16 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5677 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,7,7,5] 5 17 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5678 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,7,7,3] 3 19 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5679 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,7,7] 7 22 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5675
    (ChildrenCoverage113.cons _ _ compact113_node_5676
    (ChildrenCoverage113.cons _ _ compact113_node_5677
    (ChildrenCoverage113.cons _ _ compact113_node_5678
    ChildrenCoverage113.nil))))

theorem compact113_node_5680 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,7,6] 6 23 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5681 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,7,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5682 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,7,3] 3 26 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5683 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,7] 7 29 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5679
    (ChildrenCoverage113.cons _ _ compact113_node_5680
    (ChildrenCoverage113.cons _ _ compact113_node_5681
    (ChildrenCoverage113.cons _ _ compact113_node_5682
    ChildrenCoverage113.nil))))

theorem compact113_node_5684 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5685 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5686 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3,3] 3 0 :=
  node_no_weak_demand113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5687 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5686
    ChildrenCoverage113.nil)

theorem compact113_node_5688 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5687
    ChildrenCoverage113.nil)

theorem compact113_node_5689 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5688
    ChildrenCoverage113.nil)

theorem compact113_node_5690 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,3,3,3,3,3,3,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5689
    ChildrenCoverage113.nil)

theorem compact113_node_5691 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,3,3,3,3,3,3,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5690
    ChildrenCoverage113.nil)

theorem compact113_node_5692 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,3,3,3,3,3,3] 3 18 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5691
    ChildrenCoverage113.nil)

theorem compact113_node_5693 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,3,3,3,3,3] 3 21 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5692
    ChildrenCoverage113.nil)

theorem compact113_node_5694 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,3,3,3,3] 3 24 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5693
    ChildrenCoverage113.nil)

theorem compact113_node_5695 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,3,3,3] 3 27 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5694
    ChildrenCoverage113.nil)

theorem compact113_node_5696 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,3,3] 3 30 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5695
    ChildrenCoverage113.nil)

theorem compact113_node_5697 : NodeCoverage113 [14,14,7,7,7,7,7,7,7,3] 3 33 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5696
    ChildrenCoverage113.nil)

theorem compact113_node_5698 : NodeCoverage113 [14,14,7,7,7,7,7,7,7] 7 36 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5683
    (ChildrenCoverage113.cons _ _ compact113_node_5684
    (ChildrenCoverage113.cons _ _ compact113_node_5685
    (ChildrenCoverage113.cons _ _ compact113_node_5697
    ChildrenCoverage113.nil))))

theorem compact113_node_5699 : NodeCoverage113 [14,14,7,7,7,7,7,7,6] 6 37 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5700 : NodeCoverage113 [14,14,7,7,7,7,7,7,5] 5 38 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5701 : NodeCoverage113 [14,14,7,7,7,7,7,7,3] 3 40 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5702 : NodeCoverage113 [14,14,7,7,7,7,7,7] 7 43 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5698
    (ChildrenCoverage113.cons _ _ compact113_node_5699
    (ChildrenCoverage113.cons _ _ compact113_node_5700
    (ChildrenCoverage113.cons _ _ compact113_node_5701
    ChildrenCoverage113.nil))))

theorem compact113_node_5703 : NodeCoverage113 [14,14,7,7,7,7,7,6] 6 44 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5704 : NodeCoverage113 [14,14,7,7,7,7,7,5] 5 45 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5705 : NodeCoverage113 [14,14,7,7,7,7,7,3] 3 47 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5706 : NodeCoverage113 [14,14,7,7,7,7,7] 7 50 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5702
    (ChildrenCoverage113.cons _ _ compact113_node_5703
    (ChildrenCoverage113.cons _ _ compact113_node_5704
    (ChildrenCoverage113.cons _ _ compact113_node_5705
    ChildrenCoverage113.nil))))

theorem compact113_node_5707 : NodeCoverage113 [14,14,7,7,7,7,6] 6 51 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5708 : NodeCoverage113 [14,14,7,7,7,7,5] 5 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5709 : NodeCoverage113 [14,14,7,7,7,7,3] 3 54 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5710 : NodeCoverage113 [14,14,7,7,7,7] 7 57 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5706
    (ChildrenCoverage113.cons _ _ compact113_node_5707
    (ChildrenCoverage113.cons _ _ compact113_node_5708
    (ChildrenCoverage113.cons _ _ compact113_node_5709
    ChildrenCoverage113.nil))))

theorem compact113_node_5711 : NodeCoverage113 [14,14,7,7,7,6] 6 58 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5712 : NodeCoverage113 [14,14,7,7,7,5] 5 59 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5713 : NodeCoverage113 [14,14,7,7,7,3] 3 61 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5714 : NodeCoverage113 [14,14,7,7,7] 7 64 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5710
    (ChildrenCoverage113.cons _ _ compact113_node_5711
    (ChildrenCoverage113.cons _ _ compact113_node_5712
    (ChildrenCoverage113.cons _ _ compact113_node_5713
    ChildrenCoverage113.nil))))

theorem compact113_node_5715 : NodeCoverage113 [14,14,7,7,6] 6 65 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5716 : NodeCoverage113 [14,14,7,7,5] 5 66 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5717 : NodeCoverage113 [14,14,7,7,3] 3 68 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5718 : NodeCoverage113 [14,14,7,7] 7 71 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5714
    (ChildrenCoverage113.cons _ _ compact113_node_5715
    (ChildrenCoverage113.cons _ _ compact113_node_5716
    (ChildrenCoverage113.cons _ _ compact113_node_5717
    ChildrenCoverage113.nil))))

theorem compact113_node_5719 : NodeCoverage113 [14,14,7,6] 6 72 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5720 : NodeCoverage113 [14,14,7,5] 5 73 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5721 : NodeCoverage113 [14,14,7,3] 3 75 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5722 : NodeCoverage113 [14,14,7] 7 78 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5718
    (ChildrenCoverage113.cons _ _ compact113_node_5719
    (ChildrenCoverage113.cons _ _ compact113_node_5720
    (ChildrenCoverage113.cons _ _ compact113_node_5721
    ChildrenCoverage113.nil))))

theorem compact113_node_5723 : NodeCoverage113 [14,14,6] 6 79 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5724 : NodeCoverage113 [14,14,5] 5 80 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5725 : NodeCoverage113 [14,14,3] 3 82 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5726 : NodeCoverage113 [14,14] 14 85 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5538
    (ChildrenCoverage113.cons _ _ compact113_node_5559
    (ChildrenCoverage113.cons _ _ compact113_node_5595
    (ChildrenCoverage113.cons _ _ compact113_node_5620
    (ChildrenCoverage113.cons _ _ compact113_node_5642
    (ChildrenCoverage113.cons _ _ compact113_node_5667
    (ChildrenCoverage113.cons _ _ compact113_node_5668
    (ChildrenCoverage113.cons _ _ compact113_node_5722
    (ChildrenCoverage113.cons _ _ compact113_node_5723
    (ChildrenCoverage113.cons _ _ compact113_node_5724
    (ChildrenCoverage113.cons _ _ compact113_node_5725
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_5727 : NodeCoverage113 [14,13,13,13] 13 60 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5728 : NodeCoverage113 [14,13,13,12] 12 61 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5729 : NodeCoverage113 [14,13,13,11] 11 62 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5730 : NodeCoverage113 [14,13,13,10] 10 63 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5731 : NodeCoverage113 [14,13,13,9] 9 64 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5732 : NodeCoverage113 [14,13,13,8] 8 65 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5733 : NodeCoverage113 [14,13,13,7] 7 66 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5734 : NodeCoverage113 [14,13,13,6] 6 67 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5735 : NodeCoverage113 [14,13,13,5] 5 68 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5736 : NodeCoverage113 [14,13,13,3] 3 70 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5737 : NodeCoverage113 [14,13,13] 13 73 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5727
    (ChildrenCoverage113.cons _ _ compact113_node_5728
    (ChildrenCoverage113.cons _ _ compact113_node_5729
    (ChildrenCoverage113.cons _ _ compact113_node_5730
    (ChildrenCoverage113.cons _ _ compact113_node_5731
    (ChildrenCoverage113.cons _ _ compact113_node_5732
    (ChildrenCoverage113.cons _ _ compact113_node_5733
    (ChildrenCoverage113.cons _ _ compact113_node_5734
    (ChildrenCoverage113.cons _ _ compact113_node_5735
    (ChildrenCoverage113.cons _ _ compact113_node_5736
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_5738 : NodeCoverage113 [14,13,12] 12 74 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5739 : NodeCoverage113 [14,13,11] 11 75 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5740 : NodeCoverage113 [14,13,10] 10 76 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

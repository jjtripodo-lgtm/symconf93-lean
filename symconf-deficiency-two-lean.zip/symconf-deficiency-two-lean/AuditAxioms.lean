import SymconfDeficiencyTwo
import Symconf113
import Symconf75

#print axioms Symconf59.no_unrestricted_incidence59
#print axioms Symconf59.no_symconf_59_8
#print axioms Symconf93.no_unrestricted_incidence93
#print axioms Symconf113.original_front_half
#print axioms Symconf113.exact_original_coverage113
#print axioms Symconf113.excluded_profiles17
#print axioms Symconf113.no_hamiltonian_incidence113
#print axioms Symconf113.incidence113_two_profiles
#print axioms Symconf113.incidence113_residual_profile
#print axioms Symconf113.no_residual_incidence113
#print axioms Symconf113.no_unrestricted_incidence113
#print axioms Symconf75.original_front_half
#print axioms Symconf75.exact_original_coverage75
#print axioms Symconf75.excluded_profiles18
#print axioms Symconf75.incidence75_remaining_profiles
#print axioms Symconf75.noModularGolombRuler75
#print axioms Symconf75.no_hamiltonian_incidence75
#print axioms Symconf75.incidence75_fourteen_profiles
#print axioms Symconf75.VecClique.no_profile15
#print axioms Symconf75.VecClique.no_profile12a
#print axioms Symconf75.VecClique.no_profile12b
#print axioms Symconf75.VecClique.no_profile10
#print axioms Symconf75.no_ordered_profileSix11
#print axioms Symconf75.no_ordered_profileSix9
#print axioms Symconf75.incidence75_twelve_profiles

example : ¬ ∃ A : Matrix (Fin 59) (Fin 59) ℤ, Symconf59.Incidence59 A :=
  Symconf59.no_unrestricted_incidence59
example : ¬ ∃ A : Symconf93.Int93, Symconf93.Incidence93 A :=
  Symconf93.no_unrestricted_incidence93

/-- Proved, no hypotheses: a 113_11 incidence has leave profile [113] or 3+5+15^7. -/
example {A : Symconf113.Int113} (hA : Symconf113.Incidence113 A) :
    ∃ P : List ℕ, (P=[113] ∨ P=Symconf113.Residual113) ∧
      ∃ _R : Symconf113.OrderedCycles (Symconf113.rowLeave A) P,
        ∃ _C : Symconf113.OrderedCycles (Symconf113.colLeave A) P,
          Nonempty (Symconf113.OriginalProfileFacts P) :=
  Symconf113.incidence113_two_profiles hA

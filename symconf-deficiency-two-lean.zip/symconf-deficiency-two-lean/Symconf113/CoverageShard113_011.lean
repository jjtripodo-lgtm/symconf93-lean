import Symconf113.CoverageShard113_007
import Symconf113.CoverageShard113_008
import Symconf113.CoverageShard113_010

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0488 : NodeCoverage113 [60,3] 3 50 :=
  demand_node_prune113 60 compact113_demands_060 compact113_demands_060_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0489 : NodeCoverage113 [60] 60 53 :=
  node_fork113 (B := [53,50,49,48,47,46,45,44,43,42,41,40,39,38,37,36,35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_0354
    (ChildrenCoverage113.cons _ _ compact113_node_0355
    (ChildrenCoverage113.cons _ _ compact113_node_0356
    (ChildrenCoverage113.cons _ _ compact113_node_0357
    (ChildrenCoverage113.cons _ _ compact113_node_0358
    (ChildrenCoverage113.cons _ _ compact113_node_0359
    (ChildrenCoverage113.cons _ _ compact113_node_0360
    (ChildrenCoverage113.cons _ _ compact113_node_0361
    (ChildrenCoverage113.cons _ _ compact113_node_0362
    (ChildrenCoverage113.cons _ _ compact113_node_0363
    (ChildrenCoverage113.cons _ _ compact113_node_0364
    (ChildrenCoverage113.cons _ _ compact113_node_0365
    (ChildrenCoverage113.cons _ _ compact113_node_0366
    (ChildrenCoverage113.cons _ _ compact113_node_0367
    (ChildrenCoverage113.cons _ _ compact113_node_0368
    (ChildrenCoverage113.cons _ _ compact113_node_0369
    (ChildrenCoverage113.cons _ _ compact113_node_0370
    (ChildrenCoverage113.cons _ _ compact113_node_0371
    (ChildrenCoverage113.cons _ _ compact113_node_0372
    (ChildrenCoverage113.cons _ _ compact113_node_0373
    (ChildrenCoverage113.cons _ _ compact113_node_0374
    (ChildrenCoverage113.cons _ _ compact113_node_0375
    (ChildrenCoverage113.cons _ _ compact113_node_0376
    (ChildrenCoverage113.cons _ _ compact113_node_0377
    (ChildrenCoverage113.cons _ _ compact113_node_0378
    (ChildrenCoverage113.cons _ _ compact113_node_0379
    (ChildrenCoverage113.cons _ _ compact113_node_0380
    (ChildrenCoverage113.cons _ _ compact113_node_0381
    (ChildrenCoverage113.cons _ _ compact113_node_0382
    (ChildrenCoverage113.cons _ _ compact113_node_0383
    (ChildrenCoverage113.cons _ _ compact113_node_0384
    (ChildrenCoverage113.cons _ _ compact113_node_0385
    (ChildrenCoverage113.cons _ _ compact113_node_0386
    (ChildrenCoverage113.cons _ _ compact113_node_0387
    (ChildrenCoverage113.cons _ _ compact113_node_0388
    (ChildrenCoverage113.cons _ _ compact113_node_0389
    (ChildrenCoverage113.cons _ _ compact113_node_0448
    (ChildrenCoverage113.cons _ _ compact113_node_0449
    (ChildrenCoverage113.cons _ _ compact113_node_0450
    (ChildrenCoverage113.cons _ _ compact113_node_0480
    (ChildrenCoverage113.cons _ _ compact113_node_0481
    (ChildrenCoverage113.cons _ _ compact113_node_0482
    (ChildrenCoverage113.cons _ _ compact113_node_0483
    (ChildrenCoverage113.cons _ _ compact113_node_0484
    (ChildrenCoverage113.cons _ _ compact113_node_0485
    (ChildrenCoverage113.cons _ _ compact113_node_0486
    (ChildrenCoverage113.cons _ _ compact113_node_0487
    (ChildrenCoverage113.cons _ _ compact113_node_0488
    ChildrenCoverage113.nil))))))))))))))))))))))))))))))))))))))))))))))))

theorem compact113_node_0490 : NodeCoverage113 [59] 59 54 :=
  demand_node_prune113 59 compact113_demands_059 compact113_demands_059_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0491 : NodeCoverage113 [58] 58 55 :=
  demand_node_prune113 58 compact113_demands_058 compact113_demands_058_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0492 : NodeCoverage113 [57] 57 56 :=
  demand_node_prune113 57 compact113_demands_057 compact113_demands_057_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0493 : NodeCoverage113 [56,54] 54 3 :=
  demand_node_prune113 54 compact113_demands_054 compact113_demands_054_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0494 : NodeCoverage113 [56,53] 53 4 :=
  demand_node_prune113 53 compact113_demands_053 compact113_demands_053_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0495 : NodeCoverage113 [56,52] 52 5 :=
  demand_node_prune113 52 compact113_demands_052 compact113_demands_052_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0496 : NodeCoverage113 [56,51] 51 6 :=
  demand_node_prune113 51 compact113_demands_051 compact113_demands_051_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0497 : NodeCoverage113 [56,50] 50 7 :=
  demand_node_prune113 50 compact113_demands_050 compact113_demands_050_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0498 : NodeCoverage113 [56,49] 49 8 :=
  demand_node_prune113 49 compact113_demands_049 compact113_demands_049_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0499 : NodeCoverage113 [56,48] 48 9 :=
  demand_node_prune113 48 compact113_demands_048 compact113_demands_048_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0500 : NodeCoverage113 [56,47] 47 10 :=
  demand_node_prune113 47 compact113_demands_047 compact113_demands_047_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0501 : NodeCoverage113 [56,46] 46 11 :=
  demand_node_prune113 46 compact113_demands_046 compact113_demands_046_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0502 : NodeCoverage113 [56,45] 45 12 :=
  demand_node_prune113 45 compact113_demands_045 compact113_demands_045_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0503 : NodeCoverage113 [56,44] 44 13 :=
  demand_node_prune113 44 compact113_demands_044 compact113_demands_044_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0504 : NodeCoverage113 [56,43] 43 14 :=
  demand_node_prune113 43 compact113_demands_043 compact113_demands_043_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0505 : NodeCoverage113 [56,42] 42 15 :=
  demand_node_prune113 42 compact113_demands_042 compact113_demands_042_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0506 : NodeCoverage113 [56,41] 41 16 :=
  demand_node_prune113 41 compact113_demands_041 compact113_demands_041_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0507 : NodeCoverage113 [56,40] 40 17 :=
  demand_node_prune113 40 compact113_demands_040 compact113_demands_040_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0508 : NodeCoverage113 [56,39] 39 18 :=
  demand_node_prune113 39 compact113_demands_039 compact113_demands_039_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0509 : NodeCoverage113 [56,38] 38 19 :=
  demand_node_prune113 38 compact113_demands_038 compact113_demands_038_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0510 : NodeCoverage113 [56,37] 37 20 :=
  demand_node_prune113 37 compact113_demands_037 compact113_demands_037_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0511 : NodeCoverage113 [56,36] 36 21 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0512 : NodeCoverage113 [56,35] 35 22 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0513 : NodeCoverage113 [56,34] 34 23 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0514 : NodeCoverage113 [56,33] 33 24 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0515 : NodeCoverage113 [56,32] 32 25 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0516 : NodeCoverage113 [56,31] 31 26 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0517 : NodeCoverage113 [56,30] 30 27 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0518 : NodeCoverage113 [56,29] 29 28 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0519 : NodeCoverage113 [56,28] 28 29 :=
  demand_node_prune113 56 compact113_demands_056 compact113_demands_056_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0520 : NodeCoverage113 [56,27] 27 30 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0521 : NodeCoverage113 [56,26] 26 31 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0522 : NodeCoverage113 [56,25] 25 32 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0523 : NodeCoverage113 [56,24] 24 33 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0524 : NodeCoverage113 [56,23] 23 34 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0525 : NodeCoverage113 [56,22] 22 35 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

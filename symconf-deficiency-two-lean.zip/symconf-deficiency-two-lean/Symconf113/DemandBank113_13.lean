import Symconf113.LeafDemand113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

def compact113_demands_108 : List (List Nat) := [

]
theorem compact113_demands_108_exact : rowDemand113 108=compact113_demands_108 := by decide +kernel

def compact113_demands_109 : List (List Nat) := [

]
theorem compact113_demands_109_exact : rowDemand113 109=compact113_demands_109 := by decide +kernel

def compact113_demands_110 : List (List Nat) := [
  [10,10,10,10,10,10,10,10,11,11,11]
]
theorem compact113_demands_110_exact : rowDemand113 110=compact113_demands_110 := by decide +kernel

end Symconf113

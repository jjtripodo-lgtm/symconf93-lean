import Symconf113.ResidualDegDefs113

/-! Kernel check: the degree search below type-`A` rows 124 and 125. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem degShard_124 : ((degTopList.drop 124).take 2).all degTop=true := by decide +kernel
end Symconf113

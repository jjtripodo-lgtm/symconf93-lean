import Symconf113.CoverageShard113_093

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3319 : NodeCoverage113 [24,12,12,12,9] 9 44 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3320 : NodeCoverage113 [24,12,12,12,8] 8 45 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3321 : NodeCoverage113 [24,12,12,12,7] 7 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3322 : NodeCoverage113 [24,12,12,12,6] 6 47 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3323 : NodeCoverage113 [24,12,12,12,5] 5 48 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3324 : NodeCoverage113 [24,12,12,12,3] 3 50 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3325 : NodeCoverage113 [24,12,12,12] 12 53 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3316
    (ChildrenCoverage113.cons _ _ compact113_node_3317
    (ChildrenCoverage113.cons _ _ compact113_node_3318
    (ChildrenCoverage113.cons _ _ compact113_node_3319
    (ChildrenCoverage113.cons _ _ compact113_node_3320
    (ChildrenCoverage113.cons _ _ compact113_node_3321
    (ChildrenCoverage113.cons _ _ compact113_node_3322
    (ChildrenCoverage113.cons _ _ compact113_node_3323
    (ChildrenCoverage113.cons _ _ compact113_node_3324
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_3326 : NodeCoverage113 [24,12,12,11] 11 54 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3327 : NodeCoverage113 [24,12,12,10] 10 55 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3328 : NodeCoverage113 [24,12,12,9] 9 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3329 : NodeCoverage113 [24,12,12,8] 8 57 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3330 : NodeCoverage113 [24,12,12,7] 7 58 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3331 : NodeCoverage113 [24,12,12,6] 6 59 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3332 : NodeCoverage113 [24,12,12,5] 5 60 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3333 : NodeCoverage113 [24,12,12,3] 3 62 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3334 : NodeCoverage113 [24,12,12] 12 65 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3325
    (ChildrenCoverage113.cons _ _ compact113_node_3326
    (ChildrenCoverage113.cons _ _ compact113_node_3327
    (ChildrenCoverage113.cons _ _ compact113_node_3328
    (ChildrenCoverage113.cons _ _ compact113_node_3329
    (ChildrenCoverage113.cons _ _ compact113_node_3330
    (ChildrenCoverage113.cons _ _ compact113_node_3331
    (ChildrenCoverage113.cons _ _ compact113_node_3332
    (ChildrenCoverage113.cons _ _ compact113_node_3333
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_3335 : NodeCoverage113 [24,12,11,11] 11 55 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3336 : NodeCoverage113 [24,12,11,10] 10 56 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3337 : NodeCoverage113 [24,12,11,9] 9 57 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3338 : NodeCoverage113 [24,12,11,8] 8 58 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3339 : NodeCoverage113 [24,12,11,7] 7 59 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3340 : NodeCoverage113 [24,12,11,6] 6 60 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3341 : NodeCoverage113 [24,12,11,5] 5 61 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3342 : NodeCoverage113 [24,12,11,3] 3 63 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3343 : NodeCoverage113 [24,12,11] 11 66 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3335
    (ChildrenCoverage113.cons _ _ compact113_node_3336
    (ChildrenCoverage113.cons _ _ compact113_node_3337
    (ChildrenCoverage113.cons _ _ compact113_node_3338
    (ChildrenCoverage113.cons _ _ compact113_node_3339
    (ChildrenCoverage113.cons _ _ compact113_node_3340
    (ChildrenCoverage113.cons _ _ compact113_node_3341
    (ChildrenCoverage113.cons _ _ compact113_node_3342
    ChildrenCoverage113.nil))))))))

end Symconf113

import Symconf113.CoverageShard113_101

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3643 : NodeCoverage113 [22,14,10] 10 67 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3644 : NodeCoverage113 [22,14,9] 9 68 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3645 : NodeCoverage113 [22,14,8] 8 69 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3646 : NodeCoverage113 [22,14,7] 7 70 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3647 : NodeCoverage113 [22,14,6] 6 71 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3648 : NodeCoverage113 [22,14,5] 5 72 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3649 : NodeCoverage113 [22,14,3] 3 74 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3650 : NodeCoverage113 [22,14] 14 77 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3631
    (ChildrenCoverage113.cons _ _ compact113_node_3632
    (ChildrenCoverage113.cons _ _ compact113_node_3633
    (ChildrenCoverage113.cons _ _ compact113_node_3642
    (ChildrenCoverage113.cons _ _ compact113_node_3643
    (ChildrenCoverage113.cons _ _ compact113_node_3644
    (ChildrenCoverage113.cons _ _ compact113_node_3645
    (ChildrenCoverage113.cons _ _ compact113_node_3646
    (ChildrenCoverage113.cons _ _ compact113_node_3647
    (ChildrenCoverage113.cons _ _ compact113_node_3648
    (ChildrenCoverage113.cons _ _ compact113_node_3649
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_3651 : NodeCoverage113 [22,13,13] 13 65 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3652 : NodeCoverage113 [22,13,12] 12 66 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3653 : NodeCoverage113 [22,13,11] 11 67 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3654 : NodeCoverage113 [22,13,10] 10 68 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3655 : NodeCoverage113 [22,13,9] 9 69 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3656 : NodeCoverage113 [22,13,8] 8 70 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3657 : NodeCoverage113 [22,13,7] 7 71 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3658 : NodeCoverage113 [22,13,6] 6 72 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3659 : NodeCoverage113 [22,13,5] 5 73 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3660 : NodeCoverage113 [22,13,3] 3 75 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3661 : NodeCoverage113 [22,13] 13 78 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3651
    (ChildrenCoverage113.cons _ _ compact113_node_3652
    (ChildrenCoverage113.cons _ _ compact113_node_3653
    (ChildrenCoverage113.cons _ _ compact113_node_3654
    (ChildrenCoverage113.cons _ _ compact113_node_3655
    (ChildrenCoverage113.cons _ _ compact113_node_3656
    (ChildrenCoverage113.cons _ _ compact113_node_3657
    (ChildrenCoverage113.cons _ _ compact113_node_3658
    (ChildrenCoverage113.cons _ _ compact113_node_3659
    (ChildrenCoverage113.cons _ _ compact113_node_3660
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_3662 : NodeCoverage113 [22,12,12] 12 67 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3663 : NodeCoverage113 [22,12,11] 11 68 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3664 : NodeCoverage113 [22,12,10] 10 69 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3665 : NodeCoverage113 [22,12,9] 9 70 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3666 : NodeCoverage113 [22,12,8] 8 71 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3667 : NodeCoverage113 [22,12,7] 7 72 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3668 : NodeCoverage113 [22,12,6] 6 73 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3669 : NodeCoverage113 [22,12,5] 5 74 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3670 : NodeCoverage113 [22,12,3] 3 76 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3671 : NodeCoverage113 [22,12] 12 79 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3662
    (ChildrenCoverage113.cons _ _ compact113_node_3663
    (ChildrenCoverage113.cons _ _ compact113_node_3664
    (ChildrenCoverage113.cons _ _ compact113_node_3665
    (ChildrenCoverage113.cons _ _ compact113_node_3666
    (ChildrenCoverage113.cons _ _ compact113_node_3667
    (ChildrenCoverage113.cons _ _ compact113_node_3668
    (ChildrenCoverage113.cons _ _ compact113_node_3669
    (ChildrenCoverage113.cons _ _ compact113_node_3670
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_3672 : NodeCoverage113 [22,11,11,11,11,11,11,11,11,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3673 : NodeCoverage113 [22,11,11,11,11,11,11,11,11] 11 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3672
    ChildrenCoverage113.nil)

theorem compact113_node_3674 : NodeCoverage113 [22,11,11,11,11,11,11,11,10] 10 4 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3675 : NodeCoverage113 [22,11,11,11,11,11,11,11,9] 9 5 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3676 : NodeCoverage113 [22,11,11,11,11,11,11,11,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3677 : NodeCoverage113 [22,11,11,11,11,11,11,11,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3678 : NodeCoverage113 [22,11,11,11,11,11,11,11,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3679 : NodeCoverage113 [22,11,11,11,11,11,11,11,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3680 : NodeCoverage113 [22,11,11,11,11,11,11,11,3] 3 11 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3681 : NodeCoverage113 [22,11,11,11,11,11,11,11] 11 14 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3673
    (ChildrenCoverage113.cons _ _ compact113_node_3674
    (ChildrenCoverage113.cons _ _ compact113_node_3675
    (ChildrenCoverage113.cons _ _ compact113_node_3676
    (ChildrenCoverage113.cons _ _ compact113_node_3677
    (ChildrenCoverage113.cons _ _ compact113_node_3678
    (ChildrenCoverage113.cons _ _ compact113_node_3679
    (ChildrenCoverage113.cons _ _ compact113_node_3680
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3682 : NodeCoverage113 [22,11,11,11,11,11,11,10] 10 15 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3683 : NodeCoverage113 [22,11,11,11,11,11,11,9] 9 16 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3684 : NodeCoverage113 [22,11,11,11,11,11,11,8] 8 17 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3685 : NodeCoverage113 [22,11,11,11,11,11,11,7] 7 18 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3686 : NodeCoverage113 [22,11,11,11,11,11,11,6] 6 19 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3687 : NodeCoverage113 [22,11,11,11,11,11,11,5] 5 20 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3688 : NodeCoverage113 [22,11,11,11,11,11,11,3] 3 22 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3689 : NodeCoverage113 [22,11,11,11,11,11,11] 11 25 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3681
    (ChildrenCoverage113.cons _ _ compact113_node_3682
    (ChildrenCoverage113.cons _ _ compact113_node_3683
    (ChildrenCoverage113.cons _ _ compact113_node_3684
    (ChildrenCoverage113.cons _ _ compact113_node_3685
    (ChildrenCoverage113.cons _ _ compact113_node_3686
    (ChildrenCoverage113.cons _ _ compact113_node_3687
    (ChildrenCoverage113.cons _ _ compact113_node_3688
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3690 : NodeCoverage113 [22,11,11,11,11,11,10] 10 26 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3691 : NodeCoverage113 [22,11,11,11,11,11,9] 9 27 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3692 : NodeCoverage113 [22,11,11,11,11,11,8] 8 28 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3693 : NodeCoverage113 [22,11,11,11,11,11,7] 7 29 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3694 : NodeCoverage113 [22,11,11,11,11,11,6] 6 30 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3695 : NodeCoverage113 [22,11,11,11,11,11,5] 5 31 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3696 : NodeCoverage113 [22,11,11,11,11,11,3] 3 33 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3697 : NodeCoverage113 [22,11,11,11,11,11] 11 36 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3689
    (ChildrenCoverage113.cons _ _ compact113_node_3690
    (ChildrenCoverage113.cons _ _ compact113_node_3691
    (ChildrenCoverage113.cons _ _ compact113_node_3692
    (ChildrenCoverage113.cons _ _ compact113_node_3693
    (ChildrenCoverage113.cons _ _ compact113_node_3694
    (ChildrenCoverage113.cons _ _ compact113_node_3695
    (ChildrenCoverage113.cons _ _ compact113_node_3696
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3698 : NodeCoverage113 [22,11,11,11,11,10] 10 37 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3699 : NodeCoverage113 [22,11,11,11,11,9] 9 38 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3700 : NodeCoverage113 [22,11,11,11,11,8] 8 39 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3701 : NodeCoverage113 [22,11,11,11,11,7] 7 40 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3702 : NodeCoverage113 [22,11,11,11,11,6] 6 41 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3703 : NodeCoverage113 [22,11,11,11,11,5] 5 42 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3704 : NodeCoverage113 [22,11,11,11,11,3] 3 44 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3705 : NodeCoverage113 [22,11,11,11,11] 11 47 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3697
    (ChildrenCoverage113.cons _ _ compact113_node_3698
    (ChildrenCoverage113.cons _ _ compact113_node_3699
    (ChildrenCoverage113.cons _ _ compact113_node_3700
    (ChildrenCoverage113.cons _ _ compact113_node_3701
    (ChildrenCoverage113.cons _ _ compact113_node_3702
    (ChildrenCoverage113.cons _ _ compact113_node_3703
    (ChildrenCoverage113.cons _ _ compact113_node_3704
    ChildrenCoverage113.nil))))))))

end Symconf113

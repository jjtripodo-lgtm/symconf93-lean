import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_2322 : NodeCoverage113 [30,30,15,11] 11 27 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2323 : NodeCoverage113 [30,30,15,10,10,10,8] 8 0 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2324 : NodeCoverage113 [30,30,15,10,10,10,5] 5 3 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2325 : NodeCoverage113 [30,30,15,10,10,10,3] 3 5 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2326 : NodeCoverage113 [30,30,15,10,10,10] 10 8 :=
  node_fork113 (B := [8,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2323
    (ChildrenCoverage113.cons _ _ compact113_node_2324
    (ChildrenCoverage113.cons _ _ compact113_node_2325
    ChildrenCoverage113.nil)))

theorem compact113_node_2327 : NodeCoverage113 [30,30,15,10,10,9] 9 9 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2328 : NodeCoverage113 [30,30,15,10,10,8] 8 10 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2329 : NodeCoverage113 [30,30,15,10,10,7] 7 11 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2330 : NodeCoverage113 [30,30,15,10,10,6] 6 12 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2331 : NodeCoverage113 [30,30,15,10,10,5,5,5,3] 3 0 :=
  node_no_weak_demand113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2332 : NodeCoverage113 [30,30,15,10,10,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2331
    ChildrenCoverage113.nil)

theorem compact113_node_2333 : NodeCoverage113 [30,30,15,10,10,5,5,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_2334 : NodeCoverage113 [30,30,15,10,10,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2332
    (ChildrenCoverage113.cons _ _ compact113_node_2333
    ChildrenCoverage113.nil))

theorem compact113_node_2335 : NodeCoverage113 [30,30,15,10,10,5,3] 3 10 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2336 : NodeCoverage113 [30,30,15,10,10,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2334
    (ChildrenCoverage113.cons _ _ compact113_node_2335
    ChildrenCoverage113.nil))

theorem compact113_node_2337 : NodeCoverage113 [30,30,15,10,10,3] 3 15 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2338 : NodeCoverage113 [30,30,15,10,10] 10 18 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2326
    (ChildrenCoverage113.cons _ _ compact113_node_2327
    (ChildrenCoverage113.cons _ _ compact113_node_2328
    (ChildrenCoverage113.cons _ _ compact113_node_2329
    (ChildrenCoverage113.cons _ _ compact113_node_2330
    (ChildrenCoverage113.cons _ _ compact113_node_2336
    (ChildrenCoverage113.cons _ _ compact113_node_2337
    ChildrenCoverage113.nil)))))))

theorem compact113_node_2339 : NodeCoverage113 [30,30,15,10,9] 9 19 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2340 : NodeCoverage113 [30,30,15,10,8] 8 20 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2341 : NodeCoverage113 [30,30,15,10,7] 7 21 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2342 : NodeCoverage113 [30,30,15,10,6,6,6,6] 6 4 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2343 : NodeCoverage113 [30,30,15,10,6,6,6,5] 5 5 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2344 : NodeCoverage113 [30,30,15,10,6,6,6,3] 3 7 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_2345 : NodeCoverage113 [30,30,15,10,6,6,6] 6 10 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_2342
    (ChildrenCoverage113.cons _ _ compact113_node_2343
    (ChildrenCoverage113.cons _ _ compact113_node_2344
    ChildrenCoverage113.nil)))

theorem compact113_node_2346 : NodeCoverage113 [30,30,15,10,6,6,5] 5 11 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

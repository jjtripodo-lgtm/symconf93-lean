import Symconf113.CoverageShard113_040
import Symconf113.CoverageShard113_041

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1703 : NodeCoverage113 [36,18,7] 7 52 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1704 : NodeCoverage113 [36,18,6] 6 53 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1705 : NodeCoverage113 [36,18,5] 5 54 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1706 : NodeCoverage113 [36,18,3] 3 56 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1707 : NodeCoverage113 [36,18] 18 59 :=
  node_fork113 (B := [18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1638
    (ChildrenCoverage113.cons _ _ compact113_node_1639
    (ChildrenCoverage113.cons _ _ compact113_node_1640
    (ChildrenCoverage113.cons _ _ compact113_node_1641
    (ChildrenCoverage113.cons _ _ compact113_node_1642
    (ChildrenCoverage113.cons _ _ compact113_node_1643
    (ChildrenCoverage113.cons _ _ compact113_node_1668
    (ChildrenCoverage113.cons _ _ compact113_node_1669
    (ChildrenCoverage113.cons _ _ compact113_node_1670
    (ChildrenCoverage113.cons _ _ compact113_node_1701
    (ChildrenCoverage113.cons _ _ compact113_node_1702
    (ChildrenCoverage113.cons _ _ compact113_node_1703
    (ChildrenCoverage113.cons _ _ compact113_node_1704
    (ChildrenCoverage113.cons _ _ compact113_node_1705
    (ChildrenCoverage113.cons _ _ compact113_node_1706
    ChildrenCoverage113.nil)))))))))))))))

theorem compact113_node_1708 : NodeCoverage113 [36,17] 17 60 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1709 : NodeCoverage113 [36,16] 16 61 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1710 : NodeCoverage113 [36,15] 15 62 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1711 : NodeCoverage113 [36,14,14] 14 49 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1712 : NodeCoverage113 [36,14,13] 13 50 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1713 : NodeCoverage113 [36,14,12] 12 51 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1714 : NodeCoverage113 [36,14,11] 11 52 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1715 : NodeCoverage113 [36,14,10] 10 53 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1716 : NodeCoverage113 [36,14,9] 9 54 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1717 : NodeCoverage113 [36,14,8] 8 55 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1718 : NodeCoverage113 [36,14,7] 7 56 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1719 : NodeCoverage113 [36,14,6] 6 57 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1720 : NodeCoverage113 [36,14,5] 5 58 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1721 : NodeCoverage113 [36,14,3] 3 60 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1722 : NodeCoverage113 [36,14] 14 63 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1711
    (ChildrenCoverage113.cons _ _ compact113_node_1712
    (ChildrenCoverage113.cons _ _ compact113_node_1713
    (ChildrenCoverage113.cons _ _ compact113_node_1714
    (ChildrenCoverage113.cons _ _ compact113_node_1715
    (ChildrenCoverage113.cons _ _ compact113_node_1716
    (ChildrenCoverage113.cons _ _ compact113_node_1717
    (ChildrenCoverage113.cons _ _ compact113_node_1718
    (ChildrenCoverage113.cons _ _ compact113_node_1719
    (ChildrenCoverage113.cons _ _ compact113_node_1720
    (ChildrenCoverage113.cons _ _ compact113_node_1721
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_1723 : NodeCoverage113 [36,13] 13 64 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1724 : NodeCoverage113 [36,12,12,12,12,12,12] 12 5 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1725 : NodeCoverage113 [36,12,12,12,12,12,11] 11 6 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1726 : NodeCoverage113 [36,12,12,12,12,12,10] 10 7 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1727 : NodeCoverage113 [36,12,12,12,12,12,9] 9 8 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1728 : NodeCoverage113 [36,12,12,12,12,12,8] 8 9 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1729 : NodeCoverage113 [36,12,12,12,12,12,7] 7 10 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1730 : NodeCoverage113 [36,12,12,12,12,12,6] 6 11 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1731 : NodeCoverage113 [36,12,12,12,12,12,5] 5 12 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1732 : NodeCoverage113 [36,12,12,12,12,12,3] 3 14 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1733 : NodeCoverage113 [36,12,12,12,12,12] 12 17 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1724
    (ChildrenCoverage113.cons _ _ compact113_node_1725
    (ChildrenCoverage113.cons _ _ compact113_node_1726
    (ChildrenCoverage113.cons _ _ compact113_node_1727
    (ChildrenCoverage113.cons _ _ compact113_node_1728
    (ChildrenCoverage113.cons _ _ compact113_node_1729
    (ChildrenCoverage113.cons _ _ compact113_node_1730
    (ChildrenCoverage113.cons _ _ compact113_node_1731
    (ChildrenCoverage113.cons _ _ compact113_node_1732
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_1734 : NodeCoverage113 [36,12,12,12,12,11] 11 18 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1735 : NodeCoverage113 [36,12,12,12,12,10] 10 19 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1736 : NodeCoverage113 [36,12,12,12,12,9] 9 20 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1737 : NodeCoverage113 [36,12,12,12,12,8] 8 21 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1738 : NodeCoverage113 [36,12,12,12,12,7] 7 22 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1739 : NodeCoverage113 [36,12,12,12,12,6] 6 23 :=
  demand_node_prune113 36 compact113_demands_036 compact113_demands_036_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1740 : NodeCoverage113 [36,12,12,12,12,5] 5 24 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

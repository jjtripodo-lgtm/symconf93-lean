import Symconf113.CoverageShard113_157

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_6906 : NodeCoverage113 [10,10,10,10,9,9,3] 3 52 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6907 : NodeCoverage113 [10,10,10,10,9,9] 9 55 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6901
    (ChildrenCoverage113.cons _ _ compact113_node_6902
    (ChildrenCoverage113.cons _ _ compact113_node_6903
    (ChildrenCoverage113.cons _ _ compact113_node_6904
    (ChildrenCoverage113.cons _ _ compact113_node_6905
    (ChildrenCoverage113.cons _ _ compact113_node_6906
    ChildrenCoverage113.nil))))))

theorem compact113_node_6908 : NodeCoverage113 [10,10,10,10,9,8] 8 56 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6909 : NodeCoverage113 [10,10,10,10,9,7] 7 57 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6910 : NodeCoverage113 [10,10,10,10,9,6] 6 58 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6911 : NodeCoverage113 [10,10,10,10,9,5] 5 59 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6912 : NodeCoverage113 [10,10,10,10,9,3] 3 61 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6913 : NodeCoverage113 [10,10,10,10,9] 9 64 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6907
    (ChildrenCoverage113.cons _ _ compact113_node_6908
    (ChildrenCoverage113.cons _ _ compact113_node_6909
    (ChildrenCoverage113.cons _ _ compact113_node_6910
    (ChildrenCoverage113.cons _ _ compact113_node_6911
    (ChildrenCoverage113.cons _ _ compact113_node_6912
    ChildrenCoverage113.nil))))))

theorem compact113_node_6914 : NodeCoverage113 [10,10,10,10,8] 8 65 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6915 : NodeCoverage113 [10,10,10,10,7,7,7,7,7,7] 7 31 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6916 : NodeCoverage113 [10,10,10,10,7,7,7,7,7,6] 6 32 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6917 : NodeCoverage113 [10,10,10,10,7,7,7,7,7,5] 5 33 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6918 : NodeCoverage113 [10,10,10,10,7,7,7,7,7,3] 3 35 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6919 : NodeCoverage113 [10,10,10,10,7,7,7,7,7] 7 38 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6915
    (ChildrenCoverage113.cons _ _ compact113_node_6916
    (ChildrenCoverage113.cons _ _ compact113_node_6917
    (ChildrenCoverage113.cons _ _ compact113_node_6918
    ChildrenCoverage113.nil))))

theorem compact113_node_6920 : NodeCoverage113 [10,10,10,10,7,7,7,7,6] 6 39 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6921 : NodeCoverage113 [10,10,10,10,7,7,7,7,5] 5 40 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6922 : NodeCoverage113 [10,10,10,10,7,7,7,7,3] 3 42 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6923 : NodeCoverage113 [10,10,10,10,7,7,7,7] 7 45 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6919
    (ChildrenCoverage113.cons _ _ compact113_node_6920
    (ChildrenCoverage113.cons _ _ compact113_node_6921
    (ChildrenCoverage113.cons _ _ compact113_node_6922
    ChildrenCoverage113.nil))))

theorem compact113_node_6924 : NodeCoverage113 [10,10,10,10,7,7,7,6] 6 46 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6925 : NodeCoverage113 [10,10,10,10,7,7,7,5] 5 47 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6926 : NodeCoverage113 [10,10,10,10,7,7,7,3] 3 49 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6927 : NodeCoverage113 [10,10,10,10,7,7,7] 7 52 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6923
    (ChildrenCoverage113.cons _ _ compact113_node_6924
    (ChildrenCoverage113.cons _ _ compact113_node_6925
    (ChildrenCoverage113.cons _ _ compact113_node_6926
    ChildrenCoverage113.nil))))

theorem compact113_node_6928 : NodeCoverage113 [10,10,10,10,7,7,6] 6 53 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6929 : NodeCoverage113 [10,10,10,10,7,7,5] 5 54 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6930 : NodeCoverage113 [10,10,10,10,7,7,3] 3 56 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6931 : NodeCoverage113 [10,10,10,10,7,7] 7 59 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6927
    (ChildrenCoverage113.cons _ _ compact113_node_6928
    (ChildrenCoverage113.cons _ _ compact113_node_6929
    (ChildrenCoverage113.cons _ _ compact113_node_6930
    ChildrenCoverage113.nil))))

theorem compact113_node_6932 : NodeCoverage113 [10,10,10,10,7,6] 6 60 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6933 : NodeCoverage113 [10,10,10,10,7,5] 5 61 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6934 : NodeCoverage113 [10,10,10,10,7,3] 3 63 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6935 : NodeCoverage113 [10,10,10,10,7] 7 66 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6931
    (ChildrenCoverage113.cons _ _ compact113_node_6932
    (ChildrenCoverage113.cons _ _ compact113_node_6933
    (ChildrenCoverage113.cons _ _ compact113_node_6934
    ChildrenCoverage113.nil))))

theorem compact113_node_6936 : NodeCoverage113 [10,10,10,10,6,6,6,6,6,6,6] 6 31 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6937 : NodeCoverage113 [10,10,10,10,6,6,6,6,6,6,5] 5 32 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6938 : NodeCoverage113 [10,10,10,10,6,6,6,6,6,6,3] 3 34 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6939 : NodeCoverage113 [10,10,10,10,6,6,6,6,6,6] 6 37 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6936
    (ChildrenCoverage113.cons _ _ compact113_node_6937
    (ChildrenCoverage113.cons _ _ compact113_node_6938
    ChildrenCoverage113.nil)))

theorem compact113_node_6940 : NodeCoverage113 [10,10,10,10,6,6,6,6,6,5] 5 38 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6941 : NodeCoverage113 [10,10,10,10,6,6,6,6,6,3] 3 40 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6942 : NodeCoverage113 [10,10,10,10,6,6,6,6,6] 6 43 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6939
    (ChildrenCoverage113.cons _ _ compact113_node_6940
    (ChildrenCoverage113.cons _ _ compact113_node_6941
    ChildrenCoverage113.nil)))

theorem compact113_node_6943 : NodeCoverage113 [10,10,10,10,6,6,6,6,5] 5 44 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6944 : NodeCoverage113 [10,10,10,10,6,6,6,6,3] 3 46 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6945 : NodeCoverage113 [10,10,10,10,6,6,6,6] 6 49 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6942
    (ChildrenCoverage113.cons _ _ compact113_node_6943
    (ChildrenCoverage113.cons _ _ compact113_node_6944
    ChildrenCoverage113.nil)))

theorem compact113_node_6946 : NodeCoverage113 [10,10,10,10,6,6,6,5] 5 50 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6947 : NodeCoverage113 [10,10,10,10,6,6,6,3] 3 52 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6948 : NodeCoverage113 [10,10,10,10,6,6,6] 6 55 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6945
    (ChildrenCoverage113.cons _ _ compact113_node_6946
    (ChildrenCoverage113.cons _ _ compact113_node_6947
    ChildrenCoverage113.nil)))

theorem compact113_node_6949 : NodeCoverage113 [10,10,10,10,6,6,5] 5 56 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6950 : NodeCoverage113 [10,10,10,10,6,6,3] 3 58 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6951 : NodeCoverage113 [10,10,10,10,6,6] 6 61 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6948
    (ChildrenCoverage113.cons _ _ compact113_node_6949
    (ChildrenCoverage113.cons _ _ compact113_node_6950
    ChildrenCoverage113.nil)))

theorem compact113_node_6952 : NodeCoverage113 [10,10,10,10,6,5] 5 62 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6953 : NodeCoverage113 [10,10,10,10,6,3] 3 64 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6954 : NodeCoverage113 [10,10,10,10,6] 6 67 :=
  node_fork113 (B := [6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6951
    (ChildrenCoverage113.cons _ _ compact113_node_6952
    (ChildrenCoverage113.cons _ _ compact113_node_6953
    ChildrenCoverage113.nil)))

theorem compact113_node_6955 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,5,5,5,5,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6956 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,5,5,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6955
    ChildrenCoverage113.nil)

theorem compact113_node_6957 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,5,5,5,5,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6958 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,5,5,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6956
    (ChildrenCoverage113.cons _ _ compact113_node_6957
    ChildrenCoverage113.nil))

theorem compact113_node_6959 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,5,5,5,5,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6960 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,5,5,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6958
    (ChildrenCoverage113.cons _ _ compact113_node_6959
    ChildrenCoverage113.nil))

theorem compact113_node_6961 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,5,5,5,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6962 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,5,5,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6960
    (ChildrenCoverage113.cons _ _ compact113_node_6961
    ChildrenCoverage113.nil))

theorem compact113_node_6963 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,5,5,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6964 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,5,5] 5 23 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6962
    (ChildrenCoverage113.cons _ _ compact113_node_6963
    ChildrenCoverage113.nil))

theorem compact113_node_6965 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,5,3] 3 25 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6966 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,5] 5 28 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6964
    (ChildrenCoverage113.cons _ _ compact113_node_6965
    ChildrenCoverage113.nil))

theorem compact113_node_6967 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3] 3 0 :=
  node_no_weak_demand113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_6968 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3] 3 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6967
    ChildrenCoverage113.nil)

theorem compact113_node_6969 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3] 3 6 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6968
    ChildrenCoverage113.nil)

theorem compact113_node_6970 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3] 3 9 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6969
    ChildrenCoverage113.nil)

theorem compact113_node_6971 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,3,3,3,3,3,3,3] 3 12 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6970
    ChildrenCoverage113.nil)

theorem compact113_node_6972 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,3,3,3,3,3,3] 3 15 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6971
    ChildrenCoverage113.nil)

theorem compact113_node_6973 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,3,3,3,3,3] 3 18 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6972
    ChildrenCoverage113.nil)

theorem compact113_node_6974 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,3,3,3,3] 3 21 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6973
    ChildrenCoverage113.nil)

theorem compact113_node_6975 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,3,3,3] 3 24 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6974
    ChildrenCoverage113.nil)

theorem compact113_node_6976 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,3,3] 3 27 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6975
    ChildrenCoverage113.nil)

theorem compact113_node_6977 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5,3] 3 30 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6976
    ChildrenCoverage113.nil)

theorem compact113_node_6978 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,5] 5 33 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6966
    (ChildrenCoverage113.cons _ _ compact113_node_6977
    ChildrenCoverage113.nil))

theorem compact113_node_6979 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_6980 : NodeCoverage113 [10,10,10,10,5,5,5,5,5,5,5,3,3,3,3,3,3,3,3,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_6979
    ChildrenCoverage113.nil)

end Symconf113

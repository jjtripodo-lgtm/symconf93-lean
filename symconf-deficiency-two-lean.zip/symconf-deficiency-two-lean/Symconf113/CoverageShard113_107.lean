import Symconf113.CoverageShard113_106

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3904 : NodeCoverage113 [20,20,20,20,20,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3905 : NodeCoverage113 [20,20,20,20,20,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3904
    ChildrenCoverage113.nil)

theorem compact113_node_3906 : NodeCoverage113 [20,20,20,20,20,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3907 : NodeCoverage113 [20,20,20,20,20,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3905
    (ChildrenCoverage113.cons _ _ compact113_node_3906
    ChildrenCoverage113.nil))

theorem compact113_node_3908 : NodeCoverage113 [20,20,20,20,20,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3909 : NodeCoverage113 [20,20,20,20,20] 20 13 :=
  node_fork113 (B := [13,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3898
    (ChildrenCoverage113.cons _ _ compact113_node_3899
    (ChildrenCoverage113.cons _ _ compact113_node_3900
    (ChildrenCoverage113.cons _ _ compact113_node_3901
    (ChildrenCoverage113.cons _ _ compact113_node_3902
    (ChildrenCoverage113.cons _ _ compact113_node_3903
    (ChildrenCoverage113.cons _ _ compact113_node_3907
    (ChildrenCoverage113.cons _ _ compact113_node_3908
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3910 : NodeCoverage113 [20,20,20,20,19] 19 14 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3911 : NodeCoverage113 [20,20,20,20,18] 18 15 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3912 : NodeCoverage113 [20,20,20,20,17] 17 16 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3913 : NodeCoverage113 [20,20,20,20,16] 16 17 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3914 : NodeCoverage113 [20,20,20,20,15] 15 18 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3915 : NodeCoverage113 [20,20,20,20,14] 14 19 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3916 : NodeCoverage113 [20,20,20,20,13] 13 20 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3917 : NodeCoverage113 [20,20,20,20,12] 12 21 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3918 : NodeCoverage113 [20,20,20,20,11] 11 22 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3919 : NodeCoverage113 [20,20,20,20,10,10,10] 10 3 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3920 : NodeCoverage113 [20,20,20,20,10,10,9] 9 4 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3921 : NodeCoverage113 [20,20,20,20,10,10,8] 8 5 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3922 : NodeCoverage113 [20,20,20,20,10,10,7] 7 6 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3923 : NodeCoverage113 [20,20,20,20,10,10,6] 6 7 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3924 : NodeCoverage113 [20,20,20,20,10,10,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3925 : NodeCoverage113 [20,20,20,20,10,10,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3924
    ChildrenCoverage113.nil)

theorem compact113_node_3926 : NodeCoverage113 [20,20,20,20,10,10,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3927 : NodeCoverage113 [20,20,20,20,10,10,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3925
    (ChildrenCoverage113.cons _ _ compact113_node_3926
    ChildrenCoverage113.nil))

theorem compact113_node_3928 : NodeCoverage113 [20,20,20,20,10,10,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3929 : NodeCoverage113 [20,20,20,20,10,10] 10 13 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3919
    (ChildrenCoverage113.cons _ _ compact113_node_3920
    (ChildrenCoverage113.cons _ _ compact113_node_3921
    (ChildrenCoverage113.cons _ _ compact113_node_3922
    (ChildrenCoverage113.cons _ _ compact113_node_3923
    (ChildrenCoverage113.cons _ _ compact113_node_3927
    (ChildrenCoverage113.cons _ _ compact113_node_3928
    ChildrenCoverage113.nil)))))))

theorem compact113_node_3930 : NodeCoverage113 [20,20,20,20,10,9] 9 14 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3931 : NodeCoverage113 [20,20,20,20,10,8] 8 15 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3932 : NodeCoverage113 [20,20,20,20,10,7] 7 16 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3933 : NodeCoverage113 [20,20,20,20,10,6] 6 17 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3934 : NodeCoverage113 [20,20,20,20,10,5,5,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3935 : NodeCoverage113 [20,20,20,20,10,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3934
    ChildrenCoverage113.nil)

theorem compact113_node_3936 : NodeCoverage113 [20,20,20,20,10,5,5,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3937 : NodeCoverage113 [20,20,20,20,10,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3935
    (ChildrenCoverage113.cons _ _ compact113_node_3936
    ChildrenCoverage113.nil))

theorem compact113_node_3938 : NodeCoverage113 [20,20,20,20,10,5,5,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3939 : NodeCoverage113 [20,20,20,20,10,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3937
    (ChildrenCoverage113.cons _ _ compact113_node_3938
    ChildrenCoverage113.nil))

theorem compact113_node_3940 : NodeCoverage113 [20,20,20,20,10,5,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3941 : NodeCoverage113 [20,20,20,20,10,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3939
    (ChildrenCoverage113.cons _ _ compact113_node_3940
    ChildrenCoverage113.nil))

theorem compact113_node_3942 : NodeCoverage113 [20,20,20,20,10,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3943 : NodeCoverage113 [20,20,20,20,10] 10 23 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3929
    (ChildrenCoverage113.cons _ _ compact113_node_3930
    (ChildrenCoverage113.cons _ _ compact113_node_3931
    (ChildrenCoverage113.cons _ _ compact113_node_3932
    (ChildrenCoverage113.cons _ _ compact113_node_3933
    (ChildrenCoverage113.cons _ _ compact113_node_3941
    (ChildrenCoverage113.cons _ _ compact113_node_3942
    ChildrenCoverage113.nil)))))))

theorem compact113_node_3944 : NodeCoverage113 [20,20,20,20,9] 9 24 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3945 : NodeCoverage113 [20,20,20,20,8] 8 25 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3946 : NodeCoverage113 [20,20,20,20,7] 7 26 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3947 : NodeCoverage113 [20,20,20,20,6] 6 27 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3948 : NodeCoverage113 [20,20,20,20,5,5,5,5,5,5,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3949 : NodeCoverage113 [20,20,20,20,5,5,5,5,5,5] 5 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3948
    ChildrenCoverage113.nil)

theorem compact113_node_3950 : NodeCoverage113 [20,20,20,20,5,5,5,5,5,3] 3 5 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3951 : NodeCoverage113 [20,20,20,20,5,5,5,5,5] 5 8 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3949
    (ChildrenCoverage113.cons _ _ compact113_node_3950
    ChildrenCoverage113.nil))

theorem compact113_node_3952 : NodeCoverage113 [20,20,20,20,5,5,5,5,3] 3 10 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3953 : NodeCoverage113 [20,20,20,20,5,5,5,5] 5 13 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3951
    (ChildrenCoverage113.cons _ _ compact113_node_3952
    ChildrenCoverage113.nil))

theorem compact113_node_3954 : NodeCoverage113 [20,20,20,20,5,5,5,3] 3 15 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3955 : NodeCoverage113 [20,20,20,20,5,5,5] 5 18 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3953
    (ChildrenCoverage113.cons _ _ compact113_node_3954
    ChildrenCoverage113.nil))

theorem compact113_node_3956 : NodeCoverage113 [20,20,20,20,5,5,3] 3 20 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3957 : NodeCoverage113 [20,20,20,20,5,5] 5 23 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3955
    (ChildrenCoverage113.cons _ _ compact113_node_3956
    ChildrenCoverage113.nil))

theorem compact113_node_3958 : NodeCoverage113 [20,20,20,20,5,3] 3 25 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3959 : NodeCoverage113 [20,20,20,20,5] 5 28 :=
  node_fork113 (B := [5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3957
    (ChildrenCoverage113.cons _ _ compact113_node_3958
    ChildrenCoverage113.nil))

theorem compact113_node_3960 : NodeCoverage113 [20,20,20,20,3] 3 30 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3961 : NodeCoverage113 [20,20,20,20] 20 33 :=
  node_fork113 (B := [20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3909
    (ChildrenCoverage113.cons _ _ compact113_node_3910
    (ChildrenCoverage113.cons _ _ compact113_node_3911
    (ChildrenCoverage113.cons _ _ compact113_node_3912
    (ChildrenCoverage113.cons _ _ compact113_node_3913
    (ChildrenCoverage113.cons _ _ compact113_node_3914
    (ChildrenCoverage113.cons _ _ compact113_node_3915
    (ChildrenCoverage113.cons _ _ compact113_node_3916
    (ChildrenCoverage113.cons _ _ compact113_node_3917
    (ChildrenCoverage113.cons _ _ compact113_node_3918
    (ChildrenCoverage113.cons _ _ compact113_node_3943
    (ChildrenCoverage113.cons _ _ compact113_node_3944
    (ChildrenCoverage113.cons _ _ compact113_node_3945
    (ChildrenCoverage113.cons _ _ compact113_node_3946
    (ChildrenCoverage113.cons _ _ compact113_node_3947
    (ChildrenCoverage113.cons _ _ compact113_node_3959
    (ChildrenCoverage113.cons _ _ compact113_node_3960
    ChildrenCoverage113.nil)))))))))))))))))

theorem compact113_node_3962 : NodeCoverage113 [20,20,20,19] 19 34 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

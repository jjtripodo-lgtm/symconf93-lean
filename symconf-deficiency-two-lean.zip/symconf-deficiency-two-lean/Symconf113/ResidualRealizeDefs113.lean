import Symconf113.ResidualCensusSound113
import Mathlib.Algebra.BigOperators.Fin

/-! List form of 0/1 functions on `ZMod 15`, for the realizability check. -/
namespace Symconf113
open scoped BigOperators

def bl (l : List Bool) (k : ℕ) : ℕ := if l.getD (k%15) false then 1 else 0
def acL (l : List Bool) (d : ℕ) : ℕ := ((List.range 15).map fun u => bl l u*bl l (u+d)).sum
def cntL (l : List Bool) : ℕ := ((List.range 15).map (bl l)).sum
def sigL (l : List Bool) : List ℕ := ofF fun t => acL l (t+1)
def bools15 : List (List Bool) := prodL (List.replicate 15 [false,true])

/-- Autocorrelation on `ZMod 15`. -/
def acZ (e : ZMod 15 → ℤ) (d : ZMod 15) : ℤ := ∑ u, e u*e (u+d)

def sigZ (e : ZMod 15 → ℤ) : List ℕ := ofF fun t => (acZ e ((t+1 : ℕ) : ZMod 15)).toNat

def degZ (e : ZMod 15 → ℤ) : ℕ := (∑ u, e u).toNat

end Symconf113

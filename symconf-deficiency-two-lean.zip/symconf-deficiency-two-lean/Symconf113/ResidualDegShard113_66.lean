import Symconf113.ResidualDegDefs113

/-! Kernel check: the degree search below type-`A` rows 66 and 67. -/
namespace Symconf113
set_option maxRecDepth 100000
set_option maxHeartbeats 0 in
theorem degShard_66 : ((degTopList.drop 66).take 2).all degTop=true := by decide +kernel
end Symconf113

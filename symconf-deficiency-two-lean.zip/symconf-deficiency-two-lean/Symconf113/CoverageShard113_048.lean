import Symconf113.CoverageShard113_047

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_1954 : NodeCoverage113 [35,15] 15 63 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1955 : NodeCoverage113 [35,14] 14 64 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1956 : NodeCoverage113 [35,13] 13 65 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1957 : NodeCoverage113 [35,12] 12 66 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1958 : NodeCoverage113 [35,11] 11 67 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1959 : NodeCoverage113 [35,10] 10 68 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1960 : NodeCoverage113 [35,9] 9 69 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1961 : NodeCoverage113 [35,8] 8 70 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1962 : NodeCoverage113 [35,7] 7 71 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1963 : NodeCoverage113 [35,6] 6 72 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1964 : NodeCoverage113 [35,5] 5 73 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1965 : NodeCoverage113 [35,3] 3 75 :=
  demand_node_prune113 35 compact113_demands_035 compact113_demands_035_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1966 : NodeCoverage113 [35] 35 78 :=
  node_fork113 (B := [35,34,33,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1934
    (ChildrenCoverage113.cons _ _ compact113_node_1935
    (ChildrenCoverage113.cons _ _ compact113_node_1936
    (ChildrenCoverage113.cons _ _ compact113_node_1937
    (ChildrenCoverage113.cons _ _ compact113_node_1938
    (ChildrenCoverage113.cons _ _ compact113_node_1939
    (ChildrenCoverage113.cons _ _ compact113_node_1940
    (ChildrenCoverage113.cons _ _ compact113_node_1941
    (ChildrenCoverage113.cons _ _ compact113_node_1942
    (ChildrenCoverage113.cons _ _ compact113_node_1943
    (ChildrenCoverage113.cons _ _ compact113_node_1944
    (ChildrenCoverage113.cons _ _ compact113_node_1945
    (ChildrenCoverage113.cons _ _ compact113_node_1946
    (ChildrenCoverage113.cons _ _ compact113_node_1947
    (ChildrenCoverage113.cons _ _ compact113_node_1948
    (ChildrenCoverage113.cons _ _ compact113_node_1949
    (ChildrenCoverage113.cons _ _ compact113_node_1950
    (ChildrenCoverage113.cons _ _ compact113_node_1951
    (ChildrenCoverage113.cons _ _ compact113_node_1952
    (ChildrenCoverage113.cons _ _ compact113_node_1953
    (ChildrenCoverage113.cons _ _ compact113_node_1954
    (ChildrenCoverage113.cons _ _ compact113_node_1955
    (ChildrenCoverage113.cons _ _ compact113_node_1956
    (ChildrenCoverage113.cons _ _ compact113_node_1957
    (ChildrenCoverage113.cons _ _ compact113_node_1958
    (ChildrenCoverage113.cons _ _ compact113_node_1959
    (ChildrenCoverage113.cons _ _ compact113_node_1960
    (ChildrenCoverage113.cons _ _ compact113_node_1961
    (ChildrenCoverage113.cons _ _ compact113_node_1962
    (ChildrenCoverage113.cons _ _ compact113_node_1963
    (ChildrenCoverage113.cons _ _ compact113_node_1964
    (ChildrenCoverage113.cons _ _ compact113_node_1965
    ChildrenCoverage113.nil))))))))))))))))))))))))))))))))

theorem compact113_node_1967 : NodeCoverage113 [34] 34 79 :=
  demand_node_prune113 34 compact113_demands_034 compact113_demands_034_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1968 : NodeCoverage113 [33,33,33,14] 14 0 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1969 : NodeCoverage113 [33,33,33,11,3] 3 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_1970 : NodeCoverage113 [33,33,33,11] 11 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1969
    ChildrenCoverage113.nil)

theorem compact113_node_1971 : NodeCoverage113 [33,33,33,10] 10 4 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1972 : NodeCoverage113 [33,33,33,9] 9 5 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1973 : NodeCoverage113 [33,33,33,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1974 : NodeCoverage113 [33,33,33,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1975 : NodeCoverage113 [33,33,33,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1976 : NodeCoverage113 [33,33,33,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1977 : NodeCoverage113 [33,33,33,3,3,3] 3 5 :=
  node_fork113 (B := []) (by decide +kernel) (by decide +kernel)
    ChildrenCoverage113.nil

theorem compact113_node_1978 : NodeCoverage113 [33,33,33,3,3] 3 8 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1977
    ChildrenCoverage113.nil)

theorem compact113_node_1979 : NodeCoverage113 [33,33,33,3] 3 11 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1978
    ChildrenCoverage113.nil)

theorem compact113_node_1980 : NodeCoverage113 [33,33,33] 33 14 :=
  node_fork113 (B := [14,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_1968
    (ChildrenCoverage113.cons _ _ compact113_node_1970
    (ChildrenCoverage113.cons _ _ compact113_node_1971
    (ChildrenCoverage113.cons _ _ compact113_node_1972
    (ChildrenCoverage113.cons _ _ compact113_node_1973
    (ChildrenCoverage113.cons _ _ compact113_node_1974
    (ChildrenCoverage113.cons _ _ compact113_node_1975
    (ChildrenCoverage113.cons _ _ compact113_node_1976
    (ChildrenCoverage113.cons _ _ compact113_node_1979
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_1981 : NodeCoverage113 [33,33,32] 32 15 :=
  demand_node_prune113 32 compact113_demands_032 compact113_demands_032_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1982 : NodeCoverage113 [33,33,31] 31 16 :=
  demand_node_prune113 31 compact113_demands_031 compact113_demands_031_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1983 : NodeCoverage113 [33,33,30] 30 17 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1984 : NodeCoverage113 [33,33,29] 29 18 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1985 : NodeCoverage113 [33,33,28] 28 19 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1986 : NodeCoverage113 [33,33,27] 27 20 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1987 : NodeCoverage113 [33,33,26] 26 21 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1988 : NodeCoverage113 [33,33,25] 25 22 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_1989 : NodeCoverage113 [33,33,24] 24 23 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

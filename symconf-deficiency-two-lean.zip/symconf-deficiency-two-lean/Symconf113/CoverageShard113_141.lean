import Symconf113.CoverageShard113_140

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5741 : NodeCoverage113 [14,13,9] 9 77 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5742 : NodeCoverage113 [14,13,8] 8 78 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5743 : NodeCoverage113 [14,13,7] 7 79 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5744 : NodeCoverage113 [14,13,6] 6 80 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5745 : NodeCoverage113 [14,13,5] 5 81 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5746 : NodeCoverage113 [14,13,3] 3 83 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5747 : NodeCoverage113 [14,13] 13 86 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5737
    (ChildrenCoverage113.cons _ _ compact113_node_5738
    (ChildrenCoverage113.cons _ _ compact113_node_5739
    (ChildrenCoverage113.cons _ _ compact113_node_5740
    (ChildrenCoverage113.cons _ _ compact113_node_5741
    (ChildrenCoverage113.cons _ _ compact113_node_5742
    (ChildrenCoverage113.cons _ _ compact113_node_5743
    (ChildrenCoverage113.cons _ _ compact113_node_5744
    (ChildrenCoverage113.cons _ _ compact113_node_5745
    (ChildrenCoverage113.cons _ _ compact113_node_5746
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_5748 : NodeCoverage113 [14,12,12,12,12] 12 51 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5749 : NodeCoverage113 [14,12,12,12,11] 11 52 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5750 : NodeCoverage113 [14,12,12,12,10] 10 53 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5751 : NodeCoverage113 [14,12,12,12,9] 9 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5752 : NodeCoverage113 [14,12,12,12,8] 8 55 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5753 : NodeCoverage113 [14,12,12,12,7,7,7,7] 7 35 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5754 : NodeCoverage113 [14,12,12,12,7,7,7,6] 6 36 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5755 : NodeCoverage113 [14,12,12,12,7,7,7,5] 5 37 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5756 : NodeCoverage113 [14,12,12,12,7,7,7,3] 3 39 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5757 : NodeCoverage113 [14,12,12,12,7,7,7] 7 42 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5753
    (ChildrenCoverage113.cons _ _ compact113_node_5754
    (ChildrenCoverage113.cons _ _ compact113_node_5755
    (ChildrenCoverage113.cons _ _ compact113_node_5756
    ChildrenCoverage113.nil))))

theorem compact113_node_5758 : NodeCoverage113 [14,12,12,12,7,7,6] 6 43 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5759 : NodeCoverage113 [14,12,12,12,7,7,5] 5 44 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5760 : NodeCoverage113 [14,12,12,12,7,7,3] 3 46 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5761 : NodeCoverage113 [14,12,12,12,7,7] 7 49 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5757
    (ChildrenCoverage113.cons _ _ compact113_node_5758
    (ChildrenCoverage113.cons _ _ compact113_node_5759
    (ChildrenCoverage113.cons _ _ compact113_node_5760
    ChildrenCoverage113.nil))))

theorem compact113_node_5762 : NodeCoverage113 [14,12,12,12,7,6] 6 50 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5763 : NodeCoverage113 [14,12,12,12,7,5] 5 51 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5764 : NodeCoverage113 [14,12,12,12,7,3] 3 53 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5765 : NodeCoverage113 [14,12,12,12,7] 7 56 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5761
    (ChildrenCoverage113.cons _ _ compact113_node_5762
    (ChildrenCoverage113.cons _ _ compact113_node_5763
    (ChildrenCoverage113.cons _ _ compact113_node_5764
    ChildrenCoverage113.nil))))

theorem compact113_node_5766 : NodeCoverage113 [14,12,12,12,6] 6 57 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5767 : NodeCoverage113 [14,12,12,12,5] 5 58 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5768 : NodeCoverage113 [14,12,12,12,3] 3 60 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5769 : NodeCoverage113 [14,12,12,12] 12 63 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5748
    (ChildrenCoverage113.cons _ _ compact113_node_5749
    (ChildrenCoverage113.cons _ _ compact113_node_5750
    (ChildrenCoverage113.cons _ _ compact113_node_5751
    (ChildrenCoverage113.cons _ _ compact113_node_5752
    (ChildrenCoverage113.cons _ _ compact113_node_5765
    (ChildrenCoverage113.cons _ _ compact113_node_5766
    (ChildrenCoverage113.cons _ _ compact113_node_5767
    (ChildrenCoverage113.cons _ _ compact113_node_5768
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_5770 : NodeCoverage113 [14,12,12,11] 11 64 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5771 : NodeCoverage113 [14,12,12,10,10] 10 55 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5772 : NodeCoverage113 [14,12,12,10,9] 9 56 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5773 : NodeCoverage113 [14,12,12,10,8] 8 57 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5774 : NodeCoverage113 [14,12,12,10,7] 7 58 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5775 : NodeCoverage113 [14,12,12,10,6] 6 59 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5776 : NodeCoverage113 [14,12,12,10,5] 5 60 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5777 : NodeCoverage113 [14,12,12,10,3] 3 62 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5778 : NodeCoverage113 [14,12,12,10] 10 65 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5771
    (ChildrenCoverage113.cons _ _ compact113_node_5772
    (ChildrenCoverage113.cons _ _ compact113_node_5773
    (ChildrenCoverage113.cons _ _ compact113_node_5774
    (ChildrenCoverage113.cons _ _ compact113_node_5775
    (ChildrenCoverage113.cons _ _ compact113_node_5776
    (ChildrenCoverage113.cons _ _ compact113_node_5777
    ChildrenCoverage113.nil)))))))

theorem compact113_node_5779 : NodeCoverage113 [14,12,12,9,9] 9 57 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5780 : NodeCoverage113 [14,12,12,9,8] 8 58 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5781 : NodeCoverage113 [14,12,12,9,7] 7 59 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5782 : NodeCoverage113 [14,12,12,9,6] 6 60 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5783 : NodeCoverage113 [14,12,12,9,5] 5 61 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5784 : NodeCoverage113 [14,12,12,9,3] 3 63 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5785 : NodeCoverage113 [14,12,12,9] 9 66 :=
  node_fork113 (B := [9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5779
    (ChildrenCoverage113.cons _ _ compact113_node_5780
    (ChildrenCoverage113.cons _ _ compact113_node_5781
    (ChildrenCoverage113.cons _ _ compact113_node_5782
    (ChildrenCoverage113.cons _ _ compact113_node_5783
    (ChildrenCoverage113.cons _ _ compact113_node_5784
    ChildrenCoverage113.nil))))))

theorem compact113_node_5786 : NodeCoverage113 [14,12,12,8] 8 67 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5787 : NodeCoverage113 [14,12,12,7,7,7,7] 7 47 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5788 : NodeCoverage113 [14,12,12,7,7,7,6] 6 48 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5789 : NodeCoverage113 [14,12,12,7,7,7,5] 5 49 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5790 : NodeCoverage113 [14,12,12,7,7,7,3] 3 51 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5791 : NodeCoverage113 [14,12,12,7,7,7] 7 54 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5787
    (ChildrenCoverage113.cons _ _ compact113_node_5788
    (ChildrenCoverage113.cons _ _ compact113_node_5789
    (ChildrenCoverage113.cons _ _ compact113_node_5790
    ChildrenCoverage113.nil))))

theorem compact113_node_5792 : NodeCoverage113 [14,12,12,7,7,6] 6 55 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5793 : NodeCoverage113 [14,12,12,7,7,5] 5 56 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5794 : NodeCoverage113 [14,12,12,7,7,3] 3 58 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5795 : NodeCoverage113 [14,12,12,7,7] 7 61 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5791
    (ChildrenCoverage113.cons _ _ compact113_node_5792
    (ChildrenCoverage113.cons _ _ compact113_node_5793
    (ChildrenCoverage113.cons _ _ compact113_node_5794
    ChildrenCoverage113.nil))))

theorem compact113_node_5796 : NodeCoverage113 [14,12,12,7,6] 6 62 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5797 : NodeCoverage113 [14,12,12,7,5] 5 63 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5798 : NodeCoverage113 [14,12,12,7,3] 3 65 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5799 : NodeCoverage113 [14,12,12,7] 7 68 :=
  node_fork113 (B := [7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5795
    (ChildrenCoverage113.cons _ _ compact113_node_5796
    (ChildrenCoverage113.cons _ _ compact113_node_5797
    (ChildrenCoverage113.cons _ _ compact113_node_5798
    ChildrenCoverage113.nil))))

theorem compact113_node_5800 : NodeCoverage113 [14,12,12,6] 6 69 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5801 : NodeCoverage113 [14,12,12,5] 5 70 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5802 : NodeCoverage113 [14,12,12,3] 3 72 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5803 : NodeCoverage113 [14,12,12] 12 75 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5769
    (ChildrenCoverage113.cons _ _ compact113_node_5770
    (ChildrenCoverage113.cons _ _ compact113_node_5778
    (ChildrenCoverage113.cons _ _ compact113_node_5785
    (ChildrenCoverage113.cons _ _ compact113_node_5786
    (ChildrenCoverage113.cons _ _ compact113_node_5799
    (ChildrenCoverage113.cons _ _ compact113_node_5800
    (ChildrenCoverage113.cons _ _ compact113_node_5801
    (ChildrenCoverage113.cons _ _ compact113_node_5802
    ChildrenCoverage113.nil)))))))))

end Symconf113

import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_0000 : NodeCoverage113 [113] 113 0 :=
  node_good_leaf113 (by decide +kernel)

theorem compact113_node_0001 : NodeCoverage113 [110] 110 3 :=
  demand_node_prune113 110 compact113_demands_110 compact113_demands_110_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0002 : NodeCoverage113 [109] 109 4 :=
  demand_node_prune113 109 compact113_demands_109 compact113_demands_109_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0003 : NodeCoverage113 [108] 108 5 :=
  demand_node_prune113 108 compact113_demands_108 compact113_demands_108_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0004 : NodeCoverage113 [107] 107 6 :=
  demand_node_prune113 107 compact113_demands_107 compact113_demands_107_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0005 : NodeCoverage113 [106] 106 7 :=
  demand_node_prune113 106 compact113_demands_106 compact113_demands_106_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0006 : NodeCoverage113 [105] 105 8 :=
  demand_node_prune113 105 compact113_demands_105 compact113_demands_105_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0007 : NodeCoverage113 [104] 104 9 :=
  demand_node_prune113 104 compact113_demands_104 compact113_demands_104_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0008 : NodeCoverage113 [103] 103 10 :=
  demand_node_prune113 103 compact113_demands_103 compact113_demands_103_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0009 : NodeCoverage113 [102] 102 11 :=
  demand_node_prune113 102 compact113_demands_102 compact113_demands_102_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0010 : NodeCoverage113 [101] 101 12 :=
  demand_node_prune113 101 compact113_demands_101 compact113_demands_101_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0011 : NodeCoverage113 [100] 100 13 :=
  demand_node_prune113 100 compact113_demands_100 compact113_demands_100_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0012 : NodeCoverage113 [99] 99 14 :=
  demand_node_prune113 99 compact113_demands_099 compact113_demands_099_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0013 : NodeCoverage113 [98] 98 15 :=
  demand_node_prune113 98 compact113_demands_098 compact113_demands_098_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0014 : NodeCoverage113 [97] 97 16 :=
  demand_node_prune113 97 compact113_demands_097 compact113_demands_097_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0015 : NodeCoverage113 [96] 96 17 :=
  demand_node_prune113 96 compact113_demands_096 compact113_demands_096_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0016 : NodeCoverage113 [95] 95 18 :=
  demand_node_prune113 95 compact113_demands_095 compact113_demands_095_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0017 : NodeCoverage113 [94] 94 19 :=
  demand_node_prune113 94 compact113_demands_094 compact113_demands_094_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0018 : NodeCoverage113 [93] 93 20 :=
  demand_node_prune113 93 compact113_demands_093 compact113_demands_093_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0019 : NodeCoverage113 [92] 92 21 :=
  demand_node_prune113 92 compact113_demands_092 compact113_demands_092_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0020 : NodeCoverage113 [91] 91 22 :=
  demand_node_prune113 91 compact113_demands_091 compact113_demands_091_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0021 : NodeCoverage113 [90] 90 23 :=
  demand_node_prune113 90 compact113_demands_090 compact113_demands_090_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0022 : NodeCoverage113 [89] 89 24 :=
  demand_node_prune113 89 compact113_demands_089 compact113_demands_089_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0023 : NodeCoverage113 [88] 88 25 :=
  demand_node_prune113 88 compact113_demands_088 compact113_demands_088_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0024 : NodeCoverage113 [87] 87 26 :=
  demand_node_prune113 87 compact113_demands_087 compact113_demands_087_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0025 : NodeCoverage113 [86] 86 27 :=
  demand_node_prune113 86 compact113_demands_086 compact113_demands_086_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0026 : NodeCoverage113 [85] 85 28 :=
  demand_node_prune113 85 compact113_demands_085 compact113_demands_085_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0027 : NodeCoverage113 [84] 84 29 :=
  demand_node_prune113 84 compact113_demands_084 compact113_demands_084_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0028 : NodeCoverage113 [83] 83 30 :=
  demand_node_prune113 83 compact113_demands_083 compact113_demands_083_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0029 : NodeCoverage113 [82] 82 31 :=
  demand_node_prune113 82 compact113_demands_082 compact113_demands_082_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0030 : NodeCoverage113 [81] 81 32 :=
  demand_node_prune113 81 compact113_demands_081 compact113_demands_081_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0031 : NodeCoverage113 [80,33] 33 0 :=
  demand_node_prune113 33 compact113_demands_033 compact113_demands_033_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0032 : NodeCoverage113 [80,30] 30 3 :=
  demand_node_prune113 30 compact113_demands_030 compact113_demands_030_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0033 : NodeCoverage113 [80,29] 29 4 :=
  demand_node_prune113 29 compact113_demands_029 compact113_demands_029_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0034 : NodeCoverage113 [80,28] 28 5 :=
  demand_node_prune113 28 compact113_demands_028 compact113_demands_028_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0035 : NodeCoverage113 [80,27] 27 6 :=
  demand_node_prune113 27 compact113_demands_027 compact113_demands_027_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0036 : NodeCoverage113 [80,26] 26 7 :=
  demand_node_prune113 26 compact113_demands_026 compact113_demands_026_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0037 : NodeCoverage113 [80,25] 25 8 :=
  demand_node_prune113 25 compact113_demands_025 compact113_demands_025_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0038 : NodeCoverage113 [80,24] 24 9 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0039 : NodeCoverage113 [80,23] 23 10 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0040 : NodeCoverage113 [80,22] 22 11 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0041 : NodeCoverage113 [80,21] 21 12 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0042 : NodeCoverage113 [80,20] 20 13 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0043 : NodeCoverage113 [80,19] 19 14 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0044 : NodeCoverage113 [80,18] 18 15 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0045 : NodeCoverage113 [80,17] 17 16 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0046 : NodeCoverage113 [80,16] 16 17 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0047 : NodeCoverage113 [80,15] 15 18 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0048 : NodeCoverage113 [80,14] 14 19 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0049 : NodeCoverage113 [80,13] 13 20 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0050 : NodeCoverage113 [80,12] 12 21 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0051 : NodeCoverage113 [80,11] 11 22 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0052 : NodeCoverage113 [80,10] 10 23 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0053 : NodeCoverage113 [80,9] 9 24 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_0054 : NodeCoverage113 [80,8] 8 25 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

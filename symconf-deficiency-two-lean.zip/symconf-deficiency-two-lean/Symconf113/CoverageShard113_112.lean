import Symconf113.CoverageShard113_111

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_4160 : NodeCoverage113 [20,15,9] 9 69 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4161 : NodeCoverage113 [20,15,8] 8 70 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4162 : NodeCoverage113 [20,15,7] 7 71 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4163 : NodeCoverage113 [20,15,6] 6 72 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4164 : NodeCoverage113 [20,15,5] 5 73 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4165 : NodeCoverage113 [20,15,3] 3 75 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4166 : NodeCoverage113 [20,15] 15 78 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4154
    (ChildrenCoverage113.cons _ _ compact113_node_4155
    (ChildrenCoverage113.cons _ _ compact113_node_4156
    (ChildrenCoverage113.cons _ _ compact113_node_4157
    (ChildrenCoverage113.cons _ _ compact113_node_4158
    (ChildrenCoverage113.cons _ _ compact113_node_4159
    (ChildrenCoverage113.cons _ _ compact113_node_4160
    (ChildrenCoverage113.cons _ _ compact113_node_4161
    (ChildrenCoverage113.cons _ _ compact113_node_4162
    (ChildrenCoverage113.cons _ _ compact113_node_4163
    (ChildrenCoverage113.cons _ _ compact113_node_4164
    (ChildrenCoverage113.cons _ _ compact113_node_4165
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_4167 : NodeCoverage113 [20,14,14] 14 65 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4168 : NodeCoverage113 [20,14,13] 13 66 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4169 : NodeCoverage113 [20,14,12] 12 67 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4170 : NodeCoverage113 [20,14,11] 11 68 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4171 : NodeCoverage113 [20,14,10,10] 10 59 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4172 : NodeCoverage113 [20,14,10,9] 9 60 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4173 : NodeCoverage113 [20,14,10,8] 8 61 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4174 : NodeCoverage113 [20,14,10,7] 7 62 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4175 : NodeCoverage113 [20,14,10,6] 6 63 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4176 : NodeCoverage113 [20,14,10,5] 5 64 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4177 : NodeCoverage113 [20,14,10,3] 3 66 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4178 : NodeCoverage113 [20,14,10] 10 69 :=
  node_fork113 (B := [10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4171
    (ChildrenCoverage113.cons _ _ compact113_node_4172
    (ChildrenCoverage113.cons _ _ compact113_node_4173
    (ChildrenCoverage113.cons _ _ compact113_node_4174
    (ChildrenCoverage113.cons _ _ compact113_node_4175
    (ChildrenCoverage113.cons _ _ compact113_node_4176
    (ChildrenCoverage113.cons _ _ compact113_node_4177
    ChildrenCoverage113.nil)))))))

theorem compact113_node_4179 : NodeCoverage113 [20,14,9] 9 70 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4180 : NodeCoverage113 [20,14,8] 8 71 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4181 : NodeCoverage113 [20,14,7] 7 72 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4182 : NodeCoverage113 [20,14,6] 6 73 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4183 : NodeCoverage113 [20,14,5] 5 74 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4184 : NodeCoverage113 [20,14,3] 3 76 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4185 : NodeCoverage113 [20,14] 14 79 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4167
    (ChildrenCoverage113.cons _ _ compact113_node_4168
    (ChildrenCoverage113.cons _ _ compact113_node_4169
    (ChildrenCoverage113.cons _ _ compact113_node_4170
    (ChildrenCoverage113.cons _ _ compact113_node_4178
    (ChildrenCoverage113.cons _ _ compact113_node_4179
    (ChildrenCoverage113.cons _ _ compact113_node_4180
    (ChildrenCoverage113.cons _ _ compact113_node_4181
    (ChildrenCoverage113.cons _ _ compact113_node_4182
    (ChildrenCoverage113.cons _ _ compact113_node_4183
    (ChildrenCoverage113.cons _ _ compact113_node_4184
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_4186 : NodeCoverage113 [20,13,13] 13 67 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4187 : NodeCoverage113 [20,13,12] 12 68 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4188 : NodeCoverage113 [20,13,11] 11 69 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4189 : NodeCoverage113 [20,13,10] 10 70 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4190 : NodeCoverage113 [20,13,9] 9 71 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4191 : NodeCoverage113 [20,13,8] 8 72 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4192 : NodeCoverage113 [20,13,7] 7 73 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4193 : NodeCoverage113 [20,13,6] 6 74 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4194 : NodeCoverage113 [20,13,5] 5 75 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4195 : NodeCoverage113 [20,13,3] 3 77 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4196 : NodeCoverage113 [20,13] 13 80 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_4186
    (ChildrenCoverage113.cons _ _ compact113_node_4187
    (ChildrenCoverage113.cons _ _ compact113_node_4188
    (ChildrenCoverage113.cons _ _ compact113_node_4189
    (ChildrenCoverage113.cons _ _ compact113_node_4190
    (ChildrenCoverage113.cons _ _ compact113_node_4191
    (ChildrenCoverage113.cons _ _ compact113_node_4192
    (ChildrenCoverage113.cons _ _ compact113_node_4193
    (ChildrenCoverage113.cons _ _ compact113_node_4194
    (ChildrenCoverage113.cons _ _ compact113_node_4195
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_4197 : NodeCoverage113 [20,12,12] 12 69 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4198 : NodeCoverage113 [20,12,11] 11 70 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4199 : NodeCoverage113 [20,12,10] 10 71 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4200 : NodeCoverage113 [20,12,9] 9 72 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_4201 : NodeCoverage113 [20,12,8] 8 73 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.CoverageShard113_098

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3464 : NodeCoverage113 [23,23,9] 9 58 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3465 : NodeCoverage113 [23,23,8] 8 59 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3466 : NodeCoverage113 [23,23,7] 7 60 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3467 : NodeCoverage113 [23,23,6] 6 61 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3468 : NodeCoverage113 [23,23,5] 5 62 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3469 : NodeCoverage113 [23,23,3] 3 64 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3470 : NodeCoverage113 [23,23] 23 67 :=
  node_fork113 (B := [23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3450
    (ChildrenCoverage113.cons _ _ compact113_node_3451
    (ChildrenCoverage113.cons _ _ compact113_node_3452
    (ChildrenCoverage113.cons _ _ compact113_node_3453
    (ChildrenCoverage113.cons _ _ compact113_node_3454
    (ChildrenCoverage113.cons _ _ compact113_node_3455
    (ChildrenCoverage113.cons _ _ compact113_node_3456
    (ChildrenCoverage113.cons _ _ compact113_node_3457
    (ChildrenCoverage113.cons _ _ compact113_node_3458
    (ChildrenCoverage113.cons _ _ compact113_node_3459
    (ChildrenCoverage113.cons _ _ compact113_node_3460
    (ChildrenCoverage113.cons _ _ compact113_node_3461
    (ChildrenCoverage113.cons _ _ compact113_node_3462
    (ChildrenCoverage113.cons _ _ compact113_node_3463
    (ChildrenCoverage113.cons _ _ compact113_node_3464
    (ChildrenCoverage113.cons _ _ compact113_node_3465
    (ChildrenCoverage113.cons _ _ compact113_node_3466
    (ChildrenCoverage113.cons _ _ compact113_node_3467
    (ChildrenCoverage113.cons _ _ compact113_node_3468
    (ChildrenCoverage113.cons _ _ compact113_node_3469
    ChildrenCoverage113.nil))))))))))))))))))))

theorem compact113_node_3471 : NodeCoverage113 [23,22] 22 68 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3472 : NodeCoverage113 [23,21] 21 69 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3473 : NodeCoverage113 [23,20] 20 70 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3474 : NodeCoverage113 [23,19] 19 71 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3475 : NodeCoverage113 [23,18] 18 72 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3476 : NodeCoverage113 [23,17] 17 73 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3477 : NodeCoverage113 [23,16] 16 74 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3478 : NodeCoverage113 [23,15] 15 75 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3479 : NodeCoverage113 [23,14] 14 76 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3480 : NodeCoverage113 [23,13] 13 77 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3481 : NodeCoverage113 [23,12] 12 78 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3482 : NodeCoverage113 [23,11] 11 79 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3483 : NodeCoverage113 [23,10] 10 80 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3484 : NodeCoverage113 [23,9] 9 81 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3485 : NodeCoverage113 [23,8] 8 82 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3486 : NodeCoverage113 [23,7] 7 83 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3487 : NodeCoverage113 [23,6] 6 84 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3488 : NodeCoverage113 [23,5] 5 85 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3489 : NodeCoverage113 [23,3] 3 87 :=
  demand_node_prune113 23 compact113_demands_023 compact113_demands_023_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3490 : NodeCoverage113 [23] 23 90 :=
  node_fork113 (B := [23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3470
    (ChildrenCoverage113.cons _ _ compact113_node_3471
    (ChildrenCoverage113.cons _ _ compact113_node_3472
    (ChildrenCoverage113.cons _ _ compact113_node_3473
    (ChildrenCoverage113.cons _ _ compact113_node_3474
    (ChildrenCoverage113.cons _ _ compact113_node_3475
    (ChildrenCoverage113.cons _ _ compact113_node_3476
    (ChildrenCoverage113.cons _ _ compact113_node_3477
    (ChildrenCoverage113.cons _ _ compact113_node_3478
    (ChildrenCoverage113.cons _ _ compact113_node_3479
    (ChildrenCoverage113.cons _ _ compact113_node_3480
    (ChildrenCoverage113.cons _ _ compact113_node_3481
    (ChildrenCoverage113.cons _ _ compact113_node_3482
    (ChildrenCoverage113.cons _ _ compact113_node_3483
    (ChildrenCoverage113.cons _ _ compact113_node_3484
    (ChildrenCoverage113.cons _ _ compact113_node_3485
    (ChildrenCoverage113.cons _ _ compact113_node_3486
    (ChildrenCoverage113.cons _ _ compact113_node_3487
    (ChildrenCoverage113.cons _ _ compact113_node_3488
    (ChildrenCoverage113.cons _ _ compact113_node_3489
    ChildrenCoverage113.nil))))))))))))))))))))

theorem compact113_node_3491 : NodeCoverage113 [22,22,22,22,22] 22 3 :=
  demand_node_prune113 22 compact113_demands_022 compact113_demands_022_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3492 : NodeCoverage113 [22,22,22,22,21] 21 4 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3493 : NodeCoverage113 [22,22,22,22,20] 20 5 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3494 : NodeCoverage113 [22,22,22,22,19] 19 6 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3495 : NodeCoverage113 [22,22,22,22,18] 18 7 :=
  demand_node_prune113 18 compact113_demands_018 compact113_demands_018_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3496 : NodeCoverage113 [22,22,22,22,17] 17 8 :=
  demand_node_prune113 17 compact113_demands_017 compact113_demands_017_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3497 : NodeCoverage113 [22,22,22,22,16] 16 9 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3498 : NodeCoverage113 [22,22,22,22,15] 15 10 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3499 : NodeCoverage113 [22,22,22,22,14] 14 11 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3500 : NodeCoverage113 [22,22,22,22,13] 13 12 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3501 : NodeCoverage113 [22,22,22,22,12] 12 13 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3502 : NodeCoverage113 [22,22,22,22,11,11,3] 3 0 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3503 : NodeCoverage113 [22,22,22,22,11,11] 11 3 :=
  node_fork113 (B := [3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3502
    ChildrenCoverage113.nil)

theorem compact113_node_3504 : NodeCoverage113 [22,22,22,22,11,10] 10 4 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3505 : NodeCoverage113 [22,22,22,22,11,9] 9 5 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3506 : NodeCoverage113 [22,22,22,22,11,8] 8 6 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3507 : NodeCoverage113 [22,22,22,22,11,7] 7 7 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3508 : NodeCoverage113 [22,22,22,22,11,6] 6 8 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3509 : NodeCoverage113 [22,22,22,22,11,5] 5 9 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3510 : NodeCoverage113 [22,22,22,22,11,3] 3 11 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3511 : NodeCoverage113 [22,22,22,22,11] 11 14 :=
  node_fork113 (B := [11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3503
    (ChildrenCoverage113.cons _ _ compact113_node_3504
    (ChildrenCoverage113.cons _ _ compact113_node_3505
    (ChildrenCoverage113.cons _ _ compact113_node_3506
    (ChildrenCoverage113.cons _ _ compact113_node_3507
    (ChildrenCoverage113.cons _ _ compact113_node_3508
    (ChildrenCoverage113.cons _ _ compact113_node_3509
    (ChildrenCoverage113.cons _ _ compact113_node_3510
    ChildrenCoverage113.nil))))))))

theorem compact113_node_3512 : NodeCoverage113 [22,22,22,22,10] 10 15 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3513 : NodeCoverage113 [22,22,22,22,9] 9 16 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3514 : NodeCoverage113 [22,22,22,22,8] 8 17 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3515 : NodeCoverage113 [22,22,22,22,7] 7 18 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3516 : NodeCoverage113 [22,22,22,22,6] 6 19 :=
  demand_node_prune113 6 compact113_demands_006 compact113_demands_006_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3517 : NodeCoverage113 [22,22,22,22,5] 5 20 :=
  demand_node_prune113 5 compact113_demands_005 compact113_demands_005_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3518 : NodeCoverage113 [22,22,22,22,3] 3 22 :=
  demand_node_prune113 3 compact113_demands_003 compact113_demands_003_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3519 : NodeCoverage113 [22,22,22,22] 22 25 :=
  node_fork113 (B := [22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3491
    (ChildrenCoverage113.cons _ _ compact113_node_3492
    (ChildrenCoverage113.cons _ _ compact113_node_3493
    (ChildrenCoverage113.cons _ _ compact113_node_3494
    (ChildrenCoverage113.cons _ _ compact113_node_3495
    (ChildrenCoverage113.cons _ _ compact113_node_3496
    (ChildrenCoverage113.cons _ _ compact113_node_3497
    (ChildrenCoverage113.cons _ _ compact113_node_3498
    (ChildrenCoverage113.cons _ _ compact113_node_3499
    (ChildrenCoverage113.cons _ _ compact113_node_3500
    (ChildrenCoverage113.cons _ _ compact113_node_3501
    (ChildrenCoverage113.cons _ _ compact113_node_3511
    (ChildrenCoverage113.cons _ _ compact113_node_3512
    (ChildrenCoverage113.cons _ _ compact113_node_3513
    (ChildrenCoverage113.cons _ _ compact113_node_3514
    (ChildrenCoverage113.cons _ _ compact113_node_3515
    (ChildrenCoverage113.cons _ _ compact113_node_3516
    (ChildrenCoverage113.cons _ _ compact113_node_3517
    (ChildrenCoverage113.cons _ _ compact113_node_3518
    ChildrenCoverage113.nil)))))))))))))))))))

theorem compact113_node_3520 : NodeCoverage113 [22,22,22,21] 21 26 :=
  demand_node_prune113 21 compact113_demands_021 compact113_demands_021_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3521 : NodeCoverage113 [22,22,22,20] 20 27 :=
  demand_node_prune113 20 compact113_demands_020 compact113_demands_020_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3522 : NodeCoverage113 [22,22,22,19] 19 28 :=
  demand_node_prune113 19 compact113_demands_019 compact113_demands_019_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

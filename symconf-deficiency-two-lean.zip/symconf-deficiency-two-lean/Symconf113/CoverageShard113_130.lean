import Symconf113.CoverageShard113_129

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_5115 : NodeCoverage113 [16,16,15,5] 5 61 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5116 : NodeCoverage113 [16,16,15,3] 3 63 :=
  demand_node_prune113 15 compact113_demands_015 compact113_demands_015_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5117 : NodeCoverage113 [16,16,15] 15 66 :=
  node_fork113 (B := [15,14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5105
    (ChildrenCoverage113.cons _ _ compact113_node_5106
    (ChildrenCoverage113.cons _ _ compact113_node_5107
    (ChildrenCoverage113.cons _ _ compact113_node_5108
    (ChildrenCoverage113.cons _ _ compact113_node_5109
    (ChildrenCoverage113.cons _ _ compact113_node_5110
    (ChildrenCoverage113.cons _ _ compact113_node_5111
    (ChildrenCoverage113.cons _ _ compact113_node_5112
    (ChildrenCoverage113.cons _ _ compact113_node_5113
    (ChildrenCoverage113.cons _ _ compact113_node_5114
    (ChildrenCoverage113.cons _ _ compact113_node_5115
    (ChildrenCoverage113.cons _ _ compact113_node_5116
    ChildrenCoverage113.nil))))))))))))

theorem compact113_node_5118 : NodeCoverage113 [16,16,14,14] 14 53 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5119 : NodeCoverage113 [16,16,14,13] 13 54 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5120 : NodeCoverage113 [16,16,14,12] 12 55 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5121 : NodeCoverage113 [16,16,14,11] 11 56 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5122 : NodeCoverage113 [16,16,14,10] 10 57 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5123 : NodeCoverage113 [16,16,14,9] 9 58 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5124 : NodeCoverage113 [16,16,14,8] 8 59 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5125 : NodeCoverage113 [16,16,14,7] 7 60 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5126 : NodeCoverage113 [16,16,14,6] 6 61 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5127 : NodeCoverage113 [16,16,14,5] 5 62 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5128 : NodeCoverage113 [16,16,14,3] 3 64 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5129 : NodeCoverage113 [16,16,14] 14 67 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5118
    (ChildrenCoverage113.cons _ _ compact113_node_5119
    (ChildrenCoverage113.cons _ _ compact113_node_5120
    (ChildrenCoverage113.cons _ _ compact113_node_5121
    (ChildrenCoverage113.cons _ _ compact113_node_5122
    (ChildrenCoverage113.cons _ _ compact113_node_5123
    (ChildrenCoverage113.cons _ _ compact113_node_5124
    (ChildrenCoverage113.cons _ _ compact113_node_5125
    (ChildrenCoverage113.cons _ _ compact113_node_5126
    (ChildrenCoverage113.cons _ _ compact113_node_5127
    (ChildrenCoverage113.cons _ _ compact113_node_5128
    ChildrenCoverage113.nil)))))))))))

theorem compact113_node_5130 : NodeCoverage113 [16,16,13,13] 13 55 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5131 : NodeCoverage113 [16,16,13,12] 12 56 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5132 : NodeCoverage113 [16,16,13,11] 11 57 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5133 : NodeCoverage113 [16,16,13,10] 10 58 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5134 : NodeCoverage113 [16,16,13,9] 9 59 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5135 : NodeCoverage113 [16,16,13,8] 8 60 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5136 : NodeCoverage113 [16,16,13,7] 7 61 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5137 : NodeCoverage113 [16,16,13,6] 6 62 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5138 : NodeCoverage113 [16,16,13,5] 5 63 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5139 : NodeCoverage113 [16,16,13,3] 3 65 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5140 : NodeCoverage113 [16,16,13] 13 68 :=
  node_fork113 (B := [13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5130
    (ChildrenCoverage113.cons _ _ compact113_node_5131
    (ChildrenCoverage113.cons _ _ compact113_node_5132
    (ChildrenCoverage113.cons _ _ compact113_node_5133
    (ChildrenCoverage113.cons _ _ compact113_node_5134
    (ChildrenCoverage113.cons _ _ compact113_node_5135
    (ChildrenCoverage113.cons _ _ compact113_node_5136
    (ChildrenCoverage113.cons _ _ compact113_node_5137
    (ChildrenCoverage113.cons _ _ compact113_node_5138
    (ChildrenCoverage113.cons _ _ compact113_node_5139
    ChildrenCoverage113.nil))))))))))

theorem compact113_node_5141 : NodeCoverage113 [16,16,12,12,12] 12 45 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5142 : NodeCoverage113 [16,16,12,12,11] 11 46 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5143 : NodeCoverage113 [16,16,12,12,10] 10 47 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5144 : NodeCoverage113 [16,16,12,12,9] 9 48 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5145 : NodeCoverage113 [16,16,12,12,8] 8 49 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5146 : NodeCoverage113 [16,16,12,12,7] 7 50 :=
  demand_node_prune113 7 compact113_demands_007 compact113_demands_007_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5147 : NodeCoverage113 [16,16,12,12,6] 6 51 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5148 : NodeCoverage113 [16,16,12,12,5] 5 52 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5149 : NodeCoverage113 [16,16,12,12,3] 3 54 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5150 : NodeCoverage113 [16,16,12,12] 12 57 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5141
    (ChildrenCoverage113.cons _ _ compact113_node_5142
    (ChildrenCoverage113.cons _ _ compact113_node_5143
    (ChildrenCoverage113.cons _ _ compact113_node_5144
    (ChildrenCoverage113.cons _ _ compact113_node_5145
    (ChildrenCoverage113.cons _ _ compact113_node_5146
    (ChildrenCoverage113.cons _ _ compact113_node_5147
    (ChildrenCoverage113.cons _ _ compact113_node_5148
    (ChildrenCoverage113.cons _ _ compact113_node_5149
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_5151 : NodeCoverage113 [16,16,12,11] 11 58 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5152 : NodeCoverage113 [16,16,12,10] 10 59 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5153 : NodeCoverage113 [16,16,12,9] 9 60 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5154 : NodeCoverage113 [16,16,12,8] 8 61 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5155 : NodeCoverage113 [16,16,12,7] 7 62 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5156 : NodeCoverage113 [16,16,12,6] 6 63 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5157 : NodeCoverage113 [16,16,12,5] 5 64 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5158 : NodeCoverage113 [16,16,12,3] 3 66 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5159 : NodeCoverage113 [16,16,12] 12 69 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_5150
    (ChildrenCoverage113.cons _ _ compact113_node_5151
    (ChildrenCoverage113.cons _ _ compact113_node_5152
    (ChildrenCoverage113.cons _ _ compact113_node_5153
    (ChildrenCoverage113.cons _ _ compact113_node_5154
    (ChildrenCoverage113.cons _ _ compact113_node_5155
    (ChildrenCoverage113.cons _ _ compact113_node_5156
    (ChildrenCoverage113.cons _ _ compact113_node_5157
    (ChildrenCoverage113.cons _ _ compact113_node_5158
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_5160 : NodeCoverage113 [16,16,11,11,11] 11 48 :=
  demand_node_prune113 16 compact113_demands_016 compact113_demands_016_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_5161 : NodeCoverage113 [16,16,11,11,10] 10 49 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Symconf113

import Symconf113.ResidualRealizeDefs113

/-! The realizability check as a Boolean, split by the first five bits so
the kernel checks run in 32 pieces of `2^10` subsets each. -/
namespace Symconf113

def realB (l : List Bool) : Bool :=
  !(acL l 1==0) || !((List.range 14).all fun t => decide (acL l (t+1)≤1)) ||
    decide (sigL l ∈ realList (cntL l))

def bools10 : List (List Bool) := prodL (List.replicate 10 [false,true])

theorem prodL_rep_succ {α : Type} (n : ℕ) (x : List α) :
    prodL (List.replicate (n+1) x)=x.flatMap fun a => (prodL (List.replicate n x)).map (a :: ·) := rfl

end Symconf113

import Symconf113.AllDemandBanks113

namespace Symconf113
set_option maxRecDepth 15000
set_option maxHeartbeats 0

theorem compact113_node_3235 : NodeCoverage113 [24,14,14] 14 61 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3236 : NodeCoverage113 [24,14,13] 13 62 :=
  demand_node_prune113 13 compact113_demands_013 compact113_demands_013_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3237 : NodeCoverage113 [24,14,12,12] 12 51 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3238 : NodeCoverage113 [24,14,12,11] 11 52 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3239 : NodeCoverage113 [24,14,12,10] 10 53 :=
  demand_node_prune113 10 compact113_demands_010 compact113_demands_010_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3240 : NodeCoverage113 [24,14,12,9] 9 54 :=
  demand_node_prune113 9 compact113_demands_009 compact113_demands_009_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3241 : NodeCoverage113 [24,14,12,8] 8 55 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3242 : NodeCoverage113 [24,14,12,7] 7 56 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3243 : NodeCoverage113 [24,14,12,6] 6 57 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3244 : NodeCoverage113 [24,14,12,5] 5 58 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3245 : NodeCoverage113 [24,14,12,3] 3 60 :=
  demand_node_prune113 12 compact113_demands_012 compact113_demands_012_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3246 : NodeCoverage113 [24,14,12] 12 63 :=
  node_fork113 (B := [12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3237
    (ChildrenCoverage113.cons _ _ compact113_node_3238
    (ChildrenCoverage113.cons _ _ compact113_node_3239
    (ChildrenCoverage113.cons _ _ compact113_node_3240
    (ChildrenCoverage113.cons _ _ compact113_node_3241
    (ChildrenCoverage113.cons _ _ compact113_node_3242
    (ChildrenCoverage113.cons _ _ compact113_node_3243
    (ChildrenCoverage113.cons _ _ compact113_node_3244
    (ChildrenCoverage113.cons _ _ compact113_node_3245
    ChildrenCoverage113.nil)))))))))

theorem compact113_node_3247 : NodeCoverage113 [24,14,11] 11 64 :=
  demand_node_prune113 11 compact113_demands_011 compact113_demands_011_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3248 : NodeCoverage113 [24,14,10] 10 65 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3249 : NodeCoverage113 [24,14,9] 9 66 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3250 : NodeCoverage113 [24,14,8] 8 67 :=
  demand_node_prune113 8 compact113_demands_008 compact113_demands_008_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3251 : NodeCoverage113 [24,14,7] 7 68 :=
  demand_node_prune113 24 compact113_demands_024 compact113_demands_024_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3252 : NodeCoverage113 [24,14,6] 6 69 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3253 : NodeCoverage113 [24,14,5] 5 70 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3254 : NodeCoverage113 [24,14,3] 3 72 :=
  demand_node_prune113 14 compact113_demands_014 compact113_demands_014_exact
    (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem compact113_node_3255 : NodeCoverage113 [24,14] 14 75 :=
  node_fork113 (B := [14,13,12,11,10,9,8,7,6,5,3]) (by decide +kernel) (by decide +kernel)
    (ChildrenCoverage113.cons _ _ compact113_node_3235
    (ChildrenCoverage113.cons _ _ compact113_node_3236
    (ChildrenCoverage113.cons _ _ compact113_node_3246
    (ChildrenCoverage113.cons _ _ compact113_node_3247
    (ChildrenCoverage113.cons _ _ compact113_node_3248
    (ChildrenCoverage113.cons _ _ compact113_node_3249
    (ChildrenCoverage113.cons _ _ compact113_node_3250
    (ChildrenCoverage113.cons _ _ compact113_node_3251
    (ChildrenCoverage113.cons _ _ compact113_node_3252
    (ChildrenCoverage113.cons _ _ compact113_node_3253
    (ChildrenCoverage113.cons _ _ compact113_node_3254
    ChildrenCoverage113.nil)))))))))))

end Symconf113

import Symconf113.NoRulerCore113

/-! The difference masks after the two root branches that the cover search splits further. -/
namespace Symconf113.Ruler113

def m1a : ℕ := (addDiffs 5 [2,0] m0).getD 0
def m1b : ℕ := (addDiffs 110 [2,0] m0).getD 0

theorem any_range'_split (f : ℕ → Bool) (a n k : ℕ) (h1 : (List.range' a n).any f=false)
    (h2 : (List.range' (a+n) k).any f=false) : (List.range' a (n+k)).any f=false := by
  rw [← List.range'_append_1, List.any_append, h1, h2]; rfl

end Symconf113.Ruler113
